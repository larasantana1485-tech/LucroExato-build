from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
ui = (root/'app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt').read_text()
store = (root/'app/src/main/java/br/com/edivendas/data/SellerStore.kt').read_text()
repo = (root/'app/src/main/java/br/com/edivendas/data/SellerRepository.kt').read_text()
room = (root/'app/src/main/java/br/com/edivendas/data/RoomPersistence.kt').read_text()
codec = (root/'app/src/main/java/br/com/edivendas/data/ExchangeCodec.kt').read_text()
main = (root/'app/src/main/java/br/com/edivendas/MainActivity.kt').read_text()
gradle = (root/'app/build.gradle.kts').read_text()

checks = {
    'versionCode 126': 'versionCode = 126' in gradle,
    'versionName 1.0.26': 'versionName = "1.0.26-piloto"' in gradle,
    'Room dependency': 'androidx.room:room-runtime' in gradle and 'room-compiler' in gradle,
    'Repository UI boundary': 'interface SellerRepository' in repo and 'store: SellerRepository' in ui,
    'Room structured tables': all(x in room for x in ['edi_clients','edi_products','edi_sales','edi_sale_items','edi_batches']),
    'Room fingerprint verification': 'fingerprint(snapshot' in room and 'expected == actual' in room,
    'Room startup off main path': 'thread(start = true, isDaemon = true, name = "EdiRoomInit")' in store,
    'Automatic local safety backup': 'edi_safety_backup.json' in store and 'restoreSafetyBackup' in repo,
    'Money stays integer': 'Math.multiplyExact' in (root/'app/src/main/java/br/com/edivendas/data/Models.kt').read_text() and 'Double' not in (root/'app/src/main/java/br/com/edivendas/data/Models.kt').read_text(),
    'Payment keeps Não/Sim': 'label = "Não"' in ui and 'label = "Sim"' in ui,
    'Payment no default': 'paidOnSpot: Boolean?' in ui and 'Nenhuma opção vem marcada automaticamente.' in ui,
    'Payment card is white': '"Vai pagar agora?"' in ui and 'color = Color.White' in ui[ui.find('"Vai pagar agora?"')-1200:ui.find('"Vai pagar agora?"')+500],
    'Send states honest': all(x in ui for x in ['"A enviar"','"Compartilhada"','"Correção a enviar"']),
    'No Retirar dos envios UI': 'Retirar dos envios' not in ui,
    'No Fora dos envios UI': 'Fora dos envios' not in ui,
    'One main Histórico label': 'label = "Histórico"' in ui and 'Text("Envios anteriores")' in ui,
    'Recent clients': 'Últimos clientes' in ui and 'recentClients(5)' in ui,
    'Prepared batch does not mark sale sent': 'preparar um lote não altera o estado da venda' in store,
    'Cancelled share returns sales': 'dismissBatchConfirmation' in store and 'filterNot { it.batchId == batchId && it.sharedAt == null }' in store,
    'Share confirm is explicit': 'Sim, compartilhei' in main and 'onDismissRequest = { }' in main,
    'Reset blocks pending': 'Há 1 venda que ainda precisa ser compartilhada' in store,
    'Catalog update timestamp visible': 'Dados do Gestão atualizados em' in ui,
    'Expanded batch history limit': 'MAX_BATCHES = 1_000' in store and 'array.length() <= 1_000' in codec,
    'Dead exclusion actions removed': 'fun excludeSaleFromSending' not in store and 'fun restoreSaleToSending' not in store,
    'Price override visible': 'Preço alterado • padrão' in ui,
}

failed=[]
for name, ok in checks.items():
    print(f"{'OK' if ok else 'FAIL'}  {name}")
    if not ok: failed.append(name)
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks OK")
if failed:
    print('Failed:', ', '.join(failed))
    sys.exit(1)

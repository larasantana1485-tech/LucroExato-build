from pathlib import Path

root = Path(__file__).resolve().parents[1]
ui = (root / "app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt").read_text(encoding="utf-8")
build = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    print(("OK  " if ok else "FAIL") + name)

check("R20 versão 119 / 1.0.19", 'versionCode = 119' in build and 'versionName = "1.0.19-piloto"' in build)
check("novo draft não pré-seleciona pagamento", 'paymentChoiceMade = false' in ui)
check("restauração sem campo força nova escolha", 'json.optBoolean("paymentChoiceMade", false)' in ui)
check("estado visual de erro existe", 'showPaymentChoiceError' in ui)
check("LazyColumn possui listState", 'state = listState' in ui)
check("tentativa sem escolha é interceptada", 'if (paidOnSpot == null)' in ui)
check("rola até bloco de pagamento", 'listState.animateScrollToItem(paymentItemIndex)' in ui)
check("mensagem obrigatória correta", 'O cliente vai pagar agora ou não? Escolha Não ou Sim para continuar.' in ui)
check("borda de erro no bloco", 'BrandDanger else BrandPinkSoft' in ui)
check("escolher Não limpa erro", 'showPaymentChoiceError = false; onPaid(false)' in ui)
check("escolher Sim limpa erro", 'showPaymentChoiceError = false; onPaid(true)' in ui)
check("forma de pagamento segue obrigatória", 'Escolha PIX, Dinheiro ou Cartão.' in ui)
check("edição existente continua com escolha válida", 'paymentChoiceMade = true' in ui and 'fun editSale' in ui)
check("R19 Não/Sim mantém ripple recortado", 'heightIn(min = 46.dp).clip(RoundedCornerShape(50)).clickable' in ui)
check("R19 métodos de pagamento mantêm ripple recortado", 'heightIn(min = 44.dp).clip(RoundedCornerShape(20.dp)).clickable' in ui)
check("R19 históricos mantêm ripple recortado", 'heightIn(min = 50.dp).clip(RoundedCornerShape(16.dp)).clickable' in ui)
check("sem conflitos de merge", all(mark not in ui for mark in ('<<<<<<<', '=======', '>>>>>>>')))
check("documentação R20 presente", (root / 'R20_ESCOLHA_PAGAMENTO_OBRIGATORIA.md').exists())

passed = sum(ok for _, ok in checks)
print(f"\nR20_PAYMENT_CHOICE_CHECKS: {passed}/{len(checks)}")
raise SystemExit(0 if passed == len(checks) else 1)

from pathlib import Path

root = Path(__file__).resolve().parents[1]
ui = (root / "app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt").read_text(encoding="utf-8")
build = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
store = (root / "app/src/main/java/br/com/edivendas/data/SellerStore.kt").read_text(encoding="utf-8")

checks = {
    "versão R22": 'versionCode = 121' in build and 'versionName = "1.0.21-piloto"' in build,
    "arquivo edi nomeado internamente": 'BatchShareKind { EDI_FILE }' in ui and 'BatchShareKind.TEXT' not in ui,
    "sem opção visível enviar texto": 'Enviar texto' not in ui,
    "edi segue principal": 'title = "Enviar arquivo .edi"' in ui and 'arquivo .edi é a forma principal' in ui,
    "resumo neutro": 'Text("Neste envio"' in ui and 'color = BrandSurfaceSoft' in ui,
    "resumo sem ícone de enviar": 'if (olderCount > 0) Icons.Default.History else Icons.Default.Send' not in ui,
    "ação retirar dos envios": 'Text("Retirar dos envios"' in ui,
    "confirma retirada": 'Text("Retirar esta venda dos envios?")' in ui,
    "status histórico fora dos envios": '"Fora dos envios" to BrandSurfaceSoft' in ui,
    "restaura pendente": 'Text("Voltar para pendentes")' in ui and 'restoreSaleToSending' in ui,
    "limite 20 preservado": 'allSales.take(20)' in ui,
    "store continua excluindo sem apagar": 'fun excludeSaleFromSending' in store and 'excludedFromSend = true' in store,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("OK  " if ok else "FAIL") + name)
print(f"\n{len(checks)-len(failed)}/{len(checks)} verificações aprovadas")
if failed:
    raise SystemExit("Falhas: " + ", ".join(failed))

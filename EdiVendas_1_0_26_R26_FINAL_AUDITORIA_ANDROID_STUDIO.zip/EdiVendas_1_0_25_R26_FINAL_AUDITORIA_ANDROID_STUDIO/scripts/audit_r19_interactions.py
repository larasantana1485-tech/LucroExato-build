from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
ui = (root / 'app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt').read_text(encoding='utf-8')
build = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')

checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    print(('OK   ' if ok else 'FAIL ') + name)

check('R19 versão 118 / 1.0.18', 'versionCode = 118' in build and 'versionName = "1.0.18-piloto"' in build)
check('import clip presente', 'import androidx.compose.ui.draw.clip' in ui)
check('Não/Sim com ripple recortado', 'heightIn(min = 46.dp).clip(RoundedCornerShape(50)).clickable' in ui)
check('PIX/Dinheiro/Cartão com ripple recortado', 'heightIn(min = 44.dp).clip(RoundedCornerShape(20.dp)).clickable' in ui)
check('Históricos da Home com ripple recortado', 'heightIn(min = 50.dp).clip(RoundedCornerShape(16.dp)).clickable' in ui)
check('Data da venda com ripple recortado', 'fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { openDatePicker() }' in ui)
check('Pendências antigas com ripple recortado', 'fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(enabled = canSend, onClick = onSend)' in ui)
check('Métodos de envio com ripple recortado', 'fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)' in ui)
check('Card de escolha legado recortado', 'heightIn(min = 104.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)' in ui)
check('regra documentada', (root / 'R19_CORRECAO_VISUAL_INTERACOES.md').exists())
check('sem conflito de merge', not re.search(r'^(<<<<<<<|=======|>>>>>>>)', ui, flags=re.M))

passed = sum(ok for _, ok in checks)
print(f'\nR19_INTERACTION_CHECKS: {passed}/{len(checks)}')
raise SystemExit(0 if passed == len(checks) else 1)

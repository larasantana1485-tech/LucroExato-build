from pathlib import Path

root = Path(__file__).resolve().parents[1]
models = (root / "app/src/main/java/br/com/edivendas/data/Models.kt").read_text()
store = (root / "app/src/main/java/br/com/edivendas/data/SellerStore.kt").read_text()
codec = (root / "app/src/main/java/br/com/edivendas/data/ExchangeCodec.kt").read_text()
ui = (root / "app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt").read_text()
build = (root / "app/build.gradle.kts").read_text()

checks = {
    "modelo excludedFromSend": "val excludedFromSend: Boolean = false" in models,
    "serializa excludedFromSend": 'put("excludedFromSend", sale.excludedFromSend)' in codec,
    "backup antigo assume false": 'item.optBoolean("excludedFromSend", false)' in codec,
    "pendentes ignoram excluídas": "!it.excludedFromSend" in store,
    "lote ignora excluídas": ".filter { it.sentRevision < it.revision && !it.cancelled && !it.excludedFromSend }" in store,
    "ação excluir de envio": "fun excludeSaleFromSending" in store,
    "ação restaurar pendente": "fun restoreSaleToSending" in store,
    "reset aplicativo": "fun resetApp()" in store and "prefs.edit().clear().commit()" in store,
    "config mostra versão": 'Text("Versão $appVersion"' in ui,
    "config tem redefinir": 'Text("Redefinir aplicativo"' in ui and 'Text("Redefinir o Edi Vendas?")' in ui,
    "confirma remover pendente": 'Text("Remover dos envios pendentes?")' in ui,
    "histórico restaura": 'Text("Voltar para pendentes")' in ui,
    "status não enviar": '"Não enviar ao Gestão" to BrandSurfaceSoft' in ui,
    "versão R21": 'versionCode = 120' in build and 'versionName = "1.0.20-piloto"' in build,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("OK  " if ok else "FAIL") + name)
print(f"\n{len(checks)-len(failed)}/{len(checks)} verificações aprovadas")
if failed:
    raise SystemExit("Falhas: " + ", ".join(failed))

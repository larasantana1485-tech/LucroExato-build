# Edi Vendas R23 — metadados da origem no arquivo .edi

Base: R22 / 1.0.21-piloto
Nova versão: R23 / 1.0.22-piloto

- O arquivo `.edi` continua usando o mesmo protocolo `[EDI-BATCH-V1]` e permanece compatível.
- O JSON do lote agora inclui, de forma opcional e retrocompatível:
  - `sellerName`;
  - `sellerDeviceName` (`Build.MODEL`).
- O Santana Gestão R102 usa esses dados somente na tela de confirmação da origem.
- Nenhum dado de venda, cálculo, revisão ou identificação técnica foi alterado.

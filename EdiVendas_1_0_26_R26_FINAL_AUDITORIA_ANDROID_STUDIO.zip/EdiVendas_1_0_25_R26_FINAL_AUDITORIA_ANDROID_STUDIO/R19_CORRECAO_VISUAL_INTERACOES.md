# R19 — correção visual das interações arredondadas

Objetivo: eliminar o destaque retangular que aparecia durante o toque em componentes com cantos arredondados.

## Corrigido

- Pills `Não` / `Sim`: feedback de toque agora é recortado no mesmo formato totalmente arredondado da pill.
- Pills `PIX` / `Dinheiro` / `Cartão`: feedback de toque respeita o formato arredondado.
- Atalhos `Histórico completo` e `Histórico de envios`: ripple limitado ao contorno do componente.
- Campo arredondado `Data da venda`: toque respeita os cantos de 14 dp.
- Aviso clicável de pendências antigas na Home: toque respeita os cantos de 16 dp.
- Opções da meia aba de envio (`.edi`, imagem e QR Code): ripple recortado no card de 16 dp.
- Cards de escolha de pagamento legados: recorte consistente preservado para não reintroduzir o bug se voltarem a ser usados.

## Regra visual adotada

Todo componente arredondado que recebe `clickable` deve aplicar o mesmo `Shape` também ao `clip` antes da indicação de toque. Linhas de lista de largura total continuam retangulares por intenção de design.

# Validação R22 — 26/09/2026

## Verificado neste ambiente

- `scripts/audit_r22_send_ux.py`: 12/12 verificações aprovadas.
- Não há opção visível **Enviar texto** na UI.
- O arquivo `.edi` segue como forma principal de registro no Santana Gestão.
- O resumo superior de **Revisar e enviar vendas** não usa mais ícone de envio nem aparência azul de ação.
- A ação agora é **Retirar dos envios**; a venda continua no Histórico completo e pode voltar aos pendentes.
- O estado histórico é **Fora dos envios**.
- O limite de 20 vendas por lote foi preservado.
- O ZIP foi criado sem `build/`, `.gradle/`, `.idea/`, APK ou `local.properties`.

## Compilação Android

A tentativa de compilação Gradle não pôde começar porque o ambiente não consegue resolver `services.gradle.org` para baixar o Gradle 8.13. Isso não é uma falha de compilação do código-fonte.

Antes de instalar em dados reais, abra no Android Studio com internet, execute **Build > Make Project** e teste no aparelho a tela **Revisar e enviar vendas**, o compartilhamento `.edi`, a confirmação ao voltar do WhatsApp e a restauração de uma venda em **Histórico completo > Voltar para pendentes**.

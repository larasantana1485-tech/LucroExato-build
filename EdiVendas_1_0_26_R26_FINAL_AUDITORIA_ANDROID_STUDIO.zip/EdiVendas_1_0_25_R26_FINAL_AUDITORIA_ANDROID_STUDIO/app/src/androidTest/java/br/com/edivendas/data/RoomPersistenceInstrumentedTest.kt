package br.com.edivendas.data

import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class RoomPersistenceInstrumentedTest {
    @Test
    fun replaceAll_roundTripsCommercialData() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val persistence = RoomPersistence(context)
        persistence.clear()
        try {
            val client = SellerClient(name = "Maria", syncId = UUID.randomUUID().toString())
            val product = SellerProduct(UUID.randomUUID().toString(), "Pão de mel", 900L, true)
            val sale = SellerSale(
                externalSaleId = UUID.randomUUID().toString(),
                clientSyncId = client.syncId,
                clientNameSnapshot = client.name,
                productId = product.syncId,
                productNameSnapshot = product.name,
                quantity = 2,
                unitPriceCents = 900L,
                paidOnSpot = false,
                items = listOf(SellerSaleItem(product.syncId, product.name, 2, 900L)),
                receivedCents = 0L,
                displayId = "EDI-20260929-0001",
            )
            val snapshot = RoomSnapshot(listOf(client), listOf(product), listOf(sale), emptyList())

            val expected = persistence.replaceAll(snapshot)
            val loaded = persistence.load()

            assertEquals(expected, persistence.fingerprint(loaded))
            assertEquals(1, loaded.clients.size)
            assertEquals(1, loaded.products.size)
            assertEquals(1, loaded.sales.size)
            assertEquals(1800L, loaded.sales.single().totalCents)
            assertTrue(loaded.sales.single().items.isNotEmpty())
        } finally {
            persistence.clear()
        }
    }

    @Test(expected = IllegalArgumentException::class)
    fun replaceAll_rejectsSaleWhoseClientDoesNotExist() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val persistence = RoomPersistence(context)
        val product = SellerProduct(UUID.randomUUID().toString(), "Pão de mel", 900L, true)
        val sale = SellerSale(
            externalSaleId = UUID.randomUUID().toString(),
            clientSyncId = UUID.randomUUID().toString(),
            clientNameSnapshot = "Cliente ausente",
            productId = product.syncId,
            productNameSnapshot = product.name,
            quantity = 1,
            unitPriceCents = 900L,
            paidOnSpot = false,
            items = listOf(SellerSaleItem(product.syncId, product.name, 1, 900L)),
            receivedCents = 0L,
        )
        persistence.replaceAll(RoomSnapshot(emptyList(), listOf(product), listOf(sale), emptyList()))
    }
}

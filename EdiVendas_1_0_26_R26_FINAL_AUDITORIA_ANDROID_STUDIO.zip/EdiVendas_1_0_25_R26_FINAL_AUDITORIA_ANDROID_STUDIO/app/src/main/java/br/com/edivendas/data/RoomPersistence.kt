package br.com.edivendas.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

@Entity(tableName = "edi_clients")
data class DbClient(
    @androidx.room.PrimaryKey val syncId: String,
    val adminClientId: Long?,
    val externalClientKey: String?,
    val name: String,
    val phone: String,
    val location: String,
    val active: Boolean,
)

@Entity(tableName = "edi_products")
data class DbProduct(
    @androidx.room.PrimaryKey val syncId: String,
    val name: String,
    val unitPriceCents: Long,
    val active: Boolean,
    val sortOrder: Int,
)

@Entity(tableName = "edi_sales")
data class DbSale(
    @androidx.room.PrimaryKey val externalSaleId: String,
    val adminClientId: Long?,
    val externalClientKey: String?,
    val clientNameSnapshot: String,
    val clientPhoneSnapshot: String,
    val clientLocationSnapshot: String,
    val productId: String,
    val productNameSnapshot: String,
    val quantity: Int,
    val unitPriceCents: Long,
    val paidOnSpot: Boolean,
    val paymentMethod: String?,
    val soldAt: Long,
    val batchId: String?,
    val cancelled: Boolean,
    val displayId: String,
    val revision: Int,
    val exportedRevision: Int,
    val sentRevision: Int,
    val excludedFromSend: Boolean,
    val clientSyncId: String,
    val receivedCents: Long,
    val recordedAt: Long,
    val saleTimeKnown: Boolean,
)

@Entity(tableName = "edi_sale_items", primaryKeys = ["saleId", "position"])
data class DbSaleItem(
    val saleId: String,
    val position: Int,
    val productSyncId: String,
    val name: String,
    val quantity: Int,
    val unitPriceCents: Long,
)

@Entity(tableName = "edi_batches")
data class DbBatch(
    @androidx.room.PrimaryKey val batchId: String,
    val schemaVersion: Int,
    val businessId: String,
    val sellerDeviceId: String,
    val sellerName: String,
    val saleDate: String,
    val createdAt: Long,
    val integrity: String,
    val shareStartedAt: Long?,
    val sharedAt: Long?,
)

@Entity(tableName = "edi_batch_sales", primaryKeys = ["batchId", "position"])
data class DbBatchSale(
    val batchId: String,
    val position: Int,
    /** Snapshot congelado da venda no momento do lote. Mantido como JSON versionado porque é histórico imutável. */
    val saleJson: String,
)

@Entity(tableName = "edi_room_meta")
data class DbMeta(
    @androidx.room.PrimaryKey val key: String,
    val value: String,
    val updatedAt: Long,
)

@Dao
interface EdiRoomDao {
    @Query("SELECT * FROM edi_clients ORDER BY name COLLATE NOCASE, syncId")
    fun allClients(): List<DbClient>

    @Query("SELECT * FROM edi_products ORDER BY sortOrder, name COLLATE NOCASE")
    fun allProducts(): List<DbProduct>

    @Query("SELECT * FROM edi_sales ORDER BY soldAt DESC, externalSaleId")
    fun allSales(): List<DbSale>

    @Query("SELECT * FROM edi_sale_items ORDER BY saleId, position")
    fun allSaleItems(): List<DbSaleItem>

    @Query("SELECT * FROM edi_batches ORDER BY createdAt DESC, batchId")
    fun allBatches(): List<DbBatch>

    @Query("SELECT * FROM edi_batch_sales ORDER BY batchId, position")
    fun allBatchSales(): List<DbBatchSale>

    @Query("SELECT * FROM edi_room_meta WHERE `key` = :key LIMIT 1")
    fun meta(key: String): DbMeta?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertClients(items: List<DbClient>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertProducts(items: List<DbProduct>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertSales(items: List<DbSale>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertSaleItems(items: List<DbSaleItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertBatches(items: List<DbBatch>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertBatchSales(items: List<DbBatchSale>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun putMeta(item: DbMeta)

    @Query("DELETE FROM edi_sale_items") fun clearSaleItems()
    @Query("DELETE FROM edi_sales") fun clearSales()
    @Query("DELETE FROM edi_batch_sales") fun clearBatchSales()
    @Query("DELETE FROM edi_batches") fun clearBatches()
    @Query("DELETE FROM edi_products") fun clearProducts()
    @Query("DELETE FROM edi_clients") fun clearClients()
    @Query("DELETE FROM edi_room_meta") fun clearMeta()
}

@Database(
    entities = [DbClient::class, DbProduct::class, DbSale::class, DbSaleItem::class, DbBatch::class, DbBatchSale::class, DbMeta::class],
    version = 1,
    exportSchema = true,
)
abstract class EdiRoomDatabase : RoomDatabase() {
    abstract fun dao(): EdiRoomDao

    companion object {
        @Volatile private var INSTANCE: EdiRoomDatabase? = null
        fun get(context: Context): EdiRoomDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                EdiRoomDatabase::class.java,
                "edi_vendas_room.db",
            ).build().also { INSTANCE = it }
        }
    }
}

data class RoomSnapshot(
    val clients: List<SellerClient>,
    val products: List<SellerProduct>,
    val sales: List<SellerSale>,
    val batches: List<SellerBatch>,
)

/**
 * Banco estruturado do Edi. O JSON antigo fica apenas como espelho de compatibilidade/rollback.
 * Toda troca de conteúdo é transacional e validada por fingerprint antes de o snapshot ser aceito.
 */
class RoomPersistence(context: Context) {
    private val db = EdiRoomDatabase.get(context)
    private val dao = db.dao()

    fun migrationFingerprint(): String? = io { dao.meta(META_FINGERPRINT)?.value }

    fun load(): RoomSnapshot = io {
        val clients = dao.allClients().map { it.toModel() }
        val products = dao.allProducts().map { it.toModel() }
        val itemsBySale = dao.allSaleItems().groupBy { it.saleId }
        val sales = dao.allSales().map { entity ->
            entity.toModel(itemsBySale[entity.externalSaleId].orEmpty().sortedBy { it.position }.map { it.toModel() })
        }
        val frozenByBatch = dao.allBatchSales().groupBy { it.batchId }
        val batches = dao.allBatches().map { entity ->
            entity.toModel(
                frozenByBatch[entity.batchId].orEmpty().sortedBy { it.position }.map { row ->
                    ExchangeCodec.parseSales(row.saleJson).single()
                },
            )
        }
        RoomSnapshot(clients, products, sales, batches).also(::validate)
    }

    fun replaceAll(snapshot: RoomSnapshot): String {
        validate(snapshot)
        val expected = fingerprint(snapshot)
        io {
            db.withTransaction {
                dao.clearSaleItems()
                dao.clearSales()
                dao.clearBatchSales()
                dao.clearBatches()
                dao.clearProducts()
                dao.clearClients()

                if (snapshot.clients.isNotEmpty()) dao.insertClients(snapshot.clients.map { it.toDb() })
                if (snapshot.products.isNotEmpty()) {
                    dao.insertProducts(snapshot.products.mapIndexed { index, product -> product.toDb(index) })
                }
                if (snapshot.sales.isNotEmpty()) {
                    dao.insertSales(snapshot.sales.map { it.toDb() })
                    val itemRows = snapshot.sales.flatMap { sale ->
                        sale.items.ifEmpty {
                            listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents))
                        }.mapIndexed { index, item -> item.toDb(sale.externalSaleId, index) }
                    }
                    if (itemRows.isNotEmpty()) dao.insertSaleItems(itemRows)
                }
                if (snapshot.batches.isNotEmpty()) {
                    dao.insertBatches(snapshot.batches.map { it.toDb() })
                    val frozen = snapshot.batches.flatMap { batch ->
                        batch.sales.mapIndexed { index, sale ->
                            DbBatchSale(batch.batchId, index, ExchangeCodec.salesToJson(listOf(sale)).toString())
                        }
                    }
                    if (frozen.isNotEmpty()) dao.insertBatchSales(frozen)
                }
                dao.putMeta(DbMeta(META_FINGERPRINT, expected, System.currentTimeMillis()))
                dao.putMeta(DbMeta(META_SCHEMA, "1", System.currentTimeMillis()))
            }
        }
        val actual = fingerprint(load())
        check(expected == actual) { "A cópia para o banco estruturado não conferiu com os dados de origem." }
        return expected
    }

    fun clear() = io {
        db.withTransaction {
            dao.clearSaleItems(); dao.clearSales(); dao.clearBatchSales(); dao.clearBatches()
            dao.clearProducts(); dao.clearClients(); dao.clearMeta()
        }
    }

    fun fingerprint(snapshot: RoomSnapshot): String {
        val canonical = buildString {
            append("CLIENTS\n")
            append(ExchangeCodec.clientsToJson(snapshot.clients.sortedBy { it.syncId }))
            append("\nPRODUCTS\n")
            append(JSONArray().apply {
                snapshot.products.forEachIndexed { index, product ->
                    put(JSONObject()
                        .put("i", index)
                        .put("syncId", product.syncId)
                        .put("name", product.name)
                        .put("unitPriceCents", product.unitPriceCents)
                        .put("active", product.active))
                }
            })
            append("\nSALES\n")
            append(ExchangeCodec.salesToJson(snapshot.sales.sortedBy { it.externalSaleId }))
            append("\nBATCHES\n")
            append(ExchangeCodec.batchesToJson(snapshot.batches.sortedBy { it.batchId }))
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    fun validate(snapshot: RoomSnapshot) {
        require(snapshot.clients.map { it.syncId }.distinct().size == snapshot.clients.size) { "Clientes repetidos no banco." }
        require(snapshot.products.map { it.syncId }.distinct().size == snapshot.products.size) { "Produtos repetidos no banco." }
        require(snapshot.sales.map { it.externalSaleId }.distinct().size == snapshot.sales.size) { "Vendas repetidas no banco." }
        require(snapshot.batches.map { it.batchId }.distinct().size == snapshot.batches.size) { "Envios repetidos no banco." }
        val clientIds = snapshot.clients.map { it.syncId }.toSet()
        require(snapshot.sales.all { it.clientSyncId.isNotBlank() && it.clientSyncId in clientIds }) {
            "Existe venda ligada a um cliente que não está no banco."
        }
        snapshot.sales.forEach { sale ->
            val effectiveItems = sale.items.ifEmpty {
                listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents))
            }
            require(effectiveItems.size in 1..20) { "Venda sem itens válidos no banco." }
            require(effectiveItems.distinctBy { it.productSyncId }.size == effectiveItems.size) { "Produto repetido dentro da mesma venda." }
            require(sale.receivedCents in 0L..sale.totalCents) { "Pagamento inválido no banco." }
        }
        val currentById = snapshot.sales.associateBy { it.externalSaleId }
        snapshot.batches.forEach { batch ->
            require(batch.sales.isNotEmpty()) { "Envio vazio no banco." }
            batch.sales.forEach { frozen ->
                val current = currentById[frozen.externalSaleId]
                require(current != null && current.revision >= frozen.revision) { "Histórico de envio não corresponde às vendas salvas." }
            }
        }
    }

    private fun <T> io(block: suspend () -> T): T = runBlocking(Dispatchers.IO) { block() }

    private fun SellerClient.toDb() = DbClient(syncId, adminClientId, externalClientKey, name, phone, location, active)
    private fun DbClient.toModel() = SellerClient(adminClientId, externalClientKey, name, phone, location, active, syncId)

    private fun SellerProduct.toDb(index: Int) = DbProduct(syncId, name, unitPriceCents, active, index)
    private fun DbProduct.toModel() = SellerProduct(syncId, name, unitPriceCents, active)

    private fun SellerSale.toDb() = DbSale(
        externalSaleId, adminClientId, externalClientKey, clientNameSnapshot, clientPhoneSnapshot,
        clientLocationSnapshot, productId, productNameSnapshot, quantity, unitPriceCents, paidOnSpot,
        paymentMethod, soldAt, batchId, cancelled, displayId, revision, exportedRevision, sentRevision,
        excludedFromSend, clientSyncId, receivedCents, recordedAt, saleTimeKnown,
    )

    private fun DbSale.toModel(items: List<SellerSaleItem>) = SellerSale(
        externalSaleId = externalSaleId,
        adminClientId = adminClientId,
        externalClientKey = externalClientKey,
        clientNameSnapshot = clientNameSnapshot,
        clientPhoneSnapshot = clientPhoneSnapshot,
        clientLocationSnapshot = clientLocationSnapshot,
        productId = productId,
        productNameSnapshot = productNameSnapshot,
        quantity = quantity,
        unitPriceCents = unitPriceCents,
        paidOnSpot = paidOnSpot,
        paymentMethod = paymentMethod,
        soldAt = soldAt,
        batchId = batchId,
        cancelled = cancelled,
        displayId = displayId,
        revision = revision,
        exportedRevision = exportedRevision,
        sentRevision = sentRevision,
        excludedFromSend = excludedFromSend,
        clientSyncId = clientSyncId,
        items = items,
        receivedCents = receivedCents,
        recordedAt = recordedAt,
        saleTimeKnown = saleTimeKnown,
    )

    private fun SellerSaleItem.toDb(saleId: String, position: Int) = DbSaleItem(saleId, position, productSyncId, name, quantity, unitPriceCents)
    private fun DbSaleItem.toModel() = SellerSaleItem(productSyncId, name, quantity, unitPriceCents)

    private fun SellerBatch.toDb() = DbBatch(batchId, schemaVersion, businessId, sellerDeviceId, sellerName, saleDate, createdAt, integrity, shareStartedAt, sharedAt)
    private fun DbBatch.toModel(sales: List<SellerSale>) = SellerBatch(schemaVersion, batchId, businessId, sellerDeviceId, sellerName, saleDate, createdAt, sales, integrity, shareStartedAt, sharedAt)

    companion object {
        private const val META_FINGERPRINT = "legacy_room_fingerprint_v1"
        private const val META_SCHEMA = "room_data_schema"
    }
}

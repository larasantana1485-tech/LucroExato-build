package br.com.edivendas.data

import android.net.Uri
import java.io.File
import java.time.LocalDate

/** Contrato entre a interface e os dados. A UI não precisa conhecer Room nem o espelho legado. */
interface SellerRepository {
    fun isConfigured(): Boolean
    fun needsRecovery(): Boolean
    fun isLinkedToSantana(): Boolean
    fun exportBackup(): String
    fun previewBackup(text: String): SellerBackupPreview
    fun markBackupSaved()
    fun lastBackupAt(): Long?
    fun importBackup(text: String)
    fun importCatalog(text: String): BaseImportResult
    fun products(): List<SellerProduct>
    fun config(): SellerConfig?
    fun saveInitialConfig(sellerName: String, productName: String, unitPriceCents: Long)
    fun updateConfig(sellerName: String, productName: String, unitPriceCents: Long)
    fun sellerDeviceId(): String
    fun clients(): List<SellerClient>
    fun recentClients(limit: Int = 5): List<SellerClient>
    fun addClient(name: String, phone: String, location: String): SellerClient
    fun similarClients(name: String): List<SellerClient>
    fun sales(): List<SellerSale>
    fun localSales(): List<SellerSale>
    fun localSales(saleDate: LocalDate): List<SellerSale>
    fun salesForDate(saleDate: LocalDate): List<SellerSale>
    fun saveSale(sale: SellerSale): SellerSale
    fun deleteSale(externalSaleId: String)
    fun batches(): List<SellerBatch>
    fun createBatch(persistForSending: Boolean = true): SellerBatch
    fun markBatchShareStarted(batchId: String): SellerBatch
    fun pendingBatchConfirmation(): SellerBatch?
    fun dismissBatchConfirmation(batchId: String)
    fun confirmBatchSent(batch: SellerBatch)
    fun exportSaleReceiptImage(sale: SellerSale): File
    fun exportBatchSummaryImages(batch: SellerBatch): List<File>
    fun exportBatchFile(batch: SellerBatch): File
    fun uriFor(file: File): Uri
    fun resetApp()
    fun hasPreRestoreBackup(): Boolean
    fun draftState(): String?
    fun saveDraftState(json: String)
    fun clearDraftState()
    fun restorePreRestoreBackup()
    fun hasSafetyBackup(): Boolean
    fun restoreSafetyBackup()
    fun lastSafetyBackupAt(): Long?
    fun dataWarning(): String?
    fun roomStatus(): String
}

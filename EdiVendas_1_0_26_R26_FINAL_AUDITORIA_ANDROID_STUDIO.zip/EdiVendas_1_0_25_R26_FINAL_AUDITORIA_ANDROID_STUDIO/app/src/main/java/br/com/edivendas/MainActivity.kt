package br.com.edivendas

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import br.com.edivendas.data.SellerBatch
import br.com.edivendas.data.ExchangeCodec
import br.com.edivendas.data.SellerSale
import br.com.edivendas.data.SellerRepository
import br.com.edivendas.data.SellerStore
import br.com.edivendas.ui.BatchShareKind
import br.com.edivendas.ui.EdiVendasApp
import br.com.edivendas.ui.EdiVendasTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue

class MainActivity : ComponentActivity() {
    private lateinit var store: SellerRepository
    private var awaitingConfirmation: SellerBatch? = null
    private var confirmVisible by mutableStateOf(false)
    private var changed by mutableStateOf(0)

    override fun onResume() {
        super.onResume()
        changed += 1
        if (::store.isInitialized) {
            awaitingConfirmation = store.pendingBatchConfirmation() ?: awaitingConfirmation
        }
        if (awaitingConfirmation != null) confirmVisible = true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SellerStore(this)
        awaitingConfirmation = store.pendingBatchConfirmation()
        setContent {
            EdiVendasTheme {
                EdiVendasApp(
                    store = store,
                    onShareBatch = ::shareBatch,
                    onShareBatchSummary = ::shareBatchSummary,
                    onShareReceipt = ::shareReceipt,
                    externalRevision = changed,
                )
                if (confirmVisible) AlertDialog(
                    // Voltar ou tocar fora não decide pelo usuário: a confirmação continua pendente.
                    onDismissRequest = { },
                    title = { Text("Você conseguiu compartilhar as vendas?") },
                    text = {
                        val batch = awaitingConfirmation
                        val details = if (batch == null) "" else
                            "${batch.sales.size} ${if (batch.sales.size == 1) "venda" else "vendas"} • ${ExchangeCodec.formatCents(batch.totalCents)}\n\n"
                        Text(
                            details +
                                "Confirme somente se o arquivo terminou de enviar no aplicativo escolhido. " +
                                "Isso confirma o compartilhamento deste celular; o Santana Gestão ainda fará a conferência ao importar."
                        )
                    },
                    confirmButton = { TextButton(onClick = {
                        val batch = awaitingConfirmation ?: return@TextButton
                        try {
                            store.confirmBatchSent(batch)
                            changed += 1
                            confirmVisible = false
                            awaitingConfirmation = null
                            Toast.makeText(this@MainActivity, "Vendas marcadas como compartilhadas.", Toast.LENGTH_SHORT).show()
                        }
                        catch (error: Exception) { Toast.makeText(this@MainActivity, error.message, Toast.LENGTH_LONG).show() }
                    }) { Text("Sim, compartilhei") } },
                    dismissButton = { TextButton(onClick = {
                        val batch = awaitingConfirmation
                        try {
                            batch?.let { store.dismissBatchConfirmation(it.batchId) }
                            awaitingConfirmation = null
                            confirmVisible = false
                            changed += 1
                            Toast.makeText(this@MainActivity, "As vendas continuam a enviar.", Toast.LENGTH_SHORT).show()
                        } catch (error: Exception) {
                            Toast.makeText(this@MainActivity, error.message, Toast.LENGTH_LONG).show()
                        }
                    }) { Text("Ainda não") } },
                )
            }
        }
    }

    private fun shareBatch(batch: SellerBatch, kind: BatchShareKind) {
        lifecycleScope.launch {
            try {
                val trackedBatch = withContext(Dispatchers.IO) {
                    store.markBatchShareStarted(batch.batchId)
                    val file = store.exportBatchFile(batch)
                    store.uriFor(file) to store.pendingBatchConfirmation()
                }
                val uri = trackedBatch.first
                awaitingConfirmation = trackedBatch.second ?: batch
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "application/octet-stream"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, "Arquivo do Edi Vendas com ${batch.sales.size} venda(s). Abra no Santana Gestão.")
                    clipData = android.content.ClipData.newUri(contentResolver, "Arquivo de vendas do Edi", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(share, "Enviar vendas")
                startActivity(chooser)
            } catch (error: Exception) {
                runCatching { store.dismissBatchConfirmation(batch.batchId) }
                awaitingConfirmation = null
                confirmVisible = false
                changed += 1
                Toast.makeText(
                    this@MainActivity,
                    error.message ?: "Não foi possível abrir o compartilhamento. As vendas continuam a enviar.",
                    Toast.LENGTH_LONG,
                ).show()
            }
        }
    }

    private fun shareReceipt(sale: SellerSale) {
        lifecycleScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) { store.uriFor(store.exportSaleReceiptImage(sale)) }
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    clipData = android.content.ClipData.newUri(contentResolver, "Comprovante Edi Vendas", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(intent, "Enviar comprovante ao cliente"))
            } catch (error: Exception) {
                Toast.makeText(this@MainActivity, error.message ?: "Não foi possível criar o comprovante.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareBatchSummary(batch: SellerBatch) {
        lifecycleScope.launch {
            try {
                val uris = withContext(Dispatchers.IO) { store.exportBatchSummaryImages(batch).map(store::uriFor) }
                val intent = if (uris.size == 1) {
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/png"
                        putExtra(Intent.EXTRA_STREAM, uris.first())
                        clipData = android.content.ClipData.newUri(contentResolver, "Resumo visual do lote Edi Vendas", uris.first())
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                } else {
                    Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                        type = "image/png"
                        putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                        clipData = android.content.ClipData.newUri(contentResolver, "Resumo visual do lote Edi Vendas", uris.first()).also { clip ->
                            uris.drop(1).forEach { clip.addItem(android.content.ClipData.Item(it)) }
                        }
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                }
                startActivity(Intent.createChooser(intent, "Compartilhar resumo visual"))
            } catch (error: Exception) {
                Toast.makeText(this@MainActivity, error.message ?: "Não foi possível criar o resumo visual.", Toast.LENGTH_LONG).show()
            }
        }
    }
}

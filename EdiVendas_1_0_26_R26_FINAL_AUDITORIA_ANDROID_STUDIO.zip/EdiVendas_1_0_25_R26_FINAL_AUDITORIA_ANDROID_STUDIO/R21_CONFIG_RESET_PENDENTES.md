# R21 — Configurações, redefinição e controle de pendências

## Implementado

- Configurações agora mostra a versão instalada do Edi Vendas.
- Nova ação **Redefinir aplicativo**, com confirmação destrutiva e aviso para fazer backup.
- Redefinição limpa configurações, catálogo importado, clientes, vendas, histórico de envios, rascunhos e arquivos temporários do Edi.
- Vendas pendentes agora podem ser removidas dos próximos envios sem serem apagadas do histórico.
- Estado local `excludedFromSend` é persistido e incluído no backup.
- Vendas removidas deixam de entrar nos contadores da Home, na tela Revisar e enviar e na criação de novos lotes.
- Histórico completo identifica essas vendas como **Não enviar ao Gestão**.
- No Histórico completo há a ação **Voltar para pendentes**, sem perda da venda.
- A exclusão de envio exige confirmação e explica que a venda continua no histórico.

## Regras preservadas

- Vendas realmente enviadas continuam com status **Enviado**.
- Correções continuam usando **Corrigida — reenviar** quando aplicável.
- Remover dos pendentes não apaga a venda nem altera seus valores financeiros.
- Recolocar em pendentes não cria duplicata; apenas reativa a venda para o próximo lote.
- Backups antigos continuam legíveis: vendas sem `excludedFromSend` assumem `false`.

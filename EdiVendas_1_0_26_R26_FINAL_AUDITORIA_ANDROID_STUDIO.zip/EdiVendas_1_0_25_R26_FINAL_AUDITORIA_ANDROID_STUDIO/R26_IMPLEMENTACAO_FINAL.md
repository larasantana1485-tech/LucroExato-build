# Edi Vendas 1.0.26 — R26 — Implementação final da auditoria

Base funcional: R25.

## Decisão de produto

O aplicativo foi **evoluído**, não reconstruído. O núcleo já confiável — UUID por venda, `revision`, valores em centavos, protocolo `.edi`, rascunho, backup e integração offline — foi mantido. A reforma concentrou-se na persistência, estados verdadeiros, recuperação, simplificação e UX.

## Persistência e segurança

1. Room 2.8.5 com tabelas de clientes, produtos, vendas, itens, lotes e metadados.
2. Cópia inicial SharedPreferences/JSON → Room com validação antes da troca.
3. Fingerprint SHA-256 da origem e do banco lido de volta.
4. Se qualquer conferência falhar, `roomSnapshot` é desativado e o legado continua sendo usado.
5. O espelho legado continua sendo escrito para rollback e para o mecanismo de backup Android já existente.
6. A inicialização do Room ocorre em thread dedicada; a primeira tela pode abrir usando o legado enquanto a conferência termina.
7. Cópia automática local interna (`edi_safety_backup.json`) após mudanças importantes, além do backup manual.
8. Restauração de backup preserva o maior contador de `displayId` já usado no aparelho.
9. `fallbackToDestructiveMigration()` não é usado.

## Arquitetura

- `SellerRepository`: contrato usado pela UI/MainActivity.
- `SellerStore`: implementação e compatibilidade com o formato antigo.
- `RoomPersistence`: persistência estruturada e validação transacional.
- A UI não precisa conhecer Room.

## UX aprovada nesta rodada

- Home branca e compacta; um Histórico principal.
- `Envios anteriores` em Configurações.
- Últimos clientes + A–Z + busca.
- Pagamento: **Não / Sim**, obrigatório, nada pré-marcado.
- Card de pagamento branco; sem preenchimento rosa-claro.
- PIX/Dinheiro/Cartão só aparecem após `Sim`.
- Preço diferente do catálogo fica identificado como `Preço alterado`.
- Status: `A enviar`, `Compartilhada`, `Correção a enviar`.
- QR e resumo visual ficam em `Outras formas de enviar`.

## Envio e recuperação

- Criar lote não altera `sentRevision` nem `exportedRevision` da venda.
- Somente confirmação explícita da usuária marca a revisão como compartilhada.
- `Ainda não` remove o lote ainda não confirmado e devolve as vendas à fila.
- Fechar o app depois de iniciar o compartilhamento mantém a confirmação pendente.
- Tocar fora/Voltar no diálogo não decide por Dika.
- Preparações abandonadas antes de abrir o compartilhamento são eliminadas ao gerar o próximo lote.

## Não entrou no Edi

- estoque;
- contas a receber e baixa posterior;
- pagamento parcial novo;
- parcelamento;
- dashboard financeiro;
- lucro/despesas;
- relatórios administrativos;
- backend/login/Firebase.

Essas funções permanecem no Santana Gestão.

## Validação executada

- `python scripts/audit_r26_final.py`: **25/25 OK**.
- balanceamento de chaves/parênteses dos fontes Kotlin: OK.
- parser Kotlin sem erros sintáticos; referências Android ficam sem resolução fora do Gradle, como esperado.
- tentativa real de `./gradlew testDebugUnitTest`: bloqueada antes do build por DNS de `services.gradle.org`.

### Obrigatório antes de usar com dados reais

Abrir no Android Studio ou no pipeline GitHub com internet, executar:

```text
./gradlew testDebugUnitTest connectedDebugAndroidTest assembleDebug
```

e instalar primeiro em aparelho de teste, conferindo migração, venda, fechamento/reabertura, envio cancelado, envio confirmado, backup e restauração.

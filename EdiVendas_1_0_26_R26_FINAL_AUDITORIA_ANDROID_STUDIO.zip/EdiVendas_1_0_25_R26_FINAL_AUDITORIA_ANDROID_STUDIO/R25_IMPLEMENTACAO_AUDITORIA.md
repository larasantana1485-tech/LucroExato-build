# Edi Vendas 1.0.24 — R25 — Implementação da auditoria (Fase 1)

> **Nota:** documento histórico da R25. Na R26, por decisão final do Ricardo, a escolha de pagamento voltou para **Não / Sim**, sem pré-seleção e com o card branco (sem fundo rosa-claro).

Base: R24 / versionCode 123.
Nova versão: 1.0.24-piloto / versionCode 124.

## Implementado nesta fase

- Estado de envio corrigido: preparar um lote não marca mais a venda como exportada/compartilhada.
- Se o seletor de compartilhamento for cancelado ou a usuária escolher “Ainda não”, o lote pendente é descartado e a venda volta ao fluxo normal, editável e excluível.
- Confirmação de compartilhamento não pode mais ser decidida acidentalmente tocando fora/Voltar.
- A confirmação mostra quantidade e valor do lote e usa “Sim, compartilhei / Ainda não”.
- Status visíveis: “A enviar”, “Compartilhada”, “Correção a enviar”.
- “Retirar dos envios / Fora dos envios” removidos da experiência normal; vendas legadas nessa condição voltam para a fila ao serem salvas.
- Home simplificada para um único “Histórico”; histórico técnico de envios movido para Configurações > Envios anteriores.
- Envio principal direto por arquivo com botão “Enviar para o Gestão”; imagem e QR ficam em “Outras formas de enviar”.
- Lista de clientes ganhou “Últimos clientes” (até 5), mantendo A–Z e busca.
- Pagamento renomeado para “Ainda não / Já recebi”, obrigatório e sem pré-seleção.
- Retomada de rascunho ganhou contexto de cliente/valor e atalho na Home.
- Voltar da escolha de clientes com rascunho não descarta mais silenciosamente a venda.
- Restauração de backup não permite reduzir a sequência visível abaixo do maior valor já usado no aparelho.
- Configurações mostram data da última atualização do catálogo.
- Comprovante ao cliente foi simplificado e não exibe revisão/código técnico no corpo.
- Áreas de toque principais foram mantidas em pelo menos 48dp nos controles revisados.

## Ainda não feito nesta fase

- Migração de SharedPreferences/JSON para Room/DataStore. Esta será uma fase separada porque mexe na fundação dos dados e exige migração verificável sem perda.
- Confirmação de importação vinda do Santana Gestão (ACK). Enquanto não existir, o Edi usa “Compartilhada”, nunca “Registrada no Gestão”.
- Refatoração completa do EdiVendasApp.kt em ViewModels/Repository.
- Testes instrumentados completos Edi ↔ Gestão.

## Regra de segurança adotada

O Edi só afirma aquilo que sabe: ele sabe que a usuária compartilhou o arquivo, mas não sabe que o Santana Gestão o importou. Por isso o estado final local desta fase é “Compartilhada”.

# R20 — escolha de pagamento obrigatória

## Objetivo
Evitar que uma venda seja registrada como pendente ou paga na hora por esquecimento. A vendedora precisa escolher conscientemente **Não** ou **Sim** em “Vai pagar agora?”.

## Comportamento implementado
- Nova venda inicia sem `Não` ou `Sim` pré-selecionado.
- O botão **Revisar venda** continua disponível quando há produto, mas não avança se a escolha de pagamento ainda não foi feita.
- Ao tentar avançar sem escolher, a tela rola até o bloco **Vai pagar agora?**.
- O bloco recebe borda de erro e destaque visual.
- É exibida a mensagem: **“O cliente vai pagar agora ou não? Escolha Não ou Sim para continuar.”**
- Ao tocar em `Não` ou `Sim`, o erro some imediatamente.
- Se `Sim` for escolhido, a forma de pagamento (`PIX`, `Dinheiro` ou `Cartão`) continua obrigatória.
- Ao editar uma venda já existente, o estado de pagamento salvo é carregado normalmente.

## Compatibilidade
- R19 e suas correções visuais foram preservadas.
- R20: `versionCode 119`, `versionName 1.0.19-piloto`.

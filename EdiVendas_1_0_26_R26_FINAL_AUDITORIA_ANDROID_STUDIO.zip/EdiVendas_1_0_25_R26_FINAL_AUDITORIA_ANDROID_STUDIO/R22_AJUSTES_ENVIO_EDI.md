# R22 — Ajustes de envio .edi e clareza da revisão

Data: 26/09/2026

## Objetivo

Reduzir ambiguidade na tela **Revisar e enviar vendas** sem aumentar o fluxo. O arquivo `.edi` continua sendo a via principal para o Santana Gestão.

## Alterações

1. **Resumo do lote não parece botão**
   - fundo neutro;
   - sem ícone de avião/enviar;
   - mostra apenas “Neste envio”, quantidade, total e aviso discreto sobre vendas de dias anteriores.

2. **Retirar venda dos envios**
   - “Não enviar ao Gestão” saiu da lista de revisão;
   - a ação agora é **Retirar dos envios**;
   - confirmação explica que a venda continua no Histórico completo e ficará fora deste e dos próximos lotes;
   - o estado no histórico é **Fora dos envios**;
   - **Voltar para pendentes** continua disponível.

3. **Arquivo .edi como principal**
   - o menu de envio declara o `.edi` como forma principal de registro;
   - não existe opção visível de “Enviar texto”;
   - o texto estruturado permanece somente dentro do `.edi`/QR como implementação do protocolo;
   - imagem e QR permanecem como opções auxiliares.

4. **Limite do lote**
   - mantido em 20 vendas nesta rodada;
   - excedentes continuam pendentes para o próximo envio;
   - não foi elevado enquanto o fluxo real de recebimento no Santana Gestão ainda está em validação.

## Regras preservadas

- retirar dos envios não apaga nem altera a venda;
- venda retirada não entra nos contadores de pendentes nem em novos lotes;
- reativar não cria duplicata;
- envio do `.edi` continua exigindo confirmação humana ao retornar do compartilhamento;
- abrir o compartilhamento não significa que o Gestão importou as vendas.

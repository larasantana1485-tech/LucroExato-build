package br.com.lucroexato.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Paid
import androidx.compose.material.icons.outlined.PieChartOutline
import androidx.compose.material.icons.outlined.Print
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.CostCalculator
import br.com.lucroexato.domain.CostInput
import br.com.lucroexato.domain.CostResult
import br.com.lucroexato.domain.ExtraCostInput
import br.com.lucroexato.domain.IngredientCostInput
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import br.com.lucroexato.ui.theme.PinkDark
import br.com.lucroexato.ui.theme.PinkSoft
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToLong

private val DetailBackground = Color(0xFFFAF8F5)
private val DetailSurface = Color(0xFFFFFFFF)
private val DetailText = Color(0xFF1F1F22)
private val DetailSecondary = Color(0xFF6E6A73)
private val DetailMuted = Color(0xFF9B96A0)
private val DetailDivider = Color(0xFFECE7E2)
private val DetailGraySoft = Color(0xFFF6F4F2)
private val DetailWarning = Color(0xFFF2C94C)
private val DetailWarningSoft = Color(0xFFFFF4CC)
private val DetailPositiveSoft = Color(0xFFE8F6EF)
private val DetailIcon = Color(0xFF5C5B66)
private val DetailCardShape = RoundedCornerShape(16.dp)
private val DetailFieldShape = RoundedCornerShape(14.dp)

private enum class OfficialQuickMode { MARGIN, MARKUP }

@Composable
fun RecipeDetailScreen(
    modifier: Modifier,
    vm: AppViewModel,
    recipeId: Long,
    onBack: () -> Unit,
    onEditSection: (Int) -> Unit,
    onEditPreparation: () -> Unit,
    onSimulate: () -> Unit
) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val item = recipes.firstOrNull { it.recipe.id == recipeId }
    val listState = rememberLazyListState()
    var expandedSection by remember(recipeId) { mutableStateOf("") }
    var compositionExpanded by remember(recipeId) { mutableStateOf(false) }
    var showAllIngredients by remember(recipeId) { mutableStateOf(false) }
    var showScaledQuantitiesScreen by remember(recipeId) { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    val context = LocalContext.current

    LaunchedEffect(recipeId) { vm.refreshRecipe(recipeId) }

    if (item == null) {
        Column(modifier.fillMaxSize().background(DetailBackground)) {
            CompactTopBar("Receita", onBack)
            Text("Receita não encontrada.", Modifier.padding(16.dp))
        }
        return
    }

    var salePriceText by remember(recipeId) { mutableStateOf(moneyInput(item.recipe.salePricePerUnitCents)) }
    val enteredSalePrice = parseMoneyCents(salePriceText)?.takeIf { it > 0 }
    val actualResult = enteredSalePrice?.let { price ->
        runCatching { CostCalculator.calculate(item.toOfficialCostInput(chosenSalePriceCents = price)) }.getOrNull()
    }
    val costStructureResult = runCatching {
        CostCalculator.calculate(item.toOfficialCostInput(chosenSalePriceCents = null))
    }.getOrNull()

    val initialQuickMode = if (item.recipe.pricingMode == "MARKUP") OfficialQuickMode.MARKUP else OfficialQuickMode.MARGIN
    val savedPriceResult = remember(recipeId, item.recipe.salePricePerUnitCents, item.recipe.totalCostCents) {
        runCatching {
            CostCalculator.calculate(item.toOfficialCostInput(chosenSalePriceCents = item.recipe.salePricePerUnitCents.coerceAtLeast(1L)))
        }.getOrNull()
    }
    val storedTargetStillMatchesPrice = remember(
        recipeId,
        item.recipe.salePricePerUnitCents,
        item.recipe.totalCostCents,
        item.recipe.targetPercent,
        item.recipe.pricingMode
    ) {
        runCatching {
            CostCalculator.calculate(
                item.toOfficialCostInput(
                    chosenSalePriceCents = null,
                    targetPercent = item.recipe.targetPercent,
                    pricingMode = item.recipe.pricingMode
                )
            ).suggestedPriceCents == item.recipe.salePricePerUnitCents
        }.getOrDefault(false)
    }
    val initialQuickTarget = remember(
        recipeId,
        item.recipe.salePricePerUnitCents,
        item.recipe.totalCostCents,
        item.recipe.priceMode,
        item.recipe.pricingMode,
        item.recipe.targetPercent,
        storedTargetStillMatchesPrice
    ) {
        if (item.recipe.priceMode == "MANUAL" && !storedTargetStillMatchesPrice && savedPriceResult != null) {
            if (initialQuickMode == OfficialQuickMode.MARGIN) savedPriceResult.marginPercent else savedPriceResult.markupPercent
        } else item.recipe.targetPercent
    }
    var quickMode by remember(recipeId) { mutableStateOf(initialQuickMode) }
    var quickTargetText by remember(recipeId) { mutableStateOf(number(initialQuickTarget)) }
    val quickTarget = parseDecimal(quickTargetText) ?: initialQuickTarget

    LaunchedEffect(salePriceText, quickMode, quickTargetText, item.recipe.salePricePerUnitCents) {
        val cents = parseMoneyCents(salePriceText)?.takeIf { it > 0 } ?: return@LaunchedEffect
        val target = parseDecimal(quickTargetText)
        val validTarget = target != null && target >= 0.0 &&
            (quickMode != OfficialQuickMode.MARGIN || target < 100.0)
        if (cents != item.recipe.salePricePerUnitCents ||
            (validTarget && (item.recipe.pricingMode != (if (quickMode == OfficialQuickMode.MARGIN) "MARGIN" else "MARKUP") || kotlin.math.abs(item.recipe.targetPercent - target!!) > 0.0001))
        ) {
            delay(650)
            if (parseMoneyCents(salePriceText) == cents) {
                vm.updateRecipeSalePrice(
                    id = recipeId,
                    salePriceCents = cents,
                    pricingMode = if (validTarget) if (quickMode == OfficialQuickMode.MARGIN) "MARGIN" else "MARKUP" else null,
                    targetPercent = if (validTarget) target else null
                )
            }
        }
    }

    fun adjustedPrice(mode: OfficialQuickMode, rawTarget: String): Long? {
        val target = parseDecimal(rawTarget) ?: return null
        if (target < 0.0 || (mode == OfficialQuickMode.MARGIN && target >= 100.0)) return null
        return runCatching {
            CostCalculator.calculate(
                item.toOfficialCostInput(
                    targetPercent = target,
                    chosenSalePriceCents = null,
                    pricingMode = if (mode == OfficialQuickMode.MARGIN) "MARGIN" else "MARKUP"
                )
            ).suggestedPriceCents
        }.getOrNull()
    }

    fun applyAdjustment(mode: OfficialQuickMode, value: String) {
        quickMode = mode
        quickTargetText = value
        adjustedPrice(mode, value)?.let { salePriceText = moneyInput(it) }
    }

    val sellableYield = costStructureResult?.sellableYield ?: item.recipe.yieldQuantity
    var desiredYieldText by remember(recipeId, sellableYield) { mutableStateOf(number(sellableYield)) }
    val desiredYield = (parseDecimal(desiredYieldText) ?: sellableYield).coerceAtLeast(0.01)
    val scale = if (sellableYield > 0.0) desiredYield / sellableYield else 1.0
    val scaledTotalCostCents = ((costStructureResult?.totalCostCents ?: item.recipe.totalCostCents).toDouble() * scale).roundToLong()
    val feeTotal = actualResult?.let { (it.feeExactCents * it.sellableYield).roundToLong() } ?: 0L
    val additionalTotal = (costStructureResult?.packagingCents ?: 0L) +
        (costStructureResult?.laborCents ?: 0L) +
        (costStructureResult?.extrasCents ?: 0L) + feeTotal
    val additionalSummaryLabel = buildList {
        if ((costStructureResult?.packagingCents ?: 0L) > 0L) add("Embalagem")
        if ((costStructureResult?.laborCents ?: 0L) > 0L) add("Mão de obra")
        if ((costStructureResult?.extrasCents ?: 0L) > 0L) add("Outros")
        if (feeTotal > 0L) add("Taxas")
    }.let { parts -> if (parts.isEmpty()) "Mão de obra e taxas" else parts.joinToString(", ") }
    val catalogById = catalog.associateBy { it.id }
    val suspiciousPackaging = item.ingredients.filter { used ->
        val category = used.ingredientId?.let { catalogById[it]?.category }.orEmpty()
        isPackagingUsed(used.nameSnapshot, category) &&
            used.unit.equals("un", ignoreCase = true) &&
            used.quantityUsed <= 1.000001 && sellableYield >= 4.0
    }
    val hasPackaging = hasPackagingSupplyOfficial(item, catalog)
    val missingLabor = item.recipe.laborMinutes == 0 || item.recipe.hourlyRateCents == 0L
    val reviewBanner = when {
        suspiciousPackaging.isNotEmpty() -> "Confira as embalagens" to "INSUMOS"
        !hasPackaging -> "Confira a embalagem" to "INSUMOS"
        missingLabor -> "Confira a mão de obra" to "CUSTOS"
        else -> null
    }

    val warningSignature = reviewBanner?.let { "${it.second}_${it.first}" }
    var warningDismissed by remember(recipeId, warningSignature) {
        mutableStateOf(warningSignature?.let { vm.isRecipeWarningDismissed(recipeId, it) } == true)
    }
    val visibleReviewBanner = reviewBanner?.takeUnless { warningDismissed }

    // O cabeçalho da receita agora fica fora da lista e permanece estável no topo,
    // igual ao comportamento aprovado no mockup interativo 2. Como ele não participa
    // mais dos itens roláveis, o card de preço passa a ser 0 (ou 1 quando há aviso).
    val priceCardIndex = if (visibleReviewBanner != null) 1 else 0
    LaunchedEffect(expandedSection, visibleReviewBanner?.first) {
        val index = when (expandedSection) {
            "INSUMOS" -> priceCardIndex + 1
            "RENDIMENTO" -> priceCardIndex + 2
            "CUSTOS" -> priceCardIndex + 3
            else -> null
        } ?: return@LaunchedEffect

        // Primeiro deixa a expansão terminar. Só reposiciona se o cabeçalho não estiver
        // realmente visível; isso elimina o efeito de "chicote" causado por rolar
        // enquanto o card ainda cresce.
        delay(380)
        val visible = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
        if (visible == null || visible.offset < listState.layoutInfo.viewportStartOffset) {
            listState.animateScrollToItem(index)
        }
    }

    // A R14 usava AnimatedVisibility acima da LazyColumn. Isso alterava a altura
    // disponível da lista durante expand/shrink e empurrava todo o conteúdo, criando
    // o "tranco" visto no vídeo. Agora o resumo é uma camada sobre a lista: não muda
    // a geometria do scroll. O progresso acompanha a posição real do card de preço,
    // fazendo o resumo surgir suavemente enquanto os últimos pixels do card saem.
    val density = androidx.compose.ui.platform.LocalDensity.current
    val stickyRevealDistancePx = with(density) { 56.dp.toPx() }
    val stickyLiftPx = with(density) { 8.dp.toPx() }
    val stickyProgress by remember(priceCardIndex, stickyRevealDistancePx) {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val priceInfo = layoutInfo.visibleItemsInfo.firstOrNull { it.index == priceCardIndex }
            when {
                priceInfo != null -> {
                    val cardBottom = (priceInfo.offset + priceInfo.size - layoutInfo.viewportStartOffset).toFloat()
                    ((stickyRevealDistancePx - cardBottom) / stickyRevealDistancePx).coerceIn(0f, 1f)
                }
                listState.firstVisibleItemIndex > priceCardIndex -> 1f
                else -> 0f
            }
        }
    }

    Column(modifier.fillMaxSize().background(DetailBackground)) {
        // Cabeçalho fixo, com fundo próprio e divisor discreto. O conteúdo rola abaixo
        // dele em vez de levar o nome e as ações embora.
        Surface(color = DetailBackground, tonalElevation = 0.dp, shadowElevation = 0.dp) {
            Column {
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    RecipeOfficialHeader(
                        item = item,
                        onBack = onBack,
                        onEdit = { onEditSection(1) },
                        onPrint = { actualResult?.let { result -> printRecipe(context, item, result) } },
                        onInfo = { showInfo = true }
                    )
                }
                HorizontalDivider(color = DetailDivider)
            }
        }

        Box(Modifier.fillMaxWidth().weight(1f)) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().imePadding(),
                contentPadding = PaddingValues(start = 16.dp, top = 10.dp, end = 16.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {

        visibleReviewBanner?.let { (text, section) ->
            item {
                CostReviewBanner(
                    text = text,
                    onClick = {
                        if (section == "INSUMOS") showAllIngredients = true
                        expandedSection = section
                    },
                    onDismiss = {
                        warningSignature?.let { vm.dismissRecipeWarning(recipeId, it) }
                        warningDismissed = true
                    }
                )
            }
        }

        item {
            PriceProfitOfficialCard(
                item = item,
                catalog = catalog,
                costResult = costStructureResult,
                actualResult = actualResult,
                salePriceText = salePriceText,
                onSalePriceChange = { salePriceText = it },
                quickMode = quickMode,
                onQuickModeChange = { mode ->
                    quickMode = mode
                    val currentResult = parseMoneyCents(salePriceText)?.takeIf { it > 0 }?.let { price ->
                        runCatching { CostCalculator.calculate(item.toOfficialCostInput(chosenSalePriceCents = price)) }.getOrNull()
                    }
                    quickTargetText = number(
                        when (mode) {
                            OfficialQuickMode.MARGIN -> currentResult?.marginPercent ?: 50.0
                            OfficialQuickMode.MARKUP -> currentResult?.markupPercent ?: 100.0
                        }
                    )
                },
                quickTargetText = quickTargetText,
                onQuickTargetChange = { applyAdjustment(quickMode, it) },
                quickTarget = quickTarget,
                compositionExpanded = compositionExpanded,
                onToggleComposition = { compositionExpanded = !compositionExpanded }
            )
        }

        item {
            OfficialAccordionSection(
                icon = { Icon(Icons.Outlined.ShoppingCart, null, tint = DetailIcon, modifier = Modifier.size(24.dp)) },
                title = "Insumos",
                summary = if (suspiciousPackaging.isNotEmpty() || !hasPackaging) {
                    "Confira embalagens • ${money(item.ingredients.sumOf { it.costExactCents ?: it.costCents.toDouble() }.roundToLong())}"
                } else {
                    "${item.ingredients.size} itens • ${money(item.ingredients.sumOf { it.costExactCents ?: it.costCents.toDouble() }.roundToLong())}"
                },
                expanded = expandedSection == "INSUMOS",
                onToggle = { expandedSection = if (expandedSection == "INSUMOS") "" else "INSUMOS" }
            ) {
                if (suspiciousPackaging.isNotEmpty()) {
                    InfoCard(tint = DetailWarningSoft) {
                        Text("Confira estas embalagens", fontWeight = FontWeight.SemiBold, color = DetailText)
                        Text(
                            suspiciousPackaging.joinToString(", ") { it.nameSnapshot } +
                                " estão com 1 un para uma receita de ${number(sellableYield)} ${item.recipe.yieldUnit}.",
                            style = MaterialTheme.typography.bodySmall,
                            color = DetailText
                        )
                    }
                } else if (!hasPackaging) {
                    InfoCard(tint = DetailWarningSoft) {
                        Text("Embalagem não identificada", fontWeight = FontWeight.SemiBold, color = DetailText)
                        Text("Cadastre a embalagem usada na produção como insumo.", style = MaterialTheme.typography.bodySmall, color = DetailText)
                    }
                }
                val visible = if (showAllIngredients) item.ingredients else item.ingredients.take(4)
                visible.forEach { ingredient ->
                    OfficialIngredientLine(ingredient.nameSnapshot, ingredient.quantityUsed, ingredient.unit, ingredient.costCents)
                }
                if (item.ingredients.size > 4) {
                    TextButton(onClick = { showAllIngredients = !showAllIngredients }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (showAllIngredients) "Mostrar menos" else "Ver todos os ${item.ingredients.size} insumos", color = PinkDark)
                    }
                }
                OutlinedButton(onClick = { onEditSection(2) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Text("Editar insumos")
                }
            }
        }

        item {
            OfficialAccordionSection(
                icon = { Icon(Icons.Outlined.BarChart, null, tint = DetailIcon, modifier = Modifier.size(24.dp)) },
                title = "Rendimento e escala",
                summary = "${number(sellableYield)} ${item.recipe.yieldUnit}",
                expanded = expandedSection == "RENDIMENTO",
                onToggle = { expandedSection = if (expandedSection == "RENDIMENTO") "" else "RENDIMENTO" }
            ) {
                if (abs(item.recipe.yieldQuantity - sellableYield) < 0.0001) {
                    OfficialValueRow("Rendimento atual", "${number(sellableYield)} ${item.recipe.yieldUnit}", strong = true)
                } else {
                    OfficialValueRow("Rendimento informado", "${number(item.recipe.yieldQuantity)} ${item.recipe.yieldUnit}")
                    OfficialValueRow("Rendimento vendável", "${number(sellableYield)} ${item.recipe.yieldUnit}", strong = true)
                }
                if (item.recipe.lossPercent > 0) OfficialValueRow("Perda", "${percent(item.recipe.lossPercent)}%")

                Text("Escalar receita", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                SmartNumberField(
                    desiredYieldText,
                    { desiredYieldText = it },
                    "Quantidade desejada (${item.recipe.yieldUnit})",
                    Modifier.fillMaxWidth(),
                    helpText = "Informe quanto você quer produzir. Os atalhos abaixo preenchem a quantidade automaticamente."
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5, 1.0, 1.5, 2.0).forEach { value ->
                        PercentShortcutChip(
                            label = "${number(value)}×",
                            selected = abs(scale - value) < 0.001,
                            modifier = Modifier.weight(1f),
                            onClick = { desiredYieldText = number(sellableYield * value) }
                        )
                    }
                }

                if (abs(scale - 1.0) > 0.001) {
                    Text(
                        "Equivale a ${number(scale)}× a receita original",
                        color = DetailSecondary,
                        fontSize = 13.sp
                    )
                }
                OfficialValueRow("Novo rendimento", "${number(desiredYield)} ${item.recipe.yieldUnit}", strong = true)
                OfficialValueRow("Custo estimado da escala", money(scaledTotalCostCents), strong = true)

                if (item.ingredients.isNotEmpty()) {
                    HorizontalDivider(color = DetailDivider)
                    Text("Prévia das quantidades", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    item.ingredients.take(3).forEach { ingredient ->
                        OfficialValueRow(ingredient.nameSnapshot, "${number(ingredient.quantityUsed * scale)} ${ingredient.unit}")
                    }
                    if (item.ingredients.size > 3) {
                        TextButton(
                            onClick = { showScaledQuantitiesScreen = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Ver todas as quantidades ›", color = PinkDark)
                        }
                    }
                }

                OutlinedButton(onClick = onSimulate, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Icon(Icons.Outlined.Calculate, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Simular mudanças")
                }
                OutlinedButton(onClick = { onEditSection(1) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Text("Editar dados e rendimento")
                }
            }
        }

        item {
            OfficialAccordionSection(
                icon = { Icon(Icons.Outlined.Paid, null, tint = DetailIcon, modifier = Modifier.size(24.dp)) },
                title = "Custos adicionais",
                summary = if (missingLabor) "Mão de obra não informada" else "$additionalSummaryLabel • ${money(additionalTotal)}",
                expanded = expandedSection == "CUSTOS",
                onToggle = { expandedSection = if (expandedSection == "CUSTOS") "" else "CUSTOS" }
            ) {
                if (missingLabor) {
                    InfoCard(tint = DetailWarningSoft) {
                        Text("Mão de obra não informada", fontWeight = FontWeight.SemiBold, color = DetailText)
                        Text("Informe tempo de trabalho e valor da hora se esse custo fizer parte da produção.", style = MaterialTheme.typography.bodySmall, color = DetailText)
                    }
                }
                if ((costStructureResult?.packagingCents ?: 0L) > 0L) OfficialValueRow("Embalagem avulsa", money(costStructureResult?.packagingCents ?: 0L))
                OfficialValueRow("Mão de obra", money(costStructureResult?.laborCents ?: 0L))
                OfficialValueRow("Outros custos", money(costStructureResult?.extrasCents ?: 0L))
                if (item.recipe.variableFeePercent > 0) OfficialValueRow("Taxa percentual", "${percent(item.recipe.variableFeePercent)}%")
                if (item.recipe.fixedFeePerUnitCents > 0) OfficialValueRow("Taxa fixa por unidade", money(item.recipe.fixedFeePerUnitCents))
                if (feeTotal > 0) OfficialValueRow("Taxas no preço atual", money(feeTotal), strong = true)
                OutlinedButton(onClick = { onEditSection(3) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Text("Editar custos")
                }
            }
        }

        item {
            OutlinedButton(
                onClick = { confirmDelete = true },
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Pink)
            ) {
                Icon(Icons.Outlined.DeleteOutline, null, tint = Pink)
                Spacer(Modifier.size(8.dp))
                Text("Excluir receita", color = Pink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
            }

            // Desenhado depois da LazyColumn para ficar visualmente acima dela, sem
            // participar da medição. Alpha e deslocamento são derivados diretamente
            // do scroll, portanto não há expansão/encolhimento nem salto de conteúdo.
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(start = 16.dp, top = 6.dp, end = 16.dp)
                    .graphicsLayer {
                        alpha = stickyProgress
                        translationY = -(1f - stickyProgress) * stickyLiftPx
                    }
            ) {
                CompactStickyPriceSummary(
                    costPerUnit = costStructureResult?.costPerUnitCents,
                    salePrice = actualResult?.salePriceCents,
                    marginPercent = actualResult?.marginPercent
                )
            }
        }
    }

    if (showScaledQuantitiesScreen) {
        Dialog(
            onDismissRequest = { showScaledQuantitiesScreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(Modifier.fillMaxSize(), color = DetailBackground) {
                Column(Modifier.fillMaxSize()) {
                    CompactTopBar(
                        title = "Quantidades para ${number(desiredYield)} ${item.recipe.yieldUnit}",
                        onBack = { showScaledQuantitiesScreen = false }
                    )
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            InfoCard(tint = PinkSoft) {
                                Text("Receita: ${item.recipe.name}", fontWeight = FontWeight.SemiBold, color = DetailText)
                                Text(
                                    "${number(scale)}× a receita original • custo estimado ${money(scaledTotalCostCents)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DetailSecondary
                                )
                            }
                        }
                        items(item.ingredients.size) { index ->
                            val ingredient = item.ingredients[index]
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = DetailSurface,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, Outline)
                            ) {
                                OfficialValueRow(
                                    ingredient.nameSnapshot,
                                    "${number(ingredient.quantityUsed * scale)} ${ingredient.unit}",
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = DetailSurface,
            tonalElevation = 0.dp,
            shape = DetailCardShape,
            title = { Text("Excluir receita?") },
            text = { Text("Essa ação não pode ser desfeita.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.deleteRecipe(recipeId, onBack) }) {
                    Text("Excluir", color = Pink)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }

    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            containerColor = DetailSurface,
            tonalElevation = 0.dp,
            shape = DetailCardShape,
            title = { Text("Como os números são calculados") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Custo por unidade = custo total ÷ rendimento vendável.")
                    Text("Margem mede o lucro como porcentagem do preço de venda.")
                    Text("Markup mede quanto o preço ficou acima do custo.")
                    Text("O Lucro Exato mantém precisão completa internamente e arredonda somente a exibição e o preço cobrável.", color = DetailSecondary)
                }
            },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Entendi") } }
        )
    }

}

@Composable
private fun RecipeOfficialHeader(
    item: RecipeWithDetails,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onPrint: () -> Unit,
    onInfo: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(44.dp)) {
            Icon(Icons.Outlined.ArrowBack, "Voltar", tint = DetailIcon, modifier = Modifier.size(24.dp))
        }
        Column(Modifier.weight(1f).padding(start = 4.dp)) {
            Text(
                item.recipe.name,
                color = DetailText,
                fontSize = 24.sp,
                lineHeight = 29.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "${item.recipe.category} • ${number(item.recipe.yieldQuantity)} ${item.recipe.yieldUnit}",
                color = DetailSecondary,
                fontSize = 15.sp,
                lineHeight = 20.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onEdit, modifier = Modifier.size(44.dp)) {
            Icon(Icons.Outlined.Edit, "Editar receita completa", tint = DetailIcon, modifier = Modifier.size(24.dp))
        }
        IconButton(onClick = onPrint, modifier = Modifier.size(44.dp)) {
            Icon(Icons.Outlined.Print, "Imprimir", tint = DetailIcon, modifier = Modifier.size(24.dp))
        }
        IconButton(onClick = onInfo, modifier = Modifier.size(44.dp)) {
            Icon(Icons.Outlined.Info, "Informações", tint = DetailIcon, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun CompactStickyPriceSummary(
    costPerUnit: Long?,
    salePrice: Long?,
    marginPercent: Double?
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = DetailSurface,
        border = BorderStroke(1.dp, DetailDivider),
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 4.dp
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StickyMetric("Custo", costPerUnit?.let(::money) ?: "—", Modifier.weight(1f))
            StickyMetric("Venda", salePrice?.let(::money) ?: "—", Modifier.weight(1f), positive = salePrice != null)
            StickyMetric("Margem", marginPercent?.let { "${percent(it)}%" } ?: "—", Modifier.weight(1f))
        }
    }
}

@Composable
private fun StickyMetric(label: String, value: String, modifier: Modifier = Modifier, positive: Boolean = false) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = DetailSecondary, fontSize = 10.sp, lineHeight = 12.sp, maxLines = 1)
        Text(
            value,
            color = if (positive && value != "—") Green else DetailText,
            fontSize = 13.sp,
            lineHeight = 16.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
private fun CostReviewBanner(text: String, onClick: () -> Unit, onDismiss: () -> Unit) {
    var dragX by remember { mutableStateOf(0f) }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 50.dp)
            .graphicsLayer { translationX = dragX }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> dragX += amount },
                    onDragEnd = {
                        if (kotlin.math.abs(dragX) > 120f) onDismiss() else dragX = 0f
                    },
                    onDragCancel = { dragX = 0f }
                )
            }
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = DetailWarningSoft,
        border = BorderStroke(1.dp, Color(0xFFF6E4A4))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.WarningAmber, null, tint = DetailWarning, modifier = Modifier.size(23.dp))
            Spacer(Modifier.size(9.dp))
            Text(
                text,
                modifier = Modifier.weight(1f),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DetailText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Icon(Icons.Outlined.ChevronRight, "Abrir seção", tint = DetailIcon, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun PriceProfitOfficialCard(
    item: RecipeWithDetails,
    catalog: List<IngredientEntity>,
    costResult: CostResult?,
    actualResult: CostResult?,
    salePriceText: String,
    onSalePriceChange: (String) -> Unit,
    quickMode: OfficialQuickMode,
    onQuickModeChange: (OfficialQuickMode) -> Unit,
    quickTargetText: String,
    onQuickTargetChange: (String) -> Unit,
    quickTarget: Double,
    compositionExpanded: Boolean,
    onToggleComposition: () -> Unit
) {
    val targetIsValid = quickTarget.isFinite() && quickTarget >= 0.0 &&
        (quickMode != OfficialQuickMode.MARGIN || quickTarget < 100.0)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = DetailCardShape,
        colors = CardDefaults.cardColors(containerColor = DetailSurface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Preço e lucro", fontSize = 20.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, color = DetailText)

            UnitRecipeSummary(costResult, actualResult, item.recipe.yieldUnit)
            MarginMarkupMetrics(actualResult)

            SalePriceField(value = salePriceText, onValueChange = onSalePriceChange)

            HorizontalDivider(color = DetailDivider)

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Ajustar preço", modifier = Modifier.weight(1f), fontSize = 20.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold, color = DetailText)
                QuickModeChip("Margem", quickMode == OfficialQuickMode.MARGIN) { onQuickModeChange(OfficialQuickMode.MARGIN) }
                Spacer(Modifier.size(8.dp))
                QuickModeChip("Markup", quickMode == OfficialQuickMode.MARKUP) { onQuickModeChange(OfficialQuickMode.MARKUP) }
            }

            val shortcuts = if (quickMode == OfficialQuickMode.MARGIN) {
                listOf(30.0, 40.0, 50.0, 60.0, 70.0)
            } else {
                listOf(50.0, 100.0, 150.0, 200.0)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                shortcuts.forEach { target ->
                    PercentShortcutChip(
                        label = "${number(target)}%",
                        selected = abs(quickTarget - target) < 0.001,
                        modifier = Modifier.weight(1f),
                        onClick = { onQuickTargetChange(number(target)) }
                    )
                }
            }

            SmartNumberField(
                quickTargetText,
                onQuickTargetChange,
                if (quickMode == OfficialQuickMode.MARGIN) "Margem desejada (%)" else "Markup desejado (%)",
                Modifier.fillMaxWidth()
            )
            if (!targetIsValid) {
                Text(
                    if (quickMode == OfficialQuickMode.MARGIN) "A margem desejada precisa ficar entre 0% e menos de 100%." else "Informe um markup válido.",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 13.sp
                )
            }

            HorizontalDivider(color = DetailDivider)

            PriceCompositionAccordion(
                item = item,
                catalog = catalog,
                result = actualResult,
                expanded = compositionExpanded,
                onToggle = onToggleComposition
            )
        }
    }
}

@Composable
private fun UnitRecipeSummary(costResult: CostResult?, actualResult: CostResult?, yieldUnit: String) {
    val revenueTotal = actualResult?.let { (it.salePriceCents.toDouble() * it.sellableYield).roundToLong() }
    val profitTotal = actualResult?.let { (it.profitPerUnitExactCents * it.sellableYield).roundToLong() }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = DetailSurface,
        border = BorderStroke(1.dp, Outline)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 14.dp)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Por unidade", fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold, color = DetailText)
                CompactMoneyRow("Custo", costResult?.costPerUnitCents?.let(::money) ?: "—", false)
                CompactMoneyRow("Venda", actualResult?.salePriceCents?.let(::money) ?: "—", actualResult != null)
                CompactMoneyRow("Lucro", actualResult?.profitPerUnitCents?.let(::money) ?: "—", actualResult != null, strong = true)
            }
            Box(Modifier.padding(horizontal = 12.dp).size(width = 1.dp, height = 112.dp).background(DetailDivider))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                val yield = costResult?.sellableYield ?: actualResult?.sellableYield
                Text(
                    "Na receita (${yield?.let(::number) ?: "—"} $yieldUnit)",
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = DetailText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                CompactMoneyRow("Custo", costResult?.totalCostCents?.let(::money) ?: "—", false)
                CompactMoneyRow("Faturamento", revenueTotal?.let(::money) ?: "—", actualResult != null)
                CompactMoneyRow("Lucro", profitTotal?.let(::money) ?: "—", actualResult != null, strong = true)
            }
        }
    }
}

@Composable
private fun CompactMoneyRow(label: String, value: String, positive: Boolean, strong: Boolean = false) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), color = DetailText, fontSize = 14.sp, maxLines = 1)
        Text(
            value,
            color = if (positive && value != "—") Green else DetailText,
            fontWeight = if ((positive && value != "—") || strong) FontWeight.Bold else FontWeight.Medium,
            fontSize = 14.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun MarginMarkupMetrics(result: CostResult?) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            modifier = Modifier.weight(1f).heightIn(min = 60.dp),
            shape = RoundedCornerShape(14.dp),
            color = DetailWarningSoft
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.BarChart, null, tint = Color(0xFFF0A21B), modifier = Modifier.size(24.dp))
                Spacer(Modifier.size(9.dp))
                Column {
                    Text("Margem real", color = DetailSecondary, fontSize = 13.sp)
                    Text(result?.let { "${percent(it.marginPercent)}%" } ?: "—", color = DetailText, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 22.sp)
                }
            }
        }
        Surface(
            modifier = Modifier.weight(1f).heightIn(min = 60.dp),
            shape = RoundedCornerShape(14.dp),
            color = PinkSoft
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.TrendingUp, null, tint = PinkDark, modifier = Modifier.size(24.dp))
                Spacer(Modifier.size(9.dp))
                Column {
                    Text("Markup real", color = DetailSecondary, fontSize = 13.sp)
                    Text(result?.let { "${percent(it.markupPercent)}%" } ?: "—", color = PinkDark, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 22.sp)
                }
            }
        }
    }
}

@Composable
private fun SalePriceField(value: String, onValueChange: (String) -> Unit) {
    var field by remember { mutableStateOf(TextFieldValue(value)) }
    LaunchedEffect(value) {
        if (field.text != value) field = TextFieldValue(value, TextRange(value.length))
    }
    OutlinedTextField(
        value = field,
        onValueChange = { changed ->
            val filtered = sanitizeNumericInput(changed.text, integerOnly = false)
            field = TextFieldValue(filtered, TextRange(filtered.length))
            onValueChange(filtered)
        },
        modifier = Modifier.fillMaxWidth().onFocusChanged { focus ->
            if (focus.isFocused && field.text.isNotEmpty()) field = field.copy(selection = TextRange(0, field.text.length))
        },
        label = { Text("Preço de venda (por unidade)", fontSize = 14.sp) },
        prefix = { Text("R$ ", color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        textStyle = androidx.compose.ui.text.TextStyle(color = Green, fontSize = 22.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold),
        trailingIcon = {
            if (field.text.isNotEmpty()) {
                IconButton(onClick = { field = TextFieldValue(""); onValueChange("") }) {
                    Text("×", color = DetailSecondary, fontSize = 26.sp)
                }
            }
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        shape = DetailFieldShape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Green,
            unfocusedBorderColor = Green,
            focusedLabelColor = Green,
            unfocusedLabelColor = DetailSecondary,
            cursorColor = Green,
            focusedContainerColor = DetailSurface,
            unfocusedContainerColor = DetailSurface
        )
    )
}

@Composable
private fun QuickModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.heightIn(min = 42.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(13.dp),
        color = if (selected) Pink else DetailSurface,
        border = BorderStroke(1.dp, if (selected) Pink else Outline)
    ) {
        Box(Modifier.padding(horizontal = 16.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
            Text(
                label,
                color = if (selected) Color.White else DetailText,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PercentShortcutChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.heightIn(min = 42.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(13.dp),
        color = if (selected) PinkSoft else DetailSurface,
        border = BorderStroke(1.dp, if (selected) Pink else Outline)
    ) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
            Text(
                label,
                color = if (selected) PinkDark else DetailText,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PriceCompositionAccordion(
    item: RecipeWithDetails,
    catalog: List<IngredientEntity>,
    result: CostResult?,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val summary = result?.let { compositionSummary(item, catalog, it) } ?: "Preço de venda não informado"
    val rotation by animateFloatAsState(if (expanded) 180f else 0f, animationSpec = tween(500), label = "composition-chevron")
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.PieChartOutline, null, tint = DetailIcon, modifier = Modifier.size(24.dp))
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Composição do preço", color = DetailText, fontSize = 16.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold)
                Text(summary, color = DetailSecondary, fontSize = 13.sp, lineHeight = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(
                Icons.Outlined.KeyboardArrowDown,
                if (expanded) "Fechar composição" else "Abrir composição",
                tint = DetailIcon,
                modifier = Modifier.size(24.dp).rotate(rotation)
            )
        }
        AnimatedVisibility(
            visible = expanded && result != null,
            enter = expandVertically(animationSpec = tween(550)) + fadeIn(animationSpec = tween(360)),
            exit = shrinkVertically(animationSpec = tween(480)) + fadeOut(animationSpec = tween(300))
        ) {
            Column {
                Spacer(Modifier.size(8.dp))
                result?.let { PriceCompositionContent(item, catalog, it) }
            }
        }
    }
}

private data class OfficialCompositionSegment(val label: String, val cents: Double, val color: Color)

private fun compositionSegments(item: RecipeWithDetails, catalog: List<IngredientEntity>, result: CostResult): List<OfficialCompositionSegment> {
    val byId = catalog.associateBy { it.id }
    val packagingSupplyCents = item.ingredients.filter { used -> isPackagingUsed(used.nameSnapshot, used.ingredientId?.let { byId[it]?.category }.orEmpty()) }
        .sumOf { it.costExactCents ?: it.costCents.toDouble() }
    val regularIngredientCents = (result.ingredientsCents.toDouble() - packagingSupplyCents).coerceAtLeast(0.0)
    val y = result.sellableYield.coerceAtLeast(0.000001)
    return listOf(
        OfficialCompositionSegment("Lucro", result.profitPerUnitExactCents.coerceAtLeast(0.0), Green),
        OfficialCompositionSegment("Ingredientes", regularIngredientCents / y, Pink),
        OfficialCompositionSegment("Embalagem", (packagingSupplyCents + result.packagingCents.toDouble()) / y, Color(0xFF8E7CC3)),
        OfficialCompositionSegment("Mão de obra", result.laborCents.toDouble() / y, Color(0xFFF4A261)),
        OfficialCompositionSegment("Outros", result.extrasCents.toDouble() / y, Color(0xFF7AA6E8)),
        OfficialCompositionSegment("Taxas", result.feeExactCents.coerceAtLeast(0.0), Color(0xFF5A7DDE))
    ).filter { it.cents > 0.004 }
}

private fun compositionSummary(item: RecipeWithDetails, catalog: List<IngredientEntity>, result: CostResult): String {
    if (result.salePriceCents <= 0) return "Preço de venda não informado"
    return compositionSegments(item, catalog, result)
        .take(3)
        .joinToString(" • ") { segment ->
            val pct = segment.cents * 100.0 / result.salePriceCents.toDouble()
            "${segment.label} ${percent(pct)}%"
        }
}

@Composable
private fun PriceCompositionContent(item: RecipeWithDetails, catalog: List<IngredientEntity>, result: CostResult) {
    if (result.salePriceCents <= 0 || result.profitPerUnitExactCents < 0) {
        Surface(shape = RoundedCornerShape(12.dp), color = DetailWarningSoft, modifier = Modifier.fillMaxWidth()) {
            Text("O preço atual não cobre todos os custos. Aumente o preço para visualizar a composição.", modifier = Modifier.padding(12.dp), fontSize = 13.sp, color = DetailText)
        }
        return
    }
    val segments = compositionSegments(item, catalog, result)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        if (maxWidth < 340.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CompositionDonut(result.salePriceCents, segments)
                CompositionLegend(result.salePriceCents, segments, Modifier.fillMaxWidth())
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                CompositionDonut(result.salePriceCents, segments)
                CompositionLegend(result.salePriceCents, segments, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CompositionDonut(priceCents: Long, segments: List<OfficialCompositionSegment>) {
    Box(Modifier.size(126.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val total = priceCents.toDouble().coerceAtLeast(1.0)
            var start = -90f
            val stroke = size.minDimension * 0.17f
            segments.forEach { segment ->
                val sweep = (segment.cents / total * 360.0).toFloat().coerceAtLeast(0f)
                if (sweep > 0f) {
                    drawArc(segment.color, startAngle = start, sweepAngle = sweep, useCenter = false, style = Stroke(width = stroke))
                    start += sweep
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(money(priceCents), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("por unidade", fontSize = 11.sp, color = DetailSecondary)
        }
    }
}

@Composable
private fun CompositionLegend(priceCents: Long, segments: List<OfficialCompositionSegment>, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        segments.forEach { segment ->
            val pct = segment.cents * 100.0 / priceCents.toDouble().coerceAtLeast(1.0)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(segment.color, CircleShape))
                Text(segment.label, modifier = Modifier.weight(1f).padding(start = 6.dp), fontSize = 12.sp, color = DetailText, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${percent(pct)}%", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = DetailText)
            }
        }
    }
}

@Composable
private fun OfficialAccordionSection(
    icon: @Composable () -> Unit,
    title: String,
    summary: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    summaryAccent: Boolean = true,
    content: @Composable () -> Unit
) {
    val rotation by animateFloatAsState(if (expanded) 180f else 0f, animationSpec = tween(300), label = "accordion-chevron")
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = DetailCardShape,
        colors = CardDefaults.cardColors(containerColor = DetailSurface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 70.dp).clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) { icon() }
                Spacer(Modifier.size(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, color = DetailText, fontSize = 16.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold)
                    Text(
                        summary,
                        color = if (summaryAccent) PinkDark else DetailSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Icon(
                    Icons.Outlined.KeyboardArrowDown,
                    if (expanded) "Fechar" else "Abrir",
                    tint = DetailIcon,
                    modifier = Modifier.size(24.dp).rotate(rotation)
                )
            }
            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(animationSpec = tween(330)) + fadeIn(animationSpec = tween(180)),
                exit = shrinkVertically(animationSpec = tween(300)) + fadeOut(animationSpec = tween(150))
            ) {
                Column {
                    HorizontalDivider(color = DetailDivider, modifier = Modifier.padding(horizontal = 16.dp))
                    Column(
                        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) { content() }
                }
            }
        }
    }
}

@Composable
private fun OfficialIngredientLine(name: String, quantity: Double, unit: String, costCents: Long) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, color = DetailText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${number(quantity)} $unit", color = DetailSecondary, fontSize = 13.sp)
        }
        Text(money(costCents), color = DetailText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun OfficialValueRow(
    label: String,
    value: String,
    strong: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), color = DetailText, fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.size(8.dp))
        Text(value, color = DetailText, fontWeight = if (strong) FontWeight.Bold else FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
    }
}

private fun RecipeWithDetails.toOfficialCostInput(
    targetPercent: Double = recipe.targetPercent,
    chosenSalePriceCents: Long? = recipe.salePricePerUnitCents,
    pricingMode: String = recipe.pricingMode
) = CostInput(
    yieldQuantity = recipe.yieldQuantity,
    lossPercent = recipe.lossPercent,
    ingredients = ingredients.map { IngredientCostInput(it.nameSnapshot, it.costExactCents ?: it.costCents.toDouble()) },
    packagingPerUnitCents = recipe.packagingPerUnitCents,
    laborMinutes = recipe.laborMinutes,
    hourlyRateCents = recipe.hourlyRateCents,
    extras = extraCosts.map { ExtraCostInput(it.valueCents, it.application == "PER_UNIT") },
    variableFeePercent = recipe.variableFeePercent,
    fixedFeePerUnitCents = recipe.fixedFeePerUnitCents,
    pricingMode = pricingMode,
    targetPercent = targetPercent,
    chosenSalePriceCents = chosenSalePriceCents
)

private fun hasPackagingSupplyOfficial(item: RecipeWithDetails, catalog: List<IngredientEntity>): Boolean {
    if (item.recipe.packagingPerUnitCents > 0L) return true
    val byId = catalog.associateBy { it.id }
    return item.ingredients.any { used ->
        isPackagingUsed(used.nameSnapshot, used.ingredientId?.let { byId[it]?.category }.orEmpty())
    }
}

private fun hasSuspiciousPackagingQuantity(item: RecipeWithDetails, catalog: List<IngredientEntity>, sellableYield: Double): Boolean {
    if (sellableYield < 4.0) return false
    val byId = catalog.associateBy { it.id }
    return item.ingredients.any { used ->
        val category = used.ingredientId?.let { byId[it]?.category }.orEmpty()
        isPackagingUsed(used.nameSnapshot, category) &&
            used.unit.equals("un", ignoreCase = true) &&
            used.quantityUsed <= 1.000001
    }
}

private fun isPackagingUsed(nameRaw: String, categoryRaw: String): Boolean {
    val name = nameRaw.lowercase()
    return categoryRaw.contains("embal", ignoreCase = true) ||
        listOf("embal", "saquinho", "saco", "caixa", "adesivo", "etiqueta", "fecho", "lacre", "fitilho", "fita").any { name.contains(it) }
}

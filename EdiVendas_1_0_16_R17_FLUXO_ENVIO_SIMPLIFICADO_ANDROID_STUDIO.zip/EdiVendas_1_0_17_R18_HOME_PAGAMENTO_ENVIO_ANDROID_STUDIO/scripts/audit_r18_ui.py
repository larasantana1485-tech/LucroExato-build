from pathlib import Path
import re, sys, xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
ui = (root / 'app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt').read_text(encoding='utf-8')
store = (root / 'app/src/main/java/br/com/edivendas/data/SellerStore.kt').read_text(encoding='utf-8')
build = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')

checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    print(('OK   ' if ok else 'FAIL ') + name)

check('R18 versão 117 / 1.0.17', 'versionCode = 117' in build and 'versionName = "1.0.17-piloto"' in build)
check('Home sem botão superior Compartilhar', 'Text("Compartilhar", maxLines = 1)' not in ui)
check('Home CTA azul continua no rodapé', 'Alignment.BottomCenter' in ui and 'containerColor = BrandBlue' in ui)
check('CTA vazio continua identificado como envio', '"Enviar vendas ao Santana Gestão"' in ui)
check('pendências são globais, não só de hoje', 'val pending = remember(revision) { store.localSales() }' in ui)
check('store localSales pega revisões pendentes', 'fun localSales(): List<SellerSale> = sales().filter { it.sentRevision < it.revision && !it.cancelled }' in store)
check('aviso de pendência de dia anterior preservado', 'vendas pendentes de dias anteriores' in ui)
check('históricos em outline ghost', 'private fun HomeHistoryPill' in ui and 'border = androidx.compose.foundation.BorderStroke(1.dp, BrandLine)' in ui)
check('histórico de envios usa History, não Send', 'icon = Icons.Default.History' in ui and 'label = "Histórico de envios"' in ui)
check('avião azul reservado para enviar', 'colors = ButtonDefaults.buttonColors(containerColor = BrandBlue)' in ui)
check('Não vem selecionado por padrão em nova venda', 'mutableStateOf(restoredDraft?.paymentChoiceMade ?: true)' in ui and 'paymentChoiceMade = true' in ui)
check('draft antigo sem chave assume escolha padrão Não', 'json.optBoolean("paymentChoiceMade", true)' in ui)
check('Vai pagar agora tem bloco destacado', 'color = BrandPinkSoft.copy(alpha = .34f)' in ui and '"Vai pagar agora?"' in ui)
check('Não e Sim são pills', 'private fun PaymentBinaryOption' in ui and 'shape = RoundedCornerShape(50)' in ui)
check('pill selecionada é rosa', 'color = if (selected) BrandPink else BrandSurfaceSoft' in ui)
check('helper de pendência novo', 'Vai ficar pendente. Toque em Sim se recebeu agora.' in ui)
check('subtotal maior e à direita preservado', 'Modifier.width(144.dp)' in ui and 'style = MaterialTheme.typography.titleLarge' in ui)
check('meia aba de envio preservada', 'ModalBottomSheet(' in ui and 'Como deseja enviar?' in ui)
check('.edi destacado como principal', 'recommended = true' in ui and 'if (recommended) BrandBlueSoft.copy(alpha = .28f)' in ui)
check('três métodos de envio preservados', all(x in ui for x in ['Enviar arquivo .edi', 'Compartilhar resumo em imagem', 'Mostrar QR Code']))
check('estados humanos preservados', all(x in ui for x in ['"Enviado" to BrandGreenSoft', '"Não enviado" to BrandAmberSoft', '"Corrigida — reenviar" to BrandPinkSoft']))
check('sem status técnico Arquivo/QR gerado', 'Arquivo/QR gerado' not in ui)
check('sem conflitos de merge', not re.search(r'<<<<<<<|=======|>>>>>>>', ui))

xml_ok = True
for p in list((root/'app/src/main/res').rglob('*.xml')) + [root/'app/src/main/AndroidManifest.xml']:
    try: ET.parse(p)
    except Exception as e:
        xml_ok = False
        print('XML error:', p, e)
check('XML válido', xml_ok)

passed = sum(ok for _, ok in checks)
print(f'\nR18_UI_CHECKS: {passed}/{len(checks)}')
sys.exit(0 if passed == len(checks) else 1)

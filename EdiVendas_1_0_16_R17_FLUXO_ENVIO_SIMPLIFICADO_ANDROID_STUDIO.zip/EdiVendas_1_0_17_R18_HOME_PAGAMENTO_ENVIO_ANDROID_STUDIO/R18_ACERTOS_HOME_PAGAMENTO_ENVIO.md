# R18 — Home, pagamento e envio refinados

Implementação sobre a R17 com os ajustes fechados no teste em aparelho em 23/09/2026.

## Home

- Remove o botão superior **Compartilhar** para eliminar duplicidade com o CTA de envio.
- O botão azul do rodapé continua **sempre presente na Home**.
- O CTA usa todas as vendas pendentes, inclusive de dias anteriores; não depende de existir venda no dia atual.
- Quando não há pendências, o CTA permanece no lugar como **Enviar vendas ao Santana Gestão**, desabilitado.
- O aviso de pendências antigas permanece e continua levando ao fluxo de revisão/envio.
- **Histórico completo** e **Histórico de envios** passam a ser ações secundárias em estilo outline/ghost, sem preenchimentos fortes.
- **Histórico de envios** troca o avião de papel por ícone de histórico. O avião azul fica reservado à ação real de enviar.

## Registrar venda

- **Vai pagar agora?** ganha bloco próprio, fundo rosa muito suave e tipografia mais forte.
- O seletor volta ao comportamento inicial do projeto: **Não** já vem selecionado em rosa; **Sim** fica neutro/cinza.
- Ao tocar em Sim, o destaque visual passa para Sim.
- O seletor usa duas pills/segmentos grandes, sem radios pequenos.
- Com Não selecionado, o texto de apoio informa: **Vai ficar pendente. Toque em Sim se recebeu agora.**
- PIX / Dinheiro / Cartão continuam sem pré-seleção quando Sim é escolhido.
- O subtotal maior e alinhado à direita da R17 foi preservado.

## Revisar e enviar

- Mantém a **meia aba (bottom sheet)** com as três formas de envio.
- **Enviar arquivo .edi** recebe destaque discreto de borda/fundo azul, indicando a via principal.
- Imagem e QR Code permanecem como alternativas.
- A meia aba foi compactada levemente, sem virar modal central.

## Estados e integridade

- Permanecem os estados humanos: **Não enviado**, **Enviado** e **Corrigida — reenviar**.
- Gerar arquivo, imagem ou QR não marca automaticamente a venda como enviada.
- Regras de revisão, `sentRevision`, `exportedRevision`, backup e integração foram preservadas.

# Validação R18

Validação estática executada após os ajustes de Home, pagamento e envio.

## Resultado

- `scripts/audit_r18_ui.py`: **24/24** verificações aprovadas.
- XML do manifesto/recursos: válido.
- Delimitadores estruturais do arquivo `EdiVendasApp.kt`: balanceados.
- Nenhum marcador de conflito de merge detectado.

## Itens conferidos

- botão Compartilhar do topo removido;
- CTA azul de envio permanece no rodapé da Home;
- pendências de dias anteriores continuam incluídas pelo `store.localSales()`;
- históricos em outline/ghost e sem avião azul no Histórico de envios;
- Não pré-selecionado em rosa no fluxo de nova venda;
- Sim neutro até ser escolhido;
- bloco Vai pagar agora? destacado;
- subtotal maior à direita preservado;
- bottom sheet de envio preservado e compactado;
- `.edi` com destaque discreto como opção principal;
- estados Enviado / Não enviado / Corrigida — reenviar preservados.

## Observação

Esta validação é estática. O build Android completo deve ser feito no Android Studio ou no GitHub Actions antes de instalar a R18 no aparelho.

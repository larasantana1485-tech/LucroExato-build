package br.com.edivendas.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import android.app.DatePickerDialog
import br.com.edivendas.data.ExchangeCodec
import br.com.edivendas.data.BrazilianMoney
import br.com.edivendas.data.EdiQrCodec
import br.com.edivendas.data.SellerBatch
import br.com.edivendas.data.SellerClient
import br.com.edivendas.data.SellerSale
import br.com.edivendas.data.SellerSaleItem
import br.com.edivendas.data.SellerProduct
import br.com.edivendas.data.SellerStore
import br.com.edivendas.data.TextExchange
import br.com.edivendas.data.UserVisibleException
import br.com.edivendas.R
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.text.Normalizer
import java.util.Locale
import java.util.UUID

private enum class Screen { HOME, CLIENTS, NEW_CLIENT, SALE, REVIEW, SALE_SAVED, SEND_DAY, SALES_HISTORY, HISTORY, SETTINGS }
enum class BatchShareKind { TEXT }

private data class UiSaleDraft(
    val screen: Screen,
    val selectedClientId: String?,
    val editingSaleId: String?,
    val items: List<SellerSaleItem>,
    val receivedText: String,
    val paidOnSpot: Boolean,
    val paymentChoiceMade: Boolean,
    val paymentMethod: String?,
    val saleDate: LocalDate,
    val draftSaleId: String,
    val editReturnScreen: Screen,
)

private fun loadUiSaleDraft(store: SellerStore): UiSaleDraft? = runCatching {
    val raw = store.draftState() ?: return@runCatching null
    val json = org.json.JSONObject(raw)
    val id = json.optString("draftSaleId").takeIf { it.isNotBlank() } ?: return@runCatching null
    val rowsJson = json.optJSONArray("items") ?: org.json.JSONArray()
    val rows = buildList {
        for (i in 0 until rowsJson.length()) {
            val row = rowsJson.optJSONObject(i) ?: continue
            add(SellerSaleItem(
                productSyncId = row.optString("productSyncId"),
                name = row.optString("name"),
                quantity = row.optInt("quantity", 1).coerceIn(1, 9_999),
                unitPriceCents = row.optLong("unitPriceCents", 0L),
            ))
        }
    }.filter { it.productSyncId.isNotBlank() && it.name.isNotBlank() && it.unitPriceCents > 0L }
    UiSaleDraft(
        screen = runCatching { Screen.valueOf(json.optString("screen")) }.getOrDefault(Screen.CLIENTS),
        selectedClientId = json.optString("selectedClientId").takeIf { it.isNotBlank() },
        editingSaleId = json.optString("editingSaleId").takeIf { it.isNotBlank() },
        items = rows,
        receivedText = json.optString("receivedText", "0,00"),
        paidOnSpot = json.optBoolean("paidOnSpot", false),
        paymentChoiceMade = json.optBoolean("paymentChoiceMade", true),
        paymentMethod = json.optString("paymentMethod").takeIf { it.isNotBlank() },
        saleDate = runCatching { LocalDate.parse(json.optString("saleDate")) }.getOrDefault(LocalDate.now()),
        draftSaleId = id,
        editReturnScreen = runCatching { Screen.valueOf(json.optString("editReturnScreen")) }.getOrDefault(Screen.HOME),
    )
}.getOrNull()

private fun encodeUiSaleDraft(draft: UiSaleDraft): String = org.json.JSONObject().apply {
    put("screen", draft.screen.name)
    draft.selectedClientId?.let { put("selectedClientId", it) }
    draft.editingSaleId?.let { put("editingSaleId", it) }
    put("receivedText", draft.receivedText)
    put("paidOnSpot", draft.paidOnSpot)
    put("paymentChoiceMade", draft.paymentChoiceMade)
    draft.paymentMethod?.let { put("paymentMethod", it) }
    put("saleDate", draft.saleDate.toString())
    put("draftSaleId", draft.draftSaleId)
    put("editReturnScreen", draft.editReturnScreen.name)
    put("items", org.json.JSONArray().apply {
        draft.items.forEach { row -> put(org.json.JSONObject()
            .put("productSyncId", row.productSyncId)
            .put("name", row.name)
            .put("quantity", row.quantity)
            .put("unitPriceCents", row.unitPriceCents)) }
    })
}.toString()

@Composable
fun EdiVendasApp(
    store: SellerStore,
    onShareBatch: (SellerBatch, BatchShareKind) -> Unit,
    onShareBatchSummary: (SellerBatch) -> Unit,
    onShareReceipt: (SellerSale) -> Unit,
    externalRevision: Int = 0,
) {
    var localRevision by remember { mutableIntStateOf(0) }
    var clockRevision by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            clockRevision += 1
        }
    }
    val revision = localRevision + externalRevision + clockRevision
    var configured by remember(revision) { mutableStateOf(store.isConfigured()) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(revision) {
        store.dataWarning()?.let { snackbar.showSnackbar(it) }
    }

    Scaffold(
        containerColor = Color.White,
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        when {
            store.needsRecovery() -> RecoveryScreen(
                modifier = Modifier.padding(padding),
                store = store,
                onRecovered = { configured = true; localRevision += 1 },
                onMessage = { scope.launch { snackbar.showSnackbar(it) } },
            )
            !configured -> OnboardingScreen(
                modifier = Modifier.padding(padding),
                store = store,
                revision = revision,
                onConfigured = {
                    configured = true
                    localRevision += 1
                },
                onMessage = { scope.launch { snackbar.showSnackbar(it) } },
            )
            else -> SellerFlow(
                modifier = Modifier.padding(padding),
                store = store,
                revision = revision,
                onRevision = { localRevision += 1 },
                onShareBatch = onShareBatch,
                onShareBatchSummary = onShareBatchSummary,
                onShareReceipt = onShareReceipt,
                onMessage = { scope.launch { snackbar.showSnackbar(it) } },
            )
        }
    }
}

@Composable
private fun RecoveryScreen(
    store: SellerStore,
    onRecovered: () -> Unit,
    onMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var restoring by remember { mutableStateOf(false) }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !restoring) {
            restoring = true
            scope.launch {
                try {
                    val text = withContext(Dispatchers.IO) { readTextLimited(context, uri, 8_000_000) }
                    withContext(Dispatchers.IO) { store.previewBackup(text); store.importBackup(text) }
                    onRecovered()
                    onMessage("Backup restaurado. Confira os dados antes de continuar.")
                } catch (error: Exception) {
                    onMessage(error.message ?: "Não foi possível restaurar o backup.")
                } finally { restoring = false }
            }
        }
    }
    Column(
        modifier = modifier.fillMaxSize().background(Color.White).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Os dados de configuração precisam ser recuperados", style = MaterialTheme.typography.headlineMedium, color = BrandCocoa)
        Spacer(Modifier.height(12.dp))
        Text(
            "O Edi encontrou dados locais, mas a configuração principal está danificada. Para não criar um cadastro novo por cima deles, restaure um backup válido.",
            color = BrandMuted,
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { restore.launch(arrayOf("application/json", "text/plain", "*/*")) },
            enabled = !restoring,
            modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
        ) { Text(if (restoring) "Restaurando…" else "Restaurar backup") }
    }
}

@Composable
private fun OnboardingScreen(
    store: SellerStore,
    revision: Int,
    onConfigured: () -> Unit,
    onMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val importedConfig = store.config()
    var sellerName by rememberSaveable(revision) { mutableStateOf(importedConfig?.sellerName ?: "Edilane") }
    var productName by rememberSaveable(revision) { mutableStateOf(importedConfig?.productName ?: "Pão de mel") }
    var priceText by rememberSaveable(revision) { mutableStateOf(centsToInput(importedConfig?.unitPriceCents ?: 900L)) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    modifier = Modifier.size(72.dp),
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFFFFF7EA),
                    shadowElevation = 1.dp,
                ) {
                    Image(
                        // painterResource aceita a arte rasterizada, mas não o
                        // layer-list usado como foreground do ícone adaptável.
                        // Carregar o XML aqui fazia o app encerrar na primeira
                        // abertura, antes mesmo de exibir o cadastro inicial.
                        painter = painterResource(R.drawable.edi_vendas_icon),
                        contentDescription = "Ícone do Edi Vendas",
                        modifier = Modifier.padding(4.dp),
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text("Bem-vinda ao Edi Vendas", style = MaterialTheme.typography.headlineMedium, color = BrandCocoa)
                Text(
                    "Vamos deixar tudo pronto para registrar as vendas de forma simples.",
                    color = BrandMuted,
                )
            }
        }
        item {
            SectionCard {
                OutlinedTextField(
                    value = sellerName,
                    onValueChange = { sellerName = it.take(60) },
                    label = { Text("Nome da vendedora") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = productName,
                    onValueChange = { productName = it.take(120) },
                    label = { Text("Produto padrão") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = moneyInput(it) },
                    label = { Text("Preço padrão") },
                    prefix = { Text("R$ ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item {
            Button(
                onClick = {
                    try {
                        store.saveInitialConfig(sellerName, productName, parseMoney(priceText))
                        onConfigured()
                    } catch (error: Exception) {
                        onMessage(error.message ?: "Confira os dados.")
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
            ) { Text("Começar a vender") }
        }
        item {
            Text(
                "Depois, em Configurações, toque em Atualizar dados do Santana Gestão para colar o catálogo copiado.",
                style = MaterialTheme.typography.bodySmall,
                color = BrandMuted,
            )
        }
    }
}

@Composable
private fun SellerFlow(
    store: SellerStore,
    revision: Int,
    onRevision: () -> Unit,
    onShareBatch: (SellerBatch, BatchShareKind) -> Unit,
    onShareBatchSummary: (SellerBatch) -> Unit,
    onShareReceipt: (SellerSale) -> Unit,
    onMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val restoredDraft = remember { loadUiSaleDraft(store) }
    val clientsAtStart = remember(revision) { store.clients() }
    val salesAtStart = remember(revision) { store.sales() }
    var screen by remember { mutableStateOf(restoredDraft?.screen ?: Screen.HOME) }
    var selectedClient by remember { mutableStateOf<SellerClient?>(
        restoredDraft?.selectedClientId?.let { id -> clientsAtStart.firstOrNull { it.syncId == id } }
    ) }
    var editingSale by remember { mutableStateOf<SellerSale?>(
        restoredDraft?.editingSaleId?.let { id -> salesAtStart.firstOrNull { it.externalSaleId == id } }
    ) }
    var saleItems by remember { mutableStateOf(restoredDraft?.items ?: emptyList()) }
    var receivedText by rememberSaveable { mutableStateOf(restoredDraft?.receivedText ?: "0,00") }
    var paidOnSpot by rememberSaveable { mutableStateOf(restoredDraft?.paidOnSpot ?: false) }
    var paymentChoiceMade by rememberSaveable { mutableStateOf(restoredDraft?.paymentChoiceMade ?: true) }
    var paymentMethod by rememberSaveable { mutableStateOf(restoredDraft?.paymentMethod) }
    var saleDate by remember { mutableStateOf(restoredDraft?.saleDate ?: LocalDate.now()) }
    var draftSaleId by rememberSaveable { mutableStateOf(restoredDraft?.draftSaleId) }
    var priceItemIndex by remember { mutableStateOf<Int?>(null) }
    var deleteTarget by remember { mutableStateOf<SellerSale?>(null) }
    var showCancelSale by remember { mutableStateOf(false) }
    var editReturnScreen by remember { mutableStateOf(restoredDraft?.editReturnScreen ?: Screen.HOME) }
    var clientPickerReturnsToSale by remember { mutableStateOf(false) }
    var lastSavedSale by remember { mutableStateOf<SellerSale?>(null) }
    var savingSale by remember { mutableStateOf(false) }
    var creatingBatch by remember { mutableStateOf(false) }
    var qrBatch by remember { mutableStateOf<SellerBatch?>(null) }
    var qrFrames by remember { mutableStateOf<List<String>>(emptyList()) }
    var qrIndex by remember { mutableIntStateOf(0) }
    var lastDataWarning by remember { mutableStateOf<String?>(null) }
    var showResumeDraft by remember { mutableStateOf(restoredDraft != null) }
    val scope = rememberCoroutineScope()
    val config = store.config() ?: return
    val loadedProducts = remember(revision) { store.products() }
    val products = remember(loadedProducts, config.baseVersion) {
        if (loadedProducts.isEmpty() && config.baseVersion == 0L) {
            listOf(SellerProduct(config.productId, config.productName, config.unitPriceCents, true))
        } else loadedProducts
    }
    val defaultProduct = products.firstOrNull { it.syncId == config.productId } ?: products.firstOrNull()
    fun ensureDefaultProduct() {
        if (editingSale == null && saleItems.isEmpty()) {
            defaultProduct?.let { saleItems = listOf(SellerSaleItem(it.syncId, it.name, 1, it.unitPriceCents)) }
        }
    }
    fun currentTotal(): Long = saleItems.sumOf { it.subtotalCents }
    fun replaceItems(updated: List<SellerSaleItem>) {
        val wasPaidInFull = paidOnSpot && runCatching { parseReceived(receivedText) }.getOrNull() == currentTotal()
        saleItems = updated
        if (wasPaidInFull) receivedText = centsToInput(updated.sumOf { it.subtotalCents })
    }

    LaunchedEffect(screen, revision) {
        val warning = store.dataWarning()
        if (warning == null) {
            lastDataWarning = null
        } else if (warning != lastDataWarning) {
            lastDataWarning = warning
            onMessage(warning)
        }
    }

    LaunchedEffect(screen, selectedClient?.syncId, editingSale?.externalSaleId, saleItems, receivedText, paidOnSpot, paymentChoiceMade, paymentMethod, saleDate, draftSaleId, editReturnScreen) {
        val id = draftSaleId
        if (id == null || screen in setOf(Screen.HOME, Screen.SALE_SAVED, Screen.SEND_DAY, Screen.SALES_HISTORY, Screen.HISTORY, Screen.SETTINGS)) {
            if (id == null) store.clearDraftState()
        } else {
            store.saveDraftState(encodeUiSaleDraft(UiSaleDraft(
                screen = screen,
                selectedClientId = selectedClient?.syncId,
                editingSaleId = editingSale?.externalSaleId,
                items = saleItems,
                receivedText = receivedText,
                paidOnSpot = paidOnSpot,
                paymentChoiceMade = paymentChoiceMade,
                paymentMethod = paymentMethod,
                saleDate = saleDate,
                draftSaleId = id,
                editReturnScreen = editReturnScreen,
            )))
        }
    }

    fun resetDraft() {
        selectedClient = null
        editingSale = null
        saleItems = emptyList()
        receivedText = "0,00"
        paidOnSpot = false
        paymentChoiceMade = true
        paymentMethod = null
        saleDate = LocalDate.now()
        draftSaleId = null
        clientPickerReturnsToSale = false
        store.clearDraftState()
    }

    fun editSale(sale: SellerSale, returnScreen: Screen) {
        if (sale.receivedCents > 0L && sale.receivedCents < sale.totalCents) {
            onMessage("Esta venda usa pagamento parcial de uma versão antiga. Corrija pelo Santana Gestão.")
            return
        }
        editingSale = sale
        editReturnScreen = returnScreen
        clientPickerReturnsToSale = false
        draftSaleId = sale.externalSaleId
        selectedClient = store.clients().firstOrNull {
            it.syncId == sale.clientSyncId ||
                (sale.adminClientId != null && it.adminClientId == sale.adminClientId) ||
                (!sale.externalClientKey.isNullOrBlank() && it.externalClientKey == sale.externalClientKey)
        } ?: SellerClient(
            adminClientId = sale.adminClientId,
            externalClientKey = sale.externalClientKey,
            syncId = sale.clientSyncId,
            name = sale.clientNameSnapshot,
            phone = sale.clientPhoneSnapshot,
            location = sale.clientLocationSnapshot,
        )
        saleItems = sale.items.ifEmpty {
            listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents))
        }.map { row ->
            if (runCatching { UUID.fromString(row.productSyncId) }.isSuccess) row
            else products.filter { searchable(it.name) == searchable(row.name) }.singleOrNull()?.let { matched ->
                row.copy(productSyncId = matched.syncId, name = matched.name)
            } ?: row
        }
        paidOnSpot = sale.receivedCents == sale.totalCents
        paymentChoiceMade = true
        receivedText = if (paidOnSpot) centsToInput(sale.totalCents) else "0,00"
        paymentMethod = sale.paymentMethod
        saleDate = millisDate(sale.soldAt)
        screen = Screen.SALE
    }

    fun performBack() {
        when (screen) {
            Screen.HOME -> Unit
            Screen.CLIENTS -> {
                if (clientPickerReturnsToSale && selectedClient != null) {
                    clientPickerReturnsToSale = false
                    screen = Screen.SALE
                } else {
                    resetDraft()
                    screen = Screen.HOME
                }
            }
            Screen.NEW_CLIENT -> screen = Screen.CLIENTS
            Screen.SALE -> {
                if (editingSale != null) {
                    val destination = editReturnScreen
                    resetDraft()
                    screen = destination
                } else {
                    clientPickerReturnsToSale = false
                    screen = Screen.CLIENTS
                }
            }
            Screen.REVIEW -> screen = Screen.SALE
            Screen.SALE_SAVED, Screen.SEND_DAY, Screen.SALES_HISTORY, Screen.HISTORY, Screen.SETTINGS -> screen = Screen.HOME
        }
    }

    fun requestBack() {
        if (savingSale) onMessage("Aguarde a venda terminar de salvar.") else performBack()
    }

    BackHandler(enabled = screen != Screen.HOME, onBack = ::requestBack)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = BrandCream,
        topBar = {
            if (screen != Screen.HOME) {
            AppTopBar(
                title = when (screen) {
                    Screen.HOME -> "Edi Vendas"
                    Screen.CLIENTS -> "Escolher cliente"
                    Screen.NEW_CLIENT -> "Escolher cliente"
                    Screen.SALE -> if (editingSale == null) "Registrar venda" else "Editar venda"
                    Screen.REVIEW -> "Revisar venda"
                    Screen.SALE_SAVED -> "Venda anotada"
                    Screen.SEND_DAY -> "Revisar e enviar vendas"
                    Screen.SALES_HISTORY -> "Histórico completo"
                    Screen.HISTORY -> "Histórico de envios"
                    Screen.SETTINGS -> "Configurações"
                },
                showBack = screen != Screen.HOME,
                onBack = ::requestBack,
                onSettings = null,
            )
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    store = store,
                    revision = revision,
                    onNewSale = {
                        resetDraft()
                        clientPickerReturnsToSale = false
                        draftSaleId = UUID.randomUUID().toString()
                        screen = Screen.CLIENTS
                    },
                    onEdit = { editSale(it, Screen.HOME) },
                    onSend = { screen = Screen.SEND_DAY },
                    onHistory = { screen = Screen.HISTORY },
                    onSalesHistory = { screen = Screen.SALES_HISTORY },
                    onSettings = { screen = Screen.SETTINGS },
                    linkedToSantana = store.isLinkedToSantana(),
                    dataWarning = store.dataWarning(),
                )
                Screen.CLIENTS -> ClientPicker(
                    store = store,
                    revision = revision,
                    onSelect = { selectedClient = it; ensureDefaultProduct(); clientPickerReturnsToSale = false; screen = Screen.SALE },
                    onNew = { screen = Screen.NEW_CLIENT },
                )
                Screen.NEW_CLIENT -> {
                    ClientPicker(
                        store = store,
                        revision = revision,
                        onSelect = { selectedClient = it; ensureDefaultProduct(); clientPickerReturnsToSale = false; screen = Screen.SALE },
                        onNew = { },
                    )
                    NewClientScreen(
                        store = store,
                        onSave = { selectedClient = it; ensureDefaultProduct(); clientPickerReturnsToSale = false; onRevision(); screen = Screen.SALE },
                        onCancel = { screen = Screen.CLIENTS },
                        onMessage = onMessage,
                    )
                }
                Screen.SALE -> SaleScreen(
                    client = selectedClient ?: return@Box,
                    editingSent = editingSale?.exportedRevision?.let { it > 0 } == true,
                    saleDate = saleDate,
                    onSaleDate = { saleDate = it },
                    products = products,
                    saleItems = saleItems,
                    onSelectProduct = { product ->
                        val existingIndex = saleItems.indexOfFirst { it.productSyncId == product.syncId }
                        if (existingIndex >= 0) {
                            val row = saleItems[existingIndex]
                            if (row.quantity < 9_999) replaceItems(saleItems.toMutableList().also {
                                it[existingIndex] = row.copy(quantity = row.quantity + 1)
                            }) else onMessage("A quantidade máxima por produto é 9.999.")
                        } else if (saleItems.size < 20) {
                            replaceItems(saleItems + SellerSaleItem(product.syncId, product.name, 1, product.unitPriceCents))
                        } else onMessage("Uma venda aceita até 20 produtos.")
                    },
                    onDecrease = { index ->
                        val row = saleItems[index]
                        if (row.quantity > 1) replaceItems(saleItems.toMutableList().also { it[index] = row.copy(quantity = row.quantity - 1) })
                    },
                    onIncrease = { index ->
                        val row = saleItems[index]
                        if (row.quantity < 9_999) replaceItems(saleItems.toMutableList().also { it[index] = row.copy(quantity = row.quantity + 1) })
                        else onMessage("A quantidade máxima por produto é 9.999.")
                    },
                    onRemoveItem = { index -> replaceItems(saleItems.filterIndexed { i, _ -> i != index }) },
                    onPrice = { index -> priceItemIndex = index },
                    totalCents = currentTotal(),
                    paidOnSpot = if (paymentChoiceMade) paidOnSpot else null,
                    paymentMethod = paymentMethod,
                    onPaid = {
                        paymentChoiceMade = true
                        paidOnSpot = it
                        receivedText = if (it) centsToInput(currentTotal()) else "0,00"
                        if (!it) paymentMethod = null
                    },
                    onPaymentMethod = { paymentMethod = it },
                    onChangeClient = { clientPickerReturnsToSale = true; screen = Screen.CLIENTS },
                    cancelLabel = when {
                        editingSale?.exportedRevision?.let { it > 0 } == true -> "Cancelar correção"
                        editingSale == null -> "Descartar venda"
                        else -> "Excluir venda"
                    },
                    onCancelSale = { showCancelSale = true },
                    onContinue = {
                        val received = runCatching { parseReceived(receivedText) }.getOrNull()
                        if (saleItems.isEmpty()) onMessage("Adicione pelo menos um produto.")
                        else if (!paymentChoiceMade) onMessage("Escolha Não ou Sim em “Vai pagar agora?”.")
                        else if (received == null || received < 0L || received > currentTotal()) onMessage("Confira o valor recebido.")
                        else if (paidOnSpot != (received > 0L)) onMessage("Confira se houve pagamento na hora.")
                        else if (paidOnSpot && paymentMethod == null) onMessage("Escolha PIX, Dinheiro ou Cartão.")
                        else screen = Screen.REVIEW
                    },
                )
                Screen.REVIEW -> ReviewScreen(
                    client = selectedClient ?: return@Box,
                    items = saleItems,
                    paidOnSpot = paidOnSpot,
                    receivedCents = runCatching { parseReceived(receivedText) }.getOrDefault(0L),
                    paymentMethod = paymentMethod,
                    saleDate = saleDate,
                    saleTimeKnown = editingSale?.takeIf { millisDate(it.soldAt) == saleDate }?.saleTimeKnown ?: (saleDate == LocalDate.now()),
                    saving = savingSale,
                    onCorrect = { screen = Screen.SALE },
                    cancelLabel = when {
                        editingSale?.exportedRevision?.let { it > 0 } == true -> "Cancelar correção"
                        editingSale == null -> "Descartar venda"
                        else -> "Excluir venda"
                    },
                    onCancelSale = { showCancelSale = true },
                    onConfirm = {
                        if (savingSale) return@ReviewScreen
                        val client = selectedClient ?: return@ReviewScreen
                        val old = editingSale
                        val firstItem = saleItems.firstOrNull() ?: return@ReviewScreen
                        val sale = SellerSale(
                            externalSaleId = old?.externalSaleId ?: draftSaleId ?: UUID.randomUUID().toString(),
                            adminClientId = client.adminClientId,
                            externalClientKey = client.externalClientKey,
                            clientSyncId = client.syncId,
                            clientNameSnapshot = client.name,
                            clientPhoneSnapshot = client.phone,
                            clientLocationSnapshot = client.location,
                            productId = firstItem.productSyncId,
                            productNameSnapshot = firstItem.name,
                            quantity = firstItem.quantity,
                            unitPriceCents = firstItem.unitPriceCents,
                            paidOnSpot = paidOnSpot,
                            paymentMethod = paymentMethod,
                            items = saleItems,
                            receivedCents = parseReceived(receivedText),
                            soldAt = when {
                                old != null && millisDate(old.soldAt) == saleDate -> old.soldAt
                                saleDate == LocalDate.now() -> System.currentTimeMillis()
                                else -> saleDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                            },
                            recordedAt = old?.recordedAt ?: System.currentTimeMillis(),
                            saleTimeKnown = when {
                                old != null && millisDate(old.soldAt) == saleDate -> old.saleTimeKnown
                                saleDate == LocalDate.now() -> true
                                else -> false
                            },
                        )
                        savingSale = true
                        scope.launch {
                            try {
                                lastSavedSale = withContext(Dispatchers.IO) { store.saveSale(sale) }
                                onRevision(); resetDraft(); screen = Screen.SALE_SAVED
                            } catch (error: Exception) {
                                onMessage(error.message ?: "Não foi possível salvar a venda.")
                            } finally {
                                savingSale = false
                            }
                        }
                    },
                )
                Screen.SALE_SAVED -> SaleSavedScreen(
                    sale = lastSavedSale ?: return@Box,
                    onShareReceipt = onShareReceipt,
                    onContinue = { lastSavedSale = null; screen = Screen.HOME },
                    onNewSale = {
                        lastSavedSale = null
                        resetDraft()
                        draftSaleId = UUID.randomUUID().toString()
                        screen = Screen.CLIENTS
                    },
                )
                Screen.SEND_DAY -> SendDayScreen(
                    store = store,
                    revision = revision,
                    onEdit = { editSale(it, Screen.SEND_DAY) },
                    creatingBatch = creatingBatch,
                    linkedToSantana = store.isLinkedToSantana(),
                    onText = {
                        if (!creatingBatch) {
                            creatingBatch = true
                            scope.launch {
                                try {
                                    val batch = withContext(Dispatchers.IO) { store.createBatch() }
                                    onRevision()
                                    onShareBatch(batch, BatchShareKind.TEXT)
                                    screen = Screen.HOME
                                    onMessage("Ao voltar do WhatsApp, confirme se o arquivo .edi foi enviado.")
                                } catch (error: Exception) {
                                    onMessage(error.message ?: "Não foi possível preparar o lote.")
                                } finally {
                                    creatingBatch = false
                                }
                            }
                        }
                    },
                    onImage = {
                        if (!creatingBatch) {
                            creatingBatch = true
                            scope.launch {
                                try {
                                    val batch = withContext(Dispatchers.IO) { store.createBatch(persistForSending = false) }
                                    onShareBatchSummary(batch)
                                } catch (error: Exception) {
                                    onMessage(error.message ?: "Não foi possível preparar a imagem.")
                                } finally { creatingBatch = false }
                            }
                        }
                    },
                    onQr = {
                        if (!creatingBatch) {
                            creatingBatch = true
                            scope.launch {
                                try {
                                    val batch = withContext(Dispatchers.IO) { store.createBatch() }
                                    val frames = withContext(Dispatchers.Default) { EdiQrCodec.frames(batch) }
                                    qrBatch = batch
                                    qrFrames = frames
                                    qrIndex = 0
                                } catch (error: Exception) {
                                    onMessage(error.message ?: "Não foi possível criar o QR Code.")
                                } finally { creatingBatch = false }
                            }
                        }
                    },
                )
                Screen.SALES_HISTORY -> SalesHistoryScreen(store, revision) { editSale(it, Screen.SALES_HISTORY) }
                Screen.HISTORY -> HistoryScreen(store, revision, onShareBatch) { editSale(it, Screen.HISTORY) }
                Screen.SETTINGS -> SettingsScreen(store, revision, onRevision, onMessage)
            }
        }
    }

    qrBatch?.let { batch ->
        val frame = qrFrames.getOrNull(qrIndex)
        if (frame != null) {
            var bitmap by remember(frame) { mutableStateOf<android.graphics.Bitmap?>(null) }
            LaunchedEffect(frame) {
                bitmap = withContext(Dispatchers.Default) { EdiQrCodec.bitmap(frame) }
            }
            AlertDialog(
                onDismissRequest = { qrBatch = null; qrFrames = emptyList() },
                title = { Text("QR Code das vendas") },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("No Santana Gestão, abra Receber do Edi e escolha QR Code.", color = BrandMuted)
                        if (bitmap == null) {
                            CircularProgressIndicator()
                            Text("Preparando QR Code…", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Image(bitmap!!.asImageBitmap(), "Parte ${qrIndex + 1} de ${qrFrames.size}", Modifier.fillMaxWidth())
                        }
                        Text("Parte ${qrIndex + 1} de ${qrFrames.size}", fontWeight = FontWeight.Bold)
                        if (qrFrames.size > 1) Text("Só avance quando o Gestão confirmar esta parte.", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { qrIndex -= 1 }, enabled = qrIndex > 0) { Text("Anterior") }
                            OutlinedButton(onClick = { qrIndex += 1 }, enabled = qrIndex < qrFrames.lastIndex) { Text("Próxima") }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        try {
                            store.confirmBatchSent(batch)
                            onRevision()
                            qrBatch = null
                            qrFrames = emptyList()
                            screen = Screen.HOME
                            onMessage("Envio por QR confirmado.")
                        } catch (error: Exception) { onMessage(error.message ?: "Não foi possível confirmar o lote.") }
                    }, enabled = qrIndex == qrFrames.lastIndex && bitmap != null) { Text("Gestão leu tudo") }
                },
                dismissButton = { TextButton(onClick = { qrBatch = null; qrFrames = emptyList() }) { Text("Cancelar") } },
            )
        }
    }

    if (showCancelSale) {
        val currentEditing = editingSale
        val isSentCorrection = currentEditing?.exportedRevision?.let { it > 0 } == true
        val title = when {
            currentEditing == null -> "Cancelar esta venda?"
            isSentCorrection -> "Cancelar esta correção?"
            else -> "Excluir esta venda?"
        }
        val message = when {
            currentEditing == null -> "Os dados preenchidos serão perdidos."
            isSentCorrection -> "As alterações não salvas serão descartadas. A versão anterior será mantida."
            else -> "${currentEditing.clientNameSnapshot} • ${ExchangeCodec.formatCents(currentEditing.totalCents)}\nEsta venda ainda não foi enviada e será removida."
        }
        AlertDialog(
            onDismissRequest = { showCancelSale = false },
            title = { Text(title) },
            text = { Text(message) },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelSale = false
                        when {
                            currentEditing == null -> {
                                resetDraft()
                                screen = Screen.HOME
                                onMessage("Venda cancelada.")
                            }
                            isSentCorrection -> {
                                val destination = editReturnScreen
                                resetDraft()
                                screen = destination
                                onMessage("Correção cancelada. A venda original foi mantida.")
                            }
                            else -> {
                                val destination = editReturnScreen
                                scope.launch {
                                    try {
                                        withContext(Dispatchers.IO) { store.deleteSale(currentEditing.externalSaleId) }
                                        onRevision()
                                        resetDraft()
                                        screen = destination
                                        onMessage("Venda excluída.")
                                    } catch (error: Exception) {
                                        onMessage(error.message ?: "Não foi possível excluir a venda.")
                                    }
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandDanger),
                ) {
                    Text(when {
                        currentEditing == null -> "Descartar venda"
                        isSentCorrection -> "Descartar alterações"
                        else -> "Excluir venda"
                    })
                }
            },
            dismissButton = { TextButton(onClick = { showCancelSale = false }) { Text("Continuar venda") } },
        )
    }

    if (showResumeDraft) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = Color.White,
            title = { Text("Continuar venda em andamento?") },
            text = { Text("O Edi recuperou a venda que estava aberta antes de o aplicativo ser fechado ou recriado.") },
            confirmButton = { Button(onClick = { showResumeDraft = false }) { Text("Continuar") } },
            dismissButton = { TextButton(onClick = { showResumeDraft = false; resetDraft(); screen = Screen.HOME }) { Text("Descartar") } },
        )
    }

    priceItemIndex?.let { index ->
        val item = saleItems.getOrNull(index)
        val product = item?.let { row -> products.firstOrNull { it.syncId == row.productSyncId } }
        if (item != null) {
        PriceDialog(
            current = item.unitPriceCents,
            default = product?.unitPriceCents ?: item.unitPriceCents,
            onDismiss = { priceItemIndex = null },
            onSelect = { newPrice ->
                replaceItems(saleItems.toMutableList().also { it[index] = item.copy(unitPriceCents = newPrice) })
                priceItemIndex = null
            },
        )
        } else priceItemIndex = null
    }
    deleteTarget?.let { sale ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Excluir esta venda?") },
            text = { Text("${sale.clientNameSnapshot} • ${ExchangeCodec.formatCents(sale.totalCents)}") },
            confirmButton = {
                Button(onClick = {
                    deleteTarget = null
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { store.deleteSale(sale.externalSaleId) }
                            onRevision()
                            onMessage("Venda excluída.")
                        } catch (error: Exception) {
                            onMessage(error.message ?: "Não foi possível excluir a venda.")
                        }
                    }
                }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun AppTopBar(title: String, showBack: Boolean, onBack: () -> Unit, onSettings: (() -> Unit)?) {
    Surface(color = BrandSurface, shadowElevation = 1.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (showBack) IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
            else Spacer(Modifier.width(8.dp))
            Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, color = BrandCocoa)
            onSettings?.let {
                IconButton(onClick = it) { Icon(Icons.Default.Settings, "Configurações", tint = BrandMuted) }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    store: SellerStore,
    revision: Int,
    onNewSale: () -> Unit,
    onEdit: (SellerSale) -> Unit,
    onSend: () -> Unit,
    onHistory: () -> Unit,
    onSalesHistory: () -> Unit,
    onSettings: () -> Unit,
    linkedToSantana: Boolean,
    dataWarning: String?,
) {
    val config = remember(revision) { store.config() } ?: return
    val today = LocalDate.now()
    val todaySales = remember(revision, today) { store.salesForDate(today) }
    val pending = remember(revision) { store.localSales() }
    val pendingOlder = pending.count { millisDate(it.soldAt) != today }
    val canSend = pending.isNotEmpty() && linkedToSantana && dataWarning.isNullOrBlank()

    Box(Modifier.fillMaxSize().background(Color.White)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "${greeting()}, ${config.sellerName}",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = BrandInk,
                        )
                        IconButton(onClick = onSettings) {
                            Icon(Icons.Default.Settings, "Configurações", tint = BrandMuted)
                        }
                    }
                    Text(formatLongDate(today), color = BrandMuted)
                }
            }

            item {
                Button(
                    onClick = onNewSale,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 58.dp),
                    shape = RoundedCornerShape(18.dp),
                ) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Registrar venda", style = MaterialTheme.typography.titleMedium)
                }
            }

            if (!dataWarning.isNullOrBlank()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = BrandAmberSoft)) {
                        Text(
                            "Há um problema nos dados locais. Evite registrar ou enviar novas vendas até corrigir: $dataWarning",
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            color = BrandCocoa,
                        )
                    }
                }
            }

            if (pendingOlder > 0) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable(enabled = canSend, onClick = onSend),
                        shape = RoundedCornerShape(16.dp),
                        color = BrandAmberSoft.copy(alpha = .85f),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(40.dp).background(Color.White.copy(alpha = .55f), CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Default.History, null, tint = BrandAmber, modifier = Modifier.size(22.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "$pendingOlder ${if (pendingOlder == 1) "venda pendente de dia anterior entrará" else "vendas pendentes de dias anteriores entrarão"} neste envio.",
                                modifier = Modifier.weight(1f),
                                fontWeight = FontWeight.SemiBold,
                                color = BrandCocoa,
                            )
                            if (canSend) Icon(Icons.Default.KeyboardArrowRight, "Revisar envio", tint = BrandAmber)
                        }
                    }
                }
            }

            if (pending.isNotEmpty() && !linkedToSantana) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = BrandAmberSoft)) {
                        Text(
                            "Atualize os dados do Santana Gestão antes de enviar o primeiro lote.",
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            color = BrandCocoa,
                        )
                    }
                }
            }

            if (todaySales.isNotEmpty()) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Vendas de hoje", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(
                            "${saleCountText(todaySales.size)} • ${ExchangeCodec.formatCents(todaySales.sumOf { it.totalCents })}",
                            color = BrandMuted,
                        )
                    }
                }
                items(todaySales, key = { it.externalSaleId }) { sale ->
                    Column {
                        SaleRow(
                            sale = sale,
                            editable = true,
                            onEdit = { onEdit(sale) },
                            showSendStatus = true,
                        )
                        HorizontalDivider(color = BrandLine.copy(alpha = .7f))
                    }
                }
            } else {
                item {
                    Box(Modifier.fillMaxWidth().height(90.dp), contentAlignment = Alignment.Center) {
                        EmptyState("Nenhuma venda registrada hoje.")
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HomeHistoryPill(
                        icon = Icons.Default.ReceiptLong,
                        label = "Histórico completo",
                        onClick = onSalesHistory,
                        modifier = Modifier.weight(1f),
                    )
                    HomeHistoryPill(
                        icon = Icons.Default.History,
                        label = "Histórico de envios",
                        onClick = onHistory,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            color = Color.White,
            shadowElevation = 8.dp,
        ) {
            Button(
                onClick = onSend,
                enabled = canSend,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .navigationBarsPadding()
                    .heightIn(min = 56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
            ) {
                Icon(Icons.Default.Send, null, modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(9.dp))
                Text(if (pending.isEmpty()) "Enviar vendas ao Santana Gestão" else "Enviar ${saleCountText(pending.size)} ao Santana Gestão")
            }
        }
    }
}

@Composable
private fun HomeHistoryPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.heightIn(min = 50.dp).clickable(onClick = onClick),
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, BrandLine),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(icon, null, tint = BrandMuted, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text(
                label,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = BrandInk,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ClientPicker(store: SellerStore, revision: Int, onSelect: (SellerClient) -> Unit, onNew: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val all = remember(revision) { store.clients() }
    val filtered = remember(query, all) {
        val needle = searchable(query)
        val digits = needle.filter(Char::isDigit)
        if (needle.isBlank()) all else all.filter {
            searchable(it.name).contains(needle) ||
                searchable(it.location).contains(needle) ||
                (digits.isNotBlank() && it.phone.filter(Char::isDigit).contains(digits))
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color.White),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                placeholder = { Text("Nome, local ou telefone") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = BrandSurfaceSoft,
                    unfocusedContainerColor = BrandSurfaceSoft,
                    focusedBorderColor = BrandPink,
                    unfocusedBorderColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onNew).padding(vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(46.dp).background(BrandPinkSoft, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Add, null, tint = BrandPinkDark, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.width(14.dp))
                Text("Cadastrar novo cliente", color = BrandPinkDark, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyLarge)
            }
        }
        if (filtered.isEmpty()) item { EmptyState("Cliente não encontrado. Cadastre um novo.") }
        filtered.groupBy { clientSectionLetter(it.name) }.forEach { (letter, clients) ->
            item(key = "section-$letter") {
                Row(
                    Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(letter, fontWeight = FontWeight.Bold, color = BrandMuted)
                    Spacer(Modifier.width(12.dp))
                    HorizontalDivider(modifier = Modifier.weight(1f), color = BrandLine)
                }
            }
            items(clients, key = { it.syncId }) { client ->
                val parts = clientDisplayParts(client.name, client.location)
                Column(Modifier.fillMaxWidth().clickable { onSelect(client) }) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        InitialAvatar(parts.first, client.syncId, 46)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                parts.first,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            val secondary = when {
                                parts.second.isNotBlank() -> parts.second
                                client.phone.isNotBlank() -> client.phone
                                else -> ""
                            }
                            if (secondary.isNotBlank()) {
                                Text(secondary, color = BrandMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        Icon(Icons.Default.KeyboardArrowRight, "Abrir venda para ${parts.first}", tint = BrandMuted)
                    }
                    HorizontalDivider(color = BrandLine.copy(alpha = .65f))
                }
            }
        }
    }
}

@Composable
private fun NewClientScreen(store: SellerStore, onSave: (SellerClient) -> Unit, onCancel: () -> Unit, onMessage: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var location by rememberSaveable { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val similar = remember(name) { store.similarClients(name) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = BrandSurfaceSoft,
        unfocusedContainerColor = BrandSurfaceSoft,
        focusedBorderColor = BrandPink,
        unfocusedBorderColor = Color.Transparent,
    )
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Color.White,
        title = { Text("Cadastrar novo cliente", color = BrandCocoa) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(120) },
                    label = { Text("Nome *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it.filter { char -> char.isDigit() || char in " ()-+" }.take(40) },
                    label = { Text("Telefone (opcional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it.take(160) },
                    label = { Text("Local ou referência (opcional)") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (similar.isNotEmpty()) {
                    Card(colors = CardDefaults.cardColors(containerColor = BrandAmberSoft)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("Nome parecido encontrado", fontWeight = FontWeight.SemiBold, color = BrandCocoa)
                            similar.take(3).forEach { client ->
                                TextButton(onClick = { onSave(client) }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Usar ${client.name}", modifier = Modifier.fillMaxWidth())
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!saving) {
                        saving = true
                        scope.launch {
                            try {
                                val client = withContext(Dispatchers.IO) { store.addClient(name, phone, location) }
                                onSave(client)
                            } catch (error: Exception) {
                                onMessage(error.message ?: "Não foi possível salvar o cliente.")
                            } finally { saving = false }
                        }
                    }
                },
                enabled = name.trim().isNotBlank() && !saving,
            ) { Text(if (saving) "Salvando…" else "Cadastrar") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancelar") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SaleScreen(
    client: SellerClient,
    editingSent: Boolean,
    saleDate: LocalDate,
    onSaleDate: (LocalDate) -> Unit,
    products: List<SellerProduct>,
    onSelectProduct: (SellerProduct) -> Unit,
    saleItems: List<SellerSaleItem>,
    onDecrease: (Int) -> Unit,
    onIncrease: (Int) -> Unit,
    onRemoveItem: (Int) -> Unit,
    onPrice: (Int) -> Unit,
    totalCents: Long,
    paidOnSpot: Boolean?,
    paymentMethod: String?,
    onPaid: (Boolean) -> Unit,
    onPaymentMethod: (String) -> Unit,
    onChangeClient: () -> Unit,
    cancelLabel: String,
    onCancelSale: () -> Unit,
    onContinue: () -> Unit,
) {
    var choosingProduct by remember { mutableStateOf(false) }
    var productQuery by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current

    fun openDatePicker() {
        DatePickerDialog(
            context,
            { _, year, month, day -> onSaleDate(LocalDate.of(year, month + 1, day)) },
            saleDate.year,
            saleDate.monthValue - 1,
            saleDate.dayOfMonth,
        ).apply { datePicker.maxDate = System.currentTimeMillis() }.show()
    }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 156.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (editingSent) item {
                Card(colors = CardDefaults.cardColors(containerColor = BrandAmberSoft)) {
                    Text(
                        "Esta venda já foi preparada ou enviada. Qualquer alteração vira uma correção e precisa ser enviada novamente.",
                        modifier = Modifier.padding(12.dp),
                    )
                }
            }
            item { ClientHeader(client, onChangeClient) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Data da venda", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { openDatePicker() },
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BrandLine),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Default.CalendarMonth, null, tint = BrandMuted, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(formatSaleDate(saleDate), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                            Icon(Icons.Default.KeyboardArrowDown, "Escolher data", tint = BrandMuted)
                        }
                    }
                }
            }
            item { Text("Produtos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            if (saleItems.isEmpty()) {
                item { Text("Nenhum produto adicionado.", color = BrandMuted) }
            } else {
                items(saleItems.size, key = { index -> saleItems[index].productSyncId }) { index ->
                    val row = saleItems[index]
                    val avatar = avatarColors(row.productSyncId)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BrandLine),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(48.dp).background(avatar.first, CircleShape), contentAlignment = Alignment.Center) {
                                    Text(initials(row.name).take(1), color = avatar.second, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(row.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Row(
                                        Modifier.clickable { onPrice(index) }.padding(top = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(ExchangeCodec.formatCents(row.unitPriceCents), color = BrandMuted)
                                        Text(" • ", color = BrandMuted)
                                        Icon(Icons.Default.Edit, null, tint = BrandPinkDark, modifier = Modifier.size(17.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Alterar valor", color = BrandPinkDark, fontWeight = FontWeight.Medium)
                                    }
                                }
                                IconButton(onClick = { onRemoveItem(index) }, modifier = Modifier.size(48.dp)) {
                                    Icon(Icons.Default.DeleteOutline, "Remover ${row.name}", tint = BrandMuted)
                                }
                            }
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(22.dp),
                                    color = BrandPinkSoft,
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { onDecrease(index) }, enabled = row.quantity > 1, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Default.Remove, "Diminuir ${row.name}", tint = BrandPinkDark)
                                        }
                                        Text(
                                            row.quantity.toString(),
                                            modifier = Modifier.weight(1f),
                                            fontWeight = FontWeight.Bold,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        )
                                        IconButton(onClick = { onIncrease(index) }, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Default.Add, "Aumentar ${row.name}", tint = BrandPinkDark)
                                        }
                                    }
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(
                                    modifier = Modifier.width(144.dp),
                                    horizontalAlignment = Alignment.End,
                                ) {
                                    Text("Subtotal", color = BrandMuted, style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        ExchangeCodec.formatCents(row.subtotalCents),
                                        fontWeight = FontWeight.Bold,
                                        color = BrandGreen,
                                        style = MaterialTheme.typography.titleLarge,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.End,
                                    )
                                }
                            }
                        }
                    }
                }
            }
            item {
                OutlinedButton(
                    onClick = { choosingProduct = true },
                    enabled = products.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrandPink),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandPinkDark),
                ) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(if (products.isEmpty()) "Catálogo de produtos indisponível" else if (saleItems.isEmpty()) "Adicionar produto" else "Adicionar outro produto")
                }
            }
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = BrandPinkSoft.copy(alpha = .34f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BrandPinkSoft),
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp),
                    ) {
                        Text(
                            "Vai pagar agora?",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = BrandInk,
                        )
                        Text(
                            "Escolha se a venda ficará pendente ou paga na hora.",
                            style = MaterialTheme.typography.bodySmall,
                            color = BrandMuted,
                        )
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            PaymentBinaryOption(
                                label = "Não",
                                selected = paidOnSpot == false,
                                onClick = { onPaid(false) },
                                modifier = Modifier.weight(1f),
                            )
                            PaymentBinaryOption(
                                label = "Sim",
                                selected = paidOnSpot == true,
                                onClick = { onPaid(true) },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        when (paidOnSpot) {
                            false -> Text(
                                "Vai ficar pendente. Toque em Sim se recebeu agora.",
                                style = MaterialTheme.typography.bodySmall,
                                color = BrandMuted,
                            )
                            true -> {
                                Text("Como o cliente pagou?", color = BrandMuted, modifier = Modifier.padding(top = 2.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    CompactChoice("PIX", paymentMethod == "PIX", { onPaymentMethod("PIX") }, Modifier.weight(1f))
                                    CompactChoice("Dinheiro", paymentMethod == "Dinheiro", { onPaymentMethod("Dinheiro") }, Modifier.weight(1f))
                                    CompactChoice("Cartão", paymentMethod == "Cartão", { onPaymentMethod("Cartão") }, Modifier.weight(1f))
                                }
                            }
                            null -> Text(
                                "Escolha Não ou Sim para continuar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = BrandMuted,
                            )
                        }
                    }
                }
            }
            item {
                HorizontalDivider(color = BrandLine)
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Total", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(ExchangeCodec.formatCents(totalCents), style = MaterialTheme.typography.headlineMedium, color = BrandGreen, fontWeight = FontWeight.Bold)
                }
            }
            item {
                TextButton(onClick = onCancelSale, modifier = Modifier.fillMaxWidth()) {
                    Text(cancelLabel, color = BrandPinkDark)
                }
            }
        }

        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            color = Color.White,
            shadowElevation = 8.dp,
        ) {
            Button(
                onClick = onContinue,
                enabled = saleItems.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).navigationBarsPadding().heightIn(min = 56.dp),
                shape = RoundedCornerShape(18.dp),
            ) { Text("Revisar venda • ${ExchangeCodec.formatCents(totalCents)}") }
        }
    }

    if (choosingProduct) {
        val filteredProducts = remember(productQuery, products) {
            val query = searchable(productQuery)
            if (query.isBlank()) products else products.filter { searchable(it.name).contains(query) }
        }
        AlertDialog(
            onDismissRequest = { choosingProduct = false; productQuery = "" },
            containerColor = Color.White,
            title = { Text("Adicionar produto", color = BrandCocoa) },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 500.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = productQuery,
                        onValueChange = { productQuery = it.take(80) },
                        placeholder = { Text("Buscar produto") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = BrandSurfaceSoft,
                            unfocusedContainerColor = BrandSurfaceSoft,
                            focusedBorderColor = BrandPink,
                            unfocusedBorderColor = Color.Transparent,
                        ),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
                        if (filteredProducts.isEmpty()) item { EmptyState("Produto não encontrado.") }
                        items(filteredProducts, key = { it.syncId }) { product ->
                            val alreadyAdded = saleItems.any { it.productSyncId == product.syncId }
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    onSelectProduct(product)
                                    choosingProduct = false
                                    productQuery = ""
                                }.padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                val avatar = avatarColors(product.syncId)
                                Box(Modifier.size(40.dp).background(avatar.first, CircleShape), contentAlignment = Alignment.Center) {
                                    Text(initials(product.name).take(1), color = avatar.second, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(product.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(ExchangeCodec.formatCents(product.unitPriceCents), color = BrandGreen, style = MaterialTheme.typography.bodySmall)
                                }
                                if (alreadyAdded) Icon(Icons.Default.CheckCircle, "Já está na venda", tint = BrandPinkDark)
                            }
                            HorizontalDivider(color = BrandLine.copy(alpha = .65f))
                        }
                    }
                }
            },
            confirmButton = { },
            dismissButton = { TextButton(onClick = { choosingProduct = false; productQuery = "" }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun PaymentBinaryOption(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.heightIn(min = 46.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (selected) BrandPink else BrandSurfaceSoft,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (selected) BrandPink else BrandLine,
        ),
    ) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
            Text(
                label,
                fontWeight = FontWeight.Bold,
                color = if (selected) Color.White else BrandInk,
            )
        }
    }
}

@Composable
private fun PaymentChoiceCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    selectedColor: Color,
    selectedBackground: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.heightIn(min = 104.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) selectedBackground.copy(alpha = .72f) else Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) selectedColor else BrandLine),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).background(if (selected) selectedBackground else BrandSurfaceSoft, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = if (selected) selectedColor else BrandMuted, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, maxLines = 2)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = BrandMuted, maxLines = 2)
            }
            SelectionDot(selected = selected, color = selectedColor)
        }
    }
}

@Composable
private fun SelectionDot(selected: Boolean, color: Color) {
    Surface(
        modifier = Modifier.size(22.dp),
        shape = CircleShape,
        color = Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(2.dp, if (selected) color else BrandLine),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (selected) Box(Modifier.size(10.dp).background(color, CircleShape))
        }
    }
}

@Composable
private fun ReviewScreen(
    client: SellerClient,
    items: List<SellerSaleItem>,
    paidOnSpot: Boolean,
    receivedCents: Long,
    paymentMethod: String?,
    saleDate: LocalDate,
    saleTimeKnown: Boolean,
    saving: Boolean,
    onCorrect: () -> Unit,
    cancelLabel: String,
    onCancelSale: () -> Unit,
    onConfirm: () -> Unit,
) {
    Box(Modifier.fillMaxSize().background(Color.White)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 118.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { ClientHeader(client, null) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Resumo da venda", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Data da venda: ${formatSaleDate(saleDate)}", color = BrandMuted)
                    if (!saleTimeKnown) Text("Horário não informado para esta venda retroativa.", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                }
            }
            item {
                SectionCard {
                    items.forEach { row -> ReviewLine("${row.quantity} × ${row.name}", ExchangeCodec.formatCents(row.subtotalCents)) }
                    HorizontalDivider(color = BrandLine)
                    ReviewLine("Total", ExchangeCodec.formatCents(items.sumOf { it.subtotalCents }), emphasize = true)
                    ReviewLine("Recebido", ExchangeCodec.formatCents(receivedCents))
                    ReviewLine("Saldo", ExchangeCodec.formatCents(items.sumOf { it.subtotalCents } - receivedCents))
                }
            }
            item {
                val paidText = if (paidOnSpot) "Pago na hora • $paymentMethod" else "Vai pagar depois"
                val color = if (paidOnSpot) BrandGreenSoft else BrandAmberSoft
                Card(colors = CardDefaults.cardColors(containerColor = color)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (paidOnSpot) Icons.Default.CheckCircle else Icons.Default.History, null, tint = if (paidOnSpot) BrandGreen else BrandAmber)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(paidText, fontWeight = FontWeight.SemiBold)
                            if (!paidOnSpot) Text("O valor ficará pendente.", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                        }
                    }
                }
            }
            item {
                OutlinedButton(onClick = onCorrect, enabled = !saving, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Icon(Icons.Default.Edit, null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp)); Text("Editar venda")
                }
                TextButton(onClick = onCancelSale, enabled = !saving, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Text(cancelLabel, color = BrandPinkDark)
                }
            }
        }
        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            color = Color.White,
            shadowElevation = 8.dp,
        ) {
            Button(
                onClick = onConfirm,
                enabled = !saving,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).navigationBarsPadding().heightIn(min = 56.dp),
            ) { Text(if (saving) "Salvando…" else "Confirmar venda") }
        }
    }
}

@Composable
private fun SaleSavedScreen(
    sale: SellerSale,
    onShareReceipt: (SellerSale) -> Unit,
    onContinue: () -> Unit,
    onNewSale: () -> Unit,
) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = BrandGreenSoft)) {
                Column(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Default.CheckCircle, null, tint = BrandGreen, modifier = Modifier.size(44.dp))
                    Text(if (sale.revision > 1) "Corrigida — precisa reenviar" else "Venda anotada!", style = MaterialTheme.typography.headlineMedium, color = BrandCocoa)
                    Text(sale.clientNameSnapshot, fontWeight = FontWeight.SemiBold)
                    val rows = sale.items.ifEmpty { listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents)) }
                    rows.forEach { row -> Text("${row.quantity} × ${row.name}", color = BrandMuted) }
                    Text("Total  ${ExchangeCodec.formatCents(sale.totalCents)}", color = BrandGreen, fontWeight = FontWeight.Bold)
                    Text(
                        if (sale.receivedCents == 0L) "Vai pagar depois" else if (sale.receivedCents == sale.totalCents) "Pago na hora • ${sale.paymentMethod}" else "Parcial • ${sale.paymentMethod}",
                        color = if (sale.paidOnSpot) BrandGreen else BrandAmber,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(sale.displayId, style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                    val sendStatus = saleSendStatus(sale)
                    StatusPill(sendStatus.first, sendStatus.second)
                }
            }
        }
        item {
            Button(onClick = onNewSale, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Registrar outra venda")
            }
        }
        item {
            OutlinedButton(onClick = { onShareReceipt(sale) }, modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)) {
                Text("Enviar comprovante ao cliente")
            }
        }
        item {
            Text(
                "Para enviar esta venda ao Santana Gestão, volte para Hoje e toque em Enviar.",
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                style = MaterialTheme.typography.bodySmall,
                color = BrandMuted,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
        item {
            TextButton(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("Voltar para Hoje") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SendDayScreen(
    store: SellerStore,
    revision: Int,
    onEdit: (SellerSale) -> Unit,
    creatingBatch: Boolean,
    linkedToSantana: Boolean,
    onText: () -> Unit,
    onImage: () -> Unit,
    onQr: () -> Unit,
) {
    val allSales = remember(revision) { store.localSales() }
    val sales = remember(allSales) { allSales.take(20) }
    val olderCount = sales.count { millisDate(it.soldAt) != LocalDate.now() }
    var showSendOptions by rememberSaveable { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color.White)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (!linkedToSantana) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = BrandAmberSoft)) {
                        Text(
                            "Antes do primeiro envio, abra Configurações e atualize os dados do Santana Gestão.",
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            color = BrandCocoa,
                        )
                    }
                }
            }

            if (allSales.size > sales.size) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = BrandAmberSoft)) {
                        Text(
                            "Este envio levará ${sales.size} vendas. As ${allSales.size - sales.size} restantes continuarão pendentes para o próximo envio.",
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            color = BrandCocoa,
                        )
                    }
                }
            }

            if (sales.isNotEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = if (olderCount > 0) BrandAmberSoft.copy(alpha = .78f) else BrandBlueSoft.copy(alpha = .65f),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(44.dp).background(Color.White.copy(alpha = .55f), CircleShape),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    if (olderCount > 0) Icons.Default.History else Icons.Default.Send,
                                    null,
                                    tint = if (olderCount > 0) BrandAmber else BrandBlue,
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${saleCountText(sales.size)} pendentes",
                                    fontWeight = FontWeight.Bold,
                                    color = BrandInk,
                                )
                                if (olderCount > 0) {
                                    Text(
                                        "$olderCount ${if (olderCount == 1) "é de dia anterior" else "são de dias anteriores"} e também ${if (olderCount == 1) "entrará" else "entrarão"} neste envio.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = BrandMuted,
                                    )
                                } else {
                                    Text("Prontas para enviar ao Santana Gestão.", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    ExchangeCodec.formatCents(sales.sumOf { it.totalCents }),
                                    color = BrandGreen,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Text("total", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                            }
                        }
                    }
                }
            }

            if (sales.isEmpty()) {
                item { EmptyState("Nenhuma venda aguardando envio.") }
            }

            sales.groupBy { millisDate(it.soldAt) }.forEach { (date, datedSales) ->
                item(key = "pending-date-$date") {
                    Text(
                        formatDateHeading(date),
                        fontWeight = FontWeight.Bold,
                        color = BrandCocoa,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                items(datedSales, key = { it.externalSaleId }) { sale ->
                    Column(Modifier.fillMaxWidth()) {
                        SaleRow(
                            sale = sale,
                            editable = true,
                            onEdit = { onEdit(sale) },
                            showSendStatus = true,
                        )
                        HorizontalDivider(color = BrandLine.copy(alpha = .75f))
                    }
                }
            }
        }

        if (sales.isNotEmpty()) {
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
                color = Color.White,
                shadowElevation = 8.dp,
            ) {
                Button(
                    onClick = { showSendOptions = true },
                    enabled = linkedToSantana && !creatingBatch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .navigationBarsPadding()
                        .heightIn(min = 56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                ) {
                    Icon(Icons.Default.Send, null, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (creatingBatch) "Preparando…" else "Enviar", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }

    if (showSendOptions) {
        ModalBottomSheet(
            onDismissRequest = { showSendOptions = false },
            containerColor = Color.White,
        ) {
            Column(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 16.dp).navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("Como deseja enviar?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = BrandInk)
                Text(
                    "Escolha uma das opções abaixo.",
                    color = BrandMuted,
                    modifier = Modifier.padding(bottom = 4.dp),
                )

                SendMethodRow(
                    icon = Icons.Default.Send,
                    iconBackground = BrandBlueSoft,
                    iconTint = BrandBlue,
                    title = "Enviar arquivo .edi",
                    subtitle = "Forma principal para registrar no Santana Gestão",
                    recommended = true,
                    onClick = {
                        showSendOptions = false
                        onText()
                    },
                )
                SendMethodRow(
                    icon = Icons.Default.ImageIcon,
                    iconBackground = BrandPinkSoft,
                    iconTint = BrandPinkDark,
                    title = "Compartilhar resumo em imagem",
                    subtitle = "Para conferência ou apoio no WhatsApp",
                    onClick = {
                        showSendOptions = false
                        onImage()
                    },
                )
                SendMethodRow(
                    icon = Icons.Default.QrCode2,
                    iconBackground = BrandGreenSoft,
                    iconTint = BrandGreen,
                    title = "Mostrar QR Code",
                    subtitle = "Ler no Santana Gestão quando os aparelhos estiverem juntos",
                    onClick = {
                        showSendOptions = false
                        onQr()
                    },
                )
            }
        }
    }
}

@Composable
private fun SendMethodRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBackground: Color,
    iconTint: Color,
    title: String,
    subtitle: String,
    recommended: Boolean = false,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = if (recommended) BrandBlueSoft.copy(alpha = .28f) else Color.White,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (recommended) BrandBlue.copy(alpha = .35f) else BrandLine,
        ),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).background(iconBackground, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = iconTint, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = BrandInk)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = BrandMuted)
            }
            Icon(Icons.Default.KeyboardArrowRight, null, tint = BrandMuted)
        }
    }
}

@Composable
private fun SalesHistoryScreen(store: SellerStore, revision: Int, onEdit: (SellerSale) -> Unit) {
    val sales = remember(revision) { store.sales().filterNot { it.cancelled } }
    var detail by remember { mutableStateOf<SellerSale?>(null) }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color.White),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
    ) {
        if (sales.isEmpty()) item { EmptyState("Nenhuma venda registrada.") }
        if (sales.isNotEmpty()) item(key = "history-summary") {
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "${saleCountText(sales.size)} • ${ExchangeCodec.formatCents(sales.sumOf { it.totalCents })}",
                    color = BrandMuted,
                )
            }
            HorizontalDivider(color = BrandLine.copy(alpha = .7f))
        }
        sales.groupBy { millisDate(it.soldAt) }.forEach { (date, datedSales) ->
            item(key = "history-date-$date") {
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(formatDateHeading(date), fontWeight = FontWeight.Bold)
                    Text("${saleCountText(datedSales.size)} • ${ExchangeCodec.formatCents(datedSales.sumOf { it.totalCents })}", color = BrandMuted)
                }
            }
            items(datedSales, key = { it.externalSaleId }) { sale ->
                Column {
                    SaleRow(sale, editable = false, onEdit = { }, showSendStatus = true)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { detail = sale }) { Text("Ver detalhes") }
                        TextButton(onClick = { onEdit(sale) }) {
                            Icon(Icons.Default.Edit, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Editar")
                        }
                    }
                    HorizontalDivider(color = BrandLine.copy(alpha = .7f))
                }
            }
        }
    }
    detail?.let { SaleDetailDialog(it, onDismiss = { detail = null }) }
}

@Composable
private fun HistoryScreen(
    store: SellerStore,
    revision: Int,
    onShare: (SellerBatch, BatchShareKind) -> Unit,
    onEditSent: (SellerSale) -> Unit,
) {
    val batches = remember(revision) { store.batches() }
    val currentSales = remember(revision) { store.sales().associateBy { it.externalSaleId } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color.White),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (batches.isEmpty()) item { EmptyState("Nenhum envio foi preparado ainda.") }
        items(batches, key = { it.batchId }) { batch ->
            var expanded by remember(batch.batchId) { mutableStateOf(batch.batchId == batches.firstOrNull()?.batchId) }
            var showAll by remember(batch.batchId) { mutableStateOf(false) }
            val hasNewerRevision = batch.sales.any { frozen ->
                currentSales[frozen.externalSaleId]?.revision?.let { it > frozen.revision } == true
            }
            val statusText = if (batch.sharedAt != null) "Envio confirmado" else "Ainda não confirmado"
            val statusColor = if (batch.sharedAt != null) BrandGreenSoft else BrandBlueSoft
            val dates = batch.sales.map { millisDate(it.soldAt) }.distinct().sorted()
            val period = when (dates.size) {
                0 -> formatSaleDateText(batch.saleDate)
                1 -> formatSaleDate(dates.single())
                else -> "${formatSaleDate(dates.first())} a ${formatSaleDate(dates.last())}"
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, BrandLine),
            ) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(formatBatchDate(batch.createdAt), modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        StatusPill(statusText, statusColor)
                        IconButton(onClick = { expanded = !expanded }) {
                            Icon(
                                if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                if (expanded) "Recolher lote" else "Abrir lote",
                                tint = BrandMuted,
                            )
                        }
                    }
                    Text("${saleCountText(batch.sales.size)} • ${ExchangeCodec.formatCents(batch.totalCents)}", color = BrandMuted, style = MaterialTheme.typography.bodyLarge)
                    Text("Recebido na hora: ${ExchangeCodec.formatCents(batch.paidOnSpotCents)}", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                    Text("Vendas de $period", style = MaterialTheme.typography.bodySmall, color = BrandMuted)

                    if (expanded) {
                        HorizontalDivider(color = BrandLine)
                        val visibleSales = if (showAll) batch.sales else batch.sales.take(5)
                        visibleSales.forEach { frozen ->
                            val current = currentSales[frozen.externalSaleId]
                            val parts = clientDisplayParts(frozen.clientNameSnapshot, frozen.clientLocationSnapshot)
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    if (parts.second.isBlank()) parts.first else "${parts.first} • ${parts.second}",
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(ExchangeCodec.formatCents(frozen.totalCents), fontWeight = FontWeight.SemiBold)
                                current?.takeIf { !it.cancelled }?.let { sale ->
                                    Spacer(Modifier.width(8.dp))
                                    TextButton(onClick = { onEditSent(sale) }) { Text("Editar") }
                                }
                            }
                            HorizontalDivider(color = BrandLine.copy(alpha = .7f))
                        }
                        TextButton(onClick = {
                            if (batch.sales.size <= 5) expanded = false else showAll = !showAll
                        }) {
                            Text(
                                when {
                                    batch.sales.size <= 5 -> "Ocultar vendas"
                                    showAll -> "Mostrar menos"
                                    else -> "Ver ${saleCountText(batch.sales.size)}"
                                },
                                color = BrandPinkDark,
                            )
                            Spacer(Modifier.width(3.dp))
                            Icon(
                                if (showAll || batch.sales.size <= 5) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                null,
                                tint = BrandPinkDark,
                            )
                        }
                        if (hasNewerRevision) {
                            Card(colors = CardDefaults.cardColors(containerColor = BrandPinkSoft)) {
                                Text(
                                    "Há uma correção mais recente. Envie a versão atual pela tela Hoje; este lote antigo não pode ser reenviado.",
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BrandCocoa,
                                )
                            }
                        }
                        Button(
                            onClick = { onShare(batch, BatchShareKind.TEXT) },
                            enabled = !hasNewerRevision,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        ) {
                            Icon(Icons.Default.Send, null, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(if (hasNewerRevision) "Lote antigo" else "Reenviar lote")
                        }
                    } else {
                        TextButton(onClick = { expanded = true }) {
                            Text("Ver ${saleCountText(batch.sales.size)}", color = BrandPinkDark)
                            Spacer(Modifier.width(3.dp))
                            Icon(Icons.Default.KeyboardArrowDown, null, tint = BrandPinkDark)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    store: SellerStore,
    revision: Int,
    onRevision: () -> Unit,
    onMessage: (String) -> Unit,
) {
    val config = remember(revision) { store.config() } ?: return
    var sellerName by remember(config) { mutableStateOf(config.sellerName) }
    var productName by remember(config) { mutableStateOf(config.productName) }
    var price by remember(config) { mutableStateOf(centsToInput(config.unitPriceCents)) }
    var pendingBackupText by remember { mutableStateOf<String?>(null) }
    var pendingBackupPreview by remember { mutableStateOf<br.com.edivendas.data.SellerBackupPreview?>(null) }
    var restoringBackup by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val saveBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val content = withContext(Dispatchers.IO) { store.exportBackup() }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
                            ?: throw UserVisibleException("Não foi possível abrir o local escolhido.")
                        store.markBackupSaved()
                    }
                    onRevision()
                    onMessage("Backup salvo com sucesso.")
                } catch (error: Exception) { onMessage(error.message ?: "Não foi possível salvar o backup.") }
            }
        }
    }
    val restoreBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !restoringBackup) {
            restoringBackup = true
            scope.launch {
                try {
                    val content = withContext(Dispatchers.IO) { readTextLimited(context, uri, 8_000_000) }
                    val preview = withContext(Dispatchers.Default) { store.previewBackup(content) }
                    pendingBackupPreview = preview
                    pendingBackupText = content
                } catch (error: Exception) {
                    onMessage(error.message ?: "Não foi possível restaurar o backup.")
                } finally { restoringBackup = false }
            }
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            SectionCard {
                Text("Dados da vendedora", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(sellerName, { sellerName = it.take(60) }, label = { Text("Nome") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (config.baseVersion == 0L) {
                    OutlinedTextField(productName, { productName = it.take(120) }, label = { Text("Produto padrão") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        price,
                        { price = moneyInput(it) },
                        label = { Text("Preço padrão") }, prefix = { Text("R$ ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    Text("Produtos e preços vêm do catálogo do Santana Gestão.", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                }
                Button(
                    onClick = {
                        try { store.updateConfig(sellerName, productName, parseMoney(price)); onRevision(); onMessage("Configurações salvas.") }
                        catch (error: Exception) { onMessage(error.message ?: "Confira os dados.") }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) { Text("Salvar alterações") }
            }
        }
        item {
            SectionCard {
                Text("Produto principal", style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(BrandGreenSoft, CircleShape), contentAlignment = Alignment.Center) {
                        Text(config.productName.take(1).uppercase(), color = BrandGreen, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(config.productName, fontWeight = FontWeight.SemiBold)
                        Text(ExchangeCodec.formatCents(config.unitPriceCents), color = BrandGreen)
                    }
                }
                Text("Adicionado automaticamente ao começar uma nova venda.", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
            }
        }
        item {
            SectionCard {
                Text("Clientes", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (config.baseVersion > 0L) {
                        "${clientCountText(store.clients().size)} disponíveis • Catálogo vinculado"
                    } else {
                        "Catálogo do Santana ainda não atualizado"
                    },
                    color = if (config.baseVersion > 0L) BrandMuted else BrandDanger,
                )
                OutlinedButton(
                    onClick = {
                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val content = clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                        scope.launch {
                            try {
                                val result = withContext(Dispatchers.Default) { store.importCatalog(content) }
                                onRevision()
                                onMessage("${result.clientCount} clientes atualizados • produto ${result.productName}.")
                            } catch (error: Exception) { onMessage(error.message ?: "Não consegui ler o catálogo copiado.") }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) { Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("Atualizar dados do Santana Gestão") }
            }
        }
        item {
            SectionCard {
                Text("Backup manual", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Guarde uma cópia das configurações, clientes, produtos, vendas e histórico de envios.",
                    style = MaterialTheme.typography.bodySmall,
                    color = BrandMuted,
                )
                Text(
                    "Último backup: ${store.lastBackupAt()?.let(::formatDateTime) ?: "ainda não realizado"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = BrandMuted,
                )
                Button(
                    onClick = {
                        val date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)
                        saveBackup.launch("EdiVendas_Backup_$date.json")
                    },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Salvar backup")
                }
                OutlinedButton(
                    onClick = { restoreBackup.launch(arrayOf("application/json", "text/plain", "*/*")) },
                    enabled = !restoringBackup,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                ) {
                    Icon(Icons.Default.History, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (restoringBackup) "Validando backup…" else "Restaurar backup")
                }
                if (store.hasPreRestoreBackup()) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { store.restorePreRestoreBackup() }
                                    onRevision()
                                    onMessage("Estado anterior à última restauração recuperado.")
                                } catch (error: Exception) { onMessage(error.message ?: "Não foi possível recuperar o estado anterior.") }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                    ) { Text("Recuperar estado anterior à restauração") }
                }
                Text(
                    "O arquivo é validado por completo antes de substituir os dados atuais. A leitura tem limite de segurança e não bloqueia a tela.",
                    style = MaterialTheme.typography.bodySmall,
                    color = BrandMuted,
                )
            }
        }
        item {
            Text(
                "Vendas ainda não enviadas são preservadas quando a lista de clientes é atualizada.",
                style = MaterialTheme.typography.bodySmall,
                color = BrandMuted,
            )
        }
    }
    pendingBackupPreview?.let { preview ->
        AlertDialog(
            onDismissRequest = { pendingBackupPreview = null; pendingBackupText = null },
            title = { Text("Restaurar este backup?") },
            text = {
                Text(
                    "Backup de ${if (preview.createdAt > 0L) formatDateTime(preview.createdAt) else "data desconhecida"}\n" +
                        "${clientCountText(preview.clientCount)} • ${saleCountText(preview.saleCount)} • ${preview.batchCount} ${if (preview.batchCount == 1) "envio" else "envios"}\n\n" +
                        "Os dados atuais serão substituídos.",
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val content = pendingBackupText ?: return@Button
                        if (!restoringBackup) {
                            restoringBackup = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { store.importBackup(content) }
                                    pendingBackupPreview = null
                                    pendingBackupText = null
                                    onRevision()
                                    onMessage("Backup restaurado com sucesso.")
                                } catch (error: Exception) {
                                    onMessage(error.message ?: "Não foi possível restaurar o backup.")
                                } finally { restoringBackup = false }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandDanger),
                ) { Text("Substituir dados") }
            },
            dismissButton = { TextButton(onClick = { pendingBackupPreview = null; pendingBackupText = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = BrandSurface), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

private fun clientDisplayParts(name: String, location: String): Pair<String, String> {
    val cleanName = name.trim()
    val cleanLocation = location.trim()
    val slash = cleanName.indexOf('/')
    return if (slash > 0 && slash < cleanName.lastIndex) {
        val person = cleanName.substring(0, slash).trim().ifBlank { cleanName }
        val embeddedLocation = cleanName.substring(slash + 1).trim()
        person to cleanLocation.ifBlank { embeddedLocation }
    } else {
        cleanName to cleanLocation
    }
}

@Composable
private fun ClientHeader(client: SellerClient, onChange: (() -> Unit)?) {
    val parts = clientDisplayParts(client.name, client.location)
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            InitialAvatar(parts.first, client.syncId, 54)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(parts.first, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = BrandInk)
                val secondary = parts.second.ifBlank { client.phone.trim() }
                if (secondary.isNotBlank()) Text(secondary, color = BrandMuted, style = MaterialTheme.typography.bodyLarge)
            }
            onChange?.let { TextButton(onClick = it) { Text("Trocar", color = BrandPinkDark) } }
        }
        HorizontalDivider(color = BrandLine.copy(alpha = .7f))
    }
}

@Composable
private fun InitialAvatar(name: String, stableId: String, sizeDp: Int = 40) {
    val colors = avatarColors(stableId)
    Box(Modifier.size(sizeDp.dp).background(colors.first, CircleShape), contentAlignment = Alignment.Center) {
        Text(initials(name), color = colors.second, fontWeight = FontWeight.Bold)
    }
}

private fun avatarColors(stableId: String): Pair<Color, Color> {
    val palette = listOf(
        Color(0xFFFCE8F0) to Color(0xFF9A1C52),
        Color(0xFFE2F2FF) to Color(0xFF176A9A),
        Color(0xFFE2F4E8) to Color(0xFF237A4B),
        Color(0xFFF0E8FF) to Color(0xFF6842A0),
        Color(0xFFFFEBCB) to Color(0xFF8A5A00),
        Color(0xFFFFE3DE) to Color(0xFF9B3D2E),
    )
    return palette[(stableId.hashCode() and Int.MAX_VALUE) % palette.size]
}

@Composable
private fun SaleRow(sale: SellerSale, editable: Boolean, onEdit: () -> Unit, showSendStatus: Boolean = false) {
    val parts = clientDisplayParts(sale.clientNameSnapshot, sale.clientLocationSnapshot)
    Row(
        modifier = Modifier.fillMaxWidth().then(if (editable) Modifier.clickable(onClick = onEdit) else Modifier).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(44.dp).background(if (sale.paidOnSpot) BrandGreenSoft else BrandAmberSoft, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.ShoppingCart, null, tint = if (sale.paidOnSpot) BrandGreen else BrandAmber, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(parts.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (parts.second.isNotBlank()) Text(parts.second, color = BrandMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val units = sale.items.ifEmpty { listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents)) }.sumOf { it.quantity }
            val financial = when (sale.receivedCents) {
                0L -> "Vai pagar depois"
                sale.totalCents -> "Pago na hora • ${sale.paymentMethod}"
                else -> "Parcial ${ExchangeCodec.formatCents(sale.receivedCents)} • ${sale.paymentMethod}"
            }
            Text("$units un. • $financial", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (sale.saleTimeKnown) formatSaleTime(sale.soldAt) else "Horário não informado", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                if (showSendStatus) {
                    val status = saleSendStatus(sale)
                    StatusPill(status.first, status.second)
                }
            }
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(ExchangeCodec.formatCents(sale.totalCents), fontWeight = FontWeight.Bold, color = BrandGreen, style = MaterialTheme.typography.titleMedium)
            if (editable) Icon(Icons.Default.Edit, "Editar venda", tint = BrandMuted, modifier = Modifier.size(22.dp))
        }
    }
}

private fun clientSectionLetter(name: String): String {
    val normalized = searchable(name)
    val first = normalized.firstOrNull() ?: return "#"
    return if (first.isLetter()) first.uppercaseChar().toString() else "#"
}

private fun saleSendStatus(sale: SellerSale): Pair<String, Color> = when {
    sale.sentRevision >= sale.revision -> "Enviado" to BrandGreenSoft
    sale.sentRevision > 0 -> "Corrigida — reenviar" to BrandPinkSoft
    else -> "Não enviado" to BrandAmberSoft
}

@Composable
private fun ReviewLine(label: String, value: String, emphasize: Boolean = false) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            modifier = Modifier.weight(1f),
            color = if (emphasize) BrandInk else BrandMuted,
            fontWeight = if (emphasize) FontWeight.SemiBold else FontWeight.Normal,
        )
        Spacer(Modifier.width(10.dp))
        Text(value, fontWeight = if (emphasize) FontWeight.Bold else FontWeight.SemiBold, color = if (emphasize) BrandGreen else BrandInk)
    }
}

@Composable
private fun ChoiceButton(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier, selectedColor: Color = BrandPink) {
    if (selected) Button(onClick = onClick, modifier = modifier.heightIn(min = 48.dp), colors = ButtonDefaults.buttonColors(containerColor = selectedColor)) { Text(text) }
    else OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 48.dp)) { Text(text) }
}

@Composable
private fun CompactChoice(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.heightIn(min = 44.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = if (selected) BrandPinkSoft else Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) BrandPink else BrandLine),
    ) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
            Text(text, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, color = if (selected) BrandPinkDark else BrandInk)
        }
    }
}

@Composable
private fun StatusPill(text: String, background: Color) {
    Box(Modifier.background(background, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text(text, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun SaleDetailDialog(sale: SellerSale, onDismiss: () -> Unit) {
    val rows = sale.items.ifEmpty { listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text("Detalhes da venda", color = BrandCocoa) },
        text = {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text(sale.clientNameSnapshot, fontWeight = FontWeight.Bold) }
                item { Text("Código: ${sale.displayId.ifBlank { sale.externalSaleId.take(8) }} • revisão ${sale.revision}", style = MaterialTheme.typography.bodySmall, color = BrandMuted) }
                item {
                    val moment = Instant.ofEpochMilli(sale.soldAt).atZone(ZoneId.systemDefault())
                    Text(
                        if (sale.saleTimeKnown) "Venda: ${moment.format(DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm"))}"
                        else "Venda: ${moment.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))} • horário não informado",
                        color = BrandMuted,
                    )
                }
                if (sale.recordedAt != sale.soldAt) item { Text("Registrada: ${formatDateTime(sale.recordedAt)}", style = MaterialTheme.typography.bodySmall, color = BrandMuted) }
                item { HorizontalDivider(color = BrandLine) }
                items(rows) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${row.quantity} × ${row.name}", Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.width(8.dp))
                        Text(ExchangeCodec.formatCents(row.subtotalCents), fontWeight = FontWeight.SemiBold)
                    }
                    Text("${ExchangeCodec.formatCents(row.unitPriceCents)} cada", style = MaterialTheme.typography.bodySmall, color = BrandMuted)
                }
                item { HorizontalDivider(color = BrandLine) }
                item { ReviewLine("Total", ExchangeCodec.formatCents(sale.totalCents), emphasize = true) }
                item { ReviewLine("Recebido", ExchangeCodec.formatCents(sale.receivedCents)) }
                item { ReviewLine("Saldo", ExchangeCodec.formatCents(sale.totalCents - sale.receivedCents)) }
                item { Text("Pagamento: ${sale.paymentMethod ?: "não recebido na hora"}", color = BrandMuted) }
                item { val st = saleSendStatus(sale); StatusPill(st.first, st.second) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
    )
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = BrandMuted)
    }
}

@Composable
private fun PriceDialog(current: Long, default: Long, onDismiss: () -> Unit, onSelect: (Long) -> Unit) {
    val initial = centsToInput(current)
    var custom by remember { mutableStateOf(TextFieldValue(initial, selection = TextRange(0, initial.length))) }
    val parsed = runCatching { parseMoney(custom.text) }.getOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text("Preço desta venda") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { onSelect(default) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                    Text("Preço padrão • ${ExchangeCodec.formatCents(default)}")
                }
                OutlinedTextField(
                    value = custom,
                    onValueChange = { incoming ->
                        val cleaned = moneyInput(incoming.text)
                        custom = TextFieldValue(cleaned, selection = TextRange(cleaned.length))
                    },
                    label = { Text("Outro valor") }, prefix = { Text("R$ ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    isError = parsed == null,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = BrandSurfaceSoft,
                        unfocusedContainerColor = BrandSurfaceSoft,
                        focusedBorderColor = BrandPink,
                        unfocusedBorderColor = Color.Transparent,
                    ),
                    supportingText = if (parsed == null) ({ Text("Use um valor válido, por exemplo 10,25 ou 1.000,00.") }) else null,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = { Button(onClick = { parsed?.let(onSelect) }, enabled = parsed != null) { Text("Usar valor") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

private fun greeting(): String = when (java.time.LocalTime.now().hour) {
    in 5..11 -> "Bom dia"
    in 12..17 -> "Boa tarde"
    else -> "Boa noite"
}

private fun formatLongDate(date: LocalDate): String = date.format(
    DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM", Locale("pt", "BR"))
).replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("pt", "BR")) else it.toString() }

private fun formatDateHeading(date: LocalDate): String = when (date) {
    LocalDate.now() -> "Hoje • ${formatSaleDate(date)}"
    LocalDate.now().minusDays(1) -> "Ontem • ${formatSaleDate(date)}"
    else -> date.format(DateTimeFormatter.ofPattern("EEEE • dd/MM/yyyy", Locale("pt", "BR")))
        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("pt", "BR")) else it.toString() }
}

private fun combineDateAndTime(date: LocalDate, timeSourceMillis: Long): Long {
    val time = Instant.ofEpochMilli(timeSourceMillis).atZone(ZoneId.systemDefault()).toLocalTime()
    return date.atTime(time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
}

private fun initials(name: String): String = name.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    .mapNotNull { part -> part.firstOrNull { it.isLetterOrDigit() }?.uppercase() }
    .take(2).joinToString("").ifBlank { "?" }

private fun millisDate(millis: Long): LocalDate = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()

private fun formatBatchDate(millis: Long): String = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
    .format(DateTimeFormatter.ofPattern("dd MMM • HH:mm", Locale("pt", "BR"))).uppercase(Locale("pt", "BR"))

private fun formatSaleTime(millis: Long): String = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
    .format(DateTimeFormatter.ofPattern("HH:mm", Locale("pt", "BR")))

private fun formatDateTime(millis: Long): String = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
    .format(DateTimeFormatter.ofPattern("dd/MM/yyyy 'às' HH:mm", Locale("pt", "BR")))

private fun formatSaleDate(date: LocalDate): String = date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale("pt", "BR")))

private fun formatSaleDateText(raw: String): String = runCatching { formatSaleDate(LocalDate.parse(raw)) }.getOrDefault(raw)

private fun saleCountText(count: Int): String = if (count == 1) "1 venda" else "$count vendas"

private fun clientCountText(count: Int): String = if (count == 1) "1 cliente" else "$count clientes"

private fun unitCountText(count: Int): String = if (count == 1) "1 unidade" else "$count unidades"

private fun searchable(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
    .replace(Regex("\\p{M}+"), "")
    .lowercase(Locale.ROOT)
    .trim()

private fun safeTotal(unitPriceCents: Long, quantity: Int): Long = runCatching {
    Math.multiplyExact(unitPriceCents, quantity.toLong())
}.getOrElse { 0L }

private fun moneyInput(value: String): String = BrazilianMoney.sanitizeInput(value)

private fun parseMoney(value: String): Long = BrazilianMoney.parsePriceCents(value)

private fun parseReceived(value: String): Long = BrazilianMoney.parseReceivedCents(value)

private fun centsToInput(cents: Long): String = BrazilianMoney.centsToInput(cents)

private fun readTextLimited(context: android.content.Context, uri: android.net.Uri, maxBytes: Int): String {
    val input = context.contentResolver.openInputStream(uri) ?: throw UserVisibleException("Não foi possível abrir o arquivo escolhido.")
    input.use { stream ->
        val out = java.io.ByteArrayOutputStream(minOf(maxBytes, 64 * 1024))
        val buffer = ByteArray(16 * 1024)
        var total = 0
        while (true) {
            val read = stream.read(buffer)
            if (read < 0) break
            total += read
            if (total > maxBytes) throw UserVisibleException("O arquivo é grande demais para o Edi Vendas.")
            out.write(buffer, 0, read)
        }
        return out.toString(Charsets.UTF_8.name())
    }
}

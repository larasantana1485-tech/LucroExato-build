# Validação do Edi Vendas 1.0.14 — R15

Data: 22/09/2026

## Executado neste ambiente

1. **Checklist estático do R15** — `scripts/audit_release.py`: **74/74**. O próprio script declara que esse placar cobre somente estrutura/presença das proteções verificadas e não é homologação.
2. **Compilação JVM das classes de dados alteradas** (`Models`, `BrazilianMoney`, `ExchangeCodec`, `TextExchange`, `SellerStore`) usando stubs mínimos para Android/JSON: **passou**. Houve apenas avisos de compilador.
3. **Ensaios puros executáveis** do parser monetário, formatação em centavos e integridade V3: **12/12 passaram**.
4. **Sanidade de sintaxe Kotlin** de `EdiVendasApp.kt` e `MainActivity.kt`: o compilador não apontou erro sintático; referências Android/Compose ficaram indisponíveis fora do Gradle, como esperado.
5. **XML**: todos os 12 XMLs lidos pelo checklist foram parseados com sucesso.

## Build Android

A tentativa de `./gradlew test --offline --no-daemon` não chegou à compilação Android. O wrapper tentou obter **Gradle 8.13**, mas este ambiente não conseguiu resolver `services.gradle.org`. Por isso:

- não há APK R15 gerado/homologado nesta entrega;
- não afirmo que Compose/AGP foi compilado aqui;
- os testes JUnit adicionados ao projeto (`ExchangeCodecTest` e `BrazilianMoneyTest`) devem ser executados pelo Android Studio/CI quando as dependências estiverem disponíveis.

## Homologação ainda necessária no aparelho

Antes de usar vendas reais, conferir no Android físico:

- atualização por cima da versão já instalada preservando configuração, clientes, vendas, lotes e backup;
- Home na virada do dia e retorno do segundo plano;
- criar/editar venda multiproduto, editar preço e pagamento à vista;
- gerar arquivo `.edi`, voltar do WhatsApp, matar/reabrir o app e confirmar o lote;
- editar depois de gerar o arquivo e verificar nova revisão;
- QR de uma e várias partes;
- lote com 1, 20 e 21+ vendas;
- resumo visual multipágina no WhatsApp;
- restauração de backup e recuperação do estado anterior;
- fonte 150%/200%, tela estreita e teclado Samsung;
- catálogo com 2, 20 e 200 produtos e nomes longos.

## Compatibilidade com Santana Gestão

O conteúdo enviado entre `[EDI-BATCH-V1]` e `[/EDI-BATCH-V1]` foi preservado. O endurecimento de integridade V3 é do histórico local do Edi; não altera o formato `TextExchange.batchText()` que o Santana Gestão R101 recebe. A divergência histórica de datas anteriores a 2020 já foi corrigida no Gestão R101.

# Validação R17

## Executado neste ambiente

- `python scripts/audit_r17_flow.py`: **18/18 verificações passaram**.
- Conferência de balanceamento estrutural de `EdiVendasApp.kt`: chaves, parênteses e colchetes balanceados.
- Compilador Kotlin sem classpath Android/Compose usado apenas como verificação de parser: **nenhum diagnóstico de sintaxe** (`expecting`, `unexpected tokens`, etc.).
- Busca estática confirmou ausência do estado visual `Arquivo/QR gerado` e dos rótulos de revisão na interface principal.

## Não executado aqui

O projeto não traz `gradle-wrapper.jar` e este ambiente não possui a cadeia Android/Gradle completa em cache. Por isso, o build final APK não foi executado aqui.

No Android Studio, usar Java 17 / SDK 36 e executar **Build → Make Project** antes de instalar no aparelho.

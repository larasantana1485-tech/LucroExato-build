# R17 — fluxo de envio simplificado e venda compacta

Implementação feita sobre a R16, preservando regras de dados, revisão, backup e integração `.edi`.

## Home

- Reintroduz o botão **Compartilhar** no topo, sem remover Configurações.
- Pendências antigas voltam a ganhar aviso destacado somente quando existem.
- O aviso informa que vendas de dias anteriores entrarão no próximo envio.
- As vendas do dia exibem estado humano de envio: **Enviado**, **Não enviado** ou **Corrigida — reenviar**.
- Permanecem os atalhos de Histórico completo / Histórico de envios e o CTA azul inferior.

## Registrar venda

- A pergunta passa a ser **Vai pagar agora?**.
- As opções são **Não** e **Sim** e, em nova venda, **nenhuma fica pré-selecionada**.
- Ao escolher Sim, PIX / Dinheiro / Cartão continuam sem pré-seleção.
- Ao escolher Não, o app informa que o valor ficará pendente.
- O subtotal ficou maior, em negrito e mais alinhado à direita.
- O conteúdo ganhou folga inferior para o Total não ficar escondido pelo botão fixo.

## Revisar e enviar vendas

- Sai a pilha de três botões de envio.
- Entra **um único botão azul fixo “Enviar”**.
- Ao tocar, abre uma meia aba com as três formas:
  1. Enviar arquivo `.edi`;
  2. Compartilhar resumo em imagem;
  3. Mostrar QR Code.
- A lógica de confirmação do arquivo continua segura: abrir/gerar não marca como enviado; a confirmação acontece após a vendedora confirmar o compartilhamento.
- QR continua sendo confirmado somente após o Gestão ler todas as partes.

## Estados de envio

A interface deixa de mostrar `Arquivo/QR gerado • R1` e outros detalhes técnicos como estado principal.

- **Enviado**: a revisão atual foi confirmada como enviada.
- **Não enviado**: nenhuma revisão foi confirmada.
- **Corrigida — reenviar**: existe envio anterior, mas a revisão atual ainda não foi confirmada.

Os campos `revision`, `exportedRevision` e `sentRevision` continuam no modelo e na lógica interna para proteger a integridade da integração.

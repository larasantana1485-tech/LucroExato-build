# Edi Vendas 1.0.13 — R14

> **Documento histórico da R14.** As afirmações abaixo descrevem a intenção daquela revisão e não devem ser usadas como relatório de homologação. A auditoria de 22/09/2026 encontrou divergências que foram tratadas no R15; consulte `R15_CORRECOES_AUDITORIA.md`.

## Correções funcionais

- A Home consulta exclusivamente as vendas da data atual.
- Pendências de dias anteriores continuam disponíveis em **Revisar e enviar vendas**, sem aparecer como vendas de hoje.
- A venda agora aceita **Hoje**, **Ontem** ou **Outra data** pelo calendário.
- Ao corrigir uma venda, a data original é preservada até que a usuária a altere.
- A tela de envio calcula contagem, total e lista a partir do mesmo conjunto de até 20 vendas.
- As pendências são agrupadas por data antes do envio.
- O envio principal agora compartilha um arquivo `.edi`, em vez de publicar o conteúdo técnico como uma mensagem enorme.
- Ao retornar do WhatsApp, a confirmação explica que o arquivo deve aparecer na conversa e concluir o envio.
- Compartilhar a imagem não marca as vendas como enviadas.

## Novo layout

- Fundo branco em todo o fluxo.
- Home sem cabeçalho tradicional, com saudação, data, configuração discreta e botão grande **Registrar venda**.
- Todas as vendas de hoje aparecem em linhas, separadas por divisores finos, com status individual.
- **Histórico completo** e **Histórico de envios** aparecem como atalhos discretos após a lista.
- Botão azul de envio permanece fixo no rodapé.
- Clientes aparecem sem caixas, com avatares coloridos e divisores.
- **Cadastrar novo cliente** aparece como ação rosa sem caixa.
- Produtos usam ícones coloridos e controle de quantidade em rosa pastel.
- Seleção de produtos mantém modal branco compacto.
- A tela **Venda anotada** recebeu somente o fundo branco; estrutura e ações foram preservadas.

## Validação

- Auditoria estática: 53/53 verificações.
- A compilação automatizada não foi concluída neste ambiente porque o plugin Android `8.13.2` configurado no projeto não estava disponível no repositório remoto durante a validação.

# Especificação técnica — Edi Vendas V1

## Identidade

- Nome exibido: **Edi Vendas**
- Pacote Android: `br.com.edivendas`
- Versão piloto corrigida: `1.0.10-piloto` (`versionCode 110`)
- Ícone adaptativo: fundo creme, etiqueta cacau e cifrão rosa; sem texto dentro do ícone.

## Sistema visual

| Token | Valor |
|---|---|
| Magenta principal | `#C2185B` |
| Magenta escuro | `#941241` |
| Fundo creme | `#FFF9F2` |
| Cacau | `#3A241E` |
| Texto principal | `#17171B` |
| Texto secundário | `#575B63` |
| Verde semântico | `#237A4B` |
| Azul semântico | `#0F6FAE` |
| Âmbar semântico | `#8A5700` |
| Vermelho destrutivo | `#C62828` |

- margem lateral: `16dp`;
- distância entre seções: `12–16dp`;
- preenchimento de cards: `14–16dp`;
- botão principal: mínimo `48dp`;
- alvo mínimo de toque: `48 × 48dp`;
- cantos de cards: `14dp`;
- título principal: `22sp` semibold;
- título de tela: `20sp` semibold;
- título de seção: `16sp` semibold;
- corpo: `14–16sp`;
- texto secundário: `12sp`.

## Persistência

Os dados são locais em `SharedPreferences` JSON, isolados do Santana Gestão:

- configuração da vendedora;
- identificador persistente do aparelho;
- espelho mínimo de clientes;
- vendas locais;
- lotes gerados.

Uma atualização de base nunca apaga vendas locais ainda não enviadas.

## Intercâmbio

### Entrada do catálogo

- mensagem de texto entre `[EDI-CATALOG-V1]` ou `[EDI-CATALOG-V2]` e seu marcador final;
- V2 usa `gzip-base64`, tamanho original e SHA-256 para detectar cortes;
- valida `businessId`, clientes, produtos, preços e identificadores `syncId`;
- atualiza clientes e produtos oficiais por `syncId` e preserva vendas locais.

### Saída do lote

- mensagem de texto entre `[EDI-BATCH-V1]` e `[/EDI-BATCH-V1]`;
- `batchId` único;
- `externalSaleId` único por venda;
- valores monetários em centavos inteiros;
- datas ISO-8601 com offset;
- cada mensagem contém no máximo 20 vendas; vendas restantes continuam pendentes para o próximo envio;
- imagem PNG complementar, nunca usada como fonte da importação;
- QR Code contém a mesma mensagem técnica compactada e pode ser dividido em partes numeradas;
- WhatsApp, imagem e QR são ações separadas para não misturar dado técnico com conferência visual;
- retenção dos 120 lotes mais recentes; totais diários combinam vendas locais e vendas congeladas nesses lotes sem duplicar `externalSaleId`;
- a data do lote é validada pelo offset ISO gravado no aparelho vendedor, sem mudar de dia por causa do fuso do administrador.

## Privacidade e recuperação

- o backup automático do Android inclui os `SharedPreferences` somente quando o provedor informa criptografia no cliente;
- a transferência direta entre aparelhos pode preservar os dados locais;
- arquivos temporários de imagem, base e lote permanecem no cache e não entram no backup.

## Limites intencionais da V1

- sem servidor ou sincronização automática;
- sem saldo e histórico financeiro no celular da vendedora;
- sem pagamento parcial;
- sem recebimento de dívida antiga;
- sem divisão por conta bancária;
- PIX, Dinheiro ou Cartão quando a venda for integralmente paga na hora.

# R13 — UX baseada no teste real da Edilane

Implementado nesta revisão:

- Home sem o botão **Desfazer**.
- **Enviar N pendentes** fica como ação isolada.
- Vendas editáveis da Home mostram **lápis** e continuam clicáveis.
- Seção **Vendas de hoje** mostra a contagem à direita.
- Lista de clientes com divisores alfabéticos A/B/C...
- Nome continua em destaque; local/telefone ficam na segunda linha quando os campos existem separados no cadastro.
- **Recentes não foi implementado** nesta rodada.
- Em **Revisar venda**, seta do topo e botão Voltar do Android fazem o mesmo que **Corrigir**: retornam à edição sem descartar o rascunho.
- Em **Registrar venda**, Voltar navega sem abrir confirmação destrutiva.
- Ação explícita **Cancelar esta venda** foi adicionada em Registrar/Revisar.
- Nova venda: Cancelar permite descartar o rascunho com confirmação.
- Venda não enviada já salva: Cancelar vira exclusão confirmada.
- Venda já enviada em correção: Cancelar descarta apenas as alterações locais e mantém a venda original.
- Fluxos de WhatsApp, QR Code e resumo em imagem não foram alterados.

## Observação sobre Nome / Local

Cadastros cujo local está dentro do próprio nome, por exemplo `Amanda/Dr Consulta`, continuam aparecendo assim. Esta versão não tenta separar automaticamente pelo caractere `/`, para evitar corromper nomes legítimos. O local aparece em segunda linha quando chega no campo `location` do catálogo.

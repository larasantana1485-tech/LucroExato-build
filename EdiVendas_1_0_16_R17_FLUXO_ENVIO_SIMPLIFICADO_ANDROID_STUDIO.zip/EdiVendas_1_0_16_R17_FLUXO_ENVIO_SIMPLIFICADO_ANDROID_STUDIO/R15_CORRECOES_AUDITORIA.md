# Edi Vendas 1.0.14 — R15 — Correções da auditoria R14

Este documento registra **o que foi alterado no código** a partir da auditoria de 22/09/2026. Ele não é um selo de homologação em aparelho. Checagem estática, compilação parcial de lógica e build Android são reportados separadamente no final.

## Fechamento por achado

| Achado | Situação no R15 | Correção aplicada |
|---|---|---|
| F02 — venda antiga aparecia em “hoje” | Corrigido | `salesForDate()` usa apenas a data comercial da venda canônica; lote não injeta snapshot em outro dia. |
| F03 — edição depois de exportar mantinha a revisão | Corrigido | Nova marca `exportedRevision`; qualquer edição depois de gerar arquivo/QR abre uma nova revisão. |
| F04 — confirmar lote antigo podia carimbar conteúdo novo | Corrigido | Confirmação usa a revisão congelada no lote. Se existir edição posterior, ela continua pendente. |
| F05 — excluir depois de exportar sem confirmar | Corrigido | Depois de qualquer exportação persistente, exclusão silenciosa é bloqueada; o caminho passa a ser correção versionada. |
| F06 — backup antes do primeiro envio podia guardar deviceId vazio | Corrigido | O identificador válido é criado antes do backup; restauração antiga com ID vazio recebe ID válido e revalida os lotes. |
| F07 — lote/confirmacão se perdiam ao recriar o app | Corrigido no fluxo de arquivo | Lote é persistido antes do compartilhamento e `shareStartedAt` permite recuperar a confirmação após recriação. QR preparado permanece no histórico mesmo se a tela for perdida. |
| F08 — integridade não cobria finanças/itens/revisões | Corrigido | Lotes novos usam esquema local V3 cobrindo revisão, valores, recebimento, pagamento, cliente, produtos, itens, datas e snapshots. V1/V2 antigos continuam legíveis. |
| F09 — virada do dia sem atualização explícita | Corrigido | Relógio de atualização em primeiro plano + revisão no `onResume`; Home recalcula saudação, data e consultas. |
| F10 — `1.000` virava R$ 1 e `-10,00` virava positivo | Corrigido | Parser pt-BR explícito em centavos; milhar/decimal validados e sinal inválido é rejeitado, não apagado. |
| F11 — faixa de datas Edi/Gestão divergente | Fechado com o Gestão R101 | O R101 removeu o corte artificial pré-2020; Edi continua bloqueando apenas datas futuras. |
| F12 — revisão não mostrava data completa e inventava hora retroativa | Corrigido | Revisão mostra `dd/MM/yyyy`; venda retroativa fica com “horário não informado”; `recordedAt` é separado de `soldAt`. |
| F13 — semântica de relatório retroativo no Gestão | Decisão preservada | O Edi agora fornece data comercial e instante de registro distintos. A política do Fechamento do Gestão não foi alterada por suposição. |
| F14 — produto legado bloqueava lote | Corrigido | Atualização do catálogo tenta reconciliar produto legado pelo nome/default, inclusive venda antiga sem `items`; erro remanescente identifica venda e produto exatos. |
| F15 — venda 50.001 corrompia a leitura | Corrigido | Limite é validado **antes** da gravação; o registro excedente não é escrito. Nenhuma exclusão automática de histórico foi criada. |
| F16 — limites monetários e Double inconsistentes | Corrigido | Teto único de R$ 20.000.000,00 por venda/recebimento e formatação com `BigDecimal`/centavos, sem `Double`. |
| F17 — imagem cortava itens e datas | Corrigido | Resumo visual é paginado, usa período real, data/hora por venda, ID/revisão e lista todos os produtos/quantidades/preços/subtotais. |
| F18 — estados de envio ambíguos | Corrigido | Diferencia lote preparado, compartilhamento iniciado, confirmação feita no aparelho e correção pendente. Nunca afirma “importado no Gestão” sem reconhecimento real. |
| F19 — textos não correspondiam às ações | Corrigido | “20 de N”, “Total das vendas a enviar”, “Reenviar arquivo”, instrução QR real e mensagens de falha/pendência coerentes. |
| F20 — histórico sem detalhe somente leitura | Corrigido | “Ver detalhes” mostra ID, revisão, data, produtos, preços, total, recebido/saldo e forma; histórico completo ganhou resumo total compacto. |
| F21 — correção após envio era decisão | Decisão fechada | R15 **mantém correção versionada** após exportação/envio. Não sobrescreve silenciosamente a revisão anterior. |
| F22 — layout parcial | Corrigido no código | Branco real nas superfícies/sistema, saudação maior, novo cliente em modal central, seletor compacto e modal de preço branco/cinza. “Venda anotada” preservada. |
| F23 — seletor de produtos sem busca/rolagem | Corrigido | Modal central com altura controlada, busca e `LazyColumn`. |
| F24 — riscos de largura/toque/rodapé/iniciais | Corrigido no código | Nomes em até 2 linhas, ações com 48dp, CTA fixo em rodapé opaco, resumo com pesos e iniciais ignorando prefixos não alfanuméricos. Ainda exige conferência visual em aparelho/fonte grande. |
| F25 — rascunho perdido em recriação | Corrigido | Cliente, itens, data, pagamento e tela são persistidos; ao voltar aparece Continuar/Descartar. |
| F26 — operações pesadas/concor­rência | Corrigido em pontos identificados | Backup e catálogo fora da UI, leitura limitada, mapa de vendas reutilizado no histórico, mutações serializadas com `@Synchronized`, botões de revisão bloqueados durante salvamento. |
| F27 — recuperação de backup/dados frágil | Corrigido | Prévia valida dados completos, cópia automática antes de restaurar, recuperação do estado anterior, validação cruzada e aviso persistente de dado danificado. |
| F28 — QA/documentação superestimavam validação | Corrigido | O script passou a se chamar/relatar **checklist estático** e este documento separa claramente o que foi e o que não foi executado. |

## Layout que deve permanecer

- Home branca, sem cards extras de resumo.
- Saudação e data no topo; `Registrar venda` como ação principal.
- Vendas de hoje em linhas com divisores finos.
- Históricos discretos, sem competir com a ação principal.
- Botão azul de envio fixo.
- Clientes sem caixas pesadas; busca em cinza claro.
- Novo cliente em modal compacto branco.
- Produto em modal central pesquisável/rolável.
- Quantidade em rosa pastel; pagamento compacto.
- **Venda anotada: estrutura e ações preservadas; somente fundo branco.**

## Verificação executada neste ambiente

- Compilação JVM das classes de dados alteradas com stubs Android/JSON: **passou** (somente avisos de compilador).
- Ensaios puros de parser monetário, formatação em centavos e integridade V3: **12/12 passaram**.
- XML e checklist estático R15: executado separadamente pelo script `scripts/audit_release.py`.
- Build Android/Gradle completo: **não concluído neste ambiente**, porque o wrapper precisa obter Gradle 8.13 e o host `services.gradle.org` não foi resolvido aqui. Isso não é tratado como aprovação de APK.
- WhatsApp, câmera/QR, Galaxy físico, fonte 150/200% e atualização por cima do APK existente: **ainda exigem homologação em dispositivo**.

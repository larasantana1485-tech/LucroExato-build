# Edi Vendas 1.0.15 — R16 — layouts aprovados

Implementação baseada nas quatro referências visuais aprovadas em 22/09/2026.

## Home
- Fundo branco.
- Saudação e data mantidas no topo.
- CTA rosa **Registrar venda**.
- Aviso curto para pendências de dias anteriores.
- **Histórico completo** e **Histórico de envios** lado a lado, em pills com cores diferentes.
- Lista de vendas sem chips técnicos de revisão/arquivo.
- Cliente exibido com nome em destaque e local em segunda linha quando possível.
- CTA azul fixo **Enviar N vendas ao Santana Gestão**.

## Escolher cliente
- Removida qualquer seção de recentes.
- Pesquisa preservada.
- Separadores alfabéticos sem caixas: letra + linha fina + respiro.
- Nome e local apresentados em linhas separadas.

## Registrar venda
- Cliente com hierarquia maior.
- Removidos os três pills Hoje/Ontem/Outra.
- Data em um único seletor com ícone de calendário.
- Produto reorganizado em um único bloco coeso: nome, preço, alterar valor, excluir, quantidade e subtotal.
- Pagamento refeito como duas escolhas: **Vai pagar depois** / **Pago na hora**.
- Métodos PIX/Dinheiro/Cartão continuam aparecendo quando **Pago na hora** é selecionado.
- Total reposicionado próximo ao CTA final.

## Histórico de envios
- Cada lote agora fica claramente contido em sua própria caixa com borda fina.
- Status simplificados para **Ainda não confirmado** e **Envio confirmado**.
- Removidos ID técnico do lote e revisão R1 da interface principal.
- Vendas do lote aparecem em linhas compactas.
- **Reenviar lote** fica dentro da caixa do lote correspondente.
- Proteção contra reenvio de lote antigo com revisão mais nova foi mantida.

## Ajustes complementares
- Cabeçalhos de cliente mais fortes também beneficiam a revisão da venda.
- Ação da revisão passou de **Corrigir** para **Editar venda**.
- Rascunho novo usa **Descartar venda**; edição existente preserva as regras de exclusão/correção.
- Histórico completo remove chips técnicos repetitivos e usa **Precisa reenviar** apenas quando necessário.

## Validação nesta entrega
- Alterações aplicadas sobre a R15 (`EdiVendas_1_0_14_R15_CORRECOES_AUDITORIA_ANDROID_STUDIO`).
- Estrutura estática e XML conferidos.
- O ambiente desta sessão não possui o conjunto Android/Gradle completo em cache para concluir um build Android real; por isso a compilação final deve ser executada no Android Studio antes da instalação no aparelho.

package br.com.edivendas.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val BrandPink = Color(0xFFC2185B)
val BrandPinkDark = Color(0xFF941241)
val BrandPinkSoft = Color(0xFFFBE3ED)
val BrandCream = Color(0xFFFFFFFF)
val BrandSurface = Color(0xFFFFFFFF)
val BrandSurfaceSoft = Color(0xFFF5F5F7)
val BrandLine = Color(0xFFE1E2E6)
val BrandInk = Color(0xFF17171B)
val BrandMuted = Color(0xFF575B63)
val BrandCocoa = Color(0xFF3A241E)
val BrandGreen = Color(0xFF237A4B)
val BrandGreenSoft = Color(0xFFE1F2E8)
val BrandBlue = Color(0xFF0F6FAE)
val BrandBlueSoft = Color(0xFFDDEEFF)
val BrandAmber = Color(0xFF8A5700)
val BrandAmberSoft = Color(0xFFFFF1CB)
val BrandDanger = Color(0xFFC62828)

private val EdiColors = lightColorScheme(
    primary = BrandPink,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFCE8F0),
    onPrimaryContainer = BrandPinkDark,
    secondary = BrandCocoa,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF1E7E2),
    onSecondaryContainer = BrandCocoa,
    tertiary = BrandGreen,
    onTertiary = Color.White,
    background = Color.White,
    onBackground = BrandInk,
    surface = BrandSurface,
    onSurface = BrandInk,
    surfaceVariant = BrandSurfaceSoft,
    onSurfaceVariant = BrandMuted,
    outline = BrandLine,
    error = BrandDanger,
)

private val EdiTypography = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun EdiVendasTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = EdiColors, typography = EdiTypography, content = content)
}

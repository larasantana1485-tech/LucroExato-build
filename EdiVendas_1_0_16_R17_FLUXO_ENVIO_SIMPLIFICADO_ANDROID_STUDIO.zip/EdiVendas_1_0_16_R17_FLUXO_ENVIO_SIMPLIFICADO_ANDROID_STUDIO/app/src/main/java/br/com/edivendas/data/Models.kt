package br.com.edivendas.data

import java.util.UUID

data class SellerConfig(
    val sellerName: String,
    val productId: String = "pao-de-mel",
    val productName: String,
    val unitPriceCents: Long,
    val businessId: String,
    val baseVersion: Long = 0L,
)

data class SellerClient(
    val adminClientId: Long? = null,
    val externalClientKey: String? = null,
    val name: String,
    val phone: String = "",
    val location: String = "",
    val active: Boolean = true,
    val syncId: String = externalClientKey ?: UUID.randomUUID().toString(),
)

data class SellerSaleItem(
    val productSyncId: String,
    val name: String,
    val quantity: Int,
    val unitPriceCents: Long,
) {
    val subtotalCents: Long get() = Math.multiplyExact(unitPriceCents, quantity.toLong())
}

data class SellerSale(
    val externalSaleId: String = UUID.randomUUID().toString(),
    val adminClientId: Long? = null,
    val externalClientKey: String? = null,
    val clientNameSnapshot: String,
    val clientPhoneSnapshot: String = "",
    val clientLocationSnapshot: String = "",
    val productId: String,
    val productNameSnapshot: String,
    val quantity: Int,
    val unitPriceCents: Long,
    val paidOnSpot: Boolean,
    val paymentMethod: String? = null,
    val soldAt: Long = System.currentTimeMillis(),
    val batchId: String? = null,
    val cancelled: Boolean = false,
    val displayId: String = "",
    val revision: Int = 1,
    val exportedRevision: Int = 0,
    val sentRevision: Int = 0,
    val clientSyncId: String = externalClientKey ?: "",
    val items: List<SellerSaleItem> = emptyList(),
    val receivedCents: Long = if (paidOnSpot) Math.multiplyExact(unitPriceCents, quantity.toLong()) else 0L,
    val recordedAt: Long = System.currentTimeMillis(),
    val saleTimeKnown: Boolean = true,
) {
    val totalCents: Long get() = if (items.isEmpty()) Math.multiplyExact(unitPriceCents, quantity.toLong())
        else items.fold(0L) { sum, row -> Math.addExact(sum, row.subtotalCents) }
}

data class SellerBatch(
    val schemaVersion: Int = 3,
    val batchId: String,
    val businessId: String,
    val sellerDeviceId: String,
    val sellerName: String,
    val saleDate: String,
    val createdAt: Long,
    val sales: List<SellerSale>,
    val integrity: String,
    val shareStartedAt: Long? = null,
    val sharedAt: Long? = null,
) {
    val totalCents: Long get() = sales.fold(0L) { total, sale -> Math.addExact(total, sale.totalCents) }
    val paidOnSpotCents: Long get() = sales.fold(0L) { total, sale -> Math.addExact(total, sale.receivedCents) }
}

data class BaseImportResult(
    val clientCount: Int,
    val productName: String,
    val unitPriceCents: Long,
    val baseVersion: Long,
)

data class SellerBackupPreview(
    val clientCount: Int,
    val saleCount: Int,
    val batchCount: Int,
    val createdAt: Long,
)

class UserVisibleException(message: String) : IllegalArgumentException(message)

package br.com.edivendas.data

import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.UUID

object ExchangeCodec {
    private const val BATCH_TYPE = "SANTANA_SELLER_DAY"
    fun configToJson(config: SellerConfig) = JSONObject().apply {
        put("sellerName", config.sellerName)
        put("productId", config.productId)
        put("productName", config.productName)
        put("unitPriceCents", config.unitPriceCents)
        put("businessId", config.businessId)
        put("baseVersion", config.baseVersion)
    }

    fun parseConfig(text: String): SellerConfig? = runCatching {
        val item = JSONObject(text)
        SellerConfig(
            sellerName = item.getString("sellerName"),
            productId = item.optString("productId", "pao-de-mel"),
            productName = item.getString("productName"),
            unitPriceCents = item.getLong("unitPriceCents"),
            businessId = item.getString("businessId"),
            baseVersion = item.optLong("baseVersion"),
        ).also { config ->
            require(
                config.sellerName.isNotBlank() && config.sellerName.length <= 60 &&
                    config.productId.isNotBlank() && config.productId.length <= 120 &&
                    config.productName.isNotBlank() && config.productName.length <= 120
            )
            require(config.unitPriceCents in 1..100_000_000L && config.businessId.isNotBlank() && config.baseVersion >= 0L)
            require(config.businessId.length <= 120)
        }
    }.getOrNull()

    fun clientsToJson(clients: List<SellerClient>) = JSONArray().apply {
        clients.forEach { client ->
            put(JSONObject().apply {
                client.adminClientId?.let { put("adminClientId", it) }
                client.externalClientKey?.let { put("externalClientKey", it) }
                put("name", client.name)
                put("phone", client.phone)
                put("location", client.location)
                put("active", client.active)
                put("syncId", client.syncId)
            })
        }
    }

    fun parseClients(text: String): List<SellerClient> = try {
        val array = JSONArray(text)
        require(array.length() <= 20_000)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                val name = item.getString("name").trim()
                require(name.isNotBlank() && name.length <= 120)
                require(item.optString("phone").length <= 40 && item.optString("location").length <= 160)
                require(item.optString("externalClientKey").length <= 120)
                if (item.has("adminClientId") && !item.isNull("adminClientId")) {
                    require(item.getLong("adminClientId") > 0L)
                }
                add(
                    SellerClient(
                        adminClientId = item.optLongOrNull("adminClientId"),
                        externalClientKey = item.optString("externalClientKey").ifBlank { null },
                        name = name,
                        phone = item.optString("phone").trim(),
                        location = item.optString("location").trim(),
                        active = item.optBoolean("active", true),
                        syncId = item.optString("syncId").ifBlank { stableClientSyncId(item) },
                    ),
                )
            }
        }
    } catch (error: Exception) {
        throw UserVisibleException("Os clientes salvos neste aparelho estão danificados. Não registre novas vendas antes de recuperar os dados.")
    }

    fun salesToJson(sales: List<SellerSale>) = JSONArray().apply { sales.forEach { put(saleToJson(it)) } }

    fun parseSales(text: String): List<SellerSale> = try {
        val array = JSONArray(text)
        require(array.length() <= 50_000)
        buildList { for (index in 0 until array.length()) add(parseSale(array.getJSONObject(index))) }
            .also { sales -> require(sales.map { it.externalSaleId }.distinct().size == sales.size) }
    } catch (error: UserVisibleException) {
        throw error
    } catch (error: Exception) {
        throw UserVisibleException("As vendas salvas neste aparelho estão danificadas. Não gere um lote antes de recuperar os dados.")
    }

    fun batchesToJson(batches: List<SellerBatch>) = JSONArray().apply { batches.forEach { put(batchToJson(it, includeLocalState = true)) } }

    fun parseBatches(text: String): List<SellerBatch> = try {
        val array = JSONArray(text)
        require(array.length() <= 200)
        buildList { for (index in 0 until array.length()) add(parseBatch(array.getJSONObject(index))) }
            .also { batches -> require(batches.map { it.batchId }.distinct().size == batches.size) }
    } catch (error: UserVisibleException) {
        throw error
    } catch (error: Exception) {
        throw UserVisibleException("O histórico de envios está danificado. Os arquivos já compartilhados não foram alterados.")
    }

    fun batchToExportJson(batch: SellerBatch): String = batchToJson(batch.copy(shareStartedAt = null, sharedAt = null), includeLocalState = false).toString(2)

    fun withIntegrity(batch: SellerBatch): SellerBatch = batch.copy(
        integrity = integrity(batch.copy(integrity = "", shareStartedAt = null, sharedAt = null)),
    )

    /**
     * V1/V2 continuam legíveis exatamente como foram gravados. V3 fecha todos os
     * campos que alteram o conteúdo comercial/financeiro de uma venda.
     */
    fun integrity(batch: SellerBatch): String {
        val canonical = if (batch.schemaVersion <= 2) legacyIntegrityCanonical(batch) else buildString {
            append(batch.schemaVersion).append('|').append(batch.batchId).append('|')
            append(batch.businessId).append('|').append(batch.sellerDeviceId).append('|')
            append(batch.sellerName).append('|').append(batch.saleDate).append('|').append(batch.createdAt)
            batch.sales.sortedWith(compareBy<SellerSale> { it.externalSaleId }.thenBy { it.revision }).forEach { sale ->
                append('\n').append(sale.externalSaleId).append('|').append(sale.displayId).append('|')
                append(sale.revision).append('|').append(sale.exportedRevision).append('|').append(sale.sentRevision).append('|')
                append(sale.adminClientId ?: "").append('|').append(sale.externalClientKey ?: "").append('|')
                append(sale.clientSyncId).append('|').append(sale.clientNameSnapshot).append('|')
                append(sale.clientPhoneSnapshot).append('|').append(sale.clientLocationSnapshot).append('|')
                append(sale.productId).append('|').append(sale.productNameSnapshot).append('|')
                append(sale.quantity).append('|').append(sale.unitPriceCents).append('|')
                append(sale.paidOnSpot).append('|').append(sale.paymentMethod ?: "").append('|')
                append(sale.soldAt).append('|').append(sale.recordedAt).append('|').append(sale.saleTimeKnown).append('|')
                append(sale.receivedCents).append('|').append(sale.cancelled).append('|').append(sale.batchId ?: "")
                sale.items.forEach { row ->
                    append("|ITEM:").append(row.productSyncId).append('|').append(row.name).append('|')
                    append(row.quantity).append('|').append(row.unitPriceCents).append('|').append(row.subtotalCents)
                }
            }
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun legacyIntegrityCanonical(batch: SellerBatch): String = buildString {
        append(batch.schemaVersion).append('|').append(batch.batchId).append('|')
        append(batch.businessId).append('|').append(batch.sellerDeviceId).append('|')
        append(batch.saleDate).append('|').append(batch.createdAt)
        batch.sales.sortedBy { it.externalSaleId }.forEach { sale ->
            append('\n').append(sale.externalSaleId).append('|')
            append(sale.adminClientId ?: "").append('|').append(sale.externalClientKey ?: "").append('|')
            append(sale.clientNameSnapshot).append('|')
            if (batch.schemaVersion >= 2) {
                append(sale.clientPhoneSnapshot).append('|').append(sale.clientLocationSnapshot).append('|')
            }
            append(sale.productId).append('|').append(sale.productNameSnapshot).append('|').append(sale.quantity).append('|')
            append(sale.unitPriceCents).append('|').append(sale.paidOnSpot).append('|')
            append(sale.paymentMethod ?: "").append('|').append(sale.soldAt)
            if (batch.schemaVersion >= 2) append('|').append(sale.batchId ?: "").append('|').append(sale.cancelled)
        }
    }

    fun formatCents(cents: Long): String {
        val symbols = DecimalFormatSymbols(Locale("pt", "BR"))
        return "R$ " + DecimalFormat("#,##0.00", symbols).format(java.math.BigDecimal.valueOf(cents, 2))
    }

    private fun saleToJson(sale: SellerSale) = JSONObject().apply {
        put("externalSaleId", sale.externalSaleId)
        sale.adminClientId?.let { put("adminClientId", it) }
        sale.externalClientKey?.let { put("externalClientKey", it) }
        put("clientNameSnapshot", sale.clientNameSnapshot)
        put("clientPhoneSnapshot", sale.clientPhoneSnapshot)
        put("clientLocationSnapshot", sale.clientLocationSnapshot)
        put("productId", sale.productId)
        put("productNameSnapshot", sale.productNameSnapshot)
        put("quantity", sale.quantity)
        put("unitPriceCents", sale.unitPriceCents)
        put("totalCents", sale.totalCents)
        put("paidOnSpot", sale.paidOnSpot)
        sale.paymentMethod?.let { put("paymentMethod", it) }
        put("soldAt", millisToIso(sale.soldAt))
        sale.batchId?.let { put("batchId", it) }
        put("cancelled", sale.cancelled)
        put("displayId", sale.displayId)
        put("revision", sale.revision)
        put("exportedRevision", sale.exportedRevision)
        put("sentRevision", sale.sentRevision)
        put("clientSyncId", sale.clientSyncId)
        put("receivedCents", sale.receivedCents)
        put("recordedAt", millisToIso(sale.recordedAt))
        put("saleTimeKnown", sale.saleTimeKnown)
        put("items", JSONArray().apply { sale.items.forEach { row ->
            put(JSONObject().put("productSyncId", row.productSyncId).put("name", row.name)
                .put("quantity", row.quantity).put("unitPriceCents", row.unitPriceCents))
        } })
    }

    private fun parseSale(item: JSONObject): SellerSale {
        val sale = SellerSale(
            externalSaleId = item.getString("externalSaleId"),
            adminClientId = item.optLongOrNull("adminClientId"),
            externalClientKey = item.optString("externalClientKey").ifBlank { null },
            clientNameSnapshot = item.getString("clientNameSnapshot"),
            clientPhoneSnapshot = item.optString("clientPhoneSnapshot"),
            clientLocationSnapshot = item.optString("clientLocationSnapshot"),
            productId = item.getString("productId"),
            productNameSnapshot = item.getString("productNameSnapshot"),
            quantity = item.getInt("quantity"),
            unitPriceCents = item.getLong("unitPriceCents"),
            paidOnSpot = item.getBoolean("paidOnSpot"),
            paymentMethod = item.optString("paymentMethod").ifBlank { null },
            soldAt = parseTime(item.get("soldAt")),
            batchId = item.optString("batchId").ifBlank { null },
            cancelled = item.optBoolean("cancelled", false),
            displayId = item.optString("displayId"),
            revision = item.optInt("revision", 1),
            exportedRevision = item.optInt("exportedRevision", item.optInt("sentRevision", if (item.optString("batchId").isNotBlank()) 1 else 0)),
            sentRevision = item.optInt("sentRevision", if (item.optString("batchId").isNotBlank()) 1 else 0),
            clientSyncId = item.optString("clientSyncId").ifBlank { item.optString("externalClientKey") },
            items = item.optJSONArray("items")?.let { array ->
                require(array.length() <= 20)
                (0 until array.length()).map { i -> array.getJSONObject(i).let { row ->
                    SellerSaleItem(row.getString("productSyncId"), row.getString("name"),
                        row.getInt("quantity"), row.getLong("unitPriceCents"))
                } }
            }.orEmpty(),
            receivedCents = item.optLong("receivedCents", if (item.getBoolean("paidOnSpot"))
                Math.multiplyExact(item.getLong("unitPriceCents"), item.getInt("quantity").toLong()) else 0L),
            recordedAt = item.opt("recordedAt")?.let(::parseTime) ?: parseTime(item.get("soldAt")),
            saleTimeKnown = item.optBoolean("saleTimeKnown", true),
        )
        val total = runCatching { sale.totalCents }.getOrNull()
        if (
            sale.externalSaleId.isBlank() || sale.externalSaleId.length > 120 ||
            (sale.adminClientId != null && sale.adminClientId <= 0L) ||
            (sale.externalClientKey != null && sale.externalClientKey.length > 120) ||
            sale.clientNameSnapshot.isBlank() || sale.clientNameSnapshot.length > 120 ||
            sale.clientPhoneSnapshot.length > 40 || sale.clientLocationSnapshot.length > 160 ||
            sale.productId.isBlank() || sale.productId.length > 120 ||
            sale.productNameSnapshot.isBlank() || sale.productNameSnapshot.length > 120 ||
            sale.quantity !in 1..9_999 || sale.unitPriceCents !in 1..100_000_000L || total == null ||
            sale.revision < 1 || sale.exportedRevision !in 0..sale.revision || sale.sentRevision !in 0..sale.exportedRevision ||
            sale.receivedCents !in 0L..(total ?: 0L) || (total ?: Long.MAX_VALUE) > MAX_SALE_TOTAL_CENTS ||
            sale.paidOnSpot != (sale.receivedCents > 0L) ||
            sale.items.any { it.productSyncId.isBlank() || it.name.isBlank() || it.quantity !in 1..9_999 || it.unitPriceCents !in 1L..100_000_000L } ||
            item.optLong("totalCents", total) != total ||
            (sale.paidOnSpot && sale.paymentMethod !in setOf("PIX", "Dinheiro", "Cartão")) ||
            (!sale.paidOnSpot && sale.paymentMethod != null)
        ) {
            throw IllegalArgumentException("Venda inválida")
        }
        return sale
    }

    private fun batchToJson(batch: SellerBatch, includeLocalState: Boolean) = JSONObject().apply {
        put("type", BATCH_TYPE)
        put("schemaVersion", batch.schemaVersion)
        put("batchId", batch.batchId)
        put("businessId", batch.businessId)
        put("sellerDeviceId", batch.sellerDeviceId)
        put("sellerName", batch.sellerName)
        put("saleDate", batch.saleDate)
        put("createdAt", millisToIso(batch.createdAt))
        put("sales", salesToJson(batch.sales))
        put("integrity", batch.integrity)
        if (includeLocalState) {
            batch.shareStartedAt?.let { put("shareStartedAt", it) }
            batch.sharedAt?.let { put("sharedAt", it) }
        }
    }

    private fun parseBatch(item: JSONObject): SellerBatch {
        val parsed = SellerBatch(
            schemaVersion = item.getInt("schemaVersion").also { require(it in 1..3) },
            batchId = item.getString("batchId"),
            businessId = item.getString("businessId"),
            sellerDeviceId = item.getString("sellerDeviceId"),
            sellerName = item.optString("sellerName", "Vendedora"),
            saleDate = item.getString("saleDate"),
            createdAt = parseTime(item.get("createdAt")),
            sales = parseSales(item.getJSONArray("sales").toString()),
            integrity = item.getString("integrity"),
            shareStartedAt = item.optLongOrNull("shareStartedAt"),
            sharedAt = item.optLongOrNull("sharedAt"),
        )
        require(
            parsed.batchId.isNotBlank() && parsed.batchId.length <= 120 &&
                parsed.businessId.isNotBlank() && parsed.businessId.length <= 120 &&
                parsed.sellerDeviceId.length <= 120 && (parsed.schemaVersion <= 2 || parsed.sellerDeviceId.isNotBlank()) &&
                parsed.sellerName.isNotBlank() && parsed.sellerName.length <= 60
        )
        require(runCatching { LocalDate.parse(parsed.saleDate) }.isSuccess)
        require(parsed.sales.isNotEmpty() && parsed.sales.size <= 200)
        require(parsed.sales.all { sale ->
            (parsed.schemaVersion == 1 && (sale.batchId == null || sale.batchId == parsed.batchId)) ||
                (parsed.schemaVersion >= 2 && sale.batchId == parsed.batchId)
        })
        require(parsed.integrity.isNotBlank() && parsed.integrity == integrity(parsed.copy(integrity = "", sharedAt = null)))
        return parsed
    }

    private fun millisToIso(millis: Long): String = Instant.ofEpochMilli(millis)
        .atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)

    private fun parseTime(value: Any): Long = when (value) {
        is Number -> value.toLong()
        is String -> OffsetDateTime.parse(value).toInstant().toEpochMilli()
        else -> throw IllegalArgumentException("Data inválida")
    }

    private fun JSONObject.optLongOrNull(key: String): Long? =
        if (has(key) && !isNull(key)) optLong(key).takeIf { it > 0L } else null

    private const val MAX_SALE_TOTAL_CENTS = 2_000_000_000L

    private fun stableClientSyncId(item: JSONObject): String = item.optLong("adminClientId").takeIf { it > 0L }
        ?.let { UUID.nameUUIDFromBytes("santana-client:$it".toByteArray()).toString() }
        ?: item.optString("externalClientKey").ifBlank {
            UUID.nameUUIDFromBytes("edi-legacy-client:${item.optString("name")}:${item.optString("phone")}".toByteArray()).toString()
        }
}

package br.com.edivendas.data

import java.math.BigDecimal
import java.math.RoundingMode

/** Parsing monetário explícito para a interface pt-BR, sempre convertido para centavos inteiros. */
object BrazilianMoney {
    fun sanitizeInput(value: String): String {
        val trimmed = value.trimStart()
        val sign = if (trimmed.startsWith("-")) "-" else ""
        val body = trimmed.removePrefix("-")
            .filter { it.isDigit() || it == ',' || it == '.' }
            .take(18)
        return sign + body
    }

    fun parsePriceCents(value: String): Long {
        val cents = toCents(parseAmount(value, "Informe um preço válido."))
        if (cents <= 0L) throw UserVisibleException("Informe um preço maior que zero.")
        if (cents > MAX_UNIT_PRICE_CENTS) throw UserVisibleException("O preço máximo é R$ 1.000.000,00.")
        return cents
    }

    fun parseReceivedCents(value: String): Long {
        val cents = toCents(parseAmount(value, "Informe o valor recebido."))
        if (cents < 0L || cents > MAX_SALE_TOTAL_CENTS) throw UserVisibleException("Confira o valor recebido.")
        return cents
    }

    fun centsToInput(cents: Long): String = BigDecimal.valueOf(cents, 2)
        .setScale(2)
        .toPlainString()
        .replace('.', ',')

    private fun toCents(amount: BigDecimal): Long = try {
        amount.movePointRight(2).setScale(0, RoundingMode.UNNECESSARY).longValueExact()
    } catch (_: ArithmeticException) {
        throw UserVisibleException("Informe um valor válido.")
    }

    private fun parseAmount(value: String, emptyMessage: String): BigDecimal {
        val raw = value.trim()
        if (raw.isBlank()) throw UserVisibleException(emptyMessage)
        if (raw.startsWith("-") || raw.startsWith("+") || raw.any { !it.isDigit() && it != ',' && it != '.' }) {
            throw UserVisibleException("Informe um valor válido.")
        }

        val normalized = when {
            ',' in raw -> {
                if (raw.count { it == ',' } != 1) throw UserVisibleException("Informe um valor válido.")
                val integer = raw.substringBefore(',')
                val decimals = raw.substringAfter(',')
                if (integer.isBlank() || decimals.length !in 0..2 || decimals.any { !it.isDigit() }) {
                    throw UserVisibleException("Use no máximo dois centavos.")
                }
                if ('.' in integer) {
                    val groups = integer.split('.')
                    if (groups.first().length !in 1..3 || groups.first().any { !it.isDigit() } ||
                        groups.drop(1).any { it.length != 3 || it.any { c -> !c.isDigit() } }) {
                        throw UserVisibleException("Confira os separadores do valor.")
                    }
                } else if (integer.any { !it.isDigit() }) {
                    throw UserVisibleException("Informe um valor válido.")
                }
                integer.replace(".", "") + "." + decimals.padEnd(2, '0')
            }

            '.' in raw -> {
                val groups = raw.split('.')
                if (groups.any { it.isBlank() || it.any { c -> !c.isDigit() } }) {
                    throw UserVisibleException("Informe um valor válido.")
                }
                when {
                    groups.size == 2 && groups[1].length in 1..2 -> groups[0] + "." + groups[1].padEnd(2, '0')
                    groups[0].length in 1..3 && groups.drop(1).all { it.length == 3 } -> groups.joinToString("") + ".00"
                    else -> throw UserVisibleException("Confira os separadores do valor.")
                }
            }

            raw.all(Char::isDigit) -> "$raw.00"
            else -> throw UserVisibleException("Informe um valor válido.")
        }
        return normalized.toBigDecimalOrNull() ?: throw UserVisibleException("Informe um valor válido.")
    }

    private const val MAX_UNIT_PRICE_CENTS = 100_000_000L
    private const val MAX_SALE_TOTAL_CENTS = 2_000_000_000L
}

package br.com.edivendas.data

import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Base64
import java.util.zip.GZIPOutputStream

object EdiQrCodec {
    private const val PREFIX = "EDIQR1"
    private const val CHUNK_SIZE = 1_350
    private const val MAX_PARTS = 40

    fun frames(batch: SellerBatch): List<String> {
        val raw = TextExchange.batchText(batch).toByteArray(Charsets.UTF_8)
        val compressed = ByteArrayOutputStream().also { output ->
            GZIPOutputStream(output).use { it.write(raw) }
        }.toByteArray()
        val payload = Base64.getUrlEncoder().withoutPadding().encodeToString(compressed)
        val chunks = payload.chunked(CHUNK_SIZE)
        if (chunks.size > MAX_PARTS) throw UserVisibleException("Há vendas demais para enviar por QR Code. Envie pelo WhatsApp.")
        val hash = MessageDigest.getInstance("SHA-256").digest(raw).joinToString("") { "%02x".format(it) }
        return chunks.mapIndexed { index, chunk ->
            "$PREFIX|${batch.batchId}|${index + 1}|${chunks.size}|$hash|$chunk"
        }
    }

    fun bitmap(frame: String, size: Int = 900): Bitmap {
        val matrix = QRCodeWriter().encode(
            frame,
            BarcodeFormat.QR_CODE,
            size,
            size,
            mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L, EncodeHintType.MARGIN to 2),
        )
        return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also { bitmap ->
            for (y in 0 until size) for (x in 0 until size) {
                bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
    }
}

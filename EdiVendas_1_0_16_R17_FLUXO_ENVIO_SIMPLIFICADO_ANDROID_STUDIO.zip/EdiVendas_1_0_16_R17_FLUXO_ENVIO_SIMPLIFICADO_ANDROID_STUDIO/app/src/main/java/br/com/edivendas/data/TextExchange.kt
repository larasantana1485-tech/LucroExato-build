package br.com.edivendas.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Base64
import java.util.UUID
import java.util.zip.GZIPInputStream

data class SellerProduct(val syncId: String, val name: String, val unitPriceCents: Long, val active: Boolean)

/** O protocolo trafega como texto comum. O trecho entre marcadores é JSON estrito. */
object TextExchange {
    const val CATALOG_START = "[EDI-CATALOG-V1]"
    const val CATALOG_END = "[/EDI-CATALOG-V1]"
    const val COMPACT_CATALOG_START = "[EDI-CATALOG-V2]"
    const val COMPACT_CATALOG_END = "[/EDI-CATALOG-V2]"
    const val BATCH_START = "[EDI-BATCH-V1]"
    const val BATCH_END = "[/EDI-BATCH-V1]"

    fun jsonBlock(text: String, start: String, end: String): JSONObject {
        if (text.length > 1_500_000) throw UserVisibleException("O texto copiado é grande demais.")
        val first = text.indexOf(start)
        if (first < 0) throw UserVisibleException("Nenhum dado compatível do Santana Gestão foi encontrado.")
        val last = text.indexOf(end, first + start.length)
        if (last < 0 || text.indexOf(start, first + start.length) >= 0 || text.indexOf(end, last + end.length) >= 0) {
            throw UserVisibleException("O texto copiado está incompleto ou repetido.")
        }
        return runCatching { JSONObject(text.substring(first + start.length, last).trim()) }
            .getOrElse { throw UserVisibleException("Os dados copiados não são válidos.") }
    }

    fun batchText(batch: SellerBatch): String {
        val rows = JSONArray()
        batch.sales.forEach { sale ->
            val itemList = sale.items.ifEmpty { listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents)) }
            val subtotal = sale.totalCents
            rows.put(JSONObject().apply {
                put("saleSyncId", sale.externalSaleId)
                put("displayId", sale.displayId)
                put("revision", sale.revision)
                put("soldAt", Instant.ofEpochMilli(sale.soldAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME))
                put("client", JSONObject().put("syncId", sale.clientSyncId).put("name", sale.clientNameSnapshot)
                    .put("phone", sale.clientPhoneSnapshot).put("location", sale.clientLocationSnapshot))
                put("items", JSONArray().apply { itemList.forEach { row ->
                    put(JSONObject().put("productSyncId", row.productSyncId).put("name", row.name)
                        .put("quantity", row.quantity).put("unitPriceCents", row.unitPriceCents).put("subtotalCents", row.subtotalCents))
                } })
                put("totalCents", subtotal)
                put("receivedCents", sale.receivedCents)
                put("balanceCents", subtotal - sale.receivedCents)
                put("paymentMethod", sale.paymentMethod ?: JSONObject.NULL)
                put("financialStatus", when (sale.receivedCents) { 0L -> "PENDING"; subtotal -> "PAID"; else -> "PARTIAL" })
            })
        }
        val root = JSONObject().put("batchId", batch.batchId)
            .put("businessId", batch.businessId)
            .put("createdAt", Instant.ofEpochMilli(batch.createdAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME))
            .put("sales", rows)
        val saleDates = batch.sales.map { sale ->
            Instant.ofEpochMilli(sale.soldAt).atZone(ZoneId.systemDefault()).toLocalDate()
        }.distinct().sorted()
        val period = if (saleDates.size == 1) {
            saleDates.single().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        } else {
            "${saleDates.first().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))} a ${saleDates.last().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}"
        }
        val summary = buildString {
            append("Vendas pendentes do Edi — ").append(period).append('\n')
            append(batch.sales.size).append(" vendas • Total informado: ").append(ExchangeCodec.formatCents(batch.totalCents)).append('\n')
            batch.sales.filter { it.revision > 1 }.forEach { append("CORREÇÃO DA VENDA ").append(it.displayId).append(" • Revisão ").append(it.revision).append("\n") }
        }
        return "$summary\n$BATCH_START\n${root}\n$BATCH_END"
    }

    fun catalog(text: String): Triple<String, List<SellerClient>, List<SellerProduct>> {
        val root = if (COMPACT_CATALOG_START in text) compactCatalogRoot(text)
            else jsonBlock(text, CATALOG_START, CATALOG_END)
        val businessId = root.optString("businessId")
        if (runCatching { UUID.fromString(businessId) }.isFailure) throw UserVisibleException("Catálogo sem identificação válida.")
        val clientsArray = root.optJSONArray("clients") ?: throw UserVisibleException("Catálogo sem clientes.")
        val productsArray = root.optJSONArray("products") ?: throw UserVisibleException("Catálogo sem produtos.")
        if (clientsArray.length() > 2_000 || productsArray.length() > 200) throw UserVisibleException("Catálogo grande demais para uma mensagem.")
        val clients = (0 until clientsArray.length()).map { index ->
            val row = clientsArray.getJSONObject(index)
            require(row.optString("phone").length <= 40 && row.optString("location").length <= 160)
            SellerClient(syncId = uuid(row.getString("syncId")), name = row.getString("name").trim().also { require(it.isNotBlank() && it.length <= 120) },
                phone = row.optString("phone"), location = row.optString("location"), active = row.optBoolean("active", true))
        }
        val products = (0 until productsArray.length()).map { index ->
            val row = productsArray.getJSONObject(index)
            SellerProduct(uuid(row.getString("syncId")), row.getString("name").trim().also { require(it.isNotBlank() && it.length <= 120) },
                row.getLong("unitPriceCents").also { require(it in 1..100_000_000L) }, row.optBoolean("active", true))
        }
        if (clients.map { it.syncId }.distinct().size != clients.size || products.map { it.syncId }.distinct().size != products.size) {
            throw UserVisibleException("Há identificadores repetidos no catálogo.")
        }
        return Triple(businessId, clients, products)
    }

    private fun compactCatalogRoot(text: String): JSONObject {
        val envelope = jsonBlock(text, COMPACT_CATALOG_START, COMPACT_CATALOG_END)
        if (envelope.optString("encoding") != "gzip-base64") {
            throw UserVisibleException("Este catálogo compacto ainda não é compatível com esta versão do Edi Vendas.")
        }
        val expectedLength = envelope.optInt("rawLength", -1)
        val expectedHash = envelope.optString("sha256")
        val payload = envelope.optString("payload")
        if (expectedLength !in 2..1_500_000 || expectedHash.length != 64 || payload.isBlank() || payload.length > 1_500_000) {
            throw UserVisibleException("O catálogo copiado está incompleto ou inválido.")
        }
        val compressed = try { Base64.getDecoder().decode(payload) }
        catch (_: IllegalArgumentException) { throw UserVisibleException("O catálogo foi cortado durante o envio. Copie a mensagem novamente.") }
        val raw = try {
            GZIPInputStream(ByteArrayInputStream(compressed)).use { input ->
                val output = ByteArrayOutputStream(expectedLength.coerceAtMost(64 * 1024))
                val buffer = ByteArray(8 * 1024)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    output.write(buffer, 0, count)
                    if (output.size() > 1_500_000) throw UserVisibleException("O catálogo descompactado é grande demais.")
                }
                output.toByteArray()
            }
        } catch (error: UserVisibleException) { throw error }
        catch (_: Exception) { throw UserVisibleException("O catálogo foi cortado durante o envio. Copie a mensagem novamente.") }
        val actualHash = MessageDigest.getInstance("SHA-256").digest(raw).joinToString("") { "%02x".format(it) }
        if (raw.size != expectedLength || actualHash != expectedHash) {
            throw UserVisibleException("O catálogo chegou incompleto ou alterado. Copie a mensagem novamente.")
        }
        return runCatching { JSONObject(raw.toString(Charsets.UTF_8)) }
            .getOrElse { throw UserVisibleException("O catálogo descompactado não é válido.") }
    }

    private fun uuid(value: String): String = UUID.fromString(value).toString()
}

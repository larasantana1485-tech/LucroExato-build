package br.com.edivendas.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.text.Normalizer
import java.util.Locale
import java.util.UUID

class SellerStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isConfigured(): Boolean = prefs.getBoolean(KEY_ONBOARDING_COMPLETE, false) && config() != null

    fun needsRecovery(): Boolean = prefs.getBoolean(KEY_ONBOARDING_COMPLETE, false) && config() == null

    fun isLinkedToSantana(): Boolean = (config()?.baseVersion ?: 0L) > 0L

    @Synchronized
    fun exportBackup(): String {
        val deviceId = sellerDeviceId()
        val root = org.json.JSONObject()
            .put("type", "EDI_VENDAS_BACKUP")
            .put("schemaVersion", 2)
            .put("createdAt", System.currentTimeMillis())
            .put("config", org.json.JSONObject(prefs.getString(KEY_CONFIG, "{}")))
            .put("clients", org.json.JSONArray(prefs.getString(KEY_CLIENTS, "[]")))
            .put("products", org.json.JSONArray(prefs.getString(KEY_PRODUCTS, "[]")))
            .put("sales", org.json.JSONArray(prefs.getString(KEY_SALES, "[]")))
            .put("batches", org.json.JSONArray(prefs.getString(KEY_BATCHES, "[]")))
            .put("deviceId", deviceId)
            .put("displaySequence", prefs.getInt(KEY_DISPLAY_SEQUENCE, 0))
            .put("onboardingComplete", prefs.getBoolean(KEY_ONBOARDING_COMPLETE, false))
        return root.toString(2)
    }

    fun previewBackup(text: String): SellerBackupPreview {
        val root = try { org.json.JSONObject(text) }
        catch (_: Exception) { throw UserVisibleException("Este arquivo não é um backup válido do Edi Vendas.") }
        if (root.optString("type") != "EDI_VENDAS_BACKUP" || root.optInt("schemaVersion", -1) !in 1..2) {
            throw UserVisibleException("Este arquivo não é compatível com esta versão do Edi Vendas.")
        }
        val configJson = root.optJSONObject("config") ?: throw UserVisibleException("O backup não contém a configuração da vendedora.")
        val clientsJson = root.optJSONArray("clients") ?: throw UserVisibleException("O backup não contém a lista de clientes.")
        val salesJson = root.optJSONArray("sales") ?: throw UserVisibleException("O backup não contém as vendas.")
        val batchesJson = root.optJSONArray("batches") ?: throw UserVisibleException("O backup não contém o histórico de envios.")
        val productsJson = root.optJSONArray("products") ?: org.json.JSONArray()
        val incomingDeviceId = root.optString("deviceId").takeIf { runCatching { UUID.fromString(it) }.isSuccess } ?: UUID.randomUUID().toString()
        val restoredConfig = ExchangeCodec.parseConfig(configJson.toString())
            ?: throw UserVisibleException("A configuração existente no backup está danificada.")
        val restoredClients = runCatching { ExchangeCodec.parseClients(clientsJson.toString()) }
            .getOrElse { throw UserVisibleException("A lista de clientes do backup está danificada.") }
        val restoredSales = runCatching { ExchangeCodec.parseSales(salesJson.toString()) }
            .getOrElse { throw UserVisibleException("As vendas do backup estão danificadas.") }
        val restoredBatches = runCatching { ExchangeCodec.parseBatches(batchesJson.toString()) }
            .getOrElse { throw UserVisibleException("O histórico de envios do backup está danificado.") }
            .map { batch ->
                if (batch.sellerDeviceId.isBlank()) ExchangeCodec.withIntegrity(batch.copy(sellerDeviceId = incomingDeviceId)) else batch
            }
        val restoredProductIds = validateProductsJson(productsJson)
        validateBackupRelations(restoredConfig, restoredClients, restoredProductIds, restoredSales, restoredBatches)
        if (runCatching { UUID.fromString(restoredConfig.businessId) }.isFailure ||
            restoredClients.size > MAX_CLIENTS || restoredSales.size > MAX_SALES || restoredBatches.size > MAX_BATCHES ||
            productsJson.length() > MAX_PRODUCTS || restoredBatches.any { it.businessId != restoredConfig.businessId }) {
            throw UserVisibleException("O backup não passou na validação de segurança.")
        }
        return SellerBackupPreview(restoredClients.size, restoredSales.size, restoredBatches.size, root.optLong("createdAt", 0L))
    }

    fun markBackupSaved() {
        prefs.edit().putLong(KEY_LAST_BACKUP_AT, System.currentTimeMillis()).apply()
    }

    fun lastBackupAt(): Long? = prefs.getLong(KEY_LAST_BACKUP_AT, 0L).takeIf { it > 0L }

    @Synchronized
    fun importBackup(text: String) {
        val root = try { org.json.JSONObject(text) }
        catch (_: Exception) { throw UserVisibleException("Este arquivo não é um backup válido do Edi Vendas.") }
        if (root.optString("type") != "EDI_VENDAS_BACKUP" || root.optInt("schemaVersion", -1) !in 1..2) {
            throw UserVisibleException("Este arquivo não é compatível com esta versão do Edi Vendas.")
        }
        val configJson = root.optJSONObject("config")
            ?: throw UserVisibleException("O backup não contém a configuração da vendedora.")
        val clientsJson = root.optJSONArray("clients")
            ?: throw UserVisibleException("O backup não contém a lista de clientes.")
        val productsJson = root.optJSONArray("products") ?: org.json.JSONArray()
        val salesJson = root.optJSONArray("sales")
            ?: throw UserVisibleException("O backup não contém as vendas.")
        val batchesJson = root.optJSONArray("batches")
            ?: throw UserVisibleException("O backup não contém o histórico de envios.")
        val incomingDeviceId = root.optString("deviceId").takeIf { runCatching { UUID.fromString(it) }.isSuccess } ?: UUID.randomUUID().toString()

        val restoredConfig = ExchangeCodec.parseConfig(configJson.toString())
            ?: throw UserVisibleException("A configuração existente no backup está danificada.")
        val restoredClients = runCatching { ExchangeCodec.parseClients(clientsJson.toString()) }
            .getOrElse { throw UserVisibleException("A lista de clientes do backup está danificada.") }
        val restoredSales = runCatching { ExchangeCodec.parseSales(salesJson.toString()) }
            .getOrElse { throw UserVisibleException("As vendas do backup estão danificadas.") }
        val restoredBatches = runCatching { ExchangeCodec.parseBatches(batchesJson.toString()) }
            .getOrElse { throw UserVisibleException("O histórico de envios do backup está danificado.") }
            .map { batch ->
                if (batch.sellerDeviceId.isBlank()) ExchangeCodec.withIntegrity(batch.copy(sellerDeviceId = incomingDeviceId)) else batch
            }
        if (runCatching { UUID.fromString(restoredConfig.businessId) }.isFailure) {
            throw UserVisibleException("A identificação do negócio no backup está danificada.")
        }
        if (restoredClients.map { it.syncId }.distinct().size != restoredClients.size ||
            restoredClients.any { runCatching { UUID.fromString(it.syncId) }.isFailure }) {
            throw UserVisibleException("O backup contém clientes com identificação inválida ou repetida.")
        }
        if (restoredSales.any { runCatching { UUID.fromString(it.externalSaleId) }.isFailure }) {
            throw UserVisibleException("O backup contém vendas com identificação inválida.")
        }
        val visibleIds = restoredSales.map { it.displayId }.filter { it.isNotBlank() }
        if (visibleIds.distinct().size != visibleIds.size) {
            throw UserVisibleException("O backup contém códigos visíveis de venda repetidos.")
        }
        val restoredProductIds = validateProductsJson(productsJson)
        validateBackupRelations(restoredConfig, restoredClients, restoredProductIds, restoredSales, restoredBatches)
        if (restoredClients.size > MAX_CLIENTS || restoredSales.size > MAX_SALES || restoredBatches.size > MAX_BATCHES) {
            throw UserVisibleException("O backup ultrapassa os limites de segurança do aplicativo.")
        }
        if (restoredBatches.any { it.businessId != restoredConfig.businessId }) {
            throw UserVisibleException("O backup mistura históricos de negócios diferentes.")
        }

        val currentSafetyCopy = runCatching { exportBackup() }.getOrNull()
        val sequenceInSales = restoredSales.mapNotNull { sale ->
            Regex("^EDI-\\d{8}-(\\d+)$").matchEntire(sale.displayId)?.groupValues?.get(1)?.toIntOrNull()
        }.maxOrNull() ?: 0
        val safeSequence = maxOf(root.optInt("displaySequence", 0).coerceAtLeast(0), sequenceInSales)
        val editor = prefs.edit()
            .putString(KEY_CONFIG, ExchangeCodec.configToJson(restoredConfig).toString())
            .putString(KEY_CLIENTS, ExchangeCodec.clientsToJson(restoredClients).toString())
            .putString(KEY_PRODUCTS, productsJson.toString())
            .putString(KEY_SALES, ExchangeCodec.salesToJson(restoredSales).toString())
            .putString(KEY_BATCHES, ExchangeCodec.batchesToJson(restoredBatches).toString())
            .putString(KEY_DEVICE_ID, incomingDeviceId)
            .putInt(KEY_DISPLAY_SEQUENCE, safeSequence)
            .putBoolean(KEY_ONBOARDING_COMPLETE, root.optBoolean("onboardingComplete", true))
            .remove(KEY_CONFIG_ERROR).remove(KEY_CLIENTS_ERROR).remove(KEY_PRODUCTS_ERROR).remove(KEY_SALES_ERROR).remove(KEY_BATCHES_ERROR)
        currentSafetyCopy?.let { editor.putString(KEY_PRE_RESTORE_BACKUP, it) }
        if (!editor.commit()) throw UserVisibleException("O aparelho não confirmou a restauração do backup.")
    }

    @Synchronized
    fun importCatalog(text: String): BaseImportResult {
        val (businessId, incomingClients, incomingProducts) = try { TextExchange.catalog(text) }
        catch (error: Exception) { throw UserVisibleException((error as? UserVisibleException)?.message ?: "O catálogo copiado está incompleto ou inválido.") }
        val old = config() ?: throw UserVisibleException("Configure o nome da vendedora primeiro.")
        if (old.baseVersion > 0L && old.businessId != businessId) throw UserVisibleException("Este catálogo pertence a outro negócio.")
        val previous = clientsForMutation()
        val bySyncId = previous.associateBy { it.syncId }.toMutableMap()
        incomingClients.forEach { client -> bySyncId[client.syncId] = client.copy(externalClientKey = bySyncId[client.syncId]?.externalClientKey) }
        if (bySyncId.size > MAX_CLIENTS) throw UserVisibleException("O catálogo ultrapassa o limite de $MAX_CLIENTS clientes deste aparelho.")
        val default = incomingProducts.firstOrNull { it.syncId == old.productId && it.active }
            ?: incomingProducts.firstOrNull { it.active } ?: throw UserVisibleException("Catálogo sem produto ativo.")
        val newConfig = old.copy(businessId = businessId, baseVersion = System.currentTimeMillis(),
            productId = default.syncId, productName = default.name, unitPriceCents = default.unitPriceCents)
        val catalogJson = org.json.JSONArray().apply { incomingProducts.forEach { product ->
            put(org.json.JSONObject().put("syncId", product.syncId).put("name", product.name)
                .put("unitPriceCents", product.unitPriceCents).put("active", product.active))
        } }
        val currentSales = salesForMutation()
        val byName = incomingProducts.groupBy { searchKey(it.name) }
        val migratedSales = currentSales.map { sale ->
            fun migrate(row: SellerSaleItem): SellerSaleItem {
                val existing = incomingProducts.firstOrNull { it.syncId == row.productSyncId }
                if (existing != null) return row.copy(name = existing.name)
                val candidates = byName[searchKey(row.name)].orEmpty().filter { it.active }
                val match = when {
                    candidates.size == 1 -> candidates.single()
                    searchKey(row.name) == searchKey(old.productName) -> default
                    else -> null
                }
                return match?.let { row.copy(productSyncId = it.syncId, name = it.name) } ?: row
            }
            val sourceItems = sale.items.ifEmpty {
                listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents))
            }
            val migratedItems = sourceItems.map(::migrate)
            val primary = migratedItems.first()
            sale.copy(
                items = migratedItems,
                productId = primary.productSyncId,
                productNameSnapshot = primary.name,
                quantity = primary.quantity,
                unitPriceCents = primary.unitPriceCents,
            )
        }
        if (!prefs.edit().putString(KEY_CLIENTS, ExchangeCodec.clientsToJson(bySyncId.values.toList()).toString())
                .putString(KEY_CONFIG, ExchangeCodec.configToJson(newConfig).toString())
                .putString(KEY_PRODUCTS, catalogJson.toString())
                .putString(KEY_SALES, ExchangeCodec.salesToJson(migratedSales).toString())
                .remove(KEY_PRODUCTS_ERROR).commit()) throw UserVisibleException("Não foi possível salvar o catálogo.")
        return BaseImportResult(bySyncId.size, default.name, default.unitPriceCents, newConfig.baseVersion)
    }

    fun products(): List<SellerProduct> = try {
        val array = org.json.JSONArray(prefs.getString(KEY_PRODUCTS, "[]"))
        require(array.length() <= MAX_PRODUCTS)
        (0 until array.length()).map { i -> array.getJSONObject(i).let { row ->
            SellerProduct(
                UUID.fromString(row.getString("syncId")).toString(),
                row.getString("name").trim().also { require(it.isNotBlank() && it.length <= 120) },
                row.getLong("unitPriceCents").also { require(it in 1..MAX_UNIT_PRICE_CENTS) },
                row.optBoolean("active", true),
            )
        } }.filter { it.active }.also { prefs.edit().remove(KEY_PRODUCTS_ERROR).apply() }
    } catch (error: Exception) {
        recordDataError(KEY_PRODUCTS_ERROR, "O catálogo de produtos está danificado. Atualize novamente os dados do Santana Gestão.")
        emptyList()
    }

    fun config(): SellerConfig? {
        val raw = prefs.getString(KEY_CONFIG, null) ?: return null
        return ExchangeCodec.parseConfig(raw) ?: run {
            recordDataError(KEY_CONFIG_ERROR, "A configuração local está danificada. Restaure um backup válido antes de registrar novas vendas.")
            null
        }
    }

    @Synchronized
    fun saveInitialConfig(sellerName: String, productName: String, unitPriceCents: Long) {
        val cleanSeller = sellerName.trim().replace(Regex("\\s+"), " ")
        val cleanProduct = productName.trim().replace(Regex("\\s+"), " ")
        if (cleanSeller.isBlank()) throw UserVisibleException("Informe o nome da vendedora.")
        if (cleanProduct.isBlank()) throw UserVisibleException("Informe o nome do produto.")
        if (cleanSeller.length > 60 || cleanProduct.length > 120) throw UserVisibleException("Nome da vendedora ou do produto está longo demais.")
        if (unitPriceCents !in 1..MAX_UNIT_PRICE_CENTS) throw UserVisibleException("Informe um preço entre R$ 0,01 e R$ 1.000.000,00.")
        val current = config()
        val saved = SellerConfig(
            sellerName = cleanSeller,
            productId = current?.productId ?: "pao-de-mel",
            productName = cleanProduct,
            unitPriceCents = unitPriceCents,
            businessId = current?.businessId ?: UUID.randomUUID().toString(),
            baseVersion = current?.baseVersion ?: 0L,
        )
        val committed = prefs.edit()
            .putString(KEY_CONFIG, ExchangeCodec.configToJson(saved).toString())
            .putBoolean(KEY_ONBOARDING_COMPLETE, true)
            .remove(KEY_CONFIG_ERROR)
            .commit()
        if (!committed) throw UserVisibleException("O aparelho não confirmou a configuração. Tente novamente.")
    }

    @Synchronized
    fun updateConfig(sellerName: String, productName: String, unitPriceCents: Long) =
        saveInitialConfig(sellerName, productName, unitPriceCents)

    @Synchronized
    fun sellerDeviceId(): String {
        prefs.getString(KEY_DEVICE_ID, null)?.takeIf { runCatching { UUID.fromString(it) }.isSuccess }?.let { return it }
        val created = UUID.randomUUID().toString()
        if (!prefs.edit().putString(KEY_DEVICE_ID, created).commit()) {
            throw UserVisibleException("O aparelho não confirmou sua identificação. Tente gerar o lote novamente.")
        }
        return created
    }

    fun clients(): List<SellerClient> = clientsRaw().filter { it.active }.sortedBy { it.name.lowercase(Locale.ROOT) }

    @Synchronized
    fun addClient(name: String, phone: String, location: String): SellerClient {
        val cleanName = name.trim().replace(Regex("\\s+"), " ")
        if (cleanName.isBlank()) throw UserVisibleException("Informe o nome da cliente.")
        if (cleanName.length > 120 || phone.trim().length > 40 || location.trim().length > 160) {
            throw UserVisibleException("Algum dado da cliente está longo demais.")
        }
        val existingClients = clientsForMutation()
        if (existingClients.size >= MAX_CLIENTS) {
            throw UserVisibleException("O limite de $MAX_CLIENTS clientes deste aparelho foi atingido.")
        }
        val created = SellerClient(
            externalClientKey = UUID.randomUUID().toString(),
            name = cleanName,
            phone = phone.trim(),
            location = location.trim(),
        )
        val committed = prefs.edit()
            .putString(KEY_CLIENTS, ExchangeCodec.clientsToJson(existingClients + created).toString())
            .remove(KEY_CLIENTS_ERROR)
            .commit()
        if (!committed) throw UserVisibleException("O aparelho não confirmou o novo cliente. Tente novamente.")
        return created
    }

    fun similarClients(name: String): List<SellerClient> {
        val query = searchKey(name)
        if (query.length < 2) return emptyList()
        val first = query.substringBefore(' ')
        return clients().filter {
            val candidate = searchKey(it.name)
            candidate.contains(query) || query.contains(candidate) || candidate.substringBefore(' ') == first
        }.take(5)
    }

    fun sales(): List<SellerSale> = try {
        ExchangeCodec.parseSales(prefs.getString(KEY_SALES, "[]").orEmpty()).sortedByDescending { it.soldAt }
    } catch (error: Exception) {
        recordDataError(KEY_SALES_ERROR, error.message ?: "As vendas locais estão danificadas.")
        emptyList()
    }

    fun localSales(): List<SellerSale> = sales().filter { it.sentRevision < it.revision && !it.cancelled }.sortedBy { it.soldAt }

    fun localSales(saleDate: LocalDate): List<SellerSale> = localSales().filter { saleLocalDate(it.soldAt) == saleDate }

    fun salesForDate(saleDate: LocalDate): List<SellerSale> = sales()
        .filter { !it.cancelled && saleLocalDate(it.soldAt) == saleDate }
        .sortedByDescending { it.soldAt }

    fun batchHistoryLimit(): Int = MAX_BATCHES

    fun pendingDates(): List<LocalDate> = localSales().map { saleLocalDate(it.soldAt) }.distinct().sortedDescending()

    @Synchronized
    fun saveSale(sale: SellerSale): SellerSale {
        val allSales = salesForMutation()
        if (
            sale.externalSaleId.isBlank() || sale.externalSaleId.length > 120 ||
            (sale.adminClientId != null && sale.adminClientId <= 0L) ||
            (sale.externalClientKey != null && sale.externalClientKey.length > 120) ||
            sale.clientNameSnapshot.isBlank() || sale.clientNameSnapshot.length > 120 ||
            sale.clientPhoneSnapshot.length > 40 || sale.clientLocationSnapshot.length > 160 ||
            sale.productId.isBlank() || sale.productId.length > 120 ||
            sale.productNameSnapshot.isBlank() || sale.productNameSnapshot.length > 120
        ) {
            throw UserVisibleException("A venda está incompleta.")
        }
        if (sale.quantity !in 1..MAX_QUANTITY || sale.unitPriceCents !in 1..MAX_UNIT_PRICE_CENTS) {
            throw UserVisibleException("Confira quantidade e preço.")
        }
        val saleTotal = runCatching { sale.totalCents }.getOrElse { throw UserVisibleException("O total desta venda é muito alto.") }
        if (saleLocalDate(sale.soldAt).isAfter(LocalDate.now())) throw UserVisibleException("A data da venda não pode ficar no futuro.")
        if (saleTotal > MAX_SALE_TOTAL_CENTS) throw UserVisibleException("O total máximo de uma venda é ${ExchangeCodec.formatCents(MAX_SALE_TOTAL_CENTS)}.")
        if (sale.items.size !in 1..20 || sale.items.any { row ->
                row.quantity !in 1..MAX_QUANTITY || row.unitPriceCents !in 1..MAX_UNIT_PRICE_CENTS ||
                    row.productSyncId.isBlank() || row.name.isBlank()
            } || sale.receivedCents !in 0L..sale.totalCents ||
            sale.paidOnSpot != (sale.receivedCents > 0L) ||
            (sale.paidOnSpot && sale.receivedCents != sale.totalCents)) {
            throw UserVisibleException("Confira os produtos e o valor recebido.")
        }
        if (sale.paidOnSpot && sale.paymentMethod !in setOf("PIX", "Dinheiro", "Cartão")) {
            throw UserVisibleException("Escolha PIX, Dinheiro ou Cartão.")
        }
        if (!sale.paidOnSpot && sale.paymentMethod != null) {
            throw UserVisibleException("Venda em aberto não pode ter forma de pagamento.")
        }
        val existing = allSales.firstOrNull { it.externalSaleId == sale.externalSaleId }
        if (existing == null && allSales.size >= MAX_SALES) {
            throw UserVisibleException("O limite de $MAX_SALES vendas deste aparelho foi atingido. Faça um backup antes de arquivar dados antigos.")
        }
        val dateCode = DateTimeFormatter.BASIC_ISO_DATE.format(saleLocalDate(sale.soldAt))
        val sequence = prefs.getInt(KEY_DISPLAY_SEQUENCE, 0) + if (existing == null) 1 else 0
        val updatedSale = sale.copy(
            displayId = existing?.displayId?.takeIf { it.isNotBlank() } ?: "EDI-$dateCode-${sequence.toString().padStart(4, '0')}",
            revision = if (existing != null && existing.exportedRevision >= existing.revision) existing.revision + 1 else existing?.revision ?: 1,
            exportedRevision = existing?.exportedRevision ?: 0,
            sentRevision = existing?.sentRevision ?: 0,
            clientSyncId = sale.clientSyncId.ifBlank { sale.externalClientKey ?: sale.adminClientId?.let {
                UUID.nameUUIDFromBytes("santana-client:$it".toByteArray()).toString()
            } ?: "" },
            batchId = null,
        )
        if (updatedSale.clientSyncId.isBlank()) throw UserVisibleException("Cliente sem identificação. Atualize o cadastro antes de salvar.")
        val updated = allSales.filterNot { it.externalSaleId == sale.externalSaleId } + updatedSale
        if (existing == null && !prefs.edit().putInt(KEY_DISPLAY_SEQUENCE, sequence).commit()) throw UserVisibleException("Não foi possível reservar o código da venda.")
        saveSales(updated)
        return updatedSale
    }

    @Synchronized
    fun deleteSale(externalSaleId: String) {
        val allSales = salesForMutation()
        val target = allSales.firstOrNull { it.externalSaleId == externalSaleId }
            ?: throw UserVisibleException("Venda não encontrada.")
        if (target.exportedRevision > 0) throw UserVisibleException("Esta venda já foi preparada para envio e não pode ser excluída. Faça uma correção para o Santana Gestão.")
        saveSales(allSales.map { if (it.externalSaleId == externalSaleId) it.copy(cancelled = true) else it })
    }

    @Synchronized
    fun undoLastSale(): Boolean {
        val target = salesForMutation().firstOrNull { it.exportedRevision == 0 && !it.cancelled } ?: return false
        deleteSale(target.externalSaleId)
        return true
    }

    fun lastUndoableSale(): SellerSale? = sales().firstOrNull { it.exportedRevision == 0 && !it.cancelled }

    fun batches(): List<SellerBatch> = try {
        ExchangeCodec.parseBatches(prefs.getString(KEY_BATCHES, "[]").orEmpty()).sortedByDescending { it.createdAt }
    } catch (error: Exception) {
        recordDataError(KEY_BATCHES_ERROR, error.message ?: "O histórico de envios está danificado.")
        emptyList()
    }

    @Synchronized
    fun createBatch(persistForSending: Boolean = true): SellerBatch {
        val allSales = salesForMutation()
        val config = config() ?: throw UserVisibleException("Conclua a configuração inicial.")
        if (config.baseVersion <= 0L) throw UserVisibleException("Atualize os dados do Santana Gestão antes de enviar vendas.")
        val pending = allSales
            .filter { it.sentRevision < it.revision && !it.cancelled }
            .sortedBy { it.soldAt }
            .take(MAX_SALES_PER_BATCH)
        if (pending.isEmpty()) throw UserVisibleException("Não há vendas pendentes para enviar.")
        val legacy = pending.firstOrNull { sale ->
            val rows = sale.items.ifEmpty {
                listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents))
            }
            runCatching { UUID.fromString(sale.clientSyncId) }.isFailure ||
                rows.any { runCatching { UUID.fromString(it.productSyncId) }.isFailure }
        }
        if (legacy != null) {
            val rows = legacy.items.ifEmpty {
                listOf(SellerSaleItem(legacy.productId, legacy.productNameSnapshot, legacy.quantity, legacy.unitPriceCents))
            }
            val badProduct = rows.firstOrNull { runCatching { UUID.fromString(it.productSyncId) }.isFailure }?.name
            throw UserVisibleException(
                "A venda ${legacy.displayId.ifBlank { legacy.externalSaleId.take(8) }} usa cadastro antigo" +
                    (badProduct?.let { " do produto ‘$it’" } ?: "") +
                    ". Abra a venda, remova e adicione novamente o produto do catálogo atual, depois salve."
            )
        }
        val now = System.currentTimeMillis()
        val batchId = UUID.randomUUID().toString()
        val frozen = pending.map { it.copy(batchId = batchId, exportedRevision = maxOf(it.exportedRevision, it.revision)) }
        val draft = SellerBatch(
            schemaVersion = 3,
            batchId = batchId,
            businessId = config.businessId,
            sellerDeviceId = sellerDeviceId(),
            sellerName = config.sellerName,
            saleDate = saleLocalDate(frozen.minOf { it.soldAt }).toString(),
            createdAt = now,
            sales = frozen,
            integrity = "",
        )
        val batch = ExchangeCodec.withIntegrity(draft)
        if (persistForSending) {
            val revisions = frozen.associate { it.externalSaleId to it.revision }
            val updatedSales = allSales.map { sale ->
                revisions[sale.externalSaleId]?.takeIf { it == sale.revision }
                    ?.let { sale.copy(exportedRevision = maxOf(sale.exportedRevision, it)) } ?: sale
            }
            val updatedBatches = (batchesForMutation().filterNot { it.batchId == batch.batchId } + batch)
                .sortedByDescending { it.createdAt }.take(MAX_BATCHES)
            val committed = prefs.edit()
                .putString(KEY_SALES, ExchangeCodec.salesToJson(updatedSales).toString())
                .putString(KEY_BATCHES, ExchangeCodec.batchesToJson(updatedBatches).toString())
                .remove(KEY_SALES_ERROR).remove(KEY_BATCHES_ERROR)
                .commit()
            if (!committed) throw UserVisibleException("Não foi possível guardar o lote antes do compartilhamento. Nada foi marcado como enviado.")
        }
        return batch
    }

    @Synchronized
    fun markBatchShareStarted(batchId: String): SellerBatch {
        val stored = batchesForMutation().firstOrNull { it.batchId == batchId }
            ?: throw UserVisibleException("O lote preparado não foi encontrado. Gere o envio novamente.")
        val updated = stored.copy(shareStartedAt = stored.shareStartedAt ?: System.currentTimeMillis())
        val all = batchesForMutation().map { if (it.batchId == batchId) updated else it }
        if (!prefs.edit().putString(KEY_BATCHES, ExchangeCodec.batchesToJson(all).toString()).commit()) {
            throw UserVisibleException("Não foi possível registrar o início do compartilhamento.")
        }
        return updated
    }

    fun pendingBatchConfirmation(): SellerBatch? = batches().firstOrNull { it.shareStartedAt != null && it.sharedAt == null }

    @Synchronized
    fun dismissBatchConfirmation(batchId: String) {
        val all = batchesForMutation()
        val updated = all.map { if (it.batchId == batchId && it.sharedAt == null) it.copy(shareStartedAt = null) else it }
        if (!prefs.edit().putString(KEY_BATCHES, ExchangeCodec.batchesToJson(updated).toString()).commit()) {
            throw UserVisibleException("Não foi possível atualizar o estado do lote.")
        }
    }

    @Synchronized
    fun confirmBatchSent(batch: SellerBatch) {
        val allSales = salesForMutation()
        val storedBatch = batchesForMutation().firstOrNull { it.batchId == batch.batchId }
            ?: throw UserVisibleException("Este lote não está mais no histórico local. Gere um novo envio.")
        if (storedBatch.integrity != ExchangeCodec.integrity(storedBatch.copy(integrity = "", shareStartedAt = null, sharedAt = null))) {
            throw UserVisibleException("O lote preparado não passou na conferência de integridade.")
        }
        val revisions = storedBatch.sales.associate { it.externalSaleId to it.revision }
        if (storedBatch.sales.any { frozen -> allSales.none { it.externalSaleId == frozen.externalSaleId && it.revision >= frozen.revision } }) {
            throw UserVisibleException("Uma venda deste lote não foi encontrada. As demais continuam pendentes.")
        }
        val updatedSales = allSales.map { sale ->
            revisions[sale.externalSaleId]?.takeIf { it <= sale.revision }?.let { frozenRevision ->
                sale.copy(
                    exportedRevision = maxOf(sale.exportedRevision, frozenRevision),
                    sentRevision = maxOf(sale.sentRevision, frozenRevision),
                    batchId = storedBatch.batchId,
                )
            } ?: sale
        }
        val confirmedBatch = storedBatch.copy(
            shareStartedAt = storedBatch.shareStartedAt ?: System.currentTimeMillis(),
            sharedAt = System.currentTimeMillis(),
        )
        val updatedBatches = batchesForMutation().map { if (it.batchId == confirmedBatch.batchId) confirmedBatch else it }
            .sortedByDescending { it.createdAt }.take(MAX_BATCHES)
        val committed = prefs.edit()
            .putString(KEY_SALES, ExchangeCodec.salesToJson(updatedSales).toString())
            .putString(KEY_BATCHES, ExchangeCodec.batchesToJson(updatedBatches).toString())
            .remove(KEY_SALES_ERROR).remove(KEY_BATCHES_ERROR)
            .commit()
        if (!committed) throw UserVisibleException("O aparelho não confirmou o envio. As vendas continuam pendentes.")
    }

    fun exportSaleReceiptImage(sale: SellerSale): File {
        val rows = sale.items.ifEmpty { listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents)) }
        val bitmap = Bitmap.createBitmap(1080, 850 + rows.size * 130, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        val heading = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(66, 36, 31); textSize = 48f; typeface = Typeface.DEFAULT_BOLD }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(58, 42, 43); textSize = 34f }
        val pink = Paint(heading).apply { color = Color.rgb(218, 19, 99) }
        var y = 90f
        fun line(text: String, paint: Paint = body) { canvas.drawText(ellipsize(text, paint, 960f), 56f, y, paint); y += 65f }
        line("Edi Vendas", pink)
        line(sale.displayId, heading)
        if (sale.revision > 1) line("Revisão ${sale.revision} • substitui dados anteriores")
        line("Cliente: ${sale.clientNameSnapshot}")
        val soldMoment = Instant.ofEpochMilli(sale.soldAt).atZone(ZoneId.systemDefault())
        line(if (sale.saleTimeKnown) {
            "Data: ${soldMoment.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))}"
        } else {
            "Data: ${soldMoment.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))} • horário não informado"
        })
        if (sale.recordedAt != sale.soldAt) {
            line("Registrada em: ${Instant.ofEpochMilli(sale.recordedAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))}")
        }
        y += 24f
        rows.forEach { row ->
            line(row.name, heading)
            line("${row.quantity} × ${ExchangeCodec.formatCents(row.unitPriceCents)} = ${ExchangeCodec.formatCents(row.subtotalCents)}")
        }
        y += 20f
        line("Total: ${ExchangeCodec.formatCents(sale.totalCents)}", heading)
        line("Recebido: ${ExchangeCodec.formatCents(sale.receivedCents)}")
        line("Saldo: ${ExchangeCodec.formatCents(sale.totalCents - sale.receivedCents)}")
        line("Pagamento: ${sale.paymentMethod ?: "Não informado"}")
        line("Situação: ${when (sale.receivedCents) { 0L -> "Em aberto"; sale.totalCents -> "Pago"; else -> "Parcial" }}")
        return File(exchangeDir(), "Comprovante_${sale.displayId.ifBlank { sale.externalSaleId.take(8) }}.png").apply {
            outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 95, it) }
            bitmap.recycle()
        }
    }

    fun exportBatchSummaryImages(batch: SellerBatch): List<File> {
        if (batch.sales.isEmpty()) throw UserVisibleException("Este lote não possui vendas para o resumo visual.")
        val saleDates = batch.sales.map { saleLocalDate(it.soldAt) }.distinct().sorted()
        val period = if (saleDates.size == 1) formatSaleDate(saleDates.single().toString())
            else "${formatSaleDate(saleDates.first().toString())} a ${formatSaleDate(saleDates.last().toString())}"
        return batch.sales.chunked(3).mapIndexed { pageIndex, pageSales ->
            val estimatedHeight = 560 + pageSales.sumOf { sale ->
                val rows = sale.items.ifEmpty { listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents)) }
                190 + rows.size * 86
            }
            val bitmap = Bitmap.createBitmap(1080, estimatedHeight.coerceAtLeast(900), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            val cocoa = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(66, 36, 31); textSize = 42f; typeface = Typeface.DEFAULT_BOLD }
            val title = Paint(cocoa).apply { color = Color.rgb(202, 19, 91); textSize = 52f }
            val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(70, 66, 68); textSize = 29f }
            val strong = Paint(body).apply { color = Color.rgb(38, 36, 37); typeface = Typeface.DEFAULT_BOLD; textSize = 33f }
            val green = Paint(strong).apply { color = Color.rgb(32, 132, 83) }
            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(231, 226, 223); strokeWidth = 2f }
            var y = 78f
            fun line(text: String, paint: Paint = body, x: Float = 56f) { canvas.drawText(text, x, y, paint); y += paint.textSize + 18f }
            fun wrapped(text: String, paint: Paint = body, x: Float = 56f, maxWidth: Float = 968f) {
                val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.isEmpty()) { y += paint.textSize + 18f; return }
                var current = ""
                fun flush() { if (current.isNotBlank()) { line(current, paint, x); current = "" } }
                words.forEach { word ->
                    val candidate = if (current.isBlank()) word else "$current $word"
                    if (paint.measureText(candidate) <= maxWidth) current = candidate
                    else { flush(); current = word }
                }
                flush()
            }
            line("Edi Vendas", title)
            line("Resumo para conferência", cocoa)
            line("Período das vendas: $period", body)
            line("${batch.sales.size} vendas • Total ${ExchangeCodec.formatCents(batch.totalCents)}", green)
            if (batch.sales.size > pageSales.size) line("Página ${pageIndex + 1} de ${(batch.sales.size + 2) / 3}", body)
            y += 15f
            canvas.drawLine(56f, y, 1024f, y, linePaint); y += 42f
            pageSales.forEach { sale ->
                wrapped(sale.clientNameSnapshot, strong, maxWidth = 650f)
                line(ExchangeCodec.formatCents(sale.totalCents), green)
                val saleDateText = Instant.ofEpochMilli(sale.soldAt).atZone(ZoneId.systemDefault()).let { zdt ->
                    if (sale.saleTimeKnown) zdt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))
                    else zdt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " • horário não informado"
                }
                line("Venda: $saleDateText • ${sale.displayId} • revisão ${sale.revision}", body)
                val rows = sale.items.ifEmpty { listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents)) }
                rows.forEach { row ->
                    wrapped("${row.quantity} × ${row.name}", body)
                    line("${ExchangeCodec.formatCents(row.unitPriceCents)} cada • subtotal ${ExchangeCodec.formatCents(row.subtotalCents)}", body)
                }
                val status = when (sale.receivedCents) {
                    0L -> "Vai pagar depois"
                    sale.totalCents -> "Pago na hora • ${sale.paymentMethod ?: "forma não informada"}"
                    else -> "Pagamento parcial • recebido ${ExchangeCodec.formatCents(sale.receivedCents)}"
                }
                line(status, body)
                y += 10f
                canvas.drawLine(56f, y, 1024f, y, linePaint); y += 35f
            }
            File(exchangeDir(), "Resumo_Edi_${batch.batchId.take(8)}_${pageIndex + 1}.png").apply {
                outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 95, it) }
                bitmap.recycle()
            }
        }
    }

    fun exportBatchSummaryImage(batch: SellerBatch): File = exportBatchSummaryImages(batch).first()

    fun exportBatchFile(batch: SellerBatch): File {
        if (batch.sales.isEmpty()) throw UserVisibleException("Este lote não possui vendas.")
        val safeDate = batch.saleDate.replace(Regex("[^0-9-]"), "")
        return File(exchangeDir(), "Vendas_Edi_${safeDate}_${batch.batchId.take(8)}.edi").apply {
            writeText(TextExchange.batchText(batch), Charsets.UTF_8)
        }
    }

    fun uriFor(file: File): Uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)

    fun hasPreRestoreBackup(): Boolean = !prefs.getString(KEY_PRE_RESTORE_BACKUP, null).isNullOrBlank()

    fun draftState(): String? = prefs.getString(KEY_DRAFT_STATE, null)?.takeIf { it.isNotBlank() }

    @Synchronized
    fun saveDraftState(json: String) {
        if (json.length > 64_000) throw UserVisibleException("O rascunho da venda ficou grande demais para ser salvo com segurança.")
        prefs.edit().putString(KEY_DRAFT_STATE, json).apply()
    }

    @Synchronized
    fun clearDraftState() { prefs.edit().remove(KEY_DRAFT_STATE).commit() }

    @Synchronized
    fun restorePreRestoreBackup() {
        val backup = prefs.getString(KEY_PRE_RESTORE_BACKUP, null)
            ?: throw UserVisibleException("Não há cópia automática anterior à restauração.")
        importBackup(backup)
        prefs.edit().remove(KEY_PRE_RESTORE_BACKUP).commit()
    }

    fun dataWarning(): String? = listOf(KEY_CONFIG_ERROR, KEY_CLIENTS_ERROR, KEY_PRODUCTS_ERROR, KEY_SALES_ERROR, KEY_BATCHES_ERROR)
        .mapNotNull { prefs.getString(it, null) }
        .distinct()
        .joinToString("\n")
        .ifBlank { null }

    private fun clientsRaw(): List<SellerClient> = try {
        ExchangeCodec.parseClients(prefs.getString(KEY_CLIENTS, "[]").orEmpty())
    } catch (error: Exception) {
        recordDataError(KEY_CLIENTS_ERROR, error.message ?: "Os clientes locais estão danificados.")
        emptyList()
    }
    private fun clientsForMutation(): List<SellerClient> = try {
        requireHealthy(KEY_CLIENTS_ERROR)
        ExchangeCodec.parseClients(prefs.getString(KEY_CLIENTS, "[]").orEmpty())
    } catch (error: Exception) {
        val message = error.message ?: "Os clientes locais estão danificados."
        recordDataError(KEY_CLIENTS_ERROR, message)
        throw UserVisibleException(message)
    }
    private fun salesForMutation(): List<SellerSale> = try {
        requireHealthy(KEY_SALES_ERROR)
        ExchangeCodec.parseSales(prefs.getString(KEY_SALES, "[]").orEmpty()).sortedByDescending { it.soldAt }
    } catch (error: Exception) {
        val message = error.message ?: "As vendas locais estão danificadas."
        recordDataError(KEY_SALES_ERROR, message)
        throw UserVisibleException(message)
    }
    private fun batchesForMutation(): List<SellerBatch> = try {
        requireHealthy(KEY_BATCHES_ERROR)
        ExchangeCodec.parseBatches(prefs.getString(KEY_BATCHES, "[]").orEmpty()).sortedByDescending { it.createdAt }
    } catch (error: Exception) {
        val message = error.message ?: "O histórico de envios está danificado."
        recordDataError(KEY_BATCHES_ERROR, message)
        throw UserVisibleException(message)
    }
    private fun saveSales(items: List<SellerSale>) {
        val committed = prefs.edit()
            .putString(KEY_SALES, ExchangeCodec.salesToJson(items).toString())
            .remove(KEY_SALES_ERROR)
            .commit()
        if (!committed) throw UserVisibleException("O aparelho não confirmou a gravação das vendas. Tente novamente.")
    }
    private fun validateProductsJson(productsJson: org.json.JSONArray): Set<String> {
        if (productsJson.length() > MAX_PRODUCTS) throw UserVisibleException("O backup ultrapassa o limite de produtos.")
        val productIds = mutableSetOf<String>()
        for (index in 0 until productsJson.length()) {
            val product = productsJson.optJSONObject(index)
                ?: throw UserVisibleException("O catálogo de produtos do backup está danificado.")
            val syncId = product.optString("syncId")
            if (runCatching { UUID.fromString(syncId) }.isFailure || !productIds.add(syncId) ||
                product.optString("name").isBlank() || product.optString("name").length > 120 ||
                product.optLong("unitPriceCents", 0L) !in 1..MAX_UNIT_PRICE_CENTS) {
                throw UserVisibleException("O catálogo de produtos do backup está danificado.")
            }
        }
        return productIds
    }

    private fun validateBackupRelations(
        config: SellerConfig,
        clients: List<SellerClient>,
        productIds: Set<String>,
        sales: List<SellerSale>,
        batches: List<SellerBatch>,
    ) {
        val clientIds = clients.map { it.syncId }.toSet()
        if (sales.any { it.clientSyncId !in clientIds }) {
            throw UserVisibleException("O backup contém venda ligada a um cliente que não existe no próprio backup.")
        }
        if (config.baseVersion > 0L) {
            if (productIds.isEmpty()) throw UserVisibleException("O backup vinculado ao Santana Gestão não contém o catálogo de produtos.")
            val unknownProduct = sales.any { sale ->
                val rows = sale.items.ifEmpty {
                    listOf(SellerSaleItem(sale.productId, sale.productNameSnapshot, sale.quantity, sale.unitPriceCents))
                }
                rows.any { it.productSyncId !in productIds }
            }
            if (unknownProduct) {
                throw UserVisibleException("O backup contém venda ligada a um produto que não existe no catálogo salvo.")
            }
        }
        val current = sales.associateBy { it.externalSaleId }
        if (batches.any { batch -> batch.businessId != config.businessId || batch.sales.any { frozen ->
                current[frozen.externalSaleId]?.let { currentSale ->
                    currentSale.revision >= frozen.revision && currentSale.clientSyncId == frozen.clientSyncId
                } != true
            } }) {
            throw UserVisibleException("O backup contém um histórico de envio que não corresponde às versões das vendas salvas.")
        }
    }

    private fun exchangeDir(): File = File(appContext.cacheDir, "edi_exchange").apply { mkdirs() }
    private fun formatSaleDate(raw: String): String = runCatching {
        LocalDate.parse(raw).format(DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale("pt", "BR")))
    }.getOrDefault(raw)

    private fun saleLocalDate(millis: Long): LocalDate = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()

    private fun searchKey(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase(Locale.ROOT)
        .trim()

    private fun ellipsize(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var shortened = text
        while (shortened.length > 1 && paint.measureText("$shortened…") > maxWidth) shortened = shortened.dropLast(1)
        return "$shortened…"
    }

    private fun recordDataError(key: String, message: String) {
        prefs.edit().putString(key, message).apply()
    }

    private fun requireHealthy(key: String) {
        prefs.getString(key, null)?.let { throw UserVisibleException(it) }
    }

    companion object {
        private const val PREFS = "edi_vendas_v1"
        private const val KEY_CONFIG = "config"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_CLIENTS = "clients"
        private const val KEY_SALES = "sales"
        private const val KEY_BATCHES = "batches"
        private const val KEY_PRODUCTS = "products"
        private const val KEY_DISPLAY_SEQUENCE = "display_sequence"
        private const val KEY_ONBOARDING_COMPLETE = "onboarding_complete"
        private const val KEY_LAST_BACKUP_AT = "last_backup_at"
        private const val KEY_CONFIG_ERROR = "config_error"
        private const val KEY_CLIENTS_ERROR = "clients_error"
        private const val KEY_SALES_ERROR = "sales_error"
        private const val KEY_BATCHES_ERROR = "batches_error"
        private const val KEY_PRODUCTS_ERROR = "products_error"
        private const val KEY_PRE_RESTORE_BACKUP = "pre_restore_backup"
        private const val KEY_DRAFT_STATE = "sale_draft_state"
        private const val MAX_QUANTITY = 9_999
        private const val MAX_UNIT_PRICE_CENTS = 100_000_000L
        private const val MAX_CLIENTS = 20_000
        private const val MAX_PRODUCTS = 200
        private const val MAX_SALES = 50_000
        private const val MAX_SALE_TOTAL_CENTS = 2_000_000_000L
        private const val MAX_SALES_PER_BATCH = 20
        private const val MAX_BATCHES = 120
    }
}

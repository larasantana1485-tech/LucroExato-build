package br.com.edivendas.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Base64
import java.util.UUID
import java.util.zip.GZIPOutputStream

class ExchangeCodecTest {
    private fun compactCatalog(rawJson: String): String {
        val raw = rawJson.toByteArray(Charsets.UTF_8)
        val zipped = ByteArrayOutputStream().use { output ->
            GZIPOutputStream(output).use { it.write(raw) }
            output.toByteArray()
        }
        val hash = MessageDigest.getInstance("SHA-256").digest(raw).joinToString("") { "%02x".format(it) }
        return "${TextExchange.COMPACT_CATALOG_START}\n" +
            "{\"encoding\":\"gzip-base64\",\"rawLength\":${raw.size},\"sha256\":\"$hash\",\"payload\":\"${Base64.getEncoder().encodeToString(zipped)}\"}\n" +
            TextExchange.COMPACT_CATALOG_END
    }

    @Test
    fun `lote preserva ids e valores em centavos`() {
        val sale = SellerSale(
            externalSaleId = UUID.randomUUID().toString(),
            clientNameSnapshot = "Juliana Santos",
            productId = "pao-de-mel",
            productNameSnapshot = "Pão de mel",
            quantity = 4,
            unitPriceCents = 800,
            paidOnSpot = true,
            paymentMethod = "PIX",
            soldAt = 1_789_662_000_000,
            batchId = "batch",
        )
        assertEquals(3_200L, sale.totalCents)
        val batch = ExchangeCodec.withIntegrity(
            SellerBatch(
                batchId = UUID.randomUUID().toString(),
                businessId = UUID.randomUUID().toString(),
                sellerDeviceId = UUID.randomUUID().toString(),
                sellerName = "Edilane",
                saleDate = "2026-09-17",
                createdAt = 1_789_662_100_000,
                sales = listOf(sale),
                integrity = "",
            ),
        )
        val json = ExchangeCodec.batchToExportJson(batch)
        assertTrue(json.contains("SANTANA_SELLER_DAY"))
        assertTrue(json.contains("\"totalCents\": 3200"))
        assertTrue(batch.integrity.length == 64)
        val text = TextExchange.batchText(batch)
        assertTrue(text.contains("\"businessId\":\"${batch.businessId}\""))
        assertTrue(text.contains("Vendas pendentes do Edi"))
    }

    @Test
    fun `nome da vendedora nao altera assinatura fechada da V1`() {
        val base = SellerBatch(
            schemaVersion = 1,
            batchId = UUID.randomUUID().toString(),
            businessId = "negocio",
            sellerDeviceId = "celular",
            sellerName = "Edilane",
            saleDate = "2026-09-17",
            createdAt = 1000,
            sales = listOf(
                SellerSale(
                    clientNameSnapshot = "Ana",
                    productId = "pao-de-mel",
                    productNameSnapshot = "Pão de mel",
                    quantity = 1,
                    unitPriceCents = 900,
                    paidOnSpot = false,
                    soldAt = 900,
                ),
            ),
            integrity = "",
        )
        assertEquals(ExchangeCodec.integrity(base), ExchangeCodec.integrity(base.copy(sellerName = "Outra pessoa")))
        assertNotEquals(ExchangeCodec.integrity(base), ExchangeCodec.integrity(base.copy(saleDate = "2026-09-18")))
    }

    @Test
    fun `assinaturas V1 e V2 permanecem estaveis e compativeis`() {
        val sale = SellerSale(
            externalSaleId = "sale-1",
            externalClientKey = "client-key",
            clientNameSnapshot = "Ana",
            clientPhoneSnapshot = "11999999999",
            clientLocationSnapshot = "Centro",
            productId = "pao-de-mel",
            productNameSnapshot = "Pão de mel",
            quantity = 2,
            unitPriceCents = 900,
            paidOnSpot = true,
            paymentMethod = "PIX",
            soldAt = 900,
            batchId = "batch-1",
        )
        val base = SellerBatch(
            schemaVersion = 2,
            batchId = "batch-1",
            businessId = "business-1",
            sellerDeviceId = "device-1",
            sellerName = "Edilane",
            saleDate = "2026-09-17",
            createdAt = 1000,
            sales = listOf(sale),
            integrity = "",
        )
        assertEquals("c2041a53373e1fc763ab5a23905e7952248f07f8efe2c7b85553d3fdf245af3c", ExchangeCodec.integrity(base))
        assertEquals(
            "9ed801fb4a56cef0385330828aa9f81a44abf0ac6ebae5875f4ecccc57d26acd",
            ExchangeCodec.integrity(base.copy(schemaVersion = 1)),
        )
    }

    @Test
    fun `V2 detecta alteracao de telefone local e vinculo do lote`() {
        val sale = SellerSale(
            externalSaleId = "sale-1",
            externalClientKey = "client-key",
            clientNameSnapshot = "Ana",
            clientPhoneSnapshot = "11999999999",
            clientLocationSnapshot = "Centro",
            productId = "pao-de-mel",
            productNameSnapshot = "Pão de mel",
            quantity = 1,
            unitPriceCents = 900,
            paidOnSpot = false,
            soldAt = 900,
            batchId = "batch-1",
        )
        val batch = SellerBatch(
            schemaVersion = 2,
            batchId = "batch-1",
            businessId = "business-1",
            sellerDeviceId = "device-1",
            sellerName = "Edilane",
            saleDate = "2026-09-17",
            createdAt = 1000,
            sales = listOf(sale),
            integrity = "",
        )
        val original = ExchangeCodec.integrity(batch)
        assertNotEquals(original, ExchangeCodec.integrity(batch.copy(sales = listOf(sale.copy(clientPhoneSnapshot = "11888888888")))))
        assertNotEquals(original, ExchangeCodec.integrity(batch.copy(sales = listOf(sale.copy(clientLocationSnapshot = "Bairro")))))
        assertNotEquals(original, ExchangeCodec.integrity(batch.copy(sales = listOf(sale.copy(batchId = "outro")))))
    }

    @Test
    fun `V3 protege campos financeiros revisao snapshots e itens`() {
        val item = SellerSaleItem("prod-1", "Pão de mel", 2, 900)
        val sale = SellerSale(
            externalSaleId = "sale-1",
            externalClientKey = "client-key",
            clientSyncId = "client-key",
            clientNameSnapshot = "Ana",
            clientPhoneSnapshot = "11999999999",
            clientLocationSnapshot = "Loja A",
            productId = "prod-1",
            productNameSnapshot = "Pão de mel",
            quantity = 2,
            unitPriceCents = 900,
            paidOnSpot = true,
            paymentMethod = "PIX",
            soldAt = 900,
            recordedAt = 1000,
            saleTimeKnown = false,
            displayId = "EDI-20260922-0001",
            revision = 2,
            exportedRevision = 2,
            sentRevision = 1,
            batchId = "batch-1",
            items = listOf(item),
            receivedCents = 1800,
        )
        val batch = SellerBatch(
            schemaVersion = 3,
            batchId = "batch-1",
            businessId = "business-1",
            sellerDeviceId = "device-1",
            sellerName = "Edilane",
            saleDate = "2026-09-22",
            createdAt = 1000,
            sales = listOf(sale),
            integrity = "",
        )
        val original = ExchangeCodec.integrity(batch)
        val variants = listOf(
            batch.copy(sales = listOf(sale.copy(receivedCents = 0))),
            batch.copy(sales = listOf(sale.copy(revision = 3))),
            batch.copy(sales = listOf(sale.copy(displayId = "EDI-20260922-9999"))),
            batch.copy(sales = listOf(sale.copy(clientNameSnapshot = "Ana Maria"))),
            batch.copy(sales = listOf(sale.copy(items = listOf(item.copy(quantity = 1))))),
            batch.copy(sales = listOf(sale.copy(paymentMethod = "Dinheiro"))),
            batch.copy(sales = listOf(sale.copy(saleTimeKnown = true))),
        )
        assertTrue(variants.all { ExchangeCodec.integrity(it) != original })
    }

    @Test
    fun `rejeita pagamento incoerente e total com overflow`() {
        val paidWithoutMethod = """
            [{"externalSaleId":"sale-1","clientNameSnapshot":"Ana","productId":"p","productNameSnapshot":"Produto","quantity":1,"unitPriceCents":900,"totalCents":900,"paidOnSpot":true,"soldAt":900}]
        """.trimIndent()
        val overflowed = """
            [{"externalSaleId":"sale-2","clientNameSnapshot":"Ana","productId":"p","productNameSnapshot":"Produto","quantity":2147483647,"unitPriceCents":9223372036854775807,"totalCents":-2147483647,"paidOnSpot":false,"soldAt":900}]
        """.trimIndent()
        assertThrows(UserVisibleException::class.java) { ExchangeCodec.parseSales(paidWithoutMethod) }
        assertThrows(UserVisibleException::class.java) { ExchangeCodec.parseSales(overflowed) }
    }

    @Test
    fun `cartao permanece valido ao salvar e restaurar venda`() {
        val id = UUID.randomUUID().toString()
        val json = """
            [{"externalSaleId":"$id","clientNameSnapshot":"Ana","productId":"p","productNameSnapshot":"Produto","quantity":1,"unitPriceCents":900,"totalCents":900,"paidOnSpot":true,"paymentMethod":"Cartão","receivedCents":900,"soldAt":900,"items":[]}]
        """.trimIndent()
        val parsed = ExchangeCodec.parseSales(json).single()
        assertEquals("Cartão", parsed.paymentMethod)
        assertEquals(900L, parsed.receivedCents)
    }

    @Test
    fun `rejeita base com preco fora do limite`() {
        val json = """
            ${TextExchange.CATALOG_START}
            {"businessId":"550e8400-e29b-41d4-a716-446655440000","clients":[],
             "products":[{"syncId":"550e8400-e29b-41d4-a716-446655440001","name":"Produto","unitPriceCents":100000001,"active":true}]}
            ${TextExchange.CATALOG_END}
        """.trimIndent()
        assertThrows(IllegalArgumentException::class.java) { TextExchange.catalog(json) }
    }

    @Test
    fun `base oficial importa produto preco e clientes`() {
        val json = """
            ${TextExchange.CATALOG_START}
            {"businessId":"550e8400-e29b-41d4-a716-446655440000",
             "clients":[{"syncId":"550e8400-e29b-41d4-a716-446655440001","name":"Maria","location":"Loja A","active":true}],
             "products":[{"syncId":"550e8400-e29b-41d4-a716-446655440002","name":"Pão de mel","unitPriceCents":900,"active":true}]}
            ${TextExchange.CATALOG_END}
        """.trimIndent()
        val (businessId, clients, products) = TextExchange.catalog(json)
        assertEquals("550e8400-e29b-41d4-a716-446655440000", businessId)
        assertEquals(900L, products.single().unitPriceCents)
        assertEquals("Maria", clients.single().name)
        assertFalse(clients.isEmpty())
    }

    @Test
    fun `catalogo compacto importa e detecta corte`() {
        val raw = """{"businessId":"550e8400-e29b-41d4-a716-446655440000","clients":[{"syncId":"550e8400-e29b-41d4-a716-446655440001","name":"Maria","active":true}],"products":[{"syncId":"550e8400-e29b-41d4-a716-446655440002","name":"Pão de mel","unitPriceCents":900,"active":true}]}"""
        val compact = compactCatalog(raw)
        val (_, clients, products) = TextExchange.catalog(compact)
        assertEquals("Maria", clients.single().name)
        assertEquals(900L, products.single().unitPriceCents)
        assertThrows(UserVisibleException::class.java) { TextExchange.catalog(compact.dropLast(12)) }
    }
}

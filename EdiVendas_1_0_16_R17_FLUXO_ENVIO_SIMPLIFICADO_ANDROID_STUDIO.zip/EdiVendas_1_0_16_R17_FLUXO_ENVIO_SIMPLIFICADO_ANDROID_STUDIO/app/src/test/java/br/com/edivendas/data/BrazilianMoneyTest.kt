package br.com.edivendas.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class BrazilianMoneyTest {
    @Test
    fun `interpreta formatos brasileiros sem trocar milhar por centavo`() {
        assertEquals(100_000L, BrazilianMoney.parsePriceCents("1.000"))
        assertEquals(123_456L, BrazilianMoney.parsePriceCents("1.234,56"))
        assertEquals(1_025L, BrazilianMoney.parsePriceCents("10,25"))
        assertEquals(1_025L, BrazilianMoney.parsePriceCents("10.25"))
    }

    @Test
    fun `rejeita sinal negativo em vez de transforma-lo em positivo`() {
        assertThrows(UserVisibleException::class.java) { BrazilianMoney.parsePriceCents("-10,00") }
        assertEquals("-10,00", BrazilianMoney.sanitizeInput("-10,00"))
    }

    @Test
    fun `formata centavos sem usar Double`() {
        assertEquals("1234,56", BrazilianMoney.centsToInput(123_456L))
    }
}

# O piloto não usa reflexão nem serialização externa.

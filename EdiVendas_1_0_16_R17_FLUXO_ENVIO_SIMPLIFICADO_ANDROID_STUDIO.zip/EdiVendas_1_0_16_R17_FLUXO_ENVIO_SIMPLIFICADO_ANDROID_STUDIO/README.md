# Edi Vendas — 1.0.16 piloto


## R17 — fluxo de envio simplificado

- Home volta a ter **Compartilhar** no topo e aviso destacado somente quando há pendências de dias anteriores.
- Nova venda pergunta **Vai pagar agora?** com **Não** e **Sim** sem pré-seleção.
- Subtotal ficou maior e mais alinhado à direita; o Total ganhou folga para não ser coberto pelo CTA fixo.
- **Revisar e enviar vendas** agora tem um único botão fixo **Enviar**.
- Esse botão abre uma meia aba com **Enviar arquivo .edi**, **Compartilhar resumo em imagem** e **Mostrar QR Code**.
- Os estados visíveis foram simplificados para **Enviado**, **Não enviado** e **Corrigida — reenviar**.
- Gerar arquivo/QR continua separado da confirmação real de envio.

Consulte `R17_FLUXO_ENVIO_SIMPLIFICADO.md` e execute `python scripts/audit_r17_flow.py`.


## R16 — layouts aprovados

- Home branca com **Histórico completo** e **Histórico de envios** em pills lado a lado e cores diferentes.
- Lista de clientes sem “Recentes”; separadores alfabéticos agora são **letra + linha fina**, sem caixas.
- Registrar venda usa **um único campo de data com calendário**; saíram os três pills Hoje/Ontem/Outra.
- Cliente, produto, valor e ações ganharam hierarquia e agrupamento conforme os mockups aprovados.
- Pagamento agora é apresentado como **Vai pagar depois** / **Pago na hora**, mantendo PIX/Dinheiro/Cartão quando necessário.
- Histórico de envios agrupa cada lote em sua **própria caixa de borda fina**; o botão **Reenviar lote** fica dentro do lote correto.
- Textos técnicos repetitivos (ID curto do lote, R1 e chips de arquivo na Home) foram retirados das telas principais.

Consulte `R16_LAYOUTS_APROVADOS.md` e execute `python scripts/audit_r16_layout.py` para a checagem estática específica desta rodada.

## R15 — correções da auditoria R14

- Corrige os estados de **gerado/exportado**, **compartilhamento iniciado** e **envio confirmado pela vendedora**, sem afirmar importação no Santana Gestão.
- Edição depois de gerar arquivo/QR passa a ser nova revisão; confirmar um lote antigo não marca uma edição posterior como enviada.
- Venda de outro dia permanece somente na data comercial correta; data da venda e momento do registro são distintos.
- Backup gera/valida a identificação do aparelho, faz validação cruzada, cria cópia de segurança antes de restaurar e oferece recuperação.
- Entrada monetária usa parser pt-BR explícito em centavos; `1.000` é mil reais e valores negativos são rejeitados.
- Catálogo tenta reconciliar produtos legados, inclusive vendas antigas sem lista de itens normalizada.
- Resumo visual do lote é paginado e não oculta produtos, quantidades, valores ou a data da venda.
- Histórico ganhou detalhe somente leitura e total geral compacto.
- Rascunho de venda sobrevive à recriação do app e pode ser continuado ou descartado.
- Novo cliente e seletor de produto seguem os modais brancos compactos aprovados; produto tem busca e rolagem própria; CTA de venda fica fixo.
- A tela **Venda anotada** mantém estrutura e ações, com fundo branco.

Consulte `R15_CORRECOES_AUDITORIA.md` para a rastreabilidade F02–F28 e `VALIDACAO_R15.md` para o que foi realmente executado neste ambiente.

## R14 — histórico da revisão anterior

- A Home mostra somente as vendas da data atual; pendências antigas continuam na tela de envio.
- Cada venda pode ser lançada como **Hoje**, **Ontem** ou em outra data pelo calendário.
- O envio principal gera um arquivo `.edi` que o Santana Gestão pode importar, sem despejar o conteúdo técnico na conversa.
- A Home ficou branca, sem cabeçalho tradicional nem card duplicado de resumo, e ganhou envio fixo no rodapé.
- Clientes passaram a usar lista sem caixas, avatares coloridos e divisores finos.
- Produtos usam ícones coloridos e seletor de quantidade rosa pastel, seguindo as referências visuais aprovadas.
- O histórico completo agrupa todas as vendas por data; o histórico de envios continua separado.
- A tela **Venda anotada** mudou somente para fundo branco.


## R13 — usabilidade baseada no teste real da Edilane

- **Voltar agora é navegação, não descarte**: na tela Revisar venda, seta do topo e botão Voltar do Android fazem o mesmo que **Corrigir**, retornando à edição com o rascunho preservado.
- **Cancelar/Excluir ficou separado da navegação**: nova venda pode ser descartada por uma ação explícita; venda já salva e ainda não enviada pode ser excluída por esse fluxo; correção de venda já enviada apenas descarta as alterações locais e mantém a venda original.
- O botão **Desfazer** saiu da Home. Vendas editáveis do dia agora exibem um **lápis** e abrem a correção contextual.
- A seção **Vendas de hoje** ganhou contagem e cards mais claros, mantendo o envio pendente como ação principal.
- A lista de clientes ganhou **divisores alfabéticos** (A, B, C...) e mantém nome em destaque com local/telefone na segunda linha quando esses campos existem no cadastro.
- A seção **Recentes** não foi adicionada nesta rodada; ficou para novo teste de usabilidade.
- Fluxo de envio por WhatsApp, QR Code e imagem não foi alterado.

## R11 — resumo diário sem repetição

- O produto principal do catálogo entra automaticamente na nova venda com quantidade 1.
- Lista de clientes, cadastro e seleção de produtos ficaram mais compactos.
- O seletor de produtos agora usa bottom sheet baixo e legível.
- Revisão e confirmação seguem os mockups aprovados.
- Depois do envio técnico, o app oferece uma imagem separada com o resumo visual do lote.
- A tela Hoje identifica cada venda como **Não enviada**, **Envio confirmado** ou **Correção pendente**.
- Pagamento integral aceita **PIX, Dinheiro ou Cartão**. Pagamento parcial continua fora do fluxo da vendedora.
- Lotes antigos com correções posteriores não podem ser reenviados por engano.
- QR Code, mensagem de WhatsApp e resumo em imagem aparecem como três opções separadas.
- Rascunhos e restaurações de backup possuem confirmação antes de descartar ou substituir dados.

Aplicativo Android local para Edilane registrar vendas e enviar **um arquivo `.edi`** por WhatsApp. O Santana Gestão faz a conferência e o registro definitivo.

## Fluxo

- No primeiro uso, informe nome, produto e preço.
- Ricardo copia e compartilha o catálogo em **Gestão → Configurações → Integração Edi Vendas**. Edilane copia a mensagem e toca em **Edi → Configurações → Atualizar dados do Santana Gestão**.
- Registre uma ou várias vendas. Cada produto aparece em uma linha própria com quantidade, preço, subtotal e remoção. Selecionar novamente o mesmo produto aumenta a quantidade da linha existente. O preço especial da venda não altera o produto cadastrado.
- Toque **Enviar vendas pendentes**, escolha WhatsApp e confirme **Sim, enviei** somente depois que o arquivo `.edi` aparecer na conversa e concluir o envio. O aplicativo não marca automaticamente uma venda como enviada ao abrir o WhatsApp.
- **Enviar comprovante ao cliente** envia uma imagem separada. A própria tela explica que o envio ao Gestão acontece em Hoje > Enviar.
- Para corrigir venda enviada, abra **Histórico de envios → Corrigir**, altere, salve e reenvie. A correção mantém o código e aumenta a revisão.
- Cada arquivo leva até 20 vendas; se houver mais, as restantes continuam pendentes. Clientes homônimos são distinguidos pelo identificador técnico, nunca pelo nome.
- Em **Configurações → Backup manual**, é possível salvar ou restaurar configuração, catálogo, clientes, vendas e histórico de envios. O conteúdo é validado antes da restauração.

O arquivo transporta IDs e valores em centavos entre `[EDI-BATCH-V1]` e `[/EDI-BATCH-V1]`. O Edi não recebe status de importação do Gestão.

## Abrir no Android Studio

Abra esta pasta como projeto Android. Use Java 17 e SDK 36. O plugin Android Gradle `8.13.2` precisa ser resolvido pelo Android Studio. Execute **Build → Make Project** e depois **Run ▶**. Veja `VALIDACAO_V1.md` antes de usar vendas reais.

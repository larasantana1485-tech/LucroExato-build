# Edi Vendas 1.0.11 — WhatsApp, imagem e QR Code

## Uso

1. Configure nome da vendedora, produto e preço inicial.
2. Copie a mensagem de catálogo enviada pelo Santana Gestão. Abra Configurações e toque **Atualizar dados do Santana Gestão**.
3. Registre vendas; altere o preço de uma venda sem alterar o preço do cadastro. Adicione mais produtos quando necessário.
4. Toque **Enviar vendas pendentes**, compartilhe o texto pelo WhatsApp e confirme **Sim, enviei** ao retornar. Cancelar mantém as vendas pendentes.
5. Use **Enviar comprovante ao cliente** para enviar a imagem separadamente.
6. Em **Histórico de envios**, toque **Corrigir** na venda enviada. O código permanece igual e a revisão aumenta.
7. Cadastre ou importe dois clientes com o mesmo nome e confirme que ambos aparecem e podem ser escolhidos separadamente.
8. Registre vendas pagas integralmente em PIX, Dinheiro e Cartão; as três devem salvar normalmente.
9. Confira na tela Hoje os estados Não enviada, Envio confirmado e Correção pendente.
10. Corrija uma venda enviada e confirme que o lote antigo fica bloqueado para reenvio.
11. Inicie uma venda, pressione Voltar e confirme que o app pergunta antes de descartar.
12. Abra um backup e confirme que clientes, vendas e envios são mostrados antes da substituição.

## Validação neste ambiente

- Auditoria estática: `python3 scripts/audit_release.py`.
- Estrutura de Kotlin inspecionada; modelos básicos compilados com o compilador Kotlin disponível.
- Compilação Android completa não foi possível: o plugin Android `8.13.2` não estava disponível nos repositórios deste ambiente.
- Teste no Android Studio com os dois aplicativos antes de usar vendas reais. Confira especialmente a mensagem completa com 20 vendas e a confirmação de envio ao voltar do WhatsApp.


## R13 — validação de usabilidade e navegação

Antes de usar vendas reais, testar no aparelho da Edilane sem explicar onde tocar:

1. **Nova venda → Revisar**: registrar 1 unidade, chegar em Revisar e apertar a seta do topo. Deve voltar para Registrar venda com cliente, produto, quantidade, preço e pagamento preservados.
2. Repetir usando o **botão Voltar virtual do Android**. O resultado deve ser idêntico ao botão Corrigir.
3. Em Revisar, tocar **Corrigir**. Deve fazer a mesma navegação dos dois itens anteriores.
4. Em Registrar venda, tocar **Cancelar esta venda** e escolher **Continuar venda**. Nada deve ser perdido.
5. Repetir e escolher **Descartar venda**. Deve voltar à Home sem salvar a venda.
6. Salvar uma venda ainda não enviada, abrir pelo **lápis** na Home, tocar **Cancelar esta venda** e confirmar **Excluir venda**. Ela deve sumir da lista e dos pendentes.
7. Abrir uma venda já enviada pelo histórico, iniciar correção e tocar **Cancelar correção**. A venda original deve permanecer e nenhuma nova revisão deve ser criada.
8. Na Home, confirmar que não existe mais **Desfazer** e que **Enviar N pendentes** continua funcionando.
9. Na lista de clientes, confirmar os divisores A/B/C e verificar que nome/local aparecem em linhas diferentes quando o cadastro possui `location` separado.
10. Confirmar que clientes com local embutido no próprio nome (ex.: `Amanda/Dr Consulta`) continuam sendo exibidos literalmente; esta versão não tenta separar automaticamente pela barra.
11. Repetir o envio por WhatsApp/QR para confirmar que a rodada de UX não alterou integração.

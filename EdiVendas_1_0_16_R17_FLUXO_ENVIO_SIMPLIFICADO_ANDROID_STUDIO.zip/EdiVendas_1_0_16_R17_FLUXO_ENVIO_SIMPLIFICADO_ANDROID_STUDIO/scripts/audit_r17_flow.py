from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
ui = (root / 'app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt').read_text(encoding='utf-8')
store = (root / 'app/src/main/java/br/com/edivendas/data/SellerStore.kt').read_text(encoding='utf-8')
build = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')

checks = [
    ('versionCode 116', 'versionCode = 116' in build),
    ('version 1.0.16', 'versionName = "1.0.16-piloto"' in build),
    ('Home Compartilhar', 'Text("Compartilhar", maxLines = 1)' in ui),
    ('Home aviso pendencias antigas', 'vendas pendentes de dias anteriores' in ui),
    ('Vai pagar agora', 'Text("Vai pagar agora?"' in ui),
    ('escolha de pagamento persistida', 'paymentChoiceMade' in ui),
    ('nova venda sem preseleção', 'paidOnSpot = if (paymentChoiceMade) paidOnSpot else null' in ui),
    ('subtotal maior e direita', 'Modifier.width(144.dp)' in ui and 'style = MaterialTheme.typography.titleLarge' in ui),
    ('um botão Enviar fixo', 'Text(if (creatingBatch) "Preparando…" else "Enviar"' in ui),
    ('modal bottom sheet', 'ModalBottomSheet(' in ui),
    ('opção arquivo edi', 'title = "Enviar arquivo .edi"' in ui),
    ('opção resumo imagem', 'title = "Compartilhar resumo em imagem"' in ui),
    ('opção QR', 'title = "Mostrar QR Code"' in ui),
    ('status Enviado', '"Enviado" to BrandGreenSoft' in ui),
    ('status Não enviado', '"Não enviado" to BrandAmberSoft' in ui),
    ('status Corrigida reenviar', '"Corrigida — reenviar" to BrandPinkSoft' in ui),
    ('sem status Arquivo/QR gerado', 'Arquivo/QR gerado' not in ui),
    ('mensagem de exclusão sem jargão QR', 'já gerou um arquivo ou QR' not in store),
]

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('OK  ' if ok else 'FAIL') + name)

if failed:
    print('\nFalhas:', ', '.join(failed))
    sys.exit(1)
print(f'\n{len(checks)}/{len(checks)} verificações R17 passaram.')

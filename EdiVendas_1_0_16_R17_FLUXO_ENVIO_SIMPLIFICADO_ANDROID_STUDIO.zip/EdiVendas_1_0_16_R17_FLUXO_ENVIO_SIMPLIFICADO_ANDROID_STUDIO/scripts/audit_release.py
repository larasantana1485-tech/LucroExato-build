#!/usr/bin/env python3
"""Checklist estático do Edi Vendas R15.

IMPORTANTE: este script confirma presença/estrutura de proteções no código e validade XML.
Ele NÃO substitui compilação Android, testes de unidade, integração, UI ou homologação em aparelho.
"""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app" / "src" / "main"
checks: list[tuple[str, bool]] = []

def check(label: str, condition: bool) -> None:
    checks.append((label, bool(condition)))
    print(("OK    " if condition else "FALHA ") + label)

build = (ROOT / "app" / "build.gradle.kts").read_text(encoding="utf-8")
manifest = (APP / "AndroidManifest.xml").read_text(encoding="utf-8")
main = (APP / "java/br/com/edivendas/MainActivity.kt").read_text(encoding="utf-8")
ui = (APP / "java/br/com/edivendas/ui/EdiVendasApp.kt").read_text(encoding="utf-8")
store = (APP / "java/br/com/edivendas/data/SellerStore.kt").read_text(encoding="utf-8")
models = (APP / "java/br/com/edivendas/data/Models.kt").read_text(encoding="utf-8")
codec = (APP / "java/br/com/edivendas/data/ExchangeCodec.kt").read_text(encoding="utf-8")
money = (APP / "java/br/com/edivendas/data/BrazilianMoney.kt").read_text(encoding="utf-8")
text_codec = (APP / "java/br/com/edivendas/data/TextExchange.kt").read_text(encoding="utf-8")
theme = (APP / "java/br/com/edivendas/ui/Theme.kt").read_text(encoding="utf-8")
styles = (APP / "res/values/styles.xml").read_text(encoding="utf-8")
r15 = (ROOT / "R15_CORRECOES_AUDITORIA.md").read_text(encoding="utf-8")

# Identidade / plataforma / segurança básica
check("versão R15 1.0.14", 'versionCode = 114' in build and 'versionName = "1.0.14-piloto"' in build)
check("SDK 36 e Android mínimo 26", all(x in build for x in ("compileSdk = 36", "minSdk = 26", "targetSdk = 36")))
check("aplicativo sem uses-permission no manifesto", "<uses-permission" not in manifest)
check("FileProvider privado", 'android:exported="false"' in manifest and 'android:grantUriPermissions="true"' in manifest)
check("arquivos de troca ficam em cache privado", "cache-path" in (APP / "res/xml/file_paths.xml").read_text(encoding="utf-8"))

# F02-F08 integridade/envio
check("F02 salesForDate usa somente venda canônica", "fun salesForDate(saleDate: LocalDate): List<SellerSale> = sales()" in store and "saleLocalDate(it.soldAt) == saleDate" in store)
check("F03 exportedRevision existe no modelo", "val exportedRevision: Int = 0" in models)
check("F03 editar após exportação aumenta revisão", "existing.exportedRevision >= existing.revision" in store and "existing.revision + 1" in store)
check("F04 confirmação usa revisão congelada do lote", "val revisions = storedBatch.sales.associate { it.externalSaleId to it.revision }" in store and "frozenRevision" in store)
check("F04 edição posterior permanece pendente", "sentRevision = maxOf(sale.sentRevision, frozenRevision)" in store and "it <= sale.revision" in store)
check("F05 exclusão bloqueada depois de exportar", "target.exportedRevision > 0" in store and "não pode ser excluída silenciosamente" in store)
check("F06 backup força deviceId válido", "val deviceId = sellerDeviceId()" in store and '.put("deviceId", deviceId)' in store)
check("F06 restauração repara deviceId antigo", "incomingDeviceId" in store and "UUID.randomUUID().toString()" in store)
check("F07 lote é persistido antes do compartilhamento", "persistForSending" in store and "KEY_BATCHES" in store and "KEY_SALES" in store)
check("F07 compartilhamento iniciado fica persistido", "shareStartedAt" in models and "markBatchShareStarted" in store and "pendingBatchConfirmation" in store)
check("F07 MainActivity restaura confirmação", "store.pendingBatchConfirmation()" in main and "override fun onResume()" in main)
check("F08 lotes novos usam integridade V3", "schemaVersion = 3" in store and "val schemaVersion: Int = 3" in models)
check("F08 integridade cobre recebimento e pagamento", "sale.receivedCents" in codec and "sale.paymentMethod" in codec and "sale.paidOnSpot" in codec)
check("F08 integridade cobre revisão e itens", "sale.exportedRevision" in codec and "sale.sentRevision" in codec and "ITEM:" in codec)
check("F08 V1/V2 antigos mantêm canonical legado", "legacyIntegrityCanonical" in codec and "batch.schemaVersion <= 2" in codec)

# F09-F16 datas, valores e legado
check("F09 Home recebe revisão no onResume", "changed += 1" in main and "externalRevision = changed" in main)
check("F09 há atualização periódica em primeiro plano", "delay(60_000L)" in ui)
check("F10 parser monetário dedicado", "object BrazilianMoney" in money and "parsePriceCents" in money and "parseReceivedCents" in money)
check("F10 sinal negativo não é apagado", 'trimmed.startsWith("-")' in money and 'throw UserVisibleException("Informe um valor válido.")' in money)
check("F10 milhar brasileiro é reconhecido", 'groups.drop(1).all { it.length == 3 }' in money)
check("F12 venda possui recordedAt e saleTimeKnown", "val recordedAt: Long" in models and "val saleTimeKnown: Boolean" in models)
check("F12 revisão mostra data completa", 'formatSaleDate(saleDate)' in ui or 'dd/MM/yyyy' in ui)
check("F12 hora retroativa pode ser desconhecida", "Horário não informado" in ui and "saleTimeKnown" in ui)
check("F14 importação de catálogo migra produto legado", "val migratedSales = currentSales.map" in store and "sourceItems = sale.items.ifEmpty" in store)
check("F14 lote identifica produto legado exato", "badProduct" in store and "cadastro antigo" in store)
check("F15 limite é checado antes de salvar venda 50001", "if (existing == null && allSales.size >= MAX_SALES)" in store)
check("F16 teto único de venda", "MAX_SALE_TOTAL_CENTS = 2_000_000_000L" in store and "MAX_SALE_TOTAL_CENTS = 2_000_000_000L" in money)
check("F16 formatação não usa divisão por Double", "BigDecimal.valueOf(cents, 2)" in money and "DecimalFormat" in codec and "cents / 100.0" not in codec)

# F17-F21 envio e modelo mental
check("F17 resumo visual é paginado", "exportBatchSummaryImages" in store and "chunked(3)" in store)
check("F17 resumo mostra período real das vendas", "Período das vendas:" in store and "saleDates" in store)
check("F17 resumo mostra cada produto e subtotal", "subtotal" in store and "rows.forEach" in store)
check("F18 estados preparado/iniciado/confirmado existem", all(x in ui for x in ("Lote preparado", "Compartilhamento iniciado", "Envio confirmado por você")))
check("F18 confirmação não promete importação no Gestão", "não significa que o Santana Gestão já importou" in main)
check("F19 lote informa 20 de N", "20 de" in ui and "neste envio" in ui)
check("F19 total é chamado de vendas a enviar", "Total das vendas a enviar" in ui)
check("F19 histórico diz Reenviar arquivo", "Reenviar arquivo" in ui and "Reenviar mensagem" not in ui)
check("F19 QR aponta caminho real", "Receber do Edi" in ui and "QR Code" in ui)
check("F20 histórico tem detalhe somente leitura", "SaleDetailDialog" in ui and "Ver detalhes" in ui)
check("F20 histórico tem resumo total compacto", 'key = "history-summary"' in ui and "sales.sumOf { it.totalCents }" in ui)
check("F21 correção versionada continua disponível", "Correção pendente" in ui and "Corrigir" in ui)

# F22-F24 layout/acessibilidade
check("F22 fundo branco no tema/sistema", "Color.White" in theme and "#FFFFFF" in styles)
check("F22 saudação usa headline maior", "headlineMedium" in theme and "26.sp" in theme)
check("F22 novo cliente usa AlertDialog branco", 'title = { Text("Cadastrar novo cliente"' in ui and "containerColor = Color.White" in ui)
check("F22 escolha de produto não usa ModalBottomSheet", "ModalBottomSheet" not in ui and 'title = { Text("Adicionar produto"' in ui)
check("F22 preço usa TextFieldValue com seleção", "TextFieldValue" in ui and "TextRange" in ui and "PriceDialog" in ui)
check("F22 Venda anotada continua presente", "SaleSavedScreen" in ui and "Venda anotada" in ui)
check("F23 produto possui busca", 'placeholder = { Text("Buscar produto") }' in ui)
check("F23 produto possui LazyColumn com altura limitada", "filteredProducts" in ui and "LazyColumn" in ui and "heightIn(max = 500.dp)" in ui)
check("F24 botões editar/remover têm 48dp", "modifier = Modifier.size(48.dp)" in ui)
check("F24 produto aceita duas linhas", "row.name" in ui and "maxLines = 2" in ui)
check("F24 CTA da venda fica em rodapé opaco", "Alignment.BottomCenter" in ui and "shadowElevation = 8.dp" in ui and "Revisar venda" in ui)
check("F24 iniciais filtram letra/dígito", "firstOrNull { it.isLetterOrDigit() }" in ui)

# F25-F27 persistência/recuperação
check("F25 rascunho persistido", "UiSaleDraft" in ui and "saveDraftState" in store and "sale_draft_state" in store)
check("F25 oferece Continuar/Descartar", "Continuar venda em andamento?" in ui and "Descartar" in ui)
check("F26 backup é lido com limite", "readTextLimited" in ui and "8_000_000" in ui)
check("F26 backup usa Dispatcher IO", "withContext(Dispatchers.IO) { store.exportBackup() }" in ui)
check("F26 catálogo grande sai da UI", "withContext(Dispatchers.Default) { store.importCatalog(content) }" in ui)
check("F26 mutações principais são sincronizadas", store.count("@Synchronized") >= 12)
check("F26 histórico reutiliza currentSales", "val currentSales = remember(revision)" in ui)
check("F27 prévia valida antes de restaurar", "previewBackup" in store and "validateBackupRelations" in store)
check("F27 guarda cópia pré-restauração", "KEY_PRE_RESTORE_BACKUP" in store and "restorePreRestoreBackup" in store)
check("F27 tela oferece recuperar estado anterior", "Recuperar estado anterior à restauração" in ui)
check("F27 aviso de dados danificados fica disponível", "dataWarning()" in store and "store.dataWarning()" in ui)

# F28 documentação/qualidade
check("F28 documento R15 não chama checklist de homologação", "não é um selo de homologação" in r15.lower())
check("F28 documento declara build Android não concluído", "Build Android/Gradle completo" in r15 and "não concluído" in r15)
check("F28 R14 foi marcado como histórico", "Documento histórico da R14" in (ROOT / "R14_MUDANCAS.md").read_text(encoding="utf-8"))

# Estrutura do pacote
xml_files = list((APP / "res").rglob("*.xml")) + [APP / "AndroidManifest.xml"]
xml_ok = True
for path in xml_files:
    try:
        ET.parse(path)
    except ET.ParseError:
        xml_ok = False
check(f"XML válido ({len(xml_files)} arquivos)", xml_ok)
source_text = "\n".join(path.read_text(encoding="utf-8", errors="replace") for path in ROOT.rglob("*.kt"))
check("sem conflito de merge/TODO/FIXME no fonte", not re.search(r"<<<<<<<|=======|>>>>>>>|\bTODO\b|\bFIXME\b", source_text))
check("sem build/local.properties empacotados", not any((ROOT / n).exists() for n in ("build", "local.properties")) and not any((ROOT / "app" / n).exists() for n in ("build", ".cxx")))

passed = sum(ok for _, ok in checks)
print(f"\nEDI_STATIC_CHECKLIST_R15: {passed}/{len(checks)}")
print("Este número cobre somente os itens estáticos acima; não representa build, teste Android ou homologação em aparelho.")
sys.exit(0 if passed == len(checks) else 1)

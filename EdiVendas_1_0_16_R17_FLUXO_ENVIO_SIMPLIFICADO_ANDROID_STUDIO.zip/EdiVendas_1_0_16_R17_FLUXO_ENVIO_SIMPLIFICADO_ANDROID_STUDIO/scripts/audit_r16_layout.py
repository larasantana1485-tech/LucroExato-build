#!/usr/bin/env python3
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
ui=(ROOT/'app/src/main/java/br/com/edivendas/ui/EdiVendasApp.kt').read_text(encoding='utf-8')
build=(ROOT/'app/build.gradle.kts').read_text(encoding='utf-8')
checks=[]
def c(name, ok):
    checks.append((name,bool(ok))); print(('OK   ' if ok else 'FAIL ')+name)

c('versão 1.0.15 / 115', 'versionCode = 115' in build and 'versionName = "1.0.15-piloto"' in build)
c('Home com pills lado a lado', 'HomeHistoryPill' in ui and 'Histórico completo' in ui and 'Histórico de envios' in ui)
c('Home sem chips técnicos nas vendas', 'SaleRow(sale = sale, editable = true, onEdit = { onEdit(sale) }, showSendStatus = false)' in ui)
c('Home CTA azul do Gestão', 'Enviar ${saleCountText(pending.size)} ao Santana Gestão' in ui and 'containerColor = BrandBlue' in ui)
c('Clientes sem cabeçalho em caixa', 'item(key = "section-$letter")' in ui and 'HorizontalDivider(modifier = Modifier.weight(1f)' in ui)
c('Cliente nome/local separados', 'clientDisplayParts' in ui and 'parts.first' in ui and 'parts.second' in ui)
c('Venda sem pills Hoje/Ontem/Outra', 'CompactChoice("Hoje"' not in ui and 'CompactChoice("Ontem"' not in ui)
c('Venda com seletor de calendário', 'Icons.Default.CalendarMonth' in ui and 'formatSaleDate(saleDate)' in ui)
c('Produto agrupado e Alterar valor explícito', 'Text("Alterar valor"' in ui and 'Text("Subtotal"' in ui)
c('Pagamento em duas escolhas', 'PaymentChoiceCard' in ui and 'Vai pagar depois' in ui and 'Pago na hora' in ui)
c('Métodos de pagamento preservados', all(x in ui for x in ['CompactChoice("PIX"','CompactChoice("Dinheiro"','CompactChoice("Cartão"']))
c('Histórico de envios em caixas', 'border = androidx.compose.foundation.BorderStroke(1.dp, BrandLine)' in ui and 'Reenviar lote' in ui)
c('Status de lote humanizado', 'Ainda não confirmado' in ui and 'Envio confirmado' in ui)
c('ID técnico removido do histórico de envios', 'Lote ${batch.batchId.take(8)}' not in ui)
c('Revisão usa Editar venda', 'Text("Editar venda")' in ui)
c('Sem conflitos de merge', not re.search(r'<<<<<<<|=======|>>>>>>>', ui))

xml_ok=True
for p in list((ROOT/'app/src/main/res').rglob('*.xml'))+[ROOT/'app/src/main/AndroidManifest.xml']:
    try: ET.parse(p)
    except Exception as e:
        xml_ok=False; print('XML error',p,e)
c('XML válido', xml_ok)
print(f'R16_LAYOUT_CHECKS: {sum(ok for _,ok in checks)}/{len(checks)}')
sys.exit(0 if all(ok for _,ok in checks) else 1)

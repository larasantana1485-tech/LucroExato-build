package br.com.lucroexato.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.IngredientPriceEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.CostCalculator
import br.com.lucroexato.domain.CostInput
import br.com.lucroexato.domain.ExtraCostInput
import br.com.lucroexato.domain.IngredientCostInput
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import java.text.DateFormat
import java.util.Date

private enum class MainTab { RECIPES, SUPPLIES }

@Composable
fun MainShell(
    modifier: Modifier = Modifier,
    vm: AppViewModel,
    onSettings: () -> Unit,
    onNewRecipe: () -> Unit,
    onResumeDraft: () -> Unit,
    onRecipe: (Long) -> Unit,
    onIngredient: (Long) -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.RECIPES) }
    val navColors = NavigationBarItemDefaults.colors(
        selectedIconColor = Pink,
        selectedTextColor = Pink,
        indicatorColor = Color.Transparent,
        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Scaffold(
        modifier = modifier,
        bottomBar = {
            NavigationBar(
                modifier = Modifier.height(64.dp),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = tab == MainTab.RECIPES,
                    onClick = { tab = MainTab.RECIPES },
                    icon = { Icon(Icons.Outlined.ReceiptLong, null) },
                    label = { Text("Receitas", maxLines = 1) },
                    colors = navColors
                )
                NavigationBarItem(
                    selected = tab == MainTab.SUPPLIES,
                    onClick = { tab = MainTab.SUPPLIES },
                    icon = { Icon(Icons.Outlined.Inventory2, null) },
                    label = { Text("Insumos", maxLines = 1) },
                    colors = navColors
                )
            }
        }
    ) { inner ->
        when (tab) {
            MainTab.RECIPES -> RecipesScreen(Modifier.padding(inner), vm, onSettings, onNewRecipe, onResumeDraft, onRecipe)
            MainTab.SUPPLIES -> IngredientsScreen(Modifier.padding(inner), vm, onIngredient)
        }
    }
}

@Composable
private fun RecipesScreen(
    modifier: Modifier,
    vm: AppViewModel,
    onSettings: () -> Unit,
    onNewRecipe: () -> Unit,
    onResumeDraft: () -> Unit,
    onRecipe: (Long) -> Unit
) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val savedDraft by vm.savedDraft.collectAsStateWithLifecycle()
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todas") }
    var confirmNew by remember { mutableStateOf(false) }
    val categories = listOf("Todas", "Bolos", "Doces", "Tortas", "Cookies", "Pães", "Salgados", "Sobremesas", "Bebidas", "Outros")
    val filtered = recipes.filter {
        (category == "Todas" || it.recipe.category == category) && it.recipe.name.contains(search, ignoreCase = true)
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lucro Exato", style = MaterialTheme.typography.headlineSmall, color = Pink)
                    Text("Custos e precificação de receitas", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, "Configurações") }
            }
        }
        savedDraft?.takeIf { it.dirty }?.let { draft ->
            item {
                Card(
                    Modifier.fillMaxWidth().clickable(onClick = onResumeDraft),
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Outline),
                    elevation = CardDefaults.cardElevation(0.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Edit, null, tint = Pink)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(if (draft.editingRecipeId == null) "Rascunho" else "Edição não concluída", fontWeight = FontWeight.Bold)
                            Text(draft.name.ifBlank { "Receita sem nome" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Etapa ${draft.step} de 4 • toque para continuar", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("Continuar", color = Pink, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = AppFieldShape,
                placeholder = { Text("Buscar receitas...") },
                leadingIcon = { Icon(Icons.Outlined.Search, null) }
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { item -> FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item, maxLines = 1) }) }
            }
        }
        item {
            Button(
                onClick = { if (savedDraft?.dirty == true) confirmNew = true else onNewRecipe() },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = AppButtonShape
            ) {
                Icon(Icons.Outlined.Add, null); Spacer(Modifier.size(8.dp)); Text("Nova receita", maxLines = 1)
            }
        }
        item { SectionTitle("Minhas receitas", if (recipes.isEmpty()) "Crie sua primeira receita para começar." else "${filtered.size} receita(s)") }
        if (filtered.isEmpty()) {
            item {
                InfoCard {
                    Text(if (recipes.isEmpty()) "Ainda não há receitas salvas." else "Nenhuma receita encontrada.", fontWeight = FontWeight.SemiBold)
                    Text("O Lucro Exato salva tudo no próprio celular e funciona offline.", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            items(filtered, key = { it.recipe.id }) { item -> RecipeCard(item, catalog) { onRecipe(item.recipe.id) } }
        }
    }

    if (confirmNew) {
        AlertDialog(
            onDismissRequest = { confirmNew = false },
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            shape = AppCardShape,
            title = { Text("Começar outra receita?") },
            text = { Text("Existe um rascunho salvo. Começar uma nova receita descarta esse rascunho.") },
            confirmButton = {
                TextButton(onClick = { confirmNew = false; onNewRecipe() }) { Text("Começar nova") }
            },
            dismissButton = {
                TextButton(onClick = { confirmNew = false; onResumeDraft() }) { Text("Continuar rascunho") }
            }
        )
    }
}

@Composable
private fun RecipeCard(item: RecipeWithDetails, catalog: List<IngredientEntity>, onClick: () -> Unit) {
    val partial = !hasPackagingSupply(item, catalog) || item.recipe.laborMinutes == 0 || item.recipe.hourlyRateCents == 0L
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(0.dp),
        border = BorderStroke(1.dp, Outline)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.ReceiptLong, null, tint = Pink, modifier = Modifier.size(22.dp)) }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(item.recipe.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${item.recipe.category} • ${number(item.recipe.yieldQuantity, 0)} ${item.recipe.yieldUnit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text("Custo un. ${money(item.recipe.costPerUnitCents)}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                if (partial) Text("Resultado parcial", style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A5A00), fontWeight = FontWeight.SemiBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(if (partial) "Estimativa" else "Preço sugerido", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text(money(item.recipe.salePricePerUnitCents), color = Green, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

@Composable
private fun IngredientsScreen(modifier: Modifier, vm: AppViewModel, onIngredient: (Long) -> Unit) {
    val ingredients by vm.ingredients.collectAsStateWithLifecycle()
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    val categories = listOf("Todos", "Embalagens") + (SupplyCategories + ingredients.map { it.category }).distinct().filterNot { it == "Embalagens" }
    val filtered = ingredients.filter { (category == "Todos" || it.category == category) && it.name.contains(search, true) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Insumos", style = MaterialTheme.typography.headlineSmall)
                    Text("Ingredientes, embalagens e consumíveis", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { onIngredient(0) }) { Icon(Icons.Outlined.Add, "Novo insumo") }
            }
        }
        item { OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, placeholder = { Text("Buscar insumo...") }, leadingIcon = { Icon(Icons.Outlined.Search, null) }, singleLine = true) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { item -> FilterChip(category == item, { category = item }, label = { Text(item, maxLines = 1) }) } } }
        items(filtered, key = { it.id }) { item -> IngredientRow(item) { onIngredient(item.id) } }
    }
}

@Composable
private fun IngredientRow(item: IngredientEntity, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Inventory2, null, tint = Pink, modifier = Modifier.size(20.dp)) }
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
                Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("${money(item.packagePriceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
    }
}

@Composable
fun RecipeSimulationScreen(modifier: Modifier, vm: AppViewModel, recipeId: Long, onBack: () -> Unit) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val selected = recipes.firstOrNull { it.recipe.id == recipeId }
    var ingredientExpanded by remember { mutableStateOf(false) }
    var selectedIngredientId by remember(selected?.ingredients) { mutableStateOf(selected?.ingredients?.firstOrNull { it.ingredientId != null }?.ingredientId ?: 0L) }
    val recipeIngredient = selected?.ingredients?.firstOrNull { it.ingredientId == selectedIngredientId }
    val catalogIngredient = catalog.firstOrNull { it.id == selectedIngredientId }
    var yieldText by remember(recipeId) { mutableStateOf(selected?.recipe?.yieldQuantity?.let { number(it) } ?: "") }
    var ingredientPriceText by remember(recipeId, selectedIngredientId, catalogIngredient) { mutableStateOf(catalogIngredient?.packagePriceCents?.let(::moneyInput) ?: "") }
    var marginText by remember(recipeId) { mutableStateOf(selected?.recipe?.targetPercent?.let { number(it) } ?: "50") }
    var result by remember { mutableStateOf<br.com.lucroexato.domain.CostResult?>(null) }

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { CompactTopBar("Simular mudanças", onBack) }
        if (selected == null) {
            item { InfoCard(Modifier.padding(horizontal = 16.dp)) { Text("Receita não encontrada.") } }
        } else {
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text(selected.recipe.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("A simulação não altera a receita salva.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (selected.ingredients.any { it.ingredientId != null }) {
                item {
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        OutlinedButton(onClick = { ingredientExpanded = true }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = AppButtonShape) {
                            Text(recipeIngredient?.nameSnapshot ?: "Escolher insumo", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        DropdownMenu(ingredientExpanded, { ingredientExpanded = false }) {
                            selected.ingredients.filter { it.ingredientId != null }.forEach { ingredient ->
                                DropdownMenuItem(text = { Text(ingredient.nameSnapshot, maxLines = 1) }, onClick = { selectedIngredientId = ingredient.ingredientId ?: 0L; ingredientExpanded = false; result = null })
                            }
                        }
                    }
                }
                item {
                    SmartNumberField(
                        value = ingredientPriceText,
                        onValueChange = { ingredientPriceText = it; result = null },
                        label = "Novo preço de compra",
                        prefix = "R$ ",
                        supportingText = catalogIngredient?.let { "Compra cadastrada: ${number(it.packageQuantity)} ${it.packageUnit}" },
                        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                    )
                }
            }
            item {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmartNumberField(yieldText, { yieldText = it; result = null }, "Rendimento", Modifier.weight(1f))
                    SmartNumberField(marginText, { marginText = it; result = null }, "Margem (%)", Modifier.weight(1f))
                }
            }
            item {
                Button(onClick = {
                    val simulatedPrice = parseMoneyCents(ingredientPriceText)
                    result = runCatching {
                        CostCalculator.calculate(CostInput(
                            yieldQuantity = parseDecimal(yieldText) ?: selected.recipe.yieldQuantity,
                            lossPercent = selected.recipe.lossPercent,
                            ingredients = selected.ingredients.map { used ->
                                val newCost = if (used.ingredientId == selectedIngredientId && simulatedPrice != null && catalogIngredient != null) {
                                    CostCalculator.ingredientCostCents(simulatedPrice, catalogIngredient.packageQuantity, catalogIngredient.packageUnit, used.quantityUsed, used.unit)
                                } else used.costCents
                                IngredientCostInput(used.nameSnapshot, newCost)
                            },
                            packagingPerUnitCents = selected.recipe.packagingPerUnitCents,
                            laborMinutes = selected.recipe.laborMinutes,
                            hourlyRateCents = selected.recipe.hourlyRateCents,
                            extras = selected.extraCosts.map { ExtraCostInput(it.valueCents, it.application == "PER_UNIT") },
                            variableFeePercent = selected.recipe.variableFeePercent,
                            fixedFeePerUnitCents = selected.recipe.fixedFeePerUnitCents,
                            pricingMode = "MARGIN",
                            targetPercent = parseDecimal(marginText) ?: selected.recipe.targetPercent
                        ))
                    }.getOrNull()
                }, modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(50.dp), shape = AppButtonShape) { Text("Calcular simulação") }
            }
            result?.let { value ->
                item {
                    Card(
                        Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                        shape = AppCardShape,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Outline),
                        elevation = CardDefaults.cardElevation(0.dp)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Atual × simulação", fontWeight = FontWeight.Bold)
                            ComparisonRow("Custo por unidade", money(selected.recipe.costPerUnitCents), money(value.costPerUnitCents))
                            ComparisonRow("Preço", money(selected.recipe.salePricePerUnitCents), money(value.suggestedPriceCents))
                            val currentProfit = selected.recipe.salePricePerUnitCents - selected.recipe.costPerUnitCents
                            ComparisonRow("Lucro por unidade", money(currentProfit), money(value.profitPerUnitCents))
                            ComparisonRow("Margem", "${number(selected.recipe.targetPercent)}%", "${number(value.marginPercent)}%")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComparisonRow(label: String, current: String, simulated: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Atual: $current", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Simulado: $simulated", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun RecipeDetailScreen(
    modifier: Modifier,
    vm: AppViewModel,
    recipeId: Long,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onSimulate: () -> Unit
) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val item = recipes.firstOrNull { it.recipe.id == recipeId }
    var scaleText by remember { mutableStateOf("1") }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(recipeId) { vm.refreshRecipe(recipeId) }
    if (item == null) {
        Column(modifier.fillMaxSize()) { CompactTopBar("Receita", onBack); Text("Receita não encontrada.", Modifier.padding(16.dp)) }
        return
    }
    val scale = (parseDecimal(scaleText) ?: 1.0).coerceAtLeast(0.01)
    val sale = item.recipe.salePricePerUnitCents
    val profit = sale - item.recipe.costPerUnitCents - item.recipe.fixedFeePerUnitCents - (sale * item.recipe.variableFeePercent / 100.0).toLong()
    val margin = if (sale > 0) profit * 100.0 / sale else 0.0
    val markup = if (item.recipe.costPerUnitCents > 0) (sale.toDouble() / item.recipe.costPerUnitCents - 1) * 100 else 0.0
    val partial = !hasPackagingSupply(item, catalog) || item.recipe.laborMinutes == 0 || item.recipe.hourlyRateCents == 0L

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { CompactTopBar("Resultado", onBack) { IconButton(onClick = onEdit) { Icon(Icons.Outlined.Edit, "Editar") } } }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(item.recipe.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${item.recipe.category} • ${number(item.recipe.yieldQuantity, 0)} ${item.recipe.yieldUnit}", color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
        if (partial) item {
            InfoCard(Modifier.padding(horizontal = 16.dp)) {
                Text("Estimativa com os custos informados", fontWeight = FontWeight.Bold)
                Text("Ainda faltam custos importantes. Confira embalagem e mão de obra antes de definir o preço final.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Custo un.", money(item.recipe.costPerUnitCents), Pink, Modifier.weight(1f))
                MetricCard(if (partial) "Estimativa" else "Preço un.", money(sale), Green, Modifier.weight(1f))
                MetricCard("Lucro un.", money(profit), Pink, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Margem", "${number(margin)}%", Pink, Modifier.weight(1f))
                MetricCard("Markup", "${number(markup)}%", Pink, Modifier.weight(1f))
            }
        }
        item {
            InfoCard(Modifier.padding(horizontal = 16.dp)) {
                SectionTitle("Composição do custo", "Valores da receita inteira")
                ResultRow("Insumos", money(item.ingredients.sumOf { it.costCents }))
                if (item.recipe.packagingPerUnitCents > 0) ResultRow("Embalagem avulsa", money((item.recipe.packagingPerUnitCents * item.recipe.yieldQuantity).toLong()))
                ResultRow("Mão de obra", money((item.recipe.hourlyRateCents * item.recipe.laborMinutes / 60.0).toLong()))
                ResultRow("Outros", money(item.extraCosts.sumOf { if (it.application == "PER_UNIT") (it.valueCents * item.recipe.yieldQuantity).toLong() else it.valueCents }))
                ResultRow("Custo total", money(item.recipe.totalCostCents), true)
            }
        }
        item {
            OutlinedButton(onClick = onSimulate, modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(48.dp), shape = AppButtonShape) {
                Icon(Icons.Outlined.Calculate, null); Spacer(Modifier.size(8.dp)); Text("Simular mudanças", maxLines = 1)
            }
        }
        item {
            InfoCard(Modifier.padding(horizontal = 16.dp)) {
                SectionTitle("Escalar receita", "Use 0,5 para meia receita; 2 para dobrar.")
                SmartNumberField(scaleText, { scaleText = it }, "Multiplicador", Modifier.fillMaxWidth())
                item.ingredients.forEach { ingredient -> ResultRow(ingredient.nameSnapshot, "${number(ingredient.quantityUsed * scale)} ${ingredient.unit}") }
                ResultRow("Novo rendimento", "${number(item.recipe.yieldQuantity * scale)} ${item.recipe.yieldUnit}", true)
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f), shape = AppButtonShape) { Icon(Icons.Outlined.DeleteOutline, null); Text("Excluir") }
                Button(onClick = onEdit, modifier = Modifier.weight(1f), shape = AppButtonShape) { Icon(Icons.Outlined.Edit, null); Text("Editar") }
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text("Excluir receita?") },
        text = { Text("Essa ação não pode ser desfeita.") },
        confirmButton = { TextButton(onClick = { vm.deleteRecipe(recipeId); confirmDelete = false; onBack() }) { Text("Excluir") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
    )
}

@Composable
fun IngredientDetailScreen(modifier: Modifier, vm: AppViewModel, ingredientId: Long, onBack: () -> Unit) {
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val existing = catalog.firstOrNull { it.id == ingredientId }
    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var category by remember(existing) { mutableStateOf(existing?.category ?: "Outros") }
    var price by remember(existing) { mutableStateOf(existing?.packagePriceCents?.let(::moneyInput) ?: "") }
    var quantity by remember(existing) { mutableStateOf(existing?.packageQuantity?.let { number(it) } ?: "") }
    var unit by remember(existing) { mutableStateOf(existing?.packageUnit ?: "kg") }
    var history by remember { mutableStateOf<List<IngredientPriceEntity>>(emptyList()) }
    LaunchedEffect(existing?.id) { if (existing != null) history = vm.priceHistory(existing.id) }

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { CompactTopBar(if (existing == null) "Novo insumo" else existing.name, onBack) }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Nome do insumo *", maxLines = 1) }, singleLine = true)
                SelectionField(category, SupplyCategories, "Categoria *", Modifier.fillMaxWidth()) { selectedCategory ->
                    category = selectedCategory
                    if (selectedCategory == "Embalagens" && existing == null) unit = "un"
                }
                SmartNumberField(price, { price = it }, "Preço pago *", Modifier.fillMaxWidth(), prefix = "R$ ")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmartNumberField(quantity, { quantity = it }, "Qtd. comprada *", Modifier.weight(1f))
                    SelectionField(unit, listOf("kg", "g", "mg", "l", "ml", "un"), "Unidade", Modifier.weight(0.62f)) { unit = it }
                }
                existing?.let { current ->
                    if (current.referenceMinCentsPerBase != null && current.referenceMaxCentsPerBase != null) {
                        InfoCard { Text("Preço de referência", fontWeight = FontWeight.SemiBold); Text("${money(current.referenceMinCentsPerBase)} – ${money(current.referenceMaxCentsPerBase)} por kg"); Text("Use seu preço real sempre que souber.", style = MaterialTheme.typography.bodySmall) }
                    }
                }
                Button(onClick = {
                    val cents = parseMoneyCents(price); val qty = parseDecimal(quantity)
                    if (name.isNotBlank() && category.isNotBlank() && cents != null && qty != null && qty > 0) {
                        vm.saveIngredient(IngredientEntity(id = existing?.id ?: 0, name = name.trim(), category = category.trim(), packagePriceCents = cents, packageQuantity = qty, packageUnit = unit, referenceMinCentsPerBase = existing?.referenceMinCentsPerBase, referenceMaxCentsPerBase = existing?.referenceMaxCentsPerBase, isBuiltIn = existing?.isBuiltIn ?: false))
                        onBack()
                    }
                }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = AppButtonShape) { Text(if (existing == null) "Adicionar insumo" else "Salvar alterações", maxLines = 1) }
            }
        }
        if (history.isNotEmpty()) {
            item { Box(Modifier.padding(horizontal = 16.dp)) { SectionTitle("Histórico de preços", "Seus últimos valores") } }
            items(history.take(10)) { item ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.recordedAt)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${money(item.priceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}", fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

private fun hasPackagingSupply(item: RecipeWithDetails, catalog: List<IngredientEntity>): Boolean {
    if (item.recipe.packagingPerUnitCents > 0L) return true
    val byId = catalog.associateBy { it.id }
    return item.ingredients.any { used ->
        val category = used.ingredientId?.let { byId[it]?.category }.orEmpty()
        category.contains("embal", ignoreCase = true)
    }
}

@Composable
private fun MetricCard(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier.heightIn(min = 72.dp),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = accent, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun ResultRow(label: String, value: String, strong: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.size(8.dp))
        Text(value, fontWeight = if (strong) FontWeight.Bold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

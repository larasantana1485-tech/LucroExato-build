package br.com.lucroexato.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.RecipeDraft
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import kotlin.math.roundToLong

@Composable
fun RecipeWizardScreen(modifier: Modifier, vm: AppViewModel, onClose: () -> Unit, onSaved: (Long) -> Unit) {
    val draft by vm.draft.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    var askDiscard by remember { mutableStateOf(false) }

    fun requestClose() {
        if (draft.dirty) askDiscard = true else onClose()
    }
    BackHandler { if (draft.step > 1) vm.previousStep() else requestClose() }

    Scaffold(
        modifier = modifier,
        topBar = {
            Column {
                CompactTopBar(if (draft.editingRecipeId == null) "Nova receita" else "Editar receita") {
                    IconButton(onClick = ::requestClose) { Icon(Icons.Outlined.Close, "Fechar") }
                }
                StepIndicator(draft.step, listOf("Dados", "Insumos", "Custos", "Resultado"))
                Spacer(Modifier.height(8.dp))
            }
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (draft.step > 1) OutlinedButton(
                    onClick = { vm.previousStep() },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = AppButtonShape
                ) { Text("Voltar", maxLines = 1) }
                Button(
                    onClick = { if (draft.step < 4) vm.nextStep() else vm.saveRecipe(onSaved) },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = AppButtonShape
                ) { Text(if (draft.step < 4) "Próximo" else "Salvar receita", maxLines = 1) }
            }
        }
    ) { inner ->
        when (draft.step) {
            1 -> RecipeDataStep(Modifier.padding(inner), draft, vm)
            2 -> RecipeIngredientsStep(Modifier.padding(inner), draft, catalog, recipes, vm)
            3 -> RecipeCostsStep(Modifier.padding(inner), draft, vm)
            else -> RecipeResultStep(Modifier.padding(inner), draft, catalog, vm)
        }
    }

    if (askDiscard) AlertDialog(
        onDismissRequest = { askDiscard = false },
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text("Sair da receita?") },
        text = { Text("O rascunho já está salvo e aparecerá na tela inicial para você continuar depois.") },
        confirmButton = { TextButton(onClick = { askDiscard = false; onClose() }) { Text("Continuar depois") } },
        dismissButton = { TextButton(onClick = { vm.discardDraft(); askDiscard = false; onClose() }) { Text("Descartar") } }
    )
}

@Composable
private fun RecipeDataStep(modifier: Modifier, draft: RecipeDraft, vm: AppViewModel) {
    val categories = listOf("Bolos", "Doces", "Tortas", "Cookies", "Pães", "Salgados", "Sobremesas", "Bebidas", "Outros")
    var yieldText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.yieldQuantity == 0.0) "" else number(draft.yieldQuantity)) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Dados da receita", "O nome e o rendimento são obrigatórios.") }
        item {
            OutlinedTextField(
                draft.name,
                { value -> vm.updateDraft { it.copy(name = value) } },
                Modifier.fillMaxWidth(),
                shape = AppFieldShape,
                label = { Text("Nome da receita *", maxLines = 1) },
                placeholder = { Text("Ex.: Pão de Mel Tradicional", maxLines = 1) },
                singleLine = true
            )
        }
        item { Text("Categoria *", fontWeight = FontWeight.SemiBold) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { item -> FilterChip(draft.category == item, { vm.updateDraft { it.copy(category = item) } }, label = { Text(item, maxLines = 1) }) } } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartNumberField(
                    value = yieldText,
                    onValueChange = { text -> yieldText = text; vm.updateDraft { it.copy(yieldQuantity = parseDecimal(text) ?: 0.0) } },
                    label = "Rendimento *",
                    modifier = Modifier.weight(1f)
                )
                SelectionField(
                    value = draft.yieldUnit,
                    options = listOf("un", "g", "kg", "ml", "l"),
                    label = "Unidade",
                    modifier = Modifier.weight(0.62f)
                ) { value -> vm.updateDraft { it.copy(yieldUnit = value) } }
            }
        }
        item {
            InfoCard {
                Text("Rascunho automático", fontWeight = FontWeight.SemiBold, color = Pink)
                Text("Se você sair, esta receita aparece na tela inicial para continuar depois.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun RecipeIngredientsStep(
    modifier: Modifier,
    draft: RecipeDraft,
    catalog: List<IngredientEntity>,
    recipes: List<RecipeWithDetails>,
    vm: AppViewModel
) {
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<IngredientEntity?>(null) }
    var selectedDraftIndex by remember { mutableStateOf<Int?>(null) }
    var category by remember { mutableStateOf("Todos") }
    var selectedSubRecipe by remember { mutableStateOf<RecipeWithDetails?>(null) }
    var showAdded by remember { mutableStateOf(true) }
    val categories = listOf("Todos", "Embalagens") + (SupplyCategories + catalog.map { it.category }).distinct().filterNot { it == "Embalagens" }
    val filtered = catalog.filter {
        (category == "Todos" || it.category == category) && it.name.contains(search, true)
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { SectionTitle("Insumos da receita", "Ingredientes, embalagens e consumíveis entram pelo mesmo catálogo.") }
        item {
            OutlinedTextField(
                search,
                { search = it },
                Modifier.fillMaxWidth(),
                shape = AppFieldShape,
                leadingIcon = { Icon(Icons.Outlined.Search, null) },
                placeholder = { Text("Buscar no catálogo...", maxLines = 1) },
                singleLine = true
            )
        }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { items(categories) { value -> FilterChip(category == value, { category = value }, label = { Text(value, maxLines = 1) }) } } }
        item {
            OutlinedButton(
                onClick = {
                    selectedDraftIndex = null
                    selected = IngredientEntity(name = "", category = "Outros", packagePriceCents = 0, packageQuantity = 1.0, packageUnit = "kg")
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = AppButtonShape
            ) { Icon(Icons.Outlined.Add, null); Spacer(Modifier.size(6.dp)); Text("Criar insumo", maxLines = 1) }
        }
        if (draft.ingredients.isNotEmpty()) {
            item {
                Row(
                    Modifier.fillMaxWidth().clickable { showAdded = !showAdded }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Adicionados (${draft.ingredients.size})", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Icon(if (showAdded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, contentDescription = null)
                }
            }
            if (showAdded) {
                items(draft.ingredients.indices.toList()) { index ->
                    val item = draft.ingredients[index]
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable {
                            item.ingredientId?.let { id -> catalog.firstOrNull { it.id == id } }?.let {
                                selected = it
                                selectedDraftIndex = index
                            }
                        },
                        shape = AppCardShape,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Outline),
                        elevation = CardDefaults.cardElevation(0.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${number(item.quantity)} ${item.unit} • ${money(item.costCents)}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            }
                            if (item.ingredientId != null) Icon(Icons.Outlined.Edit, "Editar", tint = Pink, modifier = Modifier.size(20.dp))
                            IconButton(onClick = { vm.removeDraftIngredient(index) }) { Icon(Icons.Outlined.DeleteOutline, "Remover") }
                        }
                    }
                }
            }
        }
        item { Text("Catálogo", fontWeight = FontWeight.SemiBold) }
        items(filtered, key = { it.id }) { item ->
            Card(
                Modifier.fillMaxWidth().clickable { selectedDraftIndex = null; selected = item },
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Outline),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${item.category} • ${money(item.packagePriceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Icon(Icons.Outlined.Add, "Adicionar", tint = Pink)
                }
            }
        }
        if (recipes.any { it.recipe.id != draft.editingRecipeId }) {
            item { SectionTitle("Sub-receitas", "Use uma receita pronta como parte desta.") }
            items(recipes.filter { it.recipe.id != draft.editingRecipeId }, key = { "sub-${it.recipe.id}" }) { item ->
                OutlinedButton(onClick = { selectedSubRecipe = item }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Text("${item.recipe.name} • ${money(item.recipe.costPerUnitCents)}/${item.recipe.yieldUnit}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }

    selected?.let { item ->
        val used = selectedDraftIndex?.let { draft.ingredients.getOrNull(it) }
        IngredientPurchaseScreen(
            item = item,
            initialUsedQuantity = used?.quantity,
            initialUsedUnit = used?.unit,
            editing = selectedDraftIndex != null,
            onDismiss = { selected = null; selectedDraftIndex = null },
            onSave = { updated, price, packageQuantity, packageUnit, usedQuantity, usedUnit ->
                vm.saveAndUseIngredient(
                    ingredient = updated,
                    packagePriceCents = price,
                    packageQuantity = packageQuantity,
                    packageUnit = packageUnit,
                    usedQuantity = usedQuantity,
                    usedUnit = usedUnit,
                    draftIndex = selectedDraftIndex
                ) { selected = null; selectedDraftIndex = null }
            }
        )
    }
    selectedSubRecipe?.let { item -> SubRecipeQuantityDialog(item, onDismiss = { selectedSubRecipe = null }) { quantity -> if (vm.addSubRecipe(item, quantity)) selectedSubRecipe = null } }
}

@Composable
private fun IngredientPurchaseScreen(
    item: IngredientEntity,
    initialUsedQuantity: Double?,
    initialUsedUnit: String?,
    editing: Boolean,
    onDismiss: () -> Unit,
    onSave: (IngredientEntity, Long, Double, String, Double, String) -> Unit
) {
    var name by remember(item.id) { mutableStateOf(item.name) }
    var category by remember(item.id) { mutableStateOf(item.category) }
    var price by remember(item.id) { mutableStateOf(if (item.packagePriceCents > 0) moneyInput(item.packagePriceCents) else "") }
    var packageQuantity by remember(item.id) { mutableStateOf(if (item.packageQuantity > 0) number(item.packageQuantity) else "") }
    var packageUnit by remember(item.id) { mutableStateOf(item.packageUnit) }
    var usedQuantity by remember(item.id, initialUsedQuantity) { mutableStateOf(initialUsedQuantity?.let(::number) ?: "") }
    var usedUnit by remember(item.id, initialUsedUnit) { mutableStateOf(initialUsedUnit ?: defaultUsedUnit(item.packageUnit)) }
    var error by remember { mutableStateOf<String?>(null) }
    val priceCents = parseMoneyCents(price)
    val bought = parseDecimal(packageQuantity)
    val used = parseDecimal(usedQuantity)
    val preview = if (priceCents != null && bought != null && used != null && bought > 0 && used > 0) {
        runCatching { br.com.lucroexato.domain.CostCalculator.ingredientCostCents(priceCents, bought, packageUnit, used, usedUnit) }.getOrNull()
    } else null

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { CompactTopBar(if (editing) "Editar insumo" else "Adicionar insumo", onDismiss) },
                bottomBar = {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text("Cancelar") }
                        Button(onClick = {
                            error = when {
                                name.isBlank() -> "Informe o nome do insumo."
                                priceCents == null || priceCents <= 0 -> "Informe o preço pago."
                                bought == null || bought <= 0 -> "Informe a quantidade comprada."
                                used == null || used <= 0 -> "Informe a quantidade usada."
                                preview == null -> "As unidades da compra e do uso precisam ser compatíveis."
                                else -> null
                            }
                            if (error == null) onSave(item.copy(name = name.trim(), category = category.trim().ifBlank { "Outros" }), priceCents!!, bought!!, packageUnit, used!!, usedUnit)
                        }, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text(if (editing) "Salvar" else "Adicionar", maxLines = 1) }
                    }
                }
            ) { inner ->
                Column(
                    Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (item.id == 0L) {
                        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Nome do insumo *", maxLines = 1) }, singleLine = true)
                        SelectionField(category, SupplyCategories, "Categoria", Modifier.fillMaxWidth()) { selectedCategory ->
                            category = selectedCategory
                            if (selectedCategory == "Embalagens") {
                                packageUnit = "un"
                                usedUnit = "un"
                            }
                        }
                    } else {
                        Text(name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    SectionTitle("Compra", "Use o valor que você realmente pagou.")
                    SmartNumberField(price, { price = it }, "Preço pago *", Modifier.fillMaxWidth(), prefix = "R$ ")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmartNumberField(packageQuantity, { packageQuantity = it }, "Qtd. comprada *", Modifier.weight(1f))
                        SelectionField(packageUnit, listOf("kg", "g", "mg", "l", "ml", "un"), "Unidade", Modifier.weight(0.62f)) { value ->
                            packageUnit = value
                            usedUnit = defaultUsedUnit(value)
                        }
                    }
                    SectionTitle(
                        "Uso nesta receita",
                        if (category == "Embalagens") "Quantas embalagens foram usadas nesta produção." else "Quanto desse insumo entrou na produção."
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmartNumberField(usedQuantity, { usedQuantity = it }, "Qtd. usada *", Modifier.weight(1f))
                        SelectionField(usedUnit, compatibleUnits(packageUnit), "Unidade", Modifier.weight(0.62f)) { usedUnit = it }
                    }
                    InfoCard {
                        ResultRow("Custo na receita", preview?.let(::money) ?: "Preencha os valores")
                        if (preview != null) Text("${money(priceCents!!)} ÷ ${number(bought!!)} $packageUnit × ${number(used!!)} $usedUnit", style = MaterialTheme.typography.bodySmall)
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}

private fun compatibleUnits(unit: String) = when (unit) {
    "kg", "g", "mg" -> listOf("kg", "g", "mg")
    "l", "ml" -> listOf("l", "ml")
    else -> listOf("un")
}

private fun defaultUsedUnit(unit: String) = when (unit) {
    "kg", "g", "mg" -> "g"
    "l", "ml" -> "ml"
    else -> "un"
}

@Composable
private fun SubRecipeQuantityDialog(item: RecipeWithDetails, onDismiss: () -> Unit, onAdd: (Double) -> Unit) {
    var quantity by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text("Usar ${item.recipe.name}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = { SmartNumberField(quantity, { quantity = it }, "Quantidade em ${item.recipe.yieldUnit}", Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { parseDecimal(quantity)?.takeIf { it > 0 }?.let(onAdd) }) { Text("Adicionar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun RecipeCostsStep(modifier: Modifier, draft: RecipeDraft, vm: AppViewModel) {
    var addExtra by remember { mutableStateOf(false) }
    var lossText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.lossPercent)) }
    var laborText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.laborMinutes == 0) "" else draft.laborMinutes.toString()) }
    var hourlyText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.hourlyRateCents == 0L) "" else moneyInput(draft.hourlyRateCents)) }
    var feeText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.variableFeePercent)) }
    var fixedFeeText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.fixedFeePerUnitCents == 0L) "" else moneyInput(draft.fixedFeePerUnitCents)) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionTitle("Rendimento e custos", "Preencha somente o que fizer parte da sua produção.") }
        item { SmartNumberField(lossText, { text -> lossText = text; vm.updateDraft { it.copy(lossPercent = (parseDecimal(text) ?: 0.0).coerceIn(0.0, 99.0)) } }, "Perda estimada (%)", Modifier.fillMaxWidth(), supportingText = "Ex.: itens quebrados ou que não podem ser vendidos.") }
        item { SectionTitle("Mão de obra", "Informe quanto tempo você trabalha e quanto vale sua hora.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartNumberField(laborText, { text -> laborText = text.filter(Char::isDigit); vm.updateDraft { it.copy(laborMinutes = laborText.toIntOrNull() ?: 0) } }, "Tempo (min)", Modifier.weight(1f), integerOnly = true)
                SmartNumberField(hourlyText, { text -> hourlyText = text; vm.updateDraft { it.copy(hourlyRateCents = parseMoneyCents(text) ?: 0) } }, "Valor/hora", Modifier.weight(1f), prefix = "R$ ")
            }
        }
        item { SectionTitle("Taxas de venda", "Deixe zero se você vende sem taxa.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartNumberField(feeText, { text -> feeText = text; vm.updateDraft { it.copy(variableFeePercent = parseDecimal(text) ?: 0.0) } }, "Taxa (%)", Modifier.weight(1f))
                SmartNumberField(fixedFeeText, { text -> fixedFeeText = text; vm.updateDraft { it.copy(fixedFeePerUnitCents = parseMoneyCents(text) ?: 0) } }, "Taxa fixa/un.", Modifier.weight(1f), prefix = "R$ ")
            }
        }
        item {
            InfoCard {
                Text("Embalagens entram como insumo", fontWeight = FontWeight.SemiBold, color = Pink)
                Text("Cadastre saquinhos, caixas, etiquetas e outros consumíveis na etapa Insumos. Assim o preço de compra e a quantidade usada ficam reaproveitáveis.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("Outros custos", "Gás, energia, transporte e outros.")
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { addExtra = true }) { Icon(Icons.Outlined.Add, "Adicionar custo") }
            }
        }
        items(draft.extras.indices.toList()) { index ->
            val item = draft.extras[index]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Outline),
                shape = AppCardShape,
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.description, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${money(item.valueCents)} • ${if (item.application == "PER_UNIT") "por unidade" else "na receita inteira"}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    IconButton(onClick = { vm.removeExtraCost(index) }) { Icon(Icons.Outlined.DeleteOutline, "Remover") }
                }
            }
        }
        item { OutlinedButton(onClick = { addExtra = true }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) { Icon(Icons.Outlined.Add, null); Spacer(Modifier.size(6.dp)); Text("Adicionar outro custo", maxLines = 1) } }
    }
    if (addExtra) ExtraCostEditor(onDismiss = { addExtra = false }) { type, description, cents, perUnit -> vm.addExtraCost(type, description, cents, perUnit); addExtra = false }
}

@Composable
private fun ExtraCostEditor(onDismiss: () -> Unit, onAdd: (String, String, Long, Boolean) -> Unit) {
    var type by remember { mutableStateOf("Energia/Gás") }
    var description by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var perUnit by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { CompactTopBar("Adicionar custo", onDismiss) },
                bottomBar = {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text("Cancelar") }
                        Button(
                            onClick = {
                                val cents = parseMoneyCents(value)
                                if (description.isNotBlank() && cents != null && cents >= 0) onAdd(type, description.trim(), cents, perUnit)
                            },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = AppButtonShape
                        ) { Text("Adicionar") }
                    }
                }
            ) { inner ->
                Column(Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionTitle("Tipo de custo", "Escolha a categoria que melhor descreve o gasto.")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Energia/Gás", "Transporte", "Taxa", "Outros")) { item ->
                            FilterChip(type == item, { type = item }, label = { Text(item, maxLines = 1) })
                        }
                    }
                    OutlinedTextField(description, { description = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Descrição *", maxLines = 1) }, placeholder = { Text("Ex.: gás do forno", maxLines = 1) }, singleLine = true)
                    SmartNumberField(value, { value = it }, "Valor *", Modifier.fillMaxWidth(), prefix = "R$ ")
                    SectionTitle("Aplicar o custo")
                    Card(
                        Modifier.fillMaxWidth().clickable { perUnit = false },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Outline),
                        shape = AppCardShape
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(!perUnit, { perUnit = false })
                            Column { Text("Na receita inteira", maxLines = 1); Text("Ex.: gás e energia do preparo", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                    Card(
                        Modifier.fillMaxWidth().clickable { perUnit = true },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Outline),
                        shape = AppCardShape
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(perUnit, { perUnit = true })
                            Column { Text("Por unidade produzida", maxLines = 1); Text("Use só quando o gasto acontece a cada unidade", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecipeResultStep(modifier: Modifier, draft: RecipeDraft, catalog: List<IngredientEntity>, vm: AppViewModel) {
    val result = runCatching { draft.calculate() }.getOrNull()
    var targetText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.targetPercent)) }
    var chosenText by remember(draft.editingRecipeId) { mutableStateOf(draft.chosenSalePriceCents?.let(::moneyInput) ?: "") }
    var pricePerRecipe by remember { mutableStateOf(false) }
    val hasPackaging = draft.packagingPerUnitCents > 0 || draft.ingredients.any { used ->
        catalog.firstOrNull { it.id == used.ingredientId }?.category?.contains("embal", ignoreCase = true) == true
    }
    val missingCosts = buildList {
        if (!hasPackaging) add("embalagem")
        if (draft.laborMinutes == 0 || draft.hourlyRateCents == 0L) add("mão de obra")
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item { SectionTitle("Preço e lucro", "Resultado calculado com os valores informados.") }
        if (missingCosts.isNotEmpty()) {
            item {
                InfoCard {
                    Text("Estimativa com os custos informados", fontWeight = FontWeight.Bold, color = Pink)
                    Text("Ainda não foi informado: ${missingCosts.joinToString(" e ")}. O cálculo abaixo é parcial até esses custos serem conferidos.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            InfoCard {
                Text("Resumo da receita", fontWeight = FontWeight.Bold)
                ResultRow("Insumos", money(result?.ingredientsCents ?: 0))
                if ((result?.packagingCents ?: 0) > 0) ResultRow("Embalagem avulsa", money(result?.packagingCents ?: 0))
                ResultRow("Mão de obra", money(result?.laborCents ?: 0))
                ResultRow("Outros custos", money(result?.extrasCents ?: 0))
                ResultRow("Custo total", money(result?.totalCostCents ?: 0), true)
                ResultRow("Rendimento vendável", "${number(result?.sellableYield ?: 0.0)} ${draft.yieldUnit}")
                ResultRow("Custo por unidade", money(result?.costPerUnitCents ?: 0), true)
            }
        }
        item { SectionTitle("Defina seu preço de venda") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!pricePerRecipe, { pricePerRecipe = false; chosenText = draft.chosenSalePriceCents?.let(::moneyInput) ?: "" }, label = { Text("Por unidade", maxLines = 1) })
                FilterChip(pricePerRecipe, {
                    pricePerRecipe = true
                    chosenText = draft.chosenSalePriceCents?.let { cents -> moneyInput((cents * (result?.sellableYield ?: draft.yieldQuantity)).roundToLong()) } ?: ""
                }, label = { Text("Por receita", maxLines = 1) })
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(draft.pricingMode == "MARGIN", {
                    val adjustedTarget = if (draft.targetPercent >= 100.0) 50.0 else draft.targetPercent
                    targetText = number(adjustedTarget, 0); chosenText = ""
                    vm.updateDraft { it.copy(pricingMode = "MARGIN", targetPercent = adjustedTarget, chosenSalePriceCents = null) }
                }, label = { Text("Margem", maxLines = 1) })
                HelpTip("Margem é quanto do preço de venda sobra depois dos custos e taxas.")
                FilterChip(draft.pricingMode == "MARKUP", {
                    targetText = number(draft.targetPercent, 0); chosenText = ""
                    vm.updateDraft { it.copy(pricingMode = "MARKUP", chosenSalePriceCents = null) }
                }, label = { Text("Markup", maxLines = 1) })
                HelpTip("Markup é o acréscimo percentual aplicado sobre o custo.")
            }
        }
        item {
            val suggestions = if (draft.pricingMode == "MARGIN") listOf(20.0, 30.0, 40.0, 50.0) else listOf(30.0, 50.0, 100.0, 150.0)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(suggestions) { value -> FilterChip(draft.targetPercent == value, { targetText = number(value, 0); chosenText = ""; vm.updateDraft { it.copy(targetPercent = value, chosenSalePriceCents = null) } }, label = { Text("${number(value, 0)}%", maxLines = 1) }) }
            }
        }
        item {
            SmartNumberField(
                targetText,
                { text -> targetText = text; chosenText = ""; vm.updateDraft { it.copy(targetPercent = parseDecimal(text) ?: 0.0, chosenSalePriceCents = null) } },
                if (draft.pricingMode == "MARGIN") "Margem desejada (%)" else "Markup desejado (%)",
                Modifier.fillMaxWidth()
            )
        }
        item {
            val suggested = result?.suggestedPriceCents ?: 0
            val displaySuggested = if (pricePerRecipe) (suggested * (result?.sellableYield ?: draft.yieldQuantity)).roundToLong() else suggested
            Card(
                Modifier.fillMaxWidth(),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Outline),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when {
                            missingCosts.isNotEmpty() && pricePerRecipe -> "Estimativa da receita"
                            missingCosts.isNotEmpty() -> "Estimativa por unidade"
                            pricePerRecipe -> "Preço sugerido da receita"
                            else -> "Preço sugerido por unidade"
                        },
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(money(displaySuggested), color = Green, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
        item {
            SmartNumberField(
                chosenText,
                { text ->
                    chosenText = text
                    val entered = parseMoneyCents(text)
                    val perUnit = if (pricePerRecipe && entered != null && result != null && result.sellableYield > 0) (entered / result.sellableYield).roundToLong() else entered
                    vm.updateDraft { it.copy(chosenSalePriceCents = perUnit) }
                },
                if (pricePerRecipe) "Preço da receita (opcional)" else "Preço por unidade (opcional)",
                Modifier.fillMaxWidth(),
                prefix = "R$ ",
                supportingText = "Vazio usa o valor sugerido."
            )
        }
        result?.let { value ->
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard("Custo un.", money(value.costPerUnitCents), Modifier.weight(1f))
                    SummaryCard("Preço un.", money(value.salePriceCents), Modifier.weight(1f))
                    SummaryCard("Lucro un.", money(value.profitPerUnitCents), Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard("Margem", "${number(value.marginPercent)}%", Modifier.weight(1f))
                    SummaryCard("Markup", "${number(value.markupPercent)}%", Modifier.weight(1f))
                }
            }
        }
        item { Text("Os cálculos dependem dos preços, quantidades e custos informados.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, modifier: Modifier) {
    Card(
        modifier,
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = Pink, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

package br.com.lucroexato.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Route { MAIN, SETTINGS, WIZARD, RECIPE_DETAIL, INGREDIENT_DETAIL, SIMULATION }

@Composable
fun LucroExatoApp(vm: AppViewModel = viewModel()) {
    val tutorialComplete by vm.tutorialComplete.collectAsStateWithLifecycle()
    val snackbars = remember { SnackbarHostState() }
    var route by remember { mutableStateOf(Route.MAIN) }
    var selectedRecipeId by remember { mutableLongStateOf(0L) }
    var selectedIngredientId by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        vm.events.collect { snackbars.showSnackbar(it) }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbars) }) { padding ->
        if (!tutorialComplete) {
            OnboardingScreen(
                modifier = Modifier.padding(padding),
                onFinish = { addExample -> vm.completeTutorial(addExample); route = Route.MAIN }
            )
            return@Scaffold
        }

        BackHandler(enabled = route != Route.MAIN && route != Route.WIZARD) {
            route = when (route) {
                Route.SIMULATION -> Route.RECIPE_DETAIL
                Route.RECIPE_DETAIL, Route.INGREDIENT_DETAIL, Route.SETTINGS -> Route.MAIN
                else -> Route.MAIN
            }
        }

        when (route) {
            Route.MAIN -> MainShell(
                modifier = Modifier.padding(padding),
                vm = vm,
                onSettings = { route = Route.SETTINGS },
                onNewRecipe = { vm.startNewRecipe(); route = Route.WIZARD },
                onResumeDraft = { vm.resumeDraft(); route = Route.WIZARD },
                onRecipe = { selectedRecipeId = it; route = Route.RECIPE_DETAIL },
                onIngredient = { selectedIngredientId = it; route = Route.INGREDIENT_DETAIL }
            )
            Route.SETTINGS -> SettingsScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                onBack = { route = Route.MAIN }
            )
            Route.WIZARD -> RecipeWizardScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                onClose = { route = Route.MAIN },
                onSaved = { selectedRecipeId = it; route = Route.RECIPE_DETAIL }
            )
            Route.RECIPE_DETAIL -> RecipeDetailScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                recipeId = selectedRecipeId,
                onBack = { route = Route.MAIN },
                onEdit = { vm.editRecipe(selectedRecipeId) { route = Route.WIZARD } },
                onSimulate = { route = Route.SIMULATION }
            )
            Route.SIMULATION -> RecipeSimulationScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                recipeId = selectedRecipeId,
                onBack = { route = Route.RECIPE_DETAIL }
            )
            Route.INGREDIENT_DETAIL -> IngredientDetailScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                ingredientId = selectedIngredientId,
                onBack = { route = Route.MAIN }
            )
        }
    }
}

package br.com.lucroexato.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface IngredientDao {
    @Query("SELECT * FROM ingredients ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<IngredientEntity>>

    @Query("SELECT * FROM ingredients ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<IngredientEntity>

    @Query("SELECT COUNT(*) FROM ingredients")
    suspend fun count(): Int

    @Query("SELECT * FROM ingredients WHERE id = :id")
    suspend fun getById(id: Long): IngredientEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: IngredientEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<IngredientEntity>): List<Long>

    @Query("DELETE FROM ingredients")
    suspend fun deleteAll()

    @Insert
    suspend fun addPrice(item: IngredientPriceEntity)

    @Query("SELECT * FROM ingredient_prices WHERE ingredientId = :ingredientId ORDER BY recordedAt DESC")
    suspend fun priceHistory(ingredientId: Long): List<IngredientPriceEntity>

    @Query("SELECT * FROM ingredient_prices ORDER BY recordedAt")
    suspend fun allPrices(): List<IngredientPriceEntity>

    @Query("DELETE FROM ingredient_prices")
    suspend fun deleteAllPrices()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrices(items: List<IngredientPriceEntity>)
}

@Dao
interface RecipeDao {
    @Transaction
    @Query("SELECT * FROM recipes WHERE isDraft = 0 ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<RecipeWithDetails>>

    @Transaction
    @Query("SELECT * FROM recipes ORDER BY updatedAt DESC")
    suspend fun getAll(): List<RecipeWithDetails>

    @Transaction
    @Query("SELECT * FROM recipes WHERE id = :id")
    suspend fun getById(id: Long): RecipeWithDetails?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(recipe: RecipeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIngredients(items: List<RecipeIngredientEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExtraCosts(items: List<ExtraCostEntity>)

    @Query("DELETE FROM recipe_ingredients WHERE recipeId = :recipeId")
    suspend fun deleteIngredients(recipeId: Long)

    @Query("DELETE FROM extra_costs WHERE recipeId = :recipeId")
    suspend fun deleteExtraCosts(recipeId: Long)

    @Query("DELETE FROM recipes WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM recipe_ingredients")
    suspend fun deleteAllIngredients()

    @Query("DELETE FROM extra_costs")
    suspend fun deleteAllExtraCosts()

    @Query("DELETE FROM recipes")
    suspend fun deleteAllRecipes()
}

package br.com.lucroexato.domain

import kotlin.math.roundToLong

data class IngredientCostInput(val name: String, val costCents: Long)
data class ExtraCostInput(val valueCents: Long, val perUnit: Boolean)

data class CostInput(
    val yieldQuantity: Double,
    val lossPercent: Double,
    val ingredients: List<IngredientCostInput>,
    val packagingPerUnitCents: Long,
    val laborMinutes: Int,
    val hourlyRateCents: Long,
    val extras: List<ExtraCostInput>,
    val variableFeePercent: Double,
    val fixedFeePerUnitCents: Long,
    val pricingMode: String,
    val targetPercent: Double,
    val chosenSalePriceCents: Long? = null
)

data class CostResult(
    val sellableYield: Double,
    val ingredientsCents: Long,
    val packagingCents: Long,
    val laborCents: Long,
    val extrasCents: Long,
    val totalCostCents: Long,
    val costPerUnitCents: Long,
    val suggestedPriceCents: Long,
    val salePriceCents: Long,
    val feeCents: Long,
    val profitPerUnitCents: Long,
    val marginPercent: Double,
    val markupPercent: Double
)

object CostCalculator {
    fun convertToBase(quantity: Double, unit: String): Pair<String, Double> = when (unit.lowercase()) {
        "kg" -> "mass" to quantity * 1000.0
        "g" -> "mass" to quantity
        "mg" -> "mass" to quantity / 1000.0
        "l" -> "volume" to quantity * 1000.0
        "ml" -> "volume" to quantity
        "un", "unidade", "unidades" -> "unit" to quantity
        else -> error("Unidade não reconhecida: $unit")
    }

    fun ingredientCostCents(
        packagePriceCents: Long,
        packageQuantity: Double,
        packageUnit: String,
        usedQuantity: Double,
        usedUnit: String
    ): Long {
        require(packagePriceCents >= 0)
        require(packageQuantity > 0)
        require(usedQuantity >= 0)
        val (packageKind, packageBase) = convertToBase(packageQuantity, packageUnit)
        val (usedKind, usedBase) = convertToBase(usedQuantity, usedUnit)
        require(packageKind == usedKind) { "As unidades da compra e do uso não são compatíveis." }
        return (packagePriceCents * (usedBase / packageBase)).roundToLong()
    }

    fun calculate(input: CostInput): CostResult {
        require(input.yieldQuantity > 0)
        require(input.lossPercent in 0.0..99.99)
        val sellableYield = input.yieldQuantity * (1.0 - input.lossPercent / 100.0)
        require(sellableYield > 0)

        val ingredients = input.ingredients.sumOf { it.costCents }
        val packaging = (input.packagingPerUnitCents * sellableYield).roundToLong()
        val labor = (input.hourlyRateCents * (input.laborMinutes / 60.0)).roundToLong()
        val extras = input.extras.sumOf {
            if (it.perUnit) (it.valueCents * sellableYield).roundToLong() else it.valueCents
        }
        val total = ingredients + packaging + labor + extras
        val unitCost = (total / sellableYield).roundToLong()
        val target = (input.targetPercent / 100.0).coerceAtLeast(0.0)
        val variableFee = (input.variableFeePercent / 100.0).coerceIn(0.0, 0.99)

        val suggested = if (input.pricingMode == "MARKUP") {
            ((unitCost + input.fixedFeePerUnitCents) * (1.0 + target)).roundToLong()
        } else {
            val denominator = 1.0 - target - variableFee
            require(denominator > 0.001) { "Margem e taxa somadas precisam ser menores que 100%." }
            ((unitCost + input.fixedFeePerUnitCents) / denominator).roundToLong()
        }.coerceAtLeast(0)

        val salePrice = input.chosenSalePriceCents?.takeIf { it > 0 } ?: suggested
        val fee = (salePrice * variableFee).roundToLong() + input.fixedFeePerUnitCents
        val profit = salePrice - unitCost - fee
        val margin = if (salePrice > 0) profit * 100.0 / salePrice else 0.0
        val markup = if (unitCost > 0) (salePrice.toDouble() / unitCost - 1.0) * 100.0 else 0.0

        return CostResult(
            sellableYield = sellableYield,
            ingredientsCents = ingredients,
            packagingCents = packaging,
            laborCents = labor,
            extrasCents = extras,
            totalCostCents = total,
            costPerUnitCents = unitCost,
            suggestedPriceCents = suggested,
            salePriceCents = salePrice,
            feeCents = fee,
            profitPerUnitCents = profit,
            marginPercent = margin,
            markupPercent = markup
        )
    }
}

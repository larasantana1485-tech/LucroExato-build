package br.com.lucroexato.ui

import java.text.NumberFormat
import java.util.Locale

private val br = Locale("pt", "BR")
private val currency = NumberFormat.getCurrencyInstance(br)

fun money(cents: Long): String = currency.format(cents / 100.0)
fun moneyInput(cents: Long): String = String.format(br, "%.2f", cents / 100.0)
fun number(value: Double, decimals: Int = 1): String = String.format(br, "%.${decimals}f", value)

fun parseDecimal(text: String): Double? {
    val normalized = text.trim().replace("R$", "").replace(" ", "")
        .replace(".", "").replace(',', '.')
    return normalized.toDoubleOrNull()
}

fun parseMoneyCents(text: String): Long? = parseDecimal(text)?.times(100)?.toLong()

package br.com.lucroexato.domain

data class DraftIngredient(
    val ingredientId: Long? = null,
    val sourceRecipeId: Long? = null,
    val name: String,
    val quantity: Double,
    val unit: String,
    val costCents: Long
)

data class DraftExtraCost(
    val type: String,
    val description: String,
    val valueCents: Long,
    val application: String
)

data class RecipeDraft(
    val editingRecipeId: Long? = null,
    val name: String = "",
    val category: String = "Doces",
    val yieldQuantity: Double = 0.0,
    val yieldUnit: String = "un",
    val lossPercent: Double = 0.0,
    val ingredients: List<DraftIngredient> = emptyList(),
    val packagingPerUnitCents: Long = 0,
    val laborMinutes: Int = 0,
    val hourlyRateCents: Long = 0,
    val extras: List<DraftExtraCost> = emptyList(),
    val variableFeePercent: Double = 0.0,
    val fixedFeePerUnitCents: Long = 0,
    val pricingMode: String = "MARGIN",
    val targetPercent: Double = 50.0,
    val chosenSalePriceCents: Long? = null,
    val step: Int = 1,
    val dirty: Boolean = false
) {
    fun calculate(): CostResult = CostCalculator.calculate(
        CostInput(
            yieldQuantity = yieldQuantity,
            lossPercent = lossPercent,
            ingredients = ingredients.map { IngredientCostInput(it.name, it.costCents) },
            packagingPerUnitCents = packagingPerUnitCents,
            laborMinutes = laborMinutes,
            hourlyRateCents = hourlyRateCents,
            extras = extras.map { ExtraCostInput(it.valueCents, it.application == "PER_UNIT") },
            variableFeePercent = variableFeePercent,
            fixedFeePerUnitCents = fixedFeePerUnitCents,
            pricingMode = pricingMode,
            targetPercent = targetPercent,
            chosenSalePriceCents = chosenSalePriceCents
        )
    )
}

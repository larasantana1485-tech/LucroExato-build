package br.com.lucroexato.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class CostCalculatorTest {
    @Test fun `700 g de pacote de 2 kg a 70 reais custa 24 e 50`() {
        assertEquals(2450, CostCalculator.ingredientCostCents(7000, 2.0, "kg", 700.0, "g"))
    }

    @Test fun `margem nao e markup`() {
        val result = CostCalculator.calculate(
            CostInput(
                yieldQuantity = 10.0,
                lossPercent = 0.0,
                ingredients = listOf(IngredientCostInput("Teste", 1000)),
                packagingPerUnitCents = 0,
                laborMinutes = 0,
                hourlyRateCents = 0,
                extras = emptyList(),
                variableFeePercent = 0.0,
                fixedFeePerUnitCents = 0,
                pricingMode = "MARGIN",
                targetPercent = 50.0
            )
        )
        assertEquals(100, result.costPerUnitCents)
        assertEquals(200, result.suggestedPriceCents)
        assertEquals(50.0, result.marginPercent, 0.01)
        assertEquals(100.0, result.markupPercent, 0.01)
    }

    @Test fun `perda reduz rendimento vendavel e aumenta custo unitario`() {
        val result = CostCalculator.calculate(
            CostInput(
                yieldQuantity = 100.0,
                lossPercent = 10.0,
                ingredients = listOf(IngredientCostInput("Teste", 9000)),
                packagingPerUnitCents = 0,
                laborMinutes = 0,
                hourlyRateCents = 0,
                extras = emptyList(),
                variableFeePercent = 0.0,
                fixedFeePerUnitCents = 0,
                pricingMode = "MARKUP",
                targetPercent = 0.0
            )
        )
        assertEquals(90.0, result.sellableYield, 0.01)
        assertEquals(100, result.costPerUnitCents)
    }
}

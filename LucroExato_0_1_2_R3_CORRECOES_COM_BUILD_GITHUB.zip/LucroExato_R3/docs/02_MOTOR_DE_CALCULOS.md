# 2. Motor de cálculos — V1.0

## Regra da quantidade usada

`custo usado = preço da embalagem × quantidade usada convertida ÷ quantidade comprada convertida`

Exemplo real de teste: 2 kg custam R$ 70,00; 700 g usados custam R$ 24,50.

## Conversões

- massa: kg ↔ g ↔ mg;
- volume: l ↔ ml;
- unidade: un ↔ un;
- massa, volume e unidade não podem ser misturados.

## Rendimento e perdas

`rendimento vendável = rendimento informado × (1 − perda% ÷ 100)`

`custo por unidade = custo total da receita ÷ rendimento vendável`

## Custo total

Soma de:

- ingredientes e sub-receitas;
- embalagem por unidade × rendimento vendável;
- mão de obra: valor da hora × minutos ÷ 60;
- custos aplicados na receita inteira;
- custos aplicados por unidade × rendimento vendável.

## Preço por margem

`preço sugerido = (custo unitário + taxa fixa) ÷ (1 − margem desejada − taxa percentual)`

Margem e taxa percentual somadas devem ficar abaixo de 100%.

## Preço por markup

`preço sugerido = (custo unitário + taxa fixa) × (1 + markup%)`

## Resultado

`lucro unitário = preço − custo unitário − taxa percentual − taxa fixa`

`margem = lucro unitário ÷ preço × 100`

`markup = (preço ÷ custo unitário − 1) × 100`

Margem e markup nunca são tratados como sinônimos.

## Arredondamento

- dinheiro é armazenado em centavos;
- cada consumo é arredondado para o centavo mais próximo;
- porcentagens são calculadas com `Double` e exibidas com uma casa decimal;
- a simulação não altera o registro salvo.

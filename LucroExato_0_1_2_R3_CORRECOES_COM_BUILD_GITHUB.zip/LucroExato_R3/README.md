# Lucro Exato 0.1.2 R3

Aplicativo Android offline para calcular custo, preço, lucro, margem e markup de receitas.

## Abrir no Android Studio

1. Abra esta pasta como projeto.
2. Aguarde a sincronização do Gradle.
3. Execute o módulo `app` em um aparelho com Android 8.0 (API 26) ou superior.

## Fluxo principal

1. Dados da receita e rendimento, com unidade escolhida por seletor.
2. Insumos: ingredientes, embalagens e consumíveis usando a mesma lógica de compra e uso.
3. Custos: perdas, mão de obra, taxas e outros gastos.
4. Resultado: custo total e unitário, estimativa/preço sugerido, lucro, margem e markup.

A Home mostra rascunhos não concluídos. `Nova receita` sempre inicia uma receita nova; um rascunho existente é tratado explicitamente antes de ser substituído.

A simulação saiu da barra inferior e agora é aberta de dentro de uma receita salva, comparando `Atual x Simulação` sem alterar os dados originais.

## Catálogo

O catálogo inicial inclui ingredientes e itens de embalagem. Novos insumos criados durante uma receita são salvos no catálogo para reutilização e atualização de preço.

## Validação

Comandos previstos:

- `./gradlew testDebugUnitTest`
- `./gradlew assembleDebug`

Nesta sessão o Gradle 8.13 não pôde ser baixado porque o ambiente de execução estava sem resolução de rede. O projeto passou por validação estrutural de XML e verificação sintática sem erros de parser Kotlin; a compilação completa deve ser executada no Android Studio/ambiente com Gradle disponível.

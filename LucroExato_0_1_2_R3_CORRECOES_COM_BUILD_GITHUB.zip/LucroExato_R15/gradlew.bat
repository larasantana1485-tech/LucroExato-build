@echo off
setlocal
for /f "usebackq delims=" %%G in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0gradle\bootstrap-gradle.ps1"`) do set "GRADLE_BAT=%%G"
if errorlevel 1 exit /b 1
if not defined GRADLE_BAT (
  echo ERRO: nao foi possivel localizar o Gradle 8.13. 1>&2
  exit /b 1
)
call "%GRADLE_BAT%" %*
set EXIT_CODE=%ERRORLEVEL%
endlocal & exit /b %EXIT_CODE%

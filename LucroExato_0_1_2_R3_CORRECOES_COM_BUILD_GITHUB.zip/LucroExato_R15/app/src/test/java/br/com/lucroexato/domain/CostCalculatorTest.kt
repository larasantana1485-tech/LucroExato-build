package br.com.lucroexato.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CostCalculatorTest {
    private fun baseInput(
        yieldQuantity: Double = 10.0,
        ingredientCents: Long = 1000,
        lossPercent: Double = 0.0,
        variableFeePercent: Double = 0.0,
        fixedFeePerUnitCents: Long = 0,
        pricingMode: String = "MARGIN",
        targetPercent: Double = 50.0,
        chosenSalePriceCents: Long? = null
    ) = CostInput(
        yieldQuantity = yieldQuantity,
        lossPercent = lossPercent,
        ingredients = listOf(IngredientCostInput("Teste", ingredientCents)),
        packagingPerUnitCents = 0,
        laborMinutes = 0,
        hourlyRateCents = 0,
        extras = emptyList(),
        variableFeePercent = variableFeePercent,
        fixedFeePerUnitCents = fixedFeePerUnitCents,
        pricingMode = pricingMode,
        targetPercent = targetPercent,
        chosenSalePriceCents = chosenSalePriceCents
    )

    @Test fun `700 g de pacote de 2 kg a 70 reais custa 24 e 50`() {
        assertEquals(2450, CostCalculator.ingredientCostCents(7000, 2.0, "kg", 700.0, "g"))
    }

    @Test fun `embalagens da receita usam quantidade total consumida`() {
        assertEquals(300, CostCalculator.ingredientCostCents(5000, 400.0, "un", 24.0, "un"))
        assertEquals(120, CostCalculator.ingredientCostCents(500, 100.0, "un", 24.0, "un"))
    }

    @Test fun `conversoes de massa e volume preservam proporcao`() {
        assertEquals(3500, CostCalculator.ingredientCostCents(7000, 2.0, "kg", 1.0, "kg"))
        assertEquals(275, CostCalculator.ingredientCostCents(550, 1.0, "l", 500.0, "ml"))
        assertEquals(125, CostCalculator.ingredientCostCents(5000, 400.0, "un", 10.0, "un"))
    }

    @Test fun `margem nao e markup`() {
        val result = CostCalculator.calculate(baseInput())
        assertEquals(100, result.costPerUnitCents)
        assertEquals(200, result.suggestedPriceCents)
        assertEquals(50.0, result.marginPercent, 0.01)
        assertEquals(100.0, result.markupPercent, 0.01)
    }

    @Test fun `preco sugerido usa custo unitario exato e arredonda apenas no final`() {
        val result = CostCalculator.calculate(
            baseInput(yieldQuantity = 24.0, ingredientCents = 6659, targetPercent = 50.0)
        )
        assertEquals(277.458333, result.costPerUnitExactCents, 0.00001)
        assertEquals(277, result.costPerUnitCents)
        assertEquals(555, result.suggestedPriceCents)
        assertEquals(13320, result.suggestedRecipePriceCents)
    }

    @Test fun `custos subcentavo sao somados antes do arredondamento`() {
        val result = CostCalculator.calculate(
            baseInput(yieldQuantity = 1.0, ingredientCents = 0, pricingMode = "MARKUP", targetPercent = 0.0).copy(
                ingredients = List(10) { IngredientCostInput("micro", 0.1) }
            )
        )
        assertEquals(1, result.ingredientsCents)
        assertEquals(1, result.totalCostCents)
    }

    @Test fun `preco da receita fecha com preco unitario praticavel`() {
        val result = CostCalculator.calculate(
            baseInput(yieldQuantity = 24.0, ingredientCents = 6659, targetPercent = 50.0)
        )
        assertEquals(555, result.suggestedPriceCents)
        assertEquals(13320, result.suggestedRecipePriceCents)
    }

    @Test fun `preco real de 9 reais calcula margem e markup reais`() {
        val result = CostCalculator.calculate(
            baseInput(yieldQuantity = 24.0, ingredientCents = 6659, targetPercent = 50.0, chosenSalePriceCents = 900)
        )
        assertEquals(623, result.profitPerUnitCents)
        assertEquals(69.1713, result.marginPercent, 0.001)
        assertEquals(224.3730, result.markupPercent, 0.001)
    }

    @Test fun `taxa percentual e fixa entram no lucro e na margem`() {
        val result = CostCalculator.calculate(
            baseInput(
                yieldQuantity = 1.0,
                ingredientCents = 1000,
                variableFeePercent = 5.0,
                fixedFeePerUnitCents = 50,
                chosenSalePriceCents = 2000
            )
        )
        assertEquals(150, result.feeCents)
        assertEquals(850, result.profitPerUnitCents)
        assertEquals(42.5, result.marginPercent, 0.001)
    }

    @Test fun `margem alvo considera taxa percentual e taxa fixa`() {
        val result = CostCalculator.calculate(
            baseInput(
                yieldQuantity = 1.0,
                ingredientCents = 1000,
                variableFeePercent = 5.0,
                fixedFeePerUnitCents = 50,
                targetPercent = 50.0
            )
        )
        assertEquals(2334, result.suggestedPriceCents)
    }

    @Test fun `preco sugerido nunca fica abaixo da margem alvo por arredondamento`() {
        val result = CostCalculator.calculate(
            baseInput(
                yieldQuantity = 1.0,
                ingredientCents = 1000,
                variableFeePercent = 5.0,
                fixedFeePerUnitCents = 50,
                targetPercent = 50.0
            )
        )
        assertEquals(2334, result.suggestedPriceCents)
        assert(result.marginPercent >= 50.0)
    }

    @Test fun `markup alvo continua sendo acrescimo sobre custo de producao`() {
        val result = CostCalculator.calculate(
            baseInput(
                yieldQuantity = 1.0,
                ingredientCents = 1000,
                fixedFeePerUnitCents = 50,
                pricingMode = "MARKUP",
                targetPercent = 100.0
            )
        )
        assertEquals(2000, result.suggestedPriceCents)
        assertEquals(100.0, result.markupPercent, 0.001)
    }

    @Test fun `perda reduz rendimento vendavel e aumenta custo unitario`() {
        val result = CostCalculator.calculate(
            baseInput(yieldQuantity = 100.0, ingredientCents = 9000, lossPercent = 10.0, pricingMode = "MARKUP", targetPercent = 0.0)
        )
        assertEquals(90.0, result.sellableYield, 0.01)
        assertEquals(100, result.costPerUnitCents)
    }

    @Test fun `margem mais taxa nao pode chegar a cem por cento`() {
        assertThrows(IllegalArgumentException::class.java) {
            CostCalculator.calculate(baseInput(variableFeePercent = 10.0, targetPercent = 90.0))
        }
    }

    @Test fun `rendimento zero e unidade incompativel sao rejeitados`() {
        assertThrows(IllegalArgumentException::class.java) {
            CostCalculator.calculate(baseInput(yieldQuantity = 0.0))
        }
        assertThrows(IllegalArgumentException::class.java) {
            CostCalculator.ingredientCostCents(1000, 1.0, "kg", 100.0, "ml")
        }
    }
}

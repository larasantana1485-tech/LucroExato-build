package br.com.lucroexato.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FormattersTest {
    @Test fun `inteiros nao exibem virgula zero`() {
        assertEquals("24", number(24.0))
        assertEquals("400", number(400.0))
        assertEquals("50", number(50.0))
    }

    @Test fun `decimais necessarios permanecem`() {
        assertEquals("1,5", number(1.5))
        assertEquals("0,75", number(0.75))
        assertEquals("0,125", number(0.125))
    }

    @Test fun `parser aceita virgula e ponto decimal`() {
        assertEquals(1.5, parseDecimal("1,5")!!, 0.0001)
        assertEquals(1.5, parseDecimal("1.5")!!, 0.0001)
        assertEquals(1234.56, parseDecimal("1.234,56")!!, 0.0001)
        assertEquals(1234.56, parseDecimal("1,234.56")!!, 0.0001)
    }

    @Test fun `dinheiro arredonda centavos em vez de truncar`() {
        assertEquals(115L, parseMoneyCents("1,145"))
        assertEquals(101L, parseMoneyCents("1,005"))
        assertNull(parseMoneyCents("-1"))
    }

    @Test fun `campo numerico remove operadores e normaliza ponto`() {
        assertEquals("12,5", sanitizeNumericInput("12.5", false))
        assertEquals("1", sanitizeNumericInput("1+2/5", true))
        assertEquals("12,5", sanitizeNumericInput("12,5+7", false))
    }
}

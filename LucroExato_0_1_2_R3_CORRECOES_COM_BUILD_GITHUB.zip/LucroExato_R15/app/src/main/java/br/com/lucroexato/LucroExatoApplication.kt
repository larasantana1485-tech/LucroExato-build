package br.com.lucroexato

import android.app.Application
import br.com.lucroexato.data.AppDatabase
import br.com.lucroexato.data.LucroRepository

class LucroExatoApplication : Application() {
    val database by lazy { AppDatabase.create(this) }
    val repository by lazy { LucroRepository(database) }
}

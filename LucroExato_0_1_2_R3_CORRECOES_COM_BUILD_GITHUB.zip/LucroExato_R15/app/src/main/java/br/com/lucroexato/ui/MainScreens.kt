package br.com.lucroexato.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.IngredientPriceEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.CostCalculator
import br.com.lucroexato.domain.CostInput
import br.com.lucroexato.domain.ExtraCostInput
import br.com.lucroexato.domain.IngredientCostInput
import br.com.lucroexato.ui.theme.BlueSoft
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import br.com.lucroexato.ui.theme.PinkSoft
import br.com.lucroexato.ui.theme.YellowSoft
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToLong

enum class MainTab { RECIPES, SUPPLIES }
private enum class SimulationMode { KEEP_PRICE, KEEP_TARGET }

@Composable
fun MainShell(
    modifier: Modifier = Modifier,
    vm: AppViewModel,
    onSettings: () -> Unit,
    onNewRecipe: () -> Unit,
    onResumeDraft: () -> Unit,
    onRecipe: (Long) -> Unit,
    onIngredient: (Long) -> Unit,
    selectedTab: MainTab,
    onTabChange: (MainTab) -> Unit
) {
    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 10.dp, top = 14.dp, bottom = 6.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(Modifier.weight(1f)) {
                Text("Lucro Exato", style = MaterialTheme.typography.headlineSmall, color = Pink)
                Text(
                    "Custos e precificação de receitas",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // Alinhado à linha do título, e não ao centro do bloco título + subtítulo.
            IconButton(onClick = onSettings, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Outlined.Settings, "Configurações")
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            MainTopTab(
                selected = selectedTab == MainTab.RECIPES,
                icon = { Icon(Icons.Outlined.ReceiptLong, null, modifier = Modifier.size(20.dp)) },
                label = "Receitas",
                modifier = Modifier.weight(1f)
            ) { onTabChange(MainTab.RECIPES) }
            MainTopTab(
                selected = selectedTab == MainTab.SUPPLIES,
                icon = { Icon(Icons.Outlined.Inventory2, null, modifier = Modifier.size(20.dp)) },
                label = "Insumos",
                modifier = Modifier.weight(1f)
            ) { onTabChange(MainTab.SUPPLIES) }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Outline))
        when (selectedTab) {
            MainTab.RECIPES -> RecipesScreen(Modifier.weight(1f), vm, onNewRecipe, onResumeDraft, onRecipe)
            MainTab.SUPPLIES -> IngredientsScreen(Modifier.weight(1f), vm, onIngredient)
        }
    }
}

@Composable
private fun MainTopTab(
    selected: Boolean,
    icon: @Composable () -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier.clickable(onClick = onClick).padding(top = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(contentAlignment = Alignment.Center) { icon() }
            Text(
                label,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                color = if (selected) Pink else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box(
            Modifier.fillMaxWidth(0.72f).height(3.dp)
                .background(if (selected) Pink else Color.Transparent)
        )
    }
}

@Composable
private fun RecipesScreen(
    modifier: Modifier,
    vm: AppViewModel,
    onNewRecipe: () -> Unit,
    onResumeDraft: () -> Unit,
    onRecipe: (Long) -> Unit
) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val savedDraft by vm.savedDraft.collectAsStateWithLifecycle()
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todas") }
    var confirmNew by remember { mutableStateOf(false) }
    val categories = listOf("Todas", "Bolos", "Doces", "Tortas", "Cookies", "Pães", "Salgados", "Sobremesas", "Bebidas", "Outros")
    val filtered = recipes.filter {
        (category == "Todas" || it.recipe.category == category) && it.recipe.name.contains(search, ignoreCase = true)
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        savedDraft?.takeIf { it.dirty }?.let { draft ->
            item {
                Card(
                    Modifier.fillMaxWidth().clickable(onClick = onResumeDraft),
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = PinkSoft),
                    border = BorderStroke(1.dp, Outline),
                    elevation = CardDefaults.cardElevation(0.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Edit, null, tint = Pink)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(if (draft.editingRecipeId == null) "Rascunho" else "Edição não concluída", fontWeight = FontWeight.Bold)
                            Text(draft.name.ifBlank { "Receita sem nome" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Etapa ${draft.step} de 4 • toque para continuar", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("Continuar", color = Pink, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = AppFieldShape,
                placeholder = { Text("Buscar receitas...") },
                leadingIcon = { Icon(Icons.Outlined.Search, null) }
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { item -> FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item, maxLines = 1) }) }
            }
        }
        item {
            Button(
                onClick = { if (savedDraft?.dirty == true) confirmNew = true else onNewRecipe() },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = AppButtonShape
            ) {
                Icon(Icons.Outlined.Add, null); Spacer(Modifier.size(8.dp)); Text("Nova receita", maxLines = 1)
            }
        }
        item { SectionTitle("Minhas receitas", if (recipes.isEmpty()) "Crie sua primeira receita para começar." else recipeCountText(filtered.size)) }
        if (filtered.isEmpty()) {
            item {
                InfoCard(tint = PinkSoft) {
                    Text(if (recipes.isEmpty()) "Ainda não há receitas salvas." else "Nenhuma receita encontrada.", fontWeight = FontWeight.SemiBold)
                    Text("O Lucro Exato salva tudo no próprio celular e funciona offline.", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            items(filtered, key = { it.recipe.id }) { item -> RecipeCard(item, catalog) { onRecipe(item.recipe.id) } }
        }
    }

    if (confirmNew) {
        AlertDialog(
            onDismissRequest = { confirmNew = false },
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            shape = AppCardShape,
            title = { Text("Começar outra receita?") },
            text = { Text("Existe um rascunho salvo. Começar uma nova receita descarta esse rascunho.") },
            confirmButton = {
                TextButton(onClick = { confirmNew = false; onNewRecipe() }) { Text("Começar nova") }
            },
            dismissButton = {
                TextButton(onClick = { confirmNew = false; onResumeDraft() }) { Text("Continuar rascunho") }
            }
        )
    }
}

@Composable
private fun RecipeCard(item: RecipeWithDetails, catalog: List<IngredientEntity>, onClick: () -> Unit) {
    val missingChecks = buildList {
        if (!hasPackagingSupply(item, catalog)) add("embalagem")
        if (item.recipe.laborMinutes == 0 || item.recipe.hourlyRateCents == 0L) add("mão de obra")
    }
    val partial = missingChecks.isNotEmpty()
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(0.dp),
        border = BorderStroke(1.dp, Outline)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Card(
                Modifier.size(40.dp),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = PinkSoft),
                elevation = CardDefaults.cardElevation(0.dp)
            ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.ReceiptLong, null, tint = Pink, modifier = Modifier.size(22.dp)) } }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(item.recipe.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${item.recipe.category} • ${number(item.recipe.yieldQuantity)} ${item.recipe.yieldUnit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text("Custo un. ${money(item.recipe.costPerUnitCents)}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                if (partial) Text("Resultado parcial", style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A5A00), fontWeight = FontWeight.SemiBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Preço por unidade", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text(money(item.recipe.salePricePerUnitCents), color = Green, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

@Composable
private fun IngredientsScreen(modifier: Modifier, vm: AppViewModel, onIngredient: (Long) -> Unit) {
    val ingredients by vm.ingredients.collectAsStateWithLifecycle()
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    val categories = listOf("Todos", "Embalagens") + (SupplyCategories + ingredients.map { it.category }).distinct().filterNot { it == "Embalagens" }
    val filtered = ingredients.filter { (category == "Todos" || it.category == category) && it.name.contains(search, true) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Seus insumos", style = MaterialTheme.typography.titleLarge)
                    Text("Ingredientes, embalagens e consumíveis", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedButton(
                    onClick = { onIngredient(0) },
                    shape = RoundedCornerShape(13.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Outlined.Add, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Novo insumo", maxLines = 1)
                }
            }
        }
        item { OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, placeholder = { Text("Buscar insumo...") }, leadingIcon = { Icon(Icons.Outlined.Search, null) }, singleLine = true) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { item -> FilterChip(category == item, { category = item }, label = { Text(item, maxLines = 1) }) } } }
        items(filtered, key = { it.id }) { item -> IngredientRow(item) { onIngredient(item.id) } }
    }
}

@Composable
private fun IngredientRow(item: IngredientEntity, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(
                "${money(item.packagePriceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}",
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1
            )
            Spacer(Modifier.size(8.dp))
            Icon(Icons.Outlined.ChevronRight, "Abrir insumo", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
fun RecipeSimulationScreen(modifier: Modifier, vm: AppViewModel, recipeId: Long, onBack: () -> Unit) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val selected = recipes.firstOrNull { it.recipe.id == recipeId }
    var selectingIngredient by remember { mutableStateOf(false) }
    var pickerSearch by remember { mutableStateOf("") }
    var selectedIngredientId by remember(selected?.ingredients) {
        mutableStateOf(selected?.ingredients?.firstOrNull { it.ingredientId != null }?.ingredientId ?: 0L)
    }
    val recipeIngredient = selected?.ingredients?.firstOrNull { it.ingredientId == selectedIngredientId }
    val catalogIngredient = catalog.firstOrNull { it.id == selectedIngredientId }
    var yieldText by remember(recipeId, selected?.recipe?.yieldQuantity) {
        mutableStateOf(selected?.recipe?.yieldQuantity?.let { number(it) } ?: "")
    }
    var ingredientPriceText by remember(recipeId, selectedIngredientId, catalogIngredient) {
        mutableStateOf(catalogIngredient?.packagePriceCents?.let(::moneyInput) ?: "")
    }
    var marginText by remember(recipeId, selected?.recipe?.targetPercent) {
        mutableStateOf(selected?.recipe?.targetPercent?.let { number(it) } ?: "50")
    }
    var mode by remember { mutableStateOf(SimulationMode.KEEP_PRICE) }
    var comparison by remember { mutableStateOf<Pair<br.com.lucroexato.domain.CostResult, br.com.lucroexato.domain.CostResult>?>(null) }
    var simulationError by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    BackHandler(enabled = selectingIngredient) {
        selectingIngredient = false
        pickerSearch = ""
    }

    if (selectingIngredient && selected != null) {
        SimulationIngredientPickerScreen(
            modifier = modifier,
            selected = selected,
            selectedIngredientId = selectedIngredientId,
            search = pickerSearch,
            onSearchChange = { pickerSearch = it },
            onDismiss = {
                selectingIngredient = false
                pickerSearch = ""
            },
            onSelect = { ingredientId ->
                selectedIngredientId = ingredientId
                comparison = null
                simulationError = null
                selectingIngredient = false
                pickerSearch = ""
            }
        )
        return
    }

    LaunchedEffect(comparison, simulationError) {
        if (comparison != null || simulationError != null) {
            delay(140)
            val last = (listState.layoutInfo.totalItemsCount - 1).coerceAtLeast(0)
            listState.animateScrollToItem(last)
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize().imePadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { CompactTopBar("Simular mudanças", onBack) }
        if (selected == null) {
            item { InfoCard(Modifier.padding(horizontal = 16.dp)) { Text("Receita não encontrada.") } }
        } else {
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text(selected.recipe.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("A simulação não altera a receita salva.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("O que deve ficar fixo?", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.size(4.dp))
                        HelpTip("Manter preço conserva o preço de venda e mostra como lucro e margem mudam. Manter margem/markup recalcula o preço necessário para preservar sua meta.")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = mode == SimulationMode.KEEP_PRICE,
                            onClick = { mode = SimulationMode.KEEP_PRICE; comparison = null; simulationError = null },
                            label = { Text("Manter preço", maxLines = 1) },
                            shape = RoundedCornerShape(13.dp)
                        )
                        FilterChip(
                            selected = mode == SimulationMode.KEEP_TARGET,
                            onClick = { mode = SimulationMode.KEEP_TARGET; comparison = null; simulationError = null },
                            label = { Text(if (selected.recipe.pricingMode == "MARKUP") "Manter markup" else "Manter margem", maxLines = 1) },
                            shape = RoundedCornerShape(13.dp)
                        )
                    }
                    Text(
                        if (mode == SimulationMode.KEEP_PRICE)
                            "Mantém ${money(selected.recipe.salePricePerUnitCents)} por unidade e mostra como lucro e margem mudam."
                        else if (selected.recipe.pricingMode == "MARKUP")
                            "Mantém o markup desejado e recalcula o preço de venda."
                        else
                            "Mantém a margem desejada e recalcula o preço de venda.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (selected.ingredients.any { it.ingredientId != null }) {
                item {
                    OutlinedButton(
                        onClick = { selectingIngredient = true },
                        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().heightIn(min = 52.dp),
                        shape = AppButtonShape
                    ) {
                        Icon(Icons.Outlined.Search, null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.size(8.dp))
                        Text(recipeIngredient?.nameSnapshot ?: "Escolher insumo", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Outlined.ChevronRight, null, modifier = Modifier.size(20.dp))
                    }
                }
                item {
                    SmartNumberField(
                        value = ingredientPriceText,
                        onValueChange = { ingredientPriceText = it; comparison = null; simulationError = null },
                        label = "Novo preço de compra",
                        prefix = "R$ ",
                        supportingText = catalogIngredient?.let {
                            "Atual: ${money(it.packagePriceCents)} / ${number(it.packageQuantity)} ${it.packageUnit}"
                        },
                        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                    )
                }
            }

            item {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmartNumberField(
                        yieldText,
                        { yieldText = it; comparison = null; simulationError = null },
                        "Rendimento",
                        Modifier.weight(1f)
                    )
                    if (mode == SimulationMode.KEEP_TARGET) {
                        SmartNumberField(
                            marginText,
                            { marginText = it; comparison = null; simulationError = null },
                            if (selected.recipe.pricingMode == "MARKUP") "Markup (%)" else "Margem (%)",
                            Modifier.weight(1f)
                        )
                    } else {
                        Surface(
                            modifier = Modifier.weight(1f).heightIn(min = 56.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, Outline),
                            shape = AppFieldShape
                        ) {
                            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                Text("Preço mantido", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(money(selected.recipe.salePricePerUnitCents), fontWeight = FontWeight.Bold, color = Green)
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        val simulatedPrice = parseMoneyCents(ingredientPriceText)
                        val simulatedYield = parseDecimal(yieldText) ?: selected.recipe.yieldQuantity
                        val target = parseDecimal(marginText) ?: selected.recipe.targetPercent
                        simulationError = null
                        val attempt = runCatching {
                            val currentInput = selected.toCostInput(
                                yieldQuantity = selected.recipe.yieldQuantity,
                                targetPercent = target,
                                chosenSalePriceCents = if (mode == SimulationMode.KEEP_PRICE) selected.recipe.salePricePerUnitCents else null,
                                pricingMode = selected.recipe.pricingMode
                            )
                            val simulatedIngredients = selected.ingredients.map { used ->
                                val newCost = if (
                                    used.ingredientId == selectedIngredientId &&
                                    simulatedPrice != null && catalogIngredient != null
                                ) {
                                    CostCalculator.ingredientCostExactCents(
                                        simulatedPrice,
                                        catalogIngredient.packageQuantity,
                                        catalogIngredient.packageUnit,
                                        used.quantityUsed,
                                        used.unit
                                    )
                                } else (used.costExactCents ?: used.costCents.toDouble())
                                IngredientCostInput(used.nameSnapshot, newCost)
                            }
                            val simulatedInput = selected.toCostInput(
                                yieldQuantity = simulatedYield,
                                targetPercent = target,
                                chosenSalePriceCents = if (mode == SimulationMode.KEEP_PRICE) selected.recipe.salePricePerUnitCents else null,
                                ingredients = simulatedIngredients,
                                pricingMode = selected.recipe.pricingMode
                            )
                            CostCalculator.calculate(currentInput) to CostCalculator.calculate(simulatedInput)
                        }
                        val resultPair = attempt.getOrNull()
                        val unchanged = resultPair?.let { (current, simulated) ->
                            current.totalCostCents == simulated.totalCostCents &&
                                kotlin.math.abs(current.costPerUnitExactCents - simulated.costPerUnitExactCents) < 0.005 &&
                                current.salePriceCents == simulated.salePriceCents &&
                                current.profitPerUnitCents == simulated.profitPerUnitCents &&
                                kotlin.math.abs(current.marginPercent - simulated.marginPercent) < 0.01 &&
                                kotlin.math.abs(current.sellableYield - simulated.sellableYield) < 0.0001
                        } == true
                        comparison = if (unchanged) null else resultPair
                        simulationError = when {
                            attempt.isFailure -> attempt.exceptionOrNull()?.message ?: "Confira os valores da simulação."
                            unchanged -> "Nada mudou ainda. Altere o preço de compra de um insumo, o rendimento ou a meta antes de calcular."
                            resultPair == null -> "Confira os valores da simulação."
                            else -> null
                        }
                    },
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(48.dp),
                    shape = AppButtonShape
                ) { Text("Calcular simulação") }
            }

            simulationError?.let { message ->
                item {
                    InfoCard(Modifier.padding(horizontal = 16.dp), tint = YellowSoft) {
                        Text("Não foi possível calcular", fontWeight = FontWeight.Bold)
                        Text(message, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            comparison?.let { (current, simulated) ->
                item {
                    val currentPrice = if (mode == SimulationMode.KEEP_PRICE) current.salePriceCents else current.suggestedPriceCents
                    val simulatedPrice = if (mode == SimulationMode.KEEP_PRICE) simulated.salePriceCents else simulated.suggestedPriceCents
                    SimulationComparisonCard(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        current = current,
                        simulated = simulated,
                        currentPrice = currentPrice,
                        simulatedPrice = simulatedPrice
                    )
                }
            }
        }
    }

}

@Composable
private fun SimulationIngredientPickerScreen(
    modifier: Modifier = Modifier,
    selected: RecipeWithDetails,
    selectedIngredientId: Long,
    search: String,
    onSearchChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSelect: (Long) -> Unit
) {
    val candidates = selected.ingredients.filter { used ->
        used.ingredientId != null && used.nameSnapshot.contains(search, ignoreCase = true)
    }
    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { CompactTopBar("Escolher insumo", onDismiss) }
    ) { inner ->
        LazyColumn(
                    modifier = Modifier.padding(inner).fillMaxSize().imePadding(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, top = 10.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = search,
                            onValueChange = onSearchChange,
                            modifier = Modifier.fillMaxWidth(),
                            shape = AppFieldShape,
                            placeholder = { Text("Buscar insumo...") },
                            leadingIcon = { Icon(Icons.Outlined.Search, null) },
                            singleLine = true
                        )
                    }
                    if (candidates.isEmpty()) {
                        item {
                            InfoCard {
                                Text("Nenhum insumo encontrado.", fontWeight = FontWeight.SemiBold)
                                Text("Tente outro termo de busca.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    } else {
                        items(candidates, key = { it.id }) { ingredient ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { ingredient.ingredientId?.let(onSelect) },
                                shape = AppCardShape,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, if (ingredient.ingredientId == selectedIngredientId) Pink else Outline),
                                elevation = CardDefaults.cardElevation(0.dp)
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(ingredient.nameSnapshot, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            "${number(ingredient.quantityUsed)} ${ingredient.unit}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (ingredient.ingredientId == selectedIngredientId) {
                                        Text("Selecionado", color = Pink, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                    } else {
                                        Icon(Icons.Outlined.ChevronRight, "Selecionar", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
                                    }
                                }
                            }
                        }
                    }
        }
    }
}

@Composable
private fun SimulationComparisonCard(
    modifier: Modifier = Modifier,
    current: br.com.lucroexato.domain.CostResult,
    simulated: br.com.lucroexato.domain.CostResult,
    currentPrice: Long,
    simulatedPrice: Long
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Atual × simulado", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Métrica", modifier = Modifier.weight(1.35f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Text("Atual", modifier = Modifier.weight(0.85f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Text("Simulado", modifier = Modifier.weight(0.85f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Text("Δ", modifier = Modifier.weight(0.65f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            }
            SimulationTableRow("Custo da receita", money(current.totalCostCents), money(simulated.totalCostCents), current.totalCostCents, simulated.totalCostCents, positiveWhenHigher = false)
            SimulationTableRow("Custo por unidade", money(current.costPerUnitCents), money(simulated.costPerUnitCents), current.costPerUnitCents, simulated.costPerUnitCents, positiveWhenHigher = false)
            SimulationTableRow("Preço de venda", money(currentPrice), money(simulatedPrice), currentPrice, simulatedPrice, positiveWhenHigher = null)
            SimulationTableRow("Lucro por unidade", money(current.profitPerUnitCents), money(simulated.profitPerUnitCents), current.profitPerUnitCents, simulated.profitPerUnitCents, positiveWhenHigher = true)
            SimulationPercentRow("Margem", current.marginPercent, simulated.marginPercent)
        }
    }
}

@Composable
private fun SimulationTableRow(
    label: String,
    currentText: String,
    simulatedText: String,
    currentValue: Long,
    simulatedValue: Long,
    positiveWhenHigher: Boolean?
) {
    val delta = simulatedValue - currentValue
    val deltaText = when {
        delta > 0 -> "+${money(delta)}"
        delta < 0 -> "-${money(-delta)}"
        else -> "—"
    }
    val deltaColor = when {
        delta == 0L || positiveWhenHigher == null -> MaterialTheme.colorScheme.onSurfaceVariant
        (delta > 0L) == positiveWhenHigher -> Green
        else -> MaterialTheme.colorScheme.error
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1.35f), style = MaterialTheme.typography.bodySmall)
        Text(currentText, modifier = Modifier.weight(0.85f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
        Text(simulatedText, modifier = Modifier.weight(0.85f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(deltaText, modifier = Modifier.weight(0.65f), style = MaterialTheme.typography.bodySmall, color = deltaColor, fontWeight = if (delta == 0L) FontWeight.Normal else FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun SimulationPercentRow(label: String, current: Double, simulated: Double) {
    val delta = simulated - current
    val deltaText = when {
        kotlin.math.abs(delta) < 0.05 -> "—"
        delta > 0 -> "+${percent(delta)} p.p."
        else -> "-${percent(-delta)} p.p."
    }
    val deltaColor = when {
        kotlin.math.abs(delta) < 0.05 -> MaterialTheme.colorScheme.onSurfaceVariant
        delta > 0 -> Green
        else -> MaterialTheme.colorScheme.error
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1.35f), style = MaterialTheme.typography.bodySmall)
        Text("${percent(current)}%", modifier = Modifier.weight(0.85f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
        Text("${percent(simulated)}%", modifier = Modifier.weight(0.85f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(deltaText, modifier = Modifier.weight(0.65f), style = MaterialTheme.typography.bodySmall, color = deltaColor, fontWeight = if (kotlin.math.abs(delta) < 0.05) FontWeight.Normal else FontWeight.SemiBold, maxLines = 1)
    }
}

private fun RecipeWithDetails.toCostInput(
    yieldQuantity: Double = recipe.yieldQuantity,
    targetPercent: Double = recipe.targetPercent,
    chosenSalePriceCents: Long? = recipe.salePricePerUnitCents,
    ingredients: List<IngredientCostInput> = this.ingredients.map { IngredientCostInput(it.nameSnapshot, it.costExactCents ?: it.costCents.toDouble()) },
    pricingMode: String = recipe.pricingMode
) = CostInput(
    yieldQuantity = yieldQuantity,
    lossPercent = recipe.lossPercent,
    ingredients = ingredients,
    packagingPerUnitCents = recipe.packagingPerUnitCents,
    laborMinutes = recipe.laborMinutes,
    hourlyRateCents = recipe.hourlyRateCents,
    extras = extraCosts.map { ExtraCostInput(it.valueCents, it.application == "PER_UNIT") },
    variableFeePercent = recipe.variableFeePercent,
    fixedFeePerUnitCents = recipe.fixedFeePerUnitCents,
    pricingMode = pricingMode,
    targetPercent = targetPercent,
    chosenSalePriceCents = chosenSalePriceCents
)

@Composable
fun PreparationEditScreen(modifier: Modifier, vm: AppViewModel, recipeId: Long, onBack: () -> Unit) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val item = recipes.firstOrNull { it.recipe.id == recipeId }
    var preparation by remember(recipeId, item?.recipe?.preparation) { mutableStateOf(item?.recipe?.preparation.orEmpty()) }

    LazyColumn(
        modifier = modifier.fillMaxSize().imePadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { CompactTopBar("Modo de preparo", onBack) }
        if (item == null) {
            item { InfoCard(Modifier.padding(horizontal = 16.dp)) { Text("Receita não encontrada.") } }
        } else {
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(item.recipe.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("Opcional. Este texto não altera os cálculos da receita.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                OutlinedTextField(
                    value = preparation,
                    onValueChange = { preparation = it },
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().heightIn(min = 180.dp),
                    shape = AppFieldShape,
                    label = { Text("Modo de preparo (opcional)") },
                    minLines = 6
                )
            }
            item {
                Button(
                    onClick = { vm.updateRecipePreparation(recipeId, preparation, onBack) },
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(50.dp),
                    shape = AppButtonShape
                ) { Text("Salvar modo de preparo") }
            }
        }
    }
}

@Composable
fun IngredientDetailScreen(modifier: Modifier, vm: AppViewModel, ingredientId: Long, onBack: () -> Unit) {
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val existing = catalog.firstOrNull { it.id == ingredientId }
    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var category by remember(existing) { mutableStateOf(existing?.category ?: "Outros") }
    var price by remember(existing) { mutableStateOf(existing?.packagePriceCents?.let(::moneyInput) ?: "") }
    var quantity by remember(existing) { mutableStateOf(existing?.packageQuantity?.let { number(it) } ?: "") }
    var unit by remember(existing) { mutableStateOf(existing?.packageUnit ?: "kg") }
    var history by remember { mutableStateOf<List<IngredientPriceEntity>>(emptyList()) }
    LaunchedEffect(existing?.id) { if (existing != null) history = vm.priceHistory(existing.id) }

    LazyColumn(modifier.fillMaxSize().imePadding(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { CompactTopBar(if (existing == null) "Novo insumo" else existing.name, onBack) }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Nome do insumo *", maxLines = 1) }, singleLine = true)
                SelectionField(category, SupplyCategories, "Categoria *", Modifier.fillMaxWidth()) { selectedCategory ->
                    category = selectedCategory
                    if (selectedCategory == "Embalagens" && existing == null) unit = "un"
                }
                SmartNumberField(price, { price = it }, "Preço pago *", Modifier.fillMaxWidth(), prefix = "R$ ")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmartNumberField(quantity, { quantity = it }, "Qtd. comprada *", Modifier.weight(1f))
                    SelectionField(unit, listOf("kg", "g", "mg", "l", "ml", "un"), "Unidade", Modifier.weight(0.62f)) { unit = it }
                }
                existing?.let { current ->
                    if (current.referenceMinCentsPerBase != null && current.referenceMaxCentsPerBase != null) {
                        InfoCard(tint = BlueSoft) { Text("Preço de referência", fontWeight = FontWeight.SemiBold); Text("${money(current.referenceMinCentsPerBase)} – ${money(current.referenceMaxCentsPerBase)} por kg"); Text("Use seu preço real sempre que souber.", style = MaterialTheme.typography.bodySmall) }
                    }
                }
                Button(onClick = {
                    val cents = parseMoneyCents(price); val qty = parseDecimal(quantity)
                    if (name.isNotBlank() && category.isNotBlank() && cents != null && cents > 0 && qty != null && qty > 0) {
                        vm.saveIngredient(
                            IngredientEntity(id = existing?.id ?: 0, name = name.trim(), category = category.trim(), packagePriceCents = cents, packageQuantity = qty, packageUnit = unit, referenceMinCentsPerBase = existing?.referenceMinCentsPerBase, referenceMaxCentsPerBase = existing?.referenceMaxCentsPerBase, isBuiltIn = existing?.isBuiltIn ?: false),
                            onSaved = onBack
                        )
                    }
                }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = AppButtonShape) { Text(if (existing == null) "Adicionar insumo" else "Salvar alterações", maxLines = 1) }
            }
        }
        if (history.isNotEmpty()) {
            item { Box(Modifier.padding(horizontal = 16.dp)) { SectionTitle("Histórico de preços", "Seus últimos valores") } }
            items(history.take(10)) { item ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.recordedAt)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${money(item.priceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}", fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

private fun recipeCountText(count: Int): String = if (count == 1) "1 receita" else "$count receitas"

private fun hasPackagingSupply(item: RecipeWithDetails, catalog: List<IngredientEntity>): Boolean {
    if (item.recipe.packagingPerUnitCents > 0L) return true
    val byId = catalog.associateBy { it.id }
    return item.ingredients.any { used ->
        val category = used.ingredientId?.let { byId[it]?.category }.orEmpty()
        val name = used.nameSnapshot.lowercase()
        category.contains("embal", ignoreCase = true) ||
            listOf("embal", "saquinho", "saco", "caixa", "adesivo", "etiqueta", "fecho", "lacre", "fitilho", "fita").any { name.contains(it) }
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    background: Color,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        modifier.heightIn(min = 72.dp),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = background),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun ResultRow(label: String, value: String, strong: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.size(8.dp))
        Text(value, fontWeight = if (strong) FontWeight.Bold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

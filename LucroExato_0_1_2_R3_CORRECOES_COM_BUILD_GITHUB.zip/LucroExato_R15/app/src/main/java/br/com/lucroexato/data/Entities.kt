package br.com.lucroexato.data

import androidx.room.Embedded
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "ingredients")
data class IngredientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val packagePriceCents: Long,
    val packageQuantity: Double,
    val packageUnit: String,
    val referenceMinCentsPerBase: Long? = null,
    val referenceMaxCentsPerBase: Long? = null,
    val isBuiltIn: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "ingredient_prices",
    foreignKeys = [ForeignKey(
        entity = IngredientEntity::class,
        parentColumns = ["id"],
        childColumns = ["ingredientId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("ingredientId")]
)
data class IngredientPriceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ingredientId: Long,
    val priceCents: Long,
    val packageQuantity: Double,
    val packageUnit: String,
    val recordedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val yieldQuantity: Double,
    val yieldUnit: String = "un",
    @ColumnInfo(defaultValue = "''") val preparation: String = "",
    val lossPercent: Double = 0.0,
    val packagingPerUnitCents: Long = 0,
    val laborMinutes: Int = 0,
    val hourlyRateCents: Long = 0,
    val variableFeePercent: Double = 0.0,
    val fixedFeePerUnitCents: Long = 0,
    val pricingMode: String = "MARGIN",
    val targetPercent: Double = 50.0,
    @ColumnInfo(defaultValue = "'MANUAL'") val priceMode: String = "MANUAL",
    val salePricePerUnitCents: Long = 0,
    val costPerUnitCents: Long = 0,
    val totalCostCents: Long = 0,
    val isDraft: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "recipe_ingredients",
    foreignKeys = [ForeignKey(
        entity = RecipeEntity::class,
        parentColumns = ["id"],
        childColumns = ["recipeId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("recipeId"), Index("ingredientId"), Index("sourceRecipeId")]
)
data class RecipeIngredientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeId: Long,
    val ingredientId: Long? = null,
    val sourceRecipeId: Long? = null,
    val nameSnapshot: String,
    val quantityUsed: Double,
    val unit: String,
    val costCents: Long,
    val costExactCents: Double? = null
)

@Entity(
    tableName = "extra_costs",
    foreignKeys = [ForeignKey(
        entity = RecipeEntity::class,
        parentColumns = ["id"],
        childColumns = ["recipeId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("recipeId")]
)
data class ExtraCostEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeId: Long,
    val type: String,
    val description: String,
    val valueCents: Long,
    val application: String
)

data class RecipeWithDetails(
    @Embedded val recipe: RecipeEntity,
    @Relation(parentColumn = "id", entityColumn = "recipeId")
    val ingredients: List<RecipeIngredientEntity>,
    @Relation(parentColumn = "id", entityColumn = "recipeId")
    val extraCosts: List<ExtraCostEntity>
)

package br.com.lucroexato

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import br.com.lucroexato.ui.LucroExatoApp
import br.com.lucroexato.ui.theme.LucroExatoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LucroExatoTheme { LucroExatoApp() }
        }
    }
}

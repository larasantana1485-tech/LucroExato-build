package br.com.lucroexato.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        IngredientEntity::class,
        IngredientPriceEntity::class,
        RecipeEntity::class,
        RecipeIngredientEntity::class,
        ExtraCostEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun ingredientDao(): IngredientDao
    abstract fun recipeDao(): RecipeDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE recipes ADD COLUMN preparation TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Receitas antigas não guardavam se o preço era manual ou sugerido.
                // MANUAL é a migração mais conservadora: nunca muda sozinho um preço que o usuário já via.
                db.execSQL("ALTER TABLE recipes ADD COLUMN priceMode TEXT NOT NULL DEFAULT 'MANUAL'")
                db.execSQL("ALTER TABLE recipe_ingredients ADD COLUMN costExactCents REAL")
                db.execSQL("UPDATE recipe_ingredients SET costExactCents = CAST(costCents AS REAL) WHERE costExactCents IS NULL")
            }
        }

        fun create(context: Context): AppDatabase = Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "lucro_exato.db"
        ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build()
    }
}

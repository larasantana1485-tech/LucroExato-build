package br.com.lucroexato.data

import androidx.room.withTransaction
import br.com.lucroexato.domain.CostCalculator
import br.com.lucroexato.domain.DraftExtraCost
import br.com.lucroexato.domain.DraftIngredient
import br.com.lucroexato.domain.RecipeDraft
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToLong

class LucroRepository(private val db: AppDatabase) {
    private val ingredients = db.ingredientDao()
    private val recipes = db.recipeDao()

    fun observeIngredients(): Flow<List<IngredientEntity>> = ingredients.observeAll()
    fun observeRecipes(): Flow<List<RecipeWithDetails>> = recipes.observeAll()

    suspend fun ensureSeeded() {
        val existing = ingredients.getAll()
        existing.firstOrNull {
            it.name == "Chocolate fracionado" && it.isBuiltIn &&
                it.packagePriceCents == 3590L && it.packageQuantity == 1.0 && it.packageUnit == "kg"
        }?.let { old ->
            saveIngredient(old.copy(packagePriceCents = 7000, packageQuantity = 2.0, packageUnit = "kg"))
        }
        val existingNames = existing.map { it.name.lowercase() }.toSet()
        val missing = defaultIngredients().filter { it.name.lowercase() !in existingNames }
        if (missing.isNotEmpty()) ingredients.insertAll(missing)
    }

    suspend fun saveIngredient(item: IngredientEntity): Long = db.withTransaction {
        val previous = item.id.takeIf { it != 0L }?.let { ingredients.getById(it) }
        if (previous != null && previous.packageUnit != item.packageUnit) {
            val newKind = CostCalculator.convertToBase(1.0, item.packageUnit).first
            val incompatibleRecipes = recipes.getAll().filter { recipe ->
                recipe.ingredients.any { used ->
                    used.ingredientId == item.id && runCatching {
                        CostCalculator.convertToBase(1.0, used.unit).first != newKind
                    }.getOrDefault(true)
                }
            }
            require(incompatibleRecipes.isEmpty()) {
                val names = incompatibleRecipes.map { it.recipe.name }.distinct().take(2).joinToString()
                "Não é possível trocar a unidade para ${item.packageUnit}: este insumo já é usado com outra dimensão em $names. Ajuste essas receitas primeiro."
            }
        }
        val id = ingredients.upsert(item.copy(updatedAt = System.currentTimeMillis()))
        val realId = if (item.id == 0L) id else item.id
        val purchaseChanged = previous == null ||
            previous.packagePriceCents != item.packagePriceCents ||
            previous.packageQuantity != item.packageQuantity ||
            previous.packageUnit != item.packageUnit
        if (purchaseChanged) {
            ingredients.addPrice(
                IngredientPriceEntity(
                    ingredientId = realId,
                    priceCents = item.packagePriceCents,
                    packageQuantity = item.packageQuantity,
                    packageUnit = item.packageUnit
                )
            )
        }
        realId
    }

    suspend fun ingredient(id: Long): IngredientEntity? = ingredients.getById(id)
    suspend fun ingredientPriceHistory(id: Long): List<IngredientPriceEntity> = ingredients.priceHistory(id)
    suspend fun recipe(id: Long): RecipeWithDetails? = recipes.getById(id)

    suspend fun saveRecipe(draft: RecipeDraft, isDraft: Boolean = false, touchUpdatedAt: Boolean = true): Long = db.withTransaction {
        val result = draft.calculate()
        val now = System.currentTimeMillis()
        val old = draft.editingRecipeId?.let { recipes.getById(it)?.recipe }
        val entity = RecipeEntity(
            id = draft.editingRecipeId ?: 0,
            name = draft.name.trim(),
            category = draft.category,
            yieldQuantity = draft.yieldQuantity,
            yieldUnit = draft.yieldUnit,
            preparation = draft.preparation.trim(),
            lossPercent = draft.lossPercent,
            packagingPerUnitCents = draft.packagingPerUnitCents,
            laborMinutes = draft.laborMinutes,
            hourlyRateCents = draft.hourlyRateCents,
            variableFeePercent = draft.variableFeePercent,
            fixedFeePerUnitCents = draft.fixedFeePerUnitCents,
            pricingMode = draft.pricingMode,
            targetPercent = draft.targetPercent,
            priceMode = draft.priceMode,
            salePricePerUnitCents = result.salePriceCents,
            costPerUnitCents = result.costPerUnitCents,
            totalCostCents = result.totalCostCents,
            isDraft = isDraft,
            createdAt = old?.createdAt ?: now,
            updatedAt = if (touchUpdatedAt) now else old?.updatedAt ?: now
        )
        val recipeId = recipes.upsert(entity)
        val realId = draft.editingRecipeId ?: recipeId
        recipes.deleteIngredients(realId)
        recipes.deleteExtraCosts(realId)
        recipes.insertIngredients(draft.ingredients.map {
            RecipeIngredientEntity(
                recipeId = realId,
                ingredientId = it.ingredientId,
                sourceRecipeId = it.sourceRecipeId,
                nameSnapshot = it.name,
                quantityUsed = it.quantity,
                unit = it.unit,
                costCents = it.costCents,
                costExactCents = it.costExactCents
            )
        })
        recipes.insertExtraCosts(draft.extras.map {
            ExtraCostEntity(
                recipeId = realId,
                type = it.type,
                description = it.description,
                valueCents = it.valueCents,
                application = it.application
            )
        })
        realId
    }

    suspend fun deleteRecipe(id: Long) = recipes.delete(id)

    suspend fun resetToFactoryDefaults() {
        db.withTransaction {
            recipes.deleteAllIngredients()
            recipes.deleteAllExtraCosts()
            recipes.deleteAllRecipes()
            ingredients.deleteAllPrices()
            ingredients.deleteAll()
        }
        ensureSeeded()
    }

    suspend fun draftFromRecipe(id: Long): RecipeDraft? {
        val value = recipes.getById(id) ?: return null
        val base = RecipeDraft(
            editingRecipeId = value.recipe.id,
            name = value.recipe.name,
            category = value.recipe.category,
            yieldQuantity = value.recipe.yieldQuantity,
            yieldUnit = value.recipe.yieldUnit,
            preparation = value.recipe.preparation,
            lossPercent = value.recipe.lossPercent,
            ingredients = value.ingredients.map {
                DraftIngredient(it.ingredientId, it.sourceRecipeId, it.nameSnapshot, it.quantityUsed, it.unit, it.costCents, it.costExactCents)
            },
            packagingPerUnitCents = value.recipe.packagingPerUnitCents,
            laborMinutes = value.recipe.laborMinutes,
            hourlyRateCents = value.recipe.hourlyRateCents,
            extras = value.extraCosts.map { DraftExtraCost(it.type, it.description, it.valueCents, it.application) },
            variableFeePercent = value.recipe.variableFeePercent,
            fixedFeePerUnitCents = value.recipe.fixedFeePerUnitCents,
            pricingMode = value.recipe.pricingMode,
            targetPercent = value.recipe.targetPercent,
            priceMode = value.recipe.priceMode,
            chosenSalePriceCents = if (value.recipe.priceMode == "MANUAL") value.recipe.salePricePerUnitCents else null,
            step = 1
        )
        return base
    }

    /**
     * Recalcula todas as receitas respeitando dependências de sub-receitas.
     * Assim uma alteração no preço de um insumo aparece também nos cards da Home,
     * sem exigir abrir cada receita manualmente.
     */
    suspend fun recalculateAllRecipes() = db.withTransaction {
        // Um único transaction evita que a Home observe estados intermediários
        // enquanto várias receitas são recalculadas na inicialização.
        val ids = recipes.getAll().map { it.recipe.id }
        val done = mutableSetOf<Long>()
        val visiting = mutableSetOf<Long>()

        suspend fun visit(id: Long) {
            if (id in done) return
            // Proteção também para dados antigos que eventualmente contenham ciclo.
            if (!visiting.add(id)) return
            val value = recipes.getById(id)
            value?.ingredients
                ?.mapNotNull { it.sourceRecipeId }
                ?.distinct()
                ?.forEach { visit(it) }
            visiting.remove(id)
            recalculateRecipe(id)
            done.add(id)
        }

        ids.forEach { visit(it) }
    }

    suspend fun dependentRecipeNames(sourceRecipeId: Long): List<String> =
        recipes.getAll()
            .filter { value -> value.ingredients.any { it.sourceRecipeId == sourceRecipeId } }
            .map { it.recipe.name }

    suspend fun recalculateRecipe(id: Long) {
        val draft = draftFromRecipe(id) ?: return
        val refreshed = draft.ingredients.map { item ->
            when {
                item.ingredientId != null -> {
                    val ingredient = ingredients.getById(item.ingredientId) ?: return@map item
                    val exact = CostCalculator.ingredientCostExactCents(
                        ingredient.packagePriceCents,
                        ingredient.packageQuantity,
                        ingredient.packageUnit,
                        item.quantity,
                        item.unit
                    )
                    item.copy(name = ingredient.name, costCents = exact.roundToLong(), costExactCents = exact)
                }
                item.sourceRecipeId != null -> {
                    val source = recipes.getById(item.sourceRecipeId)?.recipe ?: return@map item
                    val sourceSellableYield = source.yieldQuantity * (1.0 - source.lossPercent / 100.0)
                    if (sourceSellableYield <= 0.0) return@map item
                    val exactUnitCostCents = source.totalCostCents.toDouble() / sourceSellableYield
                    val exact = exactUnitCostCents * item.quantity
                    item.copy(name = "Sub-receita: ${source.name}", costCents = exact.roundToLong(), costExactCents = exact)
                }
                else -> item
            }
        }
        saveRecipe(draft.copy(ingredients = refreshed), touchUpdatedAt = false)
    }

    suspend fun createExampleRecipe(): Long {
        val catalog = ingredients.getAll()
        val chocolate = catalog.first { it.name == "Chocolate fracionado" }
        val condensed = catalog.first { it.name == "Leite condensado" }
        val cream = catalog.first { it.name == "Creme de leite" }
        val cocoa = catalog.first { it.name == "Cacau em pó 32%" }
        val label = catalog.first { it.name == "Etiqueta adesiva" }
        val used = listOf(
            DraftIngredient(
                ingredientId = chocolate.id,
                name = chocolate.name,
                quantity = 700.0,
                unit = "g",
                costCents = CostCalculator.ingredientCostCents(chocolate.packagePriceCents, chocolate.packageQuantity, chocolate.packageUnit, 700.0, "g"),
                costExactCents = CostCalculator.ingredientCostExactCents(chocolate.packagePriceCents, chocolate.packageQuantity, chocolate.packageUnit, 700.0, "g")
            ),
            DraftIngredient(
                ingredientId = condensed.id,
                name = condensed.name,
                quantity = 395.0,
                unit = "g",
                costCents = CostCalculator.ingredientCostCents(condensed.packagePriceCents, condensed.packageQuantity, condensed.packageUnit, 395.0, "g"),
                costExactCents = CostCalculator.ingredientCostExactCents(condensed.packagePriceCents, condensed.packageQuantity, condensed.packageUnit, 395.0, "g")
            ),
            DraftIngredient(
                ingredientId = cream.id,
                name = cream.name,
                quantity = 200.0,
                unit = "g",
                costCents = CostCalculator.ingredientCostCents(cream.packagePriceCents, cream.packageQuantity, cream.packageUnit, 200.0, "g"),
                costExactCents = CostCalculator.ingredientCostExactCents(cream.packagePriceCents, cream.packageQuantity, cream.packageUnit, 200.0, "g")
            ),
            DraftIngredient(
                ingredientId = cocoa.id,
                name = cocoa.name,
                quantity = 30.0,
                unit = "g",
                costCents = CostCalculator.ingredientCostCents(cocoa.packagePriceCents, cocoa.packageQuantity, cocoa.packageUnit, 30.0, "g"),
                costExactCents = CostCalculator.ingredientCostExactCents(cocoa.packagePriceCents, cocoa.packageQuantity, cocoa.packageUnit, 30.0, "g")
            ),
            DraftIngredient(
                ingredientId = label.id,
                name = label.name,
                quantity = 24.0,
                unit = "un",
                costCents = CostCalculator.ingredientCostCents(label.packagePriceCents, label.packageQuantity, label.packageUnit, 24.0, "un"),
                costExactCents = CostCalculator.ingredientCostExactCents(label.packagePriceCents, label.packageQuantity, label.packageUnit, 24.0, "un")
            )
        )
        return saveRecipe(
            RecipeDraft(
                name = "Pão de Mel Santana (parcial)",
                category = "Doces",
                yieldQuantity = 24.0,
                ingredients = used,
                packagingPerUnitCents = 0,
                laborMinutes = 55,
                hourlyRateCents = 0,
                targetPercent = 50.0,
                priceMode = "MANUAL",
                chosenSalePriceCents = 900
            )
        )
    }

    suspend fun exportJson(): String {
        val ingredientList = ingredients.getAll()
        val prices = ingredients.allPrices()
        val recipeList = recipes.getAll()
        return JSONObject().apply {
            put("format", "LUCRO_EXATO_BACKUP_V1")
            put("createdAt", System.currentTimeMillis())
            put("ingredients", JSONArray().apply { ingredientList.forEach { put(it.toJson()) } })
            put("ingredientPrices", JSONArray().apply { prices.forEach { put(it.toJson()) } })
            put("recipes", JSONArray().apply { recipeList.forEach { put(it.toJson()) } })
        }.toString(2)
    }

    suspend fun importJson(raw: String) {
        db.withTransaction {
            val root = JSONObject(raw)
            require(root.optString("format") == "LUCRO_EXATO_BACKUP_V1") { "Arquivo de backup incompatível." }
            val restoredIngredients = root.getJSONArray("ingredients").mapObjects { it.ingredientFromJson() }
            val restoredPrices = root.optJSONArray("ingredientPrices")?.mapObjects { it.priceFromJson() }.orEmpty()
            val restoredRecipes = root.getJSONArray("recipes").mapObjects { it.recipeBundleFromJson() }

            recipes.deleteAllIngredients()
            recipes.deleteAllExtraCosts()
            recipes.deleteAllRecipes()
            ingredients.deleteAllPrices()
            ingredients.deleteAll()
            ingredients.insertAll(restoredIngredients)
            ingredients.insertPrices(restoredPrices)
            restoredRecipes.forEach { bundle ->
                recipes.upsert(bundle.recipe)
                recipes.insertIngredients(bundle.ingredients)
                recipes.insertExtraCosts(bundle.extraCosts)
            }
            // Backups antigos podem conter totais calculados por regras anteriores.
            // Recalcular ainda dentro da transação faz a restauração inteira voltar atrás se houver dado incompatível.
            recalculateAllRecipes()
        }
    }

    private fun defaultIngredients() = listOf(
        seed("Chocolate fracionado", "Chocolates e coberturas", 7000, 2.0, "kg", 3200, 4500),
        seed("Chocolate ao leite", "Chocolates e coberturas", 4500, 1.0, "kg"),
        seed("Chocolate meio amargo", "Chocolates e coberturas", 4800, 1.0, "kg"),
        seed("Chocolate branco", "Chocolates e coberturas", 4700, 1.0, "kg"),
        seed("Cobertura sabor chocolate", "Chocolates e coberturas", 3200, 1.0, "kg"),
        seed("Cacau em pó 32%", "Chocolates e coberturas", 4200, 1.0, "kg"),
        seed("Cacau em pó 50%", "Chocolates e coberturas", 5200, 1.0, "kg"),
        seed("Cacau em pó 100%", "Chocolates e coberturas", 6800, 1.0, "kg"),
        seed("Chocolate em pó 50%", "Chocolates e coberturas", 3500, 1.0, "kg"),
        seed("Granulado de chocolate", "Chocolates e coberturas", 1800, 500.0, "g"),
        seed("Farinha de trigo", "Farinhas e amidos", 490, 1.0, "kg"),
        seed("Farinha de arroz", "Farinhas e amidos", 980, 1.0, "kg"),
        seed("Farinha de aveia", "Farinhas e amidos", 950, 1.0, "kg"),
        seed("Farinha de amêndoas", "Farinhas e amidos", 4200, 500.0, "g"),
        seed("Amido de milho", "Farinhas e amidos", 600, 1.0, "kg"),
        seed("Polvilho doce", "Farinhas e amidos", 850, 1.0, "kg"),
        seed("Polvilho azedo", "Farinhas e amidos", 900, 1.0, "kg"),
        seed("Fécula de batata", "Farinhas e amidos", 1200, 500.0, "g"),
        seed("Açúcar refinado", "Açúcares e adoçantes", 450, 1.0, "kg"),
        seed("Açúcar cristal", "Açúcares e adoçantes", 430, 1.0, "kg"),
        seed("Açúcar mascavo", "Açúcares e adoçantes", 780, 1.0, "kg"),
        seed("Açúcar de confeiteiro", "Açúcares e adoçantes", 980, 500.0, "g"),
        seed("Açúcar impalpável", "Açúcares e adoçantes", 1150, 500.0, "g"),
        seed("Mel", "Açúcares e adoçantes", 2400, 1.0, "kg"),
        seed("Glucose de milho", "Açúcares e adoçantes", 1450, 500.0, "g"),
        seed("Leite condensado", "Leites e derivados", 649, 395.0, "g"),
        seed("Creme de leite", "Leites e derivados", 399, 200.0, "g"),
        seed("Leite integral", "Leites e derivados", 550, 1.0, "l"),
        seed("Leite em pó integral", "Leites e derivados", 2200, 400.0, "g"),
        seed("Leite de coco", "Leites e derivados", 650, 200.0, "ml"),
        seed("Cream cheese", "Leites e derivados", 1450, 300.0, "g"),
        seed("Doce de leite", "Leites e derivados", 1450, 400.0, "g"),
        seed("Queijo parmesão", "Leites e derivados", 1800, 200.0, "g"),
        seed("Manteiga", "Gorduras e óleos", 1290, 500.0, "g"),
        seed("Margarina", "Gorduras e óleos", 850, 500.0, "g"),
        seed("Óleo de soja", "Gorduras e óleos", 850, 900.0, "ml"),
        seed("Óleo de coco", "Gorduras e óleos", 2600, 500.0, "ml"),
        seed("Gordura vegetal", "Gorduras e óleos", 1500, 500.0, "g"),
        seed("Ovos", "Ovos e derivados", 1200, 12.0, "un"),
        seed("Claras pasteurizadas", "Ovos e derivados", 1800, 1.0, "kg"),
        seed("Gemas pasteurizadas", "Ovos e derivados", 2200, 1.0, "kg"),
        seed("Morango", "Frutas e derivados", 1500, 1.0, "kg"),
        seed("Banana", "Frutas e derivados", 700, 1.0, "kg"),
        seed("Limão", "Frutas e derivados", 800, 1.0, "kg"),
        seed("Maracujá", "Frutas e derivados", 1400, 1.0, "kg"),
        seed("Geleia de frutas", "Frutas e derivados", 1600, 320.0, "g"),
        seed("Uva-passa", "Frutas e derivados", 1400, 500.0, "g"),
        seed("Amendoim", "Castanhas e sementes", 1200, 1.0, "kg"),
        seed("Castanha-de-caju", "Castanhas e sementes", 4800, 1.0, "kg"),
        seed("Nozes", "Castanhas e sementes", 5200, 1.0, "kg"),
        seed("Amêndoas", "Castanhas e sementes", 5500, 1.0, "kg"),
        seed("Pistache", "Castanhas e sementes", 12000, 1.0, "kg"),
        seed("Gergelim", "Castanhas e sementes", 1200, 500.0, "g"),
        seed("Coco ralado", "Coco", 1200, 500.0, "g"),
        seed("Coco em flocos", "Coco", 1500, 500.0, "g"),
        seed("Pasta de amendoim", "Recheios e pastas", 1800, 500.0, "g"),
        seed("Creme de avelã", "Recheios e pastas", 3200, 350.0, "g"),
        seed("Goiabada", "Recheios e pastas", 1200, 500.0, "g"),
        seed("Baunilha (extrato)", "Aromas, extratos e bebidas", 4500, 100.0, "ml"),
        seed("Essência de baunilha", "Aromas, extratos e bebidas", 650, 30.0, "ml"),
        seed("Rum", "Aromas, extratos e bebidas", 3500, 1.0, "l"),
        seed("Café solúvel", "Aromas, extratos e bebidas", 1700, 100.0, "g"),
        seed("Canela em pó", "Aromas, extratos e bebidas", 850, 100.0, "g"),
        seed("Cravo em pó", "Aromas, extratos e bebidas", 750, 50.0, "g"),
        seed("Corante em gel", "Corantes e aditivos", 850, 25.0, "g"),
        seed("Fermento químico", "Corantes e aditivos", 650, 100.0, "g"),
        seed("Fermento biológico seco", "Corantes e aditivos", 220, 10.0, "g"),
        seed("Bicarbonato de sódio", "Corantes e aditivos", 550, 100.0, "g"),
        seed("Emulsificante", "Corantes e aditivos", 1300, 200.0, "g"),
        seed("Gelatina incolor", "Corantes e aditivos", 550, 24.0, "g"),
        seed("Agar-agar", "Corantes e aditivos", 1800, 100.0, "g"),
        seed("Caixa individual", "Embalagens", 4500, 100.0, "un"),
        seed("Forminha de papel", "Embalagens", 1200, 100.0, "un"),
        seed("Saco para confeitar", "Embalagens", 1800, 100.0, "un"),
        seed("Papel manteiga (rolo)", "Embalagens", 1200, 1.0, "un"),
        seed("Etiqueta adesiva", "Embalagens", 2000, 100.0, "un"),
        seed("Palito de pirulito", "Embalagens", 900, 100.0, "un")
    )

    private fun seed(
        name: String,
        category: String,
        priceCents: Long,
        quantity: Double,
        unit: String,
        referenceMin: Long? = null,
        referenceMax: Long? = null
    ) = IngredientEntity(
        name = name,
        category = category,
        packagePriceCents = priceCents,
        packageQuantity = quantity,
        packageUnit = unit,
        referenceMinCentsPerBase = referenceMin,
        referenceMaxCentsPerBase = referenceMax,
        isBuiltIn = true
    )
}

private fun IngredientEntity.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("category", category); put("packagePriceCents", packagePriceCents)
    put("packageQuantity", packageQuantity); put("packageUnit", packageUnit); put("referenceMin", referenceMinCentsPerBase)
    put("referenceMax", referenceMaxCentsPerBase); put("isBuiltIn", isBuiltIn); put("updatedAt", updatedAt)
}

private fun JSONObject.ingredientFromJson() = IngredientEntity(
    id = getLong("id"), name = getString("name"), category = getString("category"),
    packagePriceCents = getLong("packagePriceCents"), packageQuantity = getDouble("packageQuantity"),
    packageUnit = getString("packageUnit"), referenceMinCentsPerBase = optNullableLong("referenceMin"),
    referenceMaxCentsPerBase = optNullableLong("referenceMax"), isBuiltIn = optBoolean("isBuiltIn"),
    updatedAt = optLong("updatedAt", System.currentTimeMillis())
)

private fun IngredientPriceEntity.toJson() = JSONObject().apply {
    put("id", id); put("ingredientId", ingredientId); put("priceCents", priceCents)
    put("packageQuantity", packageQuantity); put("packageUnit", packageUnit); put("recordedAt", recordedAt)
}

private fun JSONObject.priceFromJson() = IngredientPriceEntity(
    id = getLong("id"), ingredientId = getLong("ingredientId"), priceCents = getLong("priceCents"),
    packageQuantity = getDouble("packageQuantity"), packageUnit = getString("packageUnit"), recordedAt = getLong("recordedAt")
)

private fun RecipeWithDetails.toJson() = JSONObject().apply {
    put("recipe", recipe.toJson())
    put("ingredients", JSONArray().apply { ingredients.forEach { put(it.toJson()) } })
    put("extraCosts", JSONArray().apply { extraCosts.forEach { put(it.toJson()) } })
}

private fun RecipeEntity.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("category", category); put("yieldQuantity", yieldQuantity); put("yieldUnit", yieldUnit); put("preparation", preparation)
    put("lossPercent", lossPercent); put("packagingPerUnitCents", packagingPerUnitCents); put("laborMinutes", laborMinutes)
    put("hourlyRateCents", hourlyRateCents); put("variableFeePercent", variableFeePercent); put("fixedFeePerUnitCents", fixedFeePerUnitCents)
    put("pricingMode", pricingMode); put("targetPercent", targetPercent); put("priceMode", priceMode); put("salePricePerUnitCents", salePricePerUnitCents)
    put("costPerUnitCents", costPerUnitCents); put("totalCostCents", totalCostCents); put("isDraft", isDraft)
    put("createdAt", createdAt); put("updatedAt", updatedAt)
}

private fun JSONObject.recipeFromJson() = RecipeEntity(
    id = getLong("id"), name = getString("name"), category = getString("category"), yieldQuantity = getDouble("yieldQuantity"),
    yieldUnit = optString("yieldUnit", "un"), preparation = optString("preparation", ""), lossPercent = getDouble("lossPercent"), packagingPerUnitCents = getLong("packagingPerUnitCents"),
    laborMinutes = getInt("laborMinutes"), hourlyRateCents = getLong("hourlyRateCents"), variableFeePercent = getDouble("variableFeePercent"),
    fixedFeePerUnitCents = getLong("fixedFeePerUnitCents"), pricingMode = getString("pricingMode"), targetPercent = getDouble("targetPercent"),
    priceMode = optString("priceMode", "MANUAL"), salePricePerUnitCents = getLong("salePricePerUnitCents"), costPerUnitCents = getLong("costPerUnitCents"), totalCostCents = getLong("totalCostCents"),
    isDraft = optBoolean("isDraft"), createdAt = getLong("createdAt"), updatedAt = getLong("updatedAt")
)

private fun RecipeIngredientEntity.toJson() = JSONObject().apply {
    put("id", id); put("recipeId", recipeId); put("ingredientId", ingredientId); put("sourceRecipeId", sourceRecipeId)
    put("nameSnapshot", nameSnapshot); put("quantityUsed", quantityUsed); put("unit", unit); put("costCents", costCents); put("costExactCents", costExactCents)
}

private fun JSONObject.recipeIngredientFromJson() = RecipeIngredientEntity(
    id = getLong("id"), recipeId = getLong("recipeId"), ingredientId = optNullableLong("ingredientId"), sourceRecipeId = optNullableLong("sourceRecipeId"),
    nameSnapshot = getString("nameSnapshot"), quantityUsed = getDouble("quantityUsed"), unit = getString("unit"), costCents = getLong("costCents"),
    costExactCents = if (!has("costExactCents") || isNull("costExactCents")) null else getDouble("costExactCents")
)

private fun ExtraCostEntity.toJson() = JSONObject().apply {
    put("id", id); put("recipeId", recipeId); put("type", type); put("description", description); put("valueCents", valueCents); put("application", application)
}

private fun JSONObject.extraCostFromJson() = ExtraCostEntity(
    id = getLong("id"), recipeId = getLong("recipeId"), type = getString("type"), description = getString("description"),
    valueCents = getLong("valueCents"), application = getString("application")
)

private data class RecipeBundle(val recipe: RecipeEntity, val ingredients: List<RecipeIngredientEntity>, val extraCosts: List<ExtraCostEntity>)
private fun JSONObject.recipeBundleFromJson() = RecipeBundle(
    recipe = getJSONObject("recipe").recipeFromJson(),
    ingredients = getJSONArray("ingredients").mapObjects { it.recipeIngredientFromJson() },
    extraCosts = getJSONArray("extraCosts").mapObjects { it.extraCostFromJson() }
)

private fun JSONObject.optNullableLong(key: String): Long? = if (!has(key) || isNull(key)) null else getLong(key)
private fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> = (0 until length()).map { transform(getJSONObject(it)) }

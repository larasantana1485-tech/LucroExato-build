package br.com.lucroexato.domain

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.ceil
import kotlin.math.roundToLong

data class IngredientCostInput(val name: String, val costExactCents: Double) {
    constructor(name: String, costCents: Long) : this(name, costCents.toDouble())
}
data class ExtraCostInput(val valueCents: Long, val perUnit: Boolean)

data class CostInput(
    val yieldQuantity: Double,
    val lossPercent: Double,
    val ingredients: List<IngredientCostInput>,
    val packagingPerUnitCents: Long,
    val laborMinutes: Int,
    val hourlyRateCents: Long,
    val extras: List<ExtraCostInput>,
    val variableFeePercent: Double,
    val fixedFeePerUnitCents: Long,
    val pricingMode: String,
    val targetPercent: Double,
    val chosenSalePriceCents: Long? = null
)

data class CostResult(
    val sellableYield: Double,
    val ingredientsCents: Long,
    val packagingCents: Long,
    val laborCents: Long,
    val extrasCents: Long,
    val totalCostCents: Long,
    val costPerUnitExactCents: Double,
    val costPerUnitCents: Long,
    val suggestedPriceExactCents: Double,
    val suggestedPriceCents: Long,
    val suggestedRecipePriceCents: Long,
    val salePriceCents: Long,
    val feeExactCents: Double,
    val feeCents: Long,
    val profitPerUnitExactCents: Double,
    val profitPerUnitCents: Long,
    val marginPercent: Double,
    val markupPercent: Double
)

object CostCalculator {
    private fun addMoney(a: Long, b: Long): Long = try {
        Math.addExact(a, b)
    } catch (_: ArithmeticException) {
        throw IllegalArgumentException("Os custos informados são altos demais para calcular com segurança.")
    }

    fun convertToBase(quantity: Double, unit: String): Pair<String, Double> {
        require(quantity.isFinite()) { "A quantidade precisa ser um número válido." }
        return when (unit.lowercase()) {
            "kg" -> "mass" to quantity * 1000.0
            "g" -> "mass" to quantity
            "mg" -> "mass" to quantity / 1000.0
            "l" -> "volume" to quantity * 1000.0
            "ml" -> "volume" to quantity
            "un", "unidade", "unidades" -> "unit" to quantity
            else -> error("Unidade não reconhecida: $unit")
        }
    }

    fun ingredientCostExactCents(
        packagePriceCents: Long,
        packageQuantity: Double,
        packageUnit: String,
        usedQuantity: Double,
        usedUnit: String
    ): Double {
        require(packagePriceCents >= 0) { "O preço de compra não pode ser negativo." }
        require(packageQuantity.isFinite() && packageQuantity > 0) { "A quantidade comprada precisa ser maior que zero." }
        require(usedQuantity.isFinite() && usedQuantity >= 0) { "A quantidade usada não pode ser negativa." }
        val (packageKind, packageBase) = convertToBase(packageQuantity, packageUnit)
        val (usedKind, usedBase) = convertToBase(usedQuantity, usedUnit)
        require(packageKind == usedKind) { "As unidades da compra e do uso não são compatíveis." }
        val exact = BigDecimal.valueOf(packagePriceCents)
            .multiply(BigDecimal.valueOf(usedBase))
            .divide(BigDecimal.valueOf(packageBase), 12, RoundingMode.HALF_UP)
        return exact.toDouble()
    }

    fun ingredientCostCents(
        packagePriceCents: Long,
        packageQuantity: Double,
        packageUnit: String,
        usedQuantity: Double,
        usedUnit: String
    ): Long = ingredientCostExactCents(
        packagePriceCents, packageQuantity, packageUnit, usedQuantity, usedUnit
    ).roundToLong()

    fun calculate(input: CostInput): CostResult {
        require(input.yieldQuantity.isFinite() && input.yieldQuantity > 0) { "O rendimento precisa ser maior que zero." }
        require(input.lossPercent.isFinite() && input.lossPercent in 0.0..99.99) { "A perda precisa ficar entre 0% e 99,99%." }
        require(input.packagingPerUnitCents >= 0) { "O custo de embalagem não pode ser negativo." }
        require(input.laborMinutes >= 0) { "O tempo de trabalho não pode ser negativo." }
        require(input.hourlyRateCents >= 0) { "O valor da hora não pode ser negativo." }
        require(input.variableFeePercent.isFinite() && input.variableFeePercent in 0.0..99.99) { "A taxa percentual precisa ficar entre 0% e 99,99%." }
        require(input.fixedFeePerUnitCents >= 0) { "A taxa fixa não pode ser negativa." }
        require(input.targetPercent.isFinite() && input.targetPercent >= 0.0) { "O percentual desejado não pode ser negativo." }
        require(input.pricingMode == "MARGIN" || input.pricingMode == "MARKUP") { "Modo de precificação inválido." }
        require(input.ingredients.all { it.costExactCents.isFinite() && it.costExactCents >= 0.0 }) { "O custo dos insumos não pode ser negativo." }
        require(input.extras.all { it.valueCents >= 0 }) { "Outros custos não podem ser negativos." }
        require(input.chosenSalePriceCents == null || input.chosenSalePriceCents > 0) { "O preço de venda precisa ser maior que zero." }

        val sellableYield = input.yieldQuantity * (1.0 - input.lossPercent / 100.0)
        require(sellableYield.isFinite() && sellableYield > 0) { "O rendimento vendável precisa ser maior que zero." }

        // Cada componente monetário da receita inteira fecha em centavos. A divisão por unidade,
        // porém, mantém precisão completa até a última etapa. Assim R$ 66,59 / 24 não vira R$ 2,77
        // antes de calcular margem/preço.
        // Soma os insumos com precisão subcentavo e arredonda apenas UMA vez no total.
        // Isso evita perder pequenos custos ao arredondar cada linha separadamente.
        val ingredientsExact = input.ingredients.fold(BigDecimal.ZERO) { acc, item ->
            acc.add(BigDecimal.valueOf(item.costExactCents))
        }
        val ingredients = ingredientsExact.setScale(0, RoundingMode.HALF_UP).longValueExact()
        val packaging = (input.packagingPerUnitCents.toDouble() * sellableYield).roundToLong()
        val labor = (input.hourlyRateCents.toDouble() * (input.laborMinutes / 60.0)).roundToLong()
        val extras = input.extras.fold(0L) { acc, item ->
            val value = if (item.perUnit) (item.valueCents.toDouble() * sellableYield).roundToLong() else item.valueCents
            addMoney(acc, value)
        }
        val total = addMoney(addMoney(ingredients, packaging), addMoney(labor, extras))
        val unitCostExact = total.toDouble() / sellableYield
        val unitCost = unitCostExact.roundToLong()
        val target = input.targetPercent / 100.0
        val variableFee = input.variableFeePercent / 100.0

        val suggestedExact = if (input.pricingMode == "MARKUP") {
            // Markup mede acréscimo sobre o custo de produção. Taxas de venda afetam lucro/margem,
            // não o percentual de markup escolhido.
            unitCostExact * (1.0 + target)
        } else {
            require(target < 1.0) { "A margem desejada precisa ser menor que 100%." }
            val denominator = 1.0 - target - variableFee
            require(denominator > 0.0) { "Margem e taxa percentual somadas precisam ser menores que 100%." }
            (unitCostExact + input.fixedFeePerUnitCents) / denominator
        }
        require(suggestedExact.isFinite() && suggestedExact >= 0.0 && suggestedExact <= Long.MAX_VALUE.toDouble()) { "Não foi possível calcular um preço válido." }
        // Preço sugerido sobe para o próximo centavo quando necessário. Arredondar para o
        // centavo mais próximo poderia deixar a margem/markup real ligeiramente abaixo do alvo.
        val suggested = ceil(suggestedExact - 1e-9).toLong().coerceAtLeast(0)

        // O preço da receita deriva do preço unitário realmente praticável (centavos inteiros).
        // Assim “por unidade” e “por receita” sempre fecham entre si.
        val suggestedRecipeExact = suggested.toDouble() * sellableYield
        require(suggestedRecipeExact.isFinite() && suggestedRecipeExact <= Long.MAX_VALUE.toDouble()) { "O preço calculado ficou alto demais." }
        val suggestedRecipe = suggestedRecipeExact.roundToLong().coerceAtLeast(0)
        val salePrice = input.chosenSalePriceCents ?: suggested
        val feeExact = salePrice.toDouble() * variableFee + input.fixedFeePerUnitCents
        val fee = feeExact.roundToLong()
        val profitExact = salePrice.toDouble() - unitCostExact - feeExact
        val profit = profitExact.roundToLong()
        val margin = if (salePrice > 0) profitExact * 100.0 / salePrice else 0.0
        val markup = if (unitCostExact > 0.0) (salePrice.toDouble() / unitCostExact - 1.0) * 100.0 else 0.0

        return CostResult(
            sellableYield = sellableYield,
            ingredientsCents = ingredients,
            packagingCents = packaging,
            laborCents = labor,
            extrasCents = extras,
            totalCostCents = total,
            costPerUnitExactCents = unitCostExact,
            costPerUnitCents = unitCost,
            suggestedPriceExactCents = suggestedExact,
            suggestedPriceCents = suggested,
            suggestedRecipePriceCents = suggestedRecipe,
            salePriceCents = salePrice,
            feeExactCents = feeExact,
            feeCents = fee,
            profitPerUnitExactCents = profitExact,
            profitPerUnitCents = profit,
            marginPercent = margin,
            markupPercent = markup
        )
    }
}

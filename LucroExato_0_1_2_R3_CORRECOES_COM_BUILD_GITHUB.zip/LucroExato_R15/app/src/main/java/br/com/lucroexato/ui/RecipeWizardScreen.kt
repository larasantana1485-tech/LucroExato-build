package br.com.lucroexato.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.RecipeDraft
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Mint
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import br.com.lucroexato.ui.theme.PinkSoft
import br.com.lucroexato.ui.theme.YellowSoft
import kotlin.math.roundToLong

@Composable
fun RecipeWizardScreen(modifier: Modifier, vm: AppViewModel, onClose: () -> Unit, onSaved: (Long) -> Unit) {
    val draft by vm.draft.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    var askDiscard by remember { mutableStateOf(false) }

    fun requestClose() {
        if (draft.dirty) askDiscard = true else onClose()
    }
    val editingExisting = draft.editingRecipeId != null
    BackHandler {
        if (editingExisting) requestClose()
        else if (draft.step > 1) vm.previousStep()
        else requestClose()
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            Column {
                CompactTopBar(if (draft.editingRecipeId == null) "Nova receita" else "Editar receita") {
                    IconButton(onClick = ::requestClose) { Icon(Icons.Outlined.Close, "Fechar") }
                }
                StepIndicator(
                    current = draft.step,
                    labels = listOf("Dados", "Insumos", "Custos", "Resultado"),
                    onStepClick = if (editingExisting) ({ step -> vm.goToStep(step) }) else null
                )
                Spacer(Modifier.height(8.dp))
            }
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (editingExisting) {
                    OutlinedButton(
                        onClick = ::requestClose,
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = AppButtonShape
                    ) { Text("Fechar", maxLines = 1) }
                    Button(
                        onClick = { vm.saveRecipe(onSaved) },
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = AppButtonShape
                    ) { Text("Salvar alterações", maxLines = 1) }
                } else {
                    if (draft.step > 1) OutlinedButton(
                        onClick = { vm.previousStep() },
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = AppButtonShape
                    ) { Text("Voltar", maxLines = 1) }
                    Button(
                        onClick = { if (draft.step < 4) vm.nextStep() else vm.saveRecipe(onSaved) },
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = AppButtonShape
                    ) { Text(if (draft.step < 4) "Próximo" else "Salvar receita", maxLines = 1) }
                }
            }
        }
    ) { inner ->
        when (draft.step) {
            1 -> RecipeDataStep(Modifier.padding(inner).imePadding(), draft, vm)
            2 -> RecipeIngredientsStep(Modifier.padding(inner).imePadding(), draft, catalog, recipes, vm)
            3 -> RecipeCostsStep(Modifier.padding(inner).imePadding(), draft, vm)
            else -> RecipeResultStep(Modifier.padding(inner), draft, catalog, vm)
        }
    }

    if (askDiscard) AlertDialog(
        onDismissRequest = { askDiscard = false },
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text("Sair da receita?") },
        text = { Text("O rascunho já está salvo e aparecerá na tela inicial para você continuar depois.") },
        confirmButton = { TextButton(onClick = { askDiscard = false; onClose() }) { Text("Continuar depois") } },
        dismissButton = { TextButton(onClick = { vm.discardDraft(); askDiscard = false; onClose() }) { Text("Descartar") } }
    )
}

@Composable
private fun RecipeDataStep(modifier: Modifier, draft: RecipeDraft, vm: AppViewModel) {
    val categories = listOf("Bolos", "Doces", "Tortas", "Cookies", "Pães", "Salgados", "Sobremesas", "Bebidas", "Outros")
    var yieldText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.yieldQuantity == 0.0) "" else number(draft.yieldQuantity)) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Dados da receita", "O nome e o rendimento são obrigatórios.") }
        item {
            OutlinedTextField(
                draft.name,
                { value -> vm.updateDraft { it.copy(name = value) } },
                Modifier.fillMaxWidth(),
                shape = AppFieldShape,
                label = { Text("Nome da receita *", maxLines = 1) },
                placeholder = { Text("Ex.: Pão de Mel Tradicional", maxLines = 1) },
                singleLine = true
            )
        }
        item { Text("Categoria", fontWeight = FontWeight.SemiBold) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { item -> FilterChip(draft.category == item, { vm.updateDraft { it.copy(category = item) } }, label = { Text(item, maxLines = 1) }) } } }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                SmartNumberField(
                    value = yieldText,
                    onValueChange = { text -> yieldText = text; vm.updateDraft { it.copy(yieldQuantity = parseDecimal(text) ?: 0.0) } },
                    label = "Rendimento *",
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                SelectionField(
                    value = draft.yieldUnit,
                    options = listOf("un", "g", "kg", "ml", "l"),
                    label = "Unidade",
                    modifier = Modifier.weight(0.62f).fillMaxHeight()
                ) { value -> vm.updateDraft { it.copy(yieldUnit = value) } }
            }
        }
        item { Text("* obrigatório", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            InfoCard(tint = PinkSoft) {
                Text("Rascunho automático", fontWeight = FontWeight.SemiBold, color = Pink)
                Text("Se você sair, esta receita aparece na tela inicial para continuar depois.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun RecipeIngredientsStep(
    modifier: Modifier,
    draft: RecipeDraft,
    catalog: List<IngredientEntity>,
    recipes: List<RecipeWithDetails>,
    vm: AppViewModel
) {
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<IngredientEntity?>(null) }
    var selectedDraftIndex by remember { mutableStateOf<Int?>(null) }
    var category by remember { mutableStateOf("Todos") }
    var selectedSubRecipe by remember { mutableStateOf<RecipeWithDetails?>(null) }
    var selectedSubRecipeDraftIndex by remember { mutableStateOf<Int?>(null) }
    var showCatalogSheet by remember { mutableStateOf(false) }

    val categories = listOf("Todos", "Embalagens") +
        (SupplyCategories + catalog.map { it.category }).distinct().filterNot { it == "Embalagens" }
    val filtered = catalog.filter {
        (category == "Todos" || it.category == category) && it.name.contains(search, true)
    }
    val availableSubRecipes = recipes.filter {
        it.recipe.id != draft.editingRecipeId &&
            !wouldCreateSubRecipeCycle(draft.editingRecipeId, it.recipe.id, recipes) &&
            category == "Todos" &&
            (search.isBlank() || it.recipe.name.contains(search, ignoreCase = true))
    }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            SectionTitle(
                "Insumos da receita",
                "Adicione ingredientes, embalagens e consumíveis usados nesta produção."
            )
        }
        item {
            OutlinedButton(
                onClick = {
                    search = ""
                    category = "Todos"
                    showCatalogSheet = true
                },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = AppButtonShape
            ) {
                Icon(Icons.Outlined.Add, null)
                Spacer(Modifier.size(6.dp))
                Text("Adicionar insumos", maxLines = 1)
            }
        }

        if (draft.ingredients.isEmpty()) {
            item {
                Text(
                    "Nenhum insumo adicionado ainda.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            item {
                Text(
                    "Adicionados (${draft.ingredients.size})",
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(draft.ingredients.indices.toList()) { index ->
                val item = draft.ingredients[index]
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        when {
                            item.ingredientId != null -> catalog.firstOrNull { it.id == item.ingredientId }?.let {
                                selected = it
                                selectedDraftIndex = index
                            }
                            item.sourceRecipeId != null -> recipes.firstOrNull { it.recipe.id == item.sourceRecipeId }?.let {
                                selectedSubRecipe = it
                                selectedSubRecipeDraftIndex = index
                            }
                        }
                    },
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Outline),
                    elevation = CardDefaults.cardElevation(0.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.name,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "${number(item.quantity)} ${item.unit} • ${money(item.costCents)}",
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (item.ingredientId != null || item.sourceRecipeId != null) {
                            Icon(
                                Icons.Outlined.Edit,
                                "Editar",
                                tint = Pink,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(onClick = { vm.removeDraftIngredient(index) }, modifier = Modifier.size(44.dp)) {
                            Icon(Icons.Outlined.DeleteOutline, "Remover")
                        }
                    }
                }
            }
        }
    }

    if (showCatalogSheet) {
        Dialog(onDismissRequest = { showCatalogSheet = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(color = MaterialTheme.colorScheme.background) {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    topBar = { CompactTopBar("Adicionar insumos", onBack = { showCatalogSheet = false }) }
                ) { inner ->
                    Column(
                        Modifier.padding(inner).fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            shape = AppFieldShape,
                            leadingIcon = { Icon(Icons.Outlined.Search, null) },
                            placeholder = { Text("Buscar insumos...", maxLines = 1) },
                            singleLine = true
                        )

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(categories) { value ->
                                FilterChip(
                                    selected = category == value,
                                    onClick = { category = value },
                                    label = { Text(value, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    shape = androidx.compose.foundation.shape.RoundedCornerShape(13.dp)
                                )
                            }
                        }

                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 12.dp)
                        ) {
                            if (filtered.isEmpty() && availableSubRecipes.isEmpty()) {
                                item {
                                    Column(
                                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            if (search.isBlank()) "Nenhum insumo nesta categoria." else "Nenhum insumo encontrado para “${search.trim()}”.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (search.isNotBlank()) {
                                            OutlinedButton(
                                                onClick = {
                                                    val initialCategory = if (category == "Todos") "Outros" else category
                                                    selectedDraftIndex = null
                                                    selected = IngredientEntity(
                                                        name = search.trim(),
                                                        category = initialCategory,
                                                        packagePriceCents = 0,
                                                        packageQuantity = 1.0,
                                                        packageUnit = if (initialCategory == "Embalagens") "un" else "kg"
                                                    )
                                                    showCatalogSheet = false
                                                },
                                                modifier = Modifier.fillMaxWidth().height(44.dp),
                                                shape = AppButtonShape
                                            ) {
                                                Icon(Icons.Outlined.Add, null)
                                                Spacer(Modifier.size(6.dp))
                                                Text("Criar insumo", maxLines = 1)
                                            }
                                        }
                                    }
                                }
                            } else {
                                items(filtered, key = { it.id }) { item ->
                                    Card(
                                        Modifier.fillMaxWidth().clickable {
                                            selectedDraftIndex = null
                                            selected = item
                                            showCatalogSheet = false
                                        },
                                        shape = AppCardShape,
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, Outline),
                                        elevation = CardDefaults.cardElevation(0.dp)
                                    ) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(Modifier.weight(1f)) {
                                                Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(
                                                    "${item.category} • ${money(item.packagePriceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            Icon(Icons.Outlined.Add, "Adicionar", tint = Pink)
                                        }
                                    }
                                }

                                if (availableSubRecipes.isNotEmpty()) {
                                    item { Text("Sub-receitas", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp)) }
                                    items(availableSubRecipes, key = { "sub-${it.recipe.id}" }) { item ->
                                        OutlinedButton(
                                            onClick = {
                                                selectedSubRecipeDraftIndex = null
                                                selectedSubRecipe = item
                                                showCatalogSheet = false
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = AppButtonShape
                                        ) {
                                            Text(
                                                "${item.recipe.name} • ${money(item.recipe.costPerUnitCents)}/${item.recipe.yieldUnit}",
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    selected?.let { item ->
        val used = selectedDraftIndex?.let { draft.ingredients.getOrNull(it) }
        IngredientPurchaseScreen(
            item = item,
            initialUsedQuantity = used?.quantity,
            initialUsedUnit = used?.unit,
            editing = selectedDraftIndex != null,
            recipeYield = draft.yieldQuantity,
            onDismiss = { selected = null; selectedDraftIndex = null },
            onSave = { updated, price, packageQuantity, packageUnit, usedQuantity, usedUnit ->
                vm.saveAndUseIngredient(
                    ingredient = updated,
                    packagePriceCents = price,
                    packageQuantity = packageQuantity,
                    packageUnit = packageUnit,
                    usedQuantity = usedQuantity,
                    usedUnit = usedUnit,
                    draftIndex = selectedDraftIndex
                ) {
                    selected = null
                    selectedDraftIndex = null
                }
            }
        )
    }

    selectedSubRecipe?.let { item ->
        val editingIndex = selectedSubRecipeDraftIndex
        val existingQuantity = editingIndex?.let { draft.ingredients.getOrNull(it)?.quantity }
        SubRecipeQuantityDialog(
            item = item,
            initialQuantity = existingQuantity,
            editing = editingIndex != null,
            onDismiss = { selectedSubRecipe = null; selectedSubRecipeDraftIndex = null }
        ) { quantity ->
            val saved = if (editingIndex != null) vm.updateSubRecipe(editingIndex, item, quantity) else vm.addSubRecipe(item, quantity)
            if (saved) { selectedSubRecipe = null; selectedSubRecipeDraftIndex = null }
        }
    }
}

@Composable
private fun IngredientPurchaseScreen(
    item: IngredientEntity,
    initialUsedQuantity: Double?,
    initialUsedUnit: String?,
    editing: Boolean,
    recipeYield: Double,
    onDismiss: () -> Unit,
    onSave: (IngredientEntity, Long, Double, String, Double, String) -> Unit
) {
    var name by remember(item.id) { mutableStateOf(item.name) }
    var category by remember(item.id) { mutableStateOf(item.category) }
    var price by remember(item.id) { mutableStateOf(if (item.packagePriceCents > 0) moneyInput(item.packagePriceCents) else "") }
    var packageQuantity by remember(item.id) { mutableStateOf(if (item.packageQuantity > 0) number(item.packageQuantity) else "") }
    var packageUnit by remember(item.id) { mutableStateOf(item.packageUnit) }
    var usedQuantity by remember(item.id, initialUsedQuantity) { mutableStateOf(initialUsedQuantity?.let(::number) ?: "") }
    var usedUnit by remember(item.id, initialUsedUnit) { mutableStateOf(initialUsedUnit ?: defaultUsedUnit(item.packageUnit)) }
    var error by remember { mutableStateOf<String?>(null) }
    val priceCents = parseMoneyCents(price)
    val bought = parseDecimal(packageQuantity)
    val used = parseDecimal(usedQuantity)
    val preview = if (priceCents != null && bought != null && used != null && bought > 0 && used > 0) {
        runCatching { br.com.lucroexato.domain.CostCalculator.ingredientCostExactCents(priceCents, bought, packageUnit, used, usedUnit).roundToLong() }.getOrNull()
    } else null

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { CompactTopBar(if (editing) "Editar insumo" else "Adicionar insumo", onDismiss) },
                bottomBar = {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text("Cancelar") }
                        Button(onClick = {
                            error = when {
                                name.isBlank() -> "Informe o nome do insumo."
                                priceCents == null || priceCents <= 0 -> "Informe o preço pago."
                                bought == null || bought <= 0 -> "Informe a quantidade comprada."
                                used == null || used <= 0 -> "Informe a quantidade usada."
                                preview == null -> "As unidades da compra e do uso precisam ser compatíveis."
                                else -> null
                            }
                            if (error == null) onSave(item.copy(name = name.trim(), category = category.trim().ifBlank { "Outros" }), priceCents!!, bought!!, packageUnit, used!!, usedUnit)
                        }, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text(if (editing) "Salvar" else "Adicionar", maxLines = 1) }
                    }
                }
            ) { inner ->
                Column(
                    Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (item.id == 0L) {
                        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Nome do insumo *", maxLines = 1) }, singleLine = true)
                        SelectionField(category, SupplyCategories, "Categoria", Modifier.fillMaxWidth()) { selectedCategory ->
                            category = selectedCategory
                            if (selectedCategory == "Embalagens") {
                                packageUnit = "un"
                                usedUnit = "un"
                            }
                        }
                    } else {
                        Text(name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    SectionTitle("Compra", "Use o valor que você realmente pagou.")
                    SmartNumberField(price, { price = it }, "Preço pago *", Modifier.fillMaxWidth(), prefix = "R$ ")
                    Row(
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        SmartNumberField(packageQuantity, { packageQuantity = it }, "Qtd. comprada *", Modifier.weight(1f).fillMaxHeight())
                        SelectionField(packageUnit, listOf("kg", "g", "mg", "l", "ml", "un"), "Unidade", Modifier.weight(0.62f).fillMaxHeight()) { value ->
                            packageUnit = value
                            usedUnit = defaultUsedUnit(value)
                        }
                    }
                    val packagingLike = isPackagingLike(name, category)
                    SectionTitle(
                        "Uso nesta receita",
                        if (packagingLike)
                            "Informe o total usado para produzir todo o rendimento. Ex.: rende 24 e usa 1 por unidade → informe 24."
                        else
                            "Informe a quantidade total deste insumo usada na produção."
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        SmartNumberField(usedQuantity, { usedQuantity = it }, "Qtd. total usada *", Modifier.weight(1f).fillMaxHeight())
                        SelectionField(usedUnit, compatibleUnits(packageUnit), "Unidade", Modifier.weight(0.62f).fillMaxHeight()) { usedUnit = it }
                    }
                    if (packagingLike && recipeYield > 1.0 && used != null && kotlin.math.abs(used - 1.0) < 0.0001) {
                        InfoCard(tint = YellowSoft) {
                            Text("Confira a quantidade", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Esta receita rende ${number(recipeYield)} ${if (recipeYield == 1.0) "unidade" else "unidades"}. Se você usa 1 $name em cada unidade, o total usado é ${number(recipeYield)}.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            TextButton(onClick = { usedQuantity = number(recipeYield) }) {
                                Text("Usar ${number(recipeYield)} no total")
                            }
                        }
                    }
                    InfoCard(tint = if (preview == null) PinkSoft else Mint) {
                        ResultRow("Custo na receita", preview?.let(::money) ?: "Preencha os valores")
                        if (preview != null) Text("${money(priceCents!!)} ÷ ${number(bought!!)} $packageUnit × ${number(used!!)} $usedUnit", style = MaterialTheme.typography.bodySmall)
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}



private fun wouldCreateSubRecipeCycle(editingRecipeId: Long?, candidateId: Long, recipes: List<RecipeWithDetails>): Boolean {
    val target = editingRecipeId ?: return false
    val byId = recipes.associateBy { it.recipe.id }
    fun dependsOn(recipeId: Long, soughtId: Long, visited: MutableSet<Long>): Boolean {
        if (!visited.add(recipeId)) return false
        val recipe = byId[recipeId] ?: return false
        return recipe.ingredients.any { used ->
            val source = used.sourceRecipeId ?: return@any false
            source == soughtId || dependsOn(source, soughtId, visited)
        }
    }
    return candidateId == target || dependsOn(candidateId, target, mutableSetOf())
}

private fun isPackagingLike(name: String, category: String): Boolean {
    if (category.contains("embal", ignoreCase = true)) return true
    val normalized = name.lowercase()
    return listOf("embal", "saquinho", "saco", "caixa", "adesivo", "etiqueta", "fecho", "lacre", "fitilho", "fita").any { normalized.contains(it) }
}

private fun compatibleUnits(unit: String) = when (unit) {
    "kg", "g", "mg" -> listOf("kg", "g", "mg")
    "l", "ml" -> listOf("l", "ml")
    else -> listOf("un")
}

private fun defaultUsedUnit(unit: String) = when (unit) {
    "kg", "g", "mg" -> "g"
    "l", "ml" -> "ml"
    else -> "un"
}

@Composable
private fun SubRecipeQuantityDialog(
    item: RecipeWithDetails,
    initialQuantity: Double? = null,
    editing: Boolean = false,
    onDismiss: () -> Unit,
    onAdd: (Double) -> Unit
) {
    var quantity by remember(item.recipe.id, initialQuantity) { mutableStateOf(initialQuantity?.let(::number) ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text(if (editing) "Editar ${item.recipe.name}" else "Usar ${item.recipe.name}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = { SmartNumberField(quantity, { quantity = it }, "Quantidade em ${item.recipe.yieldUnit}", Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { parseDecimal(quantity)?.takeIf { it > 0 }?.let(onAdd) }) { Text(if (editing) "Salvar" else "Adicionar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun RecipeCostsStep(modifier: Modifier, draft: RecipeDraft, vm: AppViewModel) {
    var addExtra by remember { mutableStateOf(false) }
    var showCostHelp by remember { mutableStateOf(false) }
    var lossText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.lossPercent)) }
    var laborText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.laborMinutes == 0) "" else draft.laborMinutes.toString()) }
    var hourlyText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.hourlyRateCents == 0L) "" else moneyInput(draft.hourlyRateCents)) }
    var feeText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.variableFeePercent)) }
    var fixedFeeText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.fixedFeePerUnitCents == 0L) "" else moneyInput(draft.fixedFeePerUnitCents)) }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    SectionTitle("Rendimento e custos", "Preencha somente o que fizer parte da sua produção.")
                }
                TextButton(onClick = { showCostHelp = true }) {
                    Icon(Icons.Outlined.Info, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(4.dp))
                    Text("Como preencher custos", maxLines = 1)
                }
            }
        }
        item {
            SmartNumberField(
                lossText,
                { text ->
                    lossText = text
                    vm.updateDraft { it.copy(lossPercent = (parseDecimal(text) ?: 0.0).coerceIn(0.0, 99.99)) }
                },
                "Perda estimada (%)",
                Modifier.fillMaxWidth(),
                supportingText = "Ex.: itens quebrados ou que não podem ser vendidos.",
                helpText = "Informe a porcentagem da produção que não poderá ser vendida. Ex.: itens quebrados, queimados ou perdidos."
            )
        }
        item { SectionTitle("Mão de obra", "Informe quanto tempo você trabalha e quanto vale sua hora.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartNumberField(
                    laborText,
                    { text ->
                        laborText = text.filter(Char::isDigit)
                        vm.updateDraft { it.copy(laborMinutes = laborText.toIntOrNull() ?: 0) }
                    },
                    "Tempo (min)",
                    Modifier.weight(1f),
                    integerOnly = true
                )
                SmartNumberField(
                    hourlyText,
                    { text -> hourlyText = text; vm.updateDraft { it.copy(hourlyRateCents = parseMoneyCents(text) ?: 0) } },
                    "Valor/hora",
                    Modifier.weight(1f),
                    prefix = "R$ ",
                    helpText = "É quanto vale uma hora do seu trabalho. O app combina esse valor com o tempo informado para calcular a mão de obra da receita."
                )
            }
        }
        item { SectionTitle("Taxas de venda", "Deixe zero se você vende sem taxa.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartNumberField(
                    feeText,
                    { text -> feeText = text; vm.updateDraft { it.copy(variableFeePercent = parseDecimal(text) ?: 0.0) } },
                    "Taxa (%)",
                    Modifier.weight(1f)
                )
                SmartNumberField(
                    fixedFeeText,
                    { text -> fixedFeeText = text; vm.updateDraft { it.copy(fixedFeePerUnitCents = parseMoneyCents(text) ?: 0) } },
                    "Taxa fixa/un.",
                    Modifier.weight(1f),
                    prefix = "R$ ",
                    helpText = "Use quando existe um valor fixo cobrado em cada unidade vendida. Ex.: R$ 0,50 por unidade."
                )
            }
        }
        item {
            InfoCard {
                Text("Embalagens entram como insumo", fontWeight = FontWeight.SemiBold, color = Pink)
                Text(
                    "Cadastre saquinhos, caixas, etiquetas, fechos e outros consumíveis na etapa Insumos. Informe o total usado na receita.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        if (draft.packagingPerUnitCents > 0L) {
            item {
                InfoCard(tint = YellowSoft) {
                    Text("Custo antigo de embalagem detectado", fontWeight = FontWeight.SemiBold)
                    Text(
                        "Há ${money(draft.packagingPerUnitCents)} por unidade além dos insumos. Se você já cadastrou a embalagem como insumo, remova este valor para não contar duas vezes.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { vm.updateDraft { it.copy(packagingPerUnitCents = 0L) } }) { Text("Remover custo antigo") }
                }
            }
        }
        item { SectionTitle("Outros custos", "Gás, energia, transporte e outros valores informados por você.") }
        items(draft.extras.indices.toList()) { index ->
            val item = draft.extras[index]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Outline),
                shape = AppCardShape,
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.description, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${money(item.valueCents)} • ${if (item.application == "PER_UNIT") "por unidade" else "na receita inteira"}",
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1
                        )
                    }
                    IconButton(onClick = { vm.removeExtraCost(index) }) { Icon(Icons.Outlined.DeleteOutline, "Remover") }
                }
            }
        }
        item {
            OutlinedButton(onClick = { addExtra = true }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                Icon(Icons.Outlined.Add, null)
                Spacer(Modifier.size(6.dp))
                Text("Adicionar outro custo", maxLines = 1)
            }
        }
    }

    if (addExtra) {
        ExtraCostEditor(
            onDismiss = { addExtra = false },
            onAdd = { type, description, cents, perUnit ->
                vm.addExtraCost(type, description, cents, perUnit)
                addExtra = false
            }
        )
    }

    if (showCostHelp) {
        AlertDialog(
            onDismissRequest = { showCostHelp = false },
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            shape = AppCardShape,
            title = { Text("Como preencher custos") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Preencha apenas os custos que realmente fazem parte da sua produção.")
                    Text("• Perda: itens produzidos que não poderão ser vendidos.")
                    Text("• Mão de obra: tempo trabalhado × valor da sua hora.")
                    Text("• Taxas de venda: percentuais ou valores fixos cobrados na venda.")
                    Text("• Gás, energia e transporte: informe o valor que você quer considerar; o app não tenta adivinhar esse custo só pelo tempo.")
                }
            },
            confirmButton = { TextButton(onClick = { showCostHelp = false }) { Text("Entendi") } }
        )
    }
}

@Composable
private fun ExtraCostEditor(onDismiss: () -> Unit, onAdd: (String, String, Long, Boolean) -> Unit) {
    var type by remember { mutableStateOf("Energia/Gás") }
    var description by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var perUnit by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { CompactTopBar("Adicionar custo", onDismiss) },
                bottomBar = {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text("Cancelar") }
                        Button(
                            onClick = {
                                val cents = parseMoneyCents(value)
                                if (description.isNotBlank() && cents != null && cents >= 0) onAdd(type, description.trim(), cents, perUnit)
                            },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = AppButtonShape
                        ) { Text("Adicionar") }
                    }
                }
            ) { inner ->
                Column(
                    Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SectionTitle("Tipo de custo", "Escolha a categoria que melhor descreve o gasto.")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Energia/Gás", "Transporte", "Outros")) { item ->
                            FilterChip(
                                type == item,
                                { type = item },
                                label = { Text(item, maxLines = 1) },
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(13.dp)
                            )
                        }
                    }
                    OutlinedTextField(
                        description,
                        { description = it },
                        Modifier.fillMaxWidth(),
                        shape = AppFieldShape,
                        label = { Text("Descrição *", maxLines = 1) },
                        placeholder = { Text("Ex.: gás do forno", maxLines = 1) },
                        singleLine = true
                    )
                    SmartNumberField(value, { value = it }, "Valor *", Modifier.fillMaxWidth(), prefix = "R$ ")
                    SectionTitle("Aplicar o custo")
                    Surface(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp).clickable { perUnit = false },
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, Outline),
                        shape = AppCardShape
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(!perUnit, { perUnit = false })
                            Column(Modifier.weight(1f)) {
                                Text("Na receita inteira", maxLines = 1)
                                Text("Ex.: gás e energia do preparo", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Surface(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 60.dp).clickable { perUnit = true },
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, Outline),
                        shape = AppCardShape
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(perUnit, { perUnit = true })
                            Column(Modifier.weight(1f)) {
                                Text("Por unidade produzida", maxLines = 1)
                                Text("Use só quando o gasto acontece a cada unidade", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecipeResultStep(modifier: Modifier, draft: RecipeDraft, catalog: List<IngredientEntity>, vm: AppViewModel) {
    val referenceMargin = 50.0
    val costResult = runCatching {
        draft.copy(
            pricingMode = "MARKUP",
            targetPercent = 0.0,
            priceMode = "SUGGESTED",
            chosenSalePriceCents = null
        ).calculate()
    }.getOrNull()
    val referenceResult = runCatching {
        draft.copy(
            pricingMode = "MARGIN",
            targetPercent = referenceMargin,
            priceMode = "SUGGESTED",
            chosenSalePriceCents = null
        ).calculate()
    }.getOrNull()

    val hasPackaging = draft.packagingPerUnitCents > 0 || draft.ingredients.any { used ->
        val category = catalog.firstOrNull { it.id == used.ingredientId }?.category.orEmpty()
        isPackagingLike(used.name, category)
    }
    val missingCosts = buildList {
        if (!hasPackaging) add("embalagem")
        if (draft.laborMinutes == 0 || draft.hourlyRateCents == 0L) add("mão de obra")
    }

    val revenue = referenceResult?.let { (it.salePriceCents.toDouble() * it.sellableYield).roundToLong() }
    val profitTotal = referenceResult?.let { (it.profitPerUnitExactCents * it.sellableYield).roundToLong() }

    LazyColumn(
        modifier.fillMaxSize().imePadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item { SectionTitle("Preço e lucro", "Resultado calculado com os valores informados.") }

        if (missingCosts.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = YellowSoft,
                    border = BorderStroke(1.dp, Outline),
                    shape = AppCardShape
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "⚠ ${missingCosts.joinToString(" e ").replaceFirstChar { it.uppercase() }} não informada${if (missingCosts.size > 1) "s" else ""} · resultado pode estar incompleto",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2
                        )
                        TextButton(onClick = { vm.goToStep(3) }) { Text("Revisar") }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Outline),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Resumo da receita", fontWeight = FontWeight.Bold)
                    ResultRow("Custo total", costResult?.totalCostCents?.let(::money) ?: "—", true)
                    ResultRow("Rendimento", costResult?.sellableYield?.let { "${number(it)} ${draft.yieldUnit}" } ?: "—")
                    ResultRow("Custo por unidade", costResult?.costPerUnitCents?.let(::money) ?: "—", true)
                }
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = AppCardShape,
                color = PinkSoft.copy(alpha = 0.36f),
                border = BorderStroke(1.dp, PinkSoft)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Preço inicial sugerido", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "Margem de referência: ${number(referenceMargin, 0)}%",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            HelpTip("É apenas um ponto de partida. Depois de salvar, você pode ajustar preço, margem e markup na Ficha Técnica da Receita.")
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            referenceResult?.salePriceCents?.let(::money) ?: "—",
                            color = Pink,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            maxLines = 1
                        )
                        Text("por unidade", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Outline),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Estimativa de venda", fontWeight = FontWeight.Bold)
                    ResultRow("Faturamento estimado", revenue?.let(::money) ?: "—", true)
                    ResultRow("Lucro estimado", profitTotal?.let(::money) ?: "—", true)
                    ResultRow("Lucro por unidade", referenceResult?.profitPerUnitCents?.let(::money) ?: "—", true)
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 2.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Outlined.Info, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                Text(
                    "Depois de salvar, ajuste preço, margem e markup na Ficha Técnica.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WizardMoneyRow(label: String, value: String, strong: Boolean = false) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = if (strong) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
    }
}

private data class WizardCompositionSegment(val label: String, val centsPerUnit: Double, val color: Color)

private fun wizardCompositionSegments(
    draft: RecipeDraft,
    catalog: List<IngredientEntity>,
    result: br.com.lucroexato.domain.CostResult
): List<WizardCompositionSegment> {
    val byId = catalog.associateBy { it.id }
    val packagingSupplyCents = draft.ingredients.filter { used ->
        isPackagingLike(used.name, used.ingredientId?.let { byId[it]?.category }.orEmpty())
    }.sumOf { it.costExactCents ?: it.costCents.toDouble() }
    val regularIngredientCents = (result.ingredientsCents.toDouble() - packagingSupplyCents).coerceAtLeast(0.0)
    val y = result.sellableYield.coerceAtLeast(0.000001)
    return listOf(
        WizardCompositionSegment("Ingredientes", regularIngredientCents / y, Color(0xFFE86B72)),
        WizardCompositionSegment("Embalagem", (packagingSupplyCents + result.packagingCents.toDouble()) / y, Color(0xFF8E7CC3)),
        WizardCompositionSegment("Mão de obra", result.laborCents.toDouble() / y, Color(0xFFF4A261)),
        WizardCompositionSegment("Outros", result.extrasCents.toDouble() / y, Color(0xFF7AA6E8)),
        WizardCompositionSegment("Taxas", result.feeExactCents.coerceAtLeast(0.0), Color(0xFF5A7DDE)),
        WizardCompositionSegment("Lucro", result.profitPerUnitExactCents.coerceAtLeast(0.0), Green)
    ).filter { it.centsPerUnit > 0.004 }
}

@Composable
private fun WizardCompositionCard(
    draft: RecipeDraft,
    catalog: List<IngredientEntity>,
    result: br.com.lucroexato.domain.CostResult,
    perRecipe: Boolean,
    onModeChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Composição do preço", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                FilterChip(
                    selected = !perRecipe,
                    onClick = { onModeChange(false) },
                    label = { Text("Por unidade", maxLines = 1) },
                    shape = RoundedCornerShape(13.dp)
                )
                Spacer(Modifier.size(6.dp))
                FilterChip(
                    selected = perRecipe,
                    onClick = { onModeChange(true) },
                    label = { Text("Por receita", maxLines = 1) },
                    shape = RoundedCornerShape(13.dp)
                )
            }

            if (result.salePriceCents <= 0L || result.profitPerUnitExactCents < 0.0) {
                Surface(color = YellowSoft, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "A composição aparece quando o preço cobre os custos.",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            } else {
                val segments = wizardCompositionSegments(draft, catalog, result)
                val multiplier = if (perRecipe) result.sellableYield else 1.0
                val totalPriceCents = result.salePriceCents.toDouble() * multiplier
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val total = totalPriceCents.coerceAtLeast(1.0)
                            var startAngle = -90f
                            val stroke = size.minDimension * 0.18f
                            segments.forEach { segment ->
                                val amount = segment.centsPerUnit * multiplier
                                val sweep = (amount / total * 360.0).toFloat().coerceAtLeast(0f)
                                if (sweep > 0f) {
                                    drawArc(segment.color, startAngle, sweep, false, style = Stroke(width = stroke))
                                    startAngle += sweep
                                }
                            }
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(money(totalPriceCents.roundToLong()), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(if (perRecipe) "receita" else "unidade", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        segments.forEach { segment ->
                            val amount = segment.centsPerUnit * multiplier
                            val pct = if (totalPriceCents > 0.0) amount * 100.0 / totalPriceCents else 0.0
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(9.dp).background(segment.color, CircleShape))
                                Text(segment.label, modifier = Modifier.weight(1f).padding(start = 6.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${money(amount.roundToLong())} (${percent(pct)}%)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}


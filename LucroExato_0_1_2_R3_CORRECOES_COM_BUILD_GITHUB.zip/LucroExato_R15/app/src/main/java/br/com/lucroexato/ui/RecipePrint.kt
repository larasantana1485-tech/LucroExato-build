package br.com.lucroexato.ui

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.CostResult
import kotlin.math.roundToLong

fun printRecipe(context: Context, item: RecipeWithDetails, result: CostResult) {
    val revenue = (result.salePriceCents.toDouble() * result.sellableYield).roundToLong()
    val profitTotal = (result.profitPerUnitExactCents * result.sellableYield).roundToLong()
    val ingredients = item.ingredients.joinToString("") { used ->
        "<tr><td>${escapeHtml(used.nameSnapshot)}</td><td>${number(used.quantityUsed)} ${escapeHtml(used.unit)}</td><td>${money(used.costCents)}</td></tr>"
    }
    val html = """
        <html><head><meta charset="utf-8"><style>
        body{font-family:sans-serif;color:#1F1F22;padding:28px} h1{margin-bottom:2px} .muted{color:#6E6A73}
        .grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:20px 0}.card{border:1px solid #E7E1DA;border-radius:12px;padding:14px}
        table{width:100%;border-collapse:collapse;margin-top:12px}td,th{padding:7px;border-bottom:1px solid #ECE7E2;text-align:left}td:last-child,th:last-child{text-align:right}
        .green{color:#138A5B;font-weight:700}
        </style></head><body>
        <h1>${escapeHtml(item.recipe.name)}</h1><div class="muted">${escapeHtml(item.recipe.category)} • ${number(result.sellableYield)} ${escapeHtml(item.recipe.yieldUnit)}</div>
        <div class="grid"><div class="card"><b>Por unidade</b><p>Custo: ${money(result.costPerUnitCents)}</p><p>Venda: <span class="green">${money(result.salePriceCents)}</span></p><p>Lucro: <span class="green">${money(result.profitPerUnitCents)}</span></p></div>
        <div class="card"><b>Na receita</b><p>Custo: ${money(result.totalCostCents)}</p><p>Faturamento: <span class="green">${money(revenue)}</span></p><p>Lucro: <span class="green">${money(profitTotal)}</span></p></div></div>
        <p><b>Margem real:</b> ${percent(result.marginPercent)}% &nbsp;&nbsp; <b>Markup real:</b> ${percent(result.markupPercent)}%</p>
        <h2>Insumos</h2><table><tr><th>Insumo</th><th>Quantidade</th><th>Custo</th></tr>$ingredients</table>
        </body></html>
    """.trimIndent()

    val webView = WebView(context)
    webView.settings.javaScriptEnabled = false
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = view.createPrintDocumentAdapter("Lucro Exato - ${item.recipe.name}")
            manager.print(
                "Lucro Exato - ${item.recipe.name}",
                adapter,
                PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
            )
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null)
}

private fun escapeHtml(text: String): String = text
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .replace("'", "&#39;")

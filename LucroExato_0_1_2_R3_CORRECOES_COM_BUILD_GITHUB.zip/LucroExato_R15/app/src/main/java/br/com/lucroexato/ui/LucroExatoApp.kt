package br.com.lucroexato.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Route { MAIN, SETTINGS, WIZARD, RECIPE_DETAIL, INGREDIENT_DETAIL, SIMULATION, PREPARATION_EDIT }

@Composable
fun LucroExatoApp(vm: AppViewModel = viewModel()) {
    val tutorialComplete by vm.tutorialComplete.collectAsStateWithLifecycle()
    val isInitializing by vm.isInitializing.collectAsStateWithLifecycle()
    val snackbars = remember { SnackbarHostState() }
    var route by remember { mutableStateOf(Route.MAIN) }
    var selectedRecipeId by remember { mutableLongStateOf(0L) }
    var selectedIngredientId by remember { mutableLongStateOf(0L) }
    var mainTab by remember { mutableStateOf(MainTab.RECIPES) }
    var wizardReturnRecipeId by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        vm.events.collect { snackbars.showSnackbar(it) }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbars) }) { padding ->
        if (!tutorialComplete) {
            OnboardingScreen(
                modifier = Modifier.padding(padding),
                onFinish = { addExample -> vm.completeTutorial(addExample); route = Route.MAIN }
            )
            return@Scaffold
        }

        if (isInitializing) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator()
                    Text("Atualizando suas receitas…", style = MaterialTheme.typography.bodyMedium)
                }
            }
            return@Scaffold
        }

        BackHandler(enabled = route != Route.MAIN && route != Route.WIZARD) {
            route = when (route) {
                Route.SIMULATION, Route.PREPARATION_EDIT -> Route.RECIPE_DETAIL
                Route.RECIPE_DETAIL, Route.INGREDIENT_DETAIL, Route.SETTINGS -> Route.MAIN
                else -> Route.MAIN
            }
        }

        when (route) {
            Route.MAIN -> MainShell(
                modifier = Modifier.padding(padding),
                vm = vm,
                onSettings = { route = Route.SETTINGS },
                onNewRecipe = { wizardReturnRecipeId = 0L; vm.startNewRecipe(); route = Route.WIZARD },
                onResumeDraft = { wizardReturnRecipeId = 0L; vm.resumeDraft(); route = Route.WIZARD },
                onRecipe = { selectedRecipeId = it; route = Route.RECIPE_DETAIL },
                onIngredient = { selectedIngredientId = it; route = Route.INGREDIENT_DETAIL },
                selectedTab = mainTab,
                onTabChange = { mainTab = it }
            )
            Route.SETTINGS -> SettingsScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                onBack = { route = Route.MAIN }
            )
            Route.WIZARD -> RecipeWizardScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                onClose = {
                    route = if (wizardReturnRecipeId != 0L) {
                        selectedRecipeId = wizardReturnRecipeId
                        Route.RECIPE_DETAIL
                    } else Route.MAIN
                    wizardReturnRecipeId = 0L
                },
                onSaved = { selectedRecipeId = it; wizardReturnRecipeId = 0L; route = Route.RECIPE_DETAIL }
            )
            Route.RECIPE_DETAIL -> RecipeDetailScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                recipeId = selectedRecipeId,
                onBack = { route = Route.MAIN },
                onEditSection = { step ->
                    wizardReturnRecipeId = selectedRecipeId
                    vm.editRecipe(selectedRecipeId, step) { route = Route.WIZARD }
                },
                onEditPreparation = { route = Route.PREPARATION_EDIT },
                onSimulate = { route = Route.SIMULATION }
            )
            Route.SIMULATION -> RecipeSimulationScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                recipeId = selectedRecipeId,
                onBack = { route = Route.RECIPE_DETAIL }
            )
            Route.PREPARATION_EDIT -> PreparationEditScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                recipeId = selectedRecipeId,
                onBack = { route = Route.RECIPE_DETAIL }
            )
            Route.INGREDIENT_DETAIL -> IngredientDetailScreen(
                modifier = Modifier.padding(padding),
                vm = vm,
                ingredientId = selectedIngredientId,
                onBack = { route = Route.MAIN }
            )
        }
    }
}

package br.com.lucroexato.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.com.lucroexato.ui.theme.Pink

private data class TutorialPage(val icon: ImageVector, val title: String, val text: String)

@Composable
fun OnboardingScreen(modifier: Modifier = Modifier, onFinish: (Boolean) -> Unit) {
    val pages = listOf(
        TutorialPage(
            Icons.Outlined.Inventory2,
            "Cadastre seus insumos",
            "Cadastre ingredientes, embalagens e consumíveis. Informe quanto pagou e a quantidade comprada."
        ),
        TutorialPage(
            Icons.Outlined.ReceiptLong,
            "Monte a receita",
            "Informe as quantidades usadas e quanto a receita rende. O Lucro Exato calcula o custo da parte consumida."
        ),
        TutorialPage(
            Icons.Outlined.Calculate,
            "Veja os números certos",
            "Confira custo real, preço sugerido, margem e lucro. O resultado depende dos valores que você informar."
        )
    )
    var page by remember { mutableIntStateOf(0) }
    val item = pages[page]

    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { onFinish(false) }) { Text("Pular") }
        }
        Spacer(Modifier.weight(1f))
        Icon(item.icon, contentDescription = null, tint = Pink, modifier = Modifier.height(86.dp).fillMaxWidth(0.3f))
        Spacer(Modifier.height(26.dp))
        Text(item.title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(item.text, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Text("${page + 1} de ${pages.size}", color = Pink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        if (page < pages.lastIndex) {
            Button(onClick = { page++ }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = AppButtonShape) { Text("Próximo") }
        } else {
            Button(onClick = { onFinish(false) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = AppButtonShape) { Text("Começar") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { onFinish(true) }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = AppButtonShape) {
                Text("Começar com receita de exemplo")
            }
        }
    }
}

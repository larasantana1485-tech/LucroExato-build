# R15 — correção do resumo fixo da Ficha Técnica

Data: 25/09/2026

## Motivo
Na R14 o resumo compacto de Custo/Venda/Margem foi colocado acima da `LazyColumn` dentro de um `AnimatedVisibility` com `expandVertically`/`shrinkVertically`. Ao aparecer ou desaparecer, o componente alterava a altura disponível da lista e empurrava todo o conteúdo, causando o tranco observado no vídeo de teste. O cabeçalho da receita também rolava para fora da tela, diferente do mockup interativo 2.

## Correção
- Cabeçalho da receita retirado da lista e mantido estável no topo.
- Resumo compacto desenhado como overlay sobre a área rolável; ele não participa da medição da `LazyColumn`.
- Removida animação de expansão/encolhimento do resumo.
- Aparição usa progresso contínuo calculado pela posição real do card `Preço e lucro`.
- Quando os últimos 56 dp do card passam pelo topo, o resumo faz uma transição curta de opacidade e deslocamento de 8 dp; quando o card sai, o resumo já está totalmente visível.
- Ao voltar para o card, a transição é revertida pelo próprio movimento de rolagem.
- Mantidas as três métricas definidas: Custo, Venda e Margem.
- Card compacto recebeu raio 16 dp, borda discreta, sombra menor e tipografia reduzida.

## Escopo preservado
- Sanfonas continuam sanfonas.
- As três mudanças funcionais da R14 permanecem.
- Motor `CostCalculator` não foi alterado.
- Ícone do aplicativo não foi alterado.

# R4 — restauração de identidade visual e refinamentos

## Objetivo
Corrigir a neutralização excessiva introduzida no R3 sem voltar aos modais e seletores coloridos que prejudicavam a leitura.

## Regra visual oficial
- Cor continua sendo usada para significado: item já adicionado, resultado, lucro, aviso, rascunho e confirmação.
- Estrutura/base fica neutra: modais, dropdowns, seletores de unidade e campos permanecem brancos/neutros.
- Nenhum rótulo de campo, chip ou botão deve quebrar em duas linhas. Quando necessário, o texto é encurtado e permanece em uma linha.

## Alterações do R4
- Itens adicionados à receita voltam a usar verde/mint suave.
- O card de custo calculado do insumo volta a usar mint quando o cálculo é válido.
- Resultado parcial volta a usar amarelo suave como aviso.
- Preço/estimativa sugerida volta a usar azul suave.
- Cards Custo, Preço, Lucro, Margem e Markup voltam a usar cores semânticas diferentes.
- Outros custos salvos voltam a usar pêssego suave.
- Rascunho e estado vazio da Home voltam a ter rosa suave.
- Dropdowns e ajuda contextual têm fundo branco, sem lilás de fundo.
- Seletores de unidade continuam neutros e não aceitam digitação manual.
- Configurações foram compactadas: backup lado a lado e tutorial/ajuda como linhas clicáveis, sem botões duplicados.
- Ícone do launcher foi revertido para a versão anterior com fouet + gráfico, que tinha melhor presença visual no launcher.
- DEBUG passa a usar uma chave fixa incluída no projeto. Depois da primeira instalação do R4, os próximos DEBUGs poderão atualizar por cima sem trocar a assinatura a cada build.

## Assinatura de teste
A chave em `app/keystore/lucroexato-debug.jks` é apenas para builds DEBUG deste projeto. Não deve ser usada para uma publicação final em loja.

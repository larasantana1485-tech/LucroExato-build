# 2. Motor de cálculos — R6

## Regra da quantidade usada

`custo usado = preço da embalagem × quantidade usada convertida ÷ quantidade comprada convertida`

Exemplo: 2 kg custam R$ 70,00; 700 g usados custam R$ 24,50.

## Conversões

- massa: kg ↔ g ↔ mg;
- volume: l ↔ ml;
- unidade: un ↔ un;
- massa, volume e unidade não podem ser misturados.

## Rendimento e perdas

`rendimento vendável = rendimento informado × (1 − perda% ÷ 100)`

`custo unitário exato = custo total da receita ÷ rendimento vendável`

O custo unitário exato não é arredondado antes da precificação.

## Custo total

Soma de:

- ingredientes e sub-receitas;
- embalagem avulsa legada por unidade × rendimento vendável;
- mão de obra: valor da hora × minutos ÷ 60;
- custos aplicados na receita inteira;
- custos aplicados por unidade × rendimento vendável.

## Preço por margem

`preço sugerido exato = (custo unitário exato + taxa fixa) ÷ (1 − margem desejada − taxa percentual)`

Margem e taxa percentual somadas devem ficar abaixo de 100%.

## Preço por markup

`preço sugerido exato = custo unitário exato × (1 + markup%)`

Markup é acréscimo sobre o custo de produção. Taxas de venda reduzem lucro e margem, mas não mudam o conceito de markup.

## Resultado com preço praticado

`taxa = preço × taxa percentual + taxa fixa`

`lucro unitário = preço − custo unitário exato − taxa`

`margem = lucro unitário ÷ preço × 100`

`markup = (preço ÷ custo unitário exato − 1) × 100`

Margem desejada e margem real são grandezas diferentes.

## Arredondamento

- valores persistidos de dinheiro ficam em centavos;
- custo proporcional de cada insumo mantém precisão subcentavo internamente;
- os insumos são somados com essa precisão e o subtotal é arredondado uma única vez;
- `custo total ÷ rendimento vendável` mantém precisão completa;
- preço sugerido usa essa precisão e, quando há fração de centavo, sobe ao centavo necessário para não ficar abaixo da meta;
- preço sugerido da receita inteira deriva do preço unitário praticável em centavos × rendimento vendável, garantindo que os dois modos fechem entre si;
- porcentagens são calculadas com precisão e exibidas sem `,0` quando inteiras.

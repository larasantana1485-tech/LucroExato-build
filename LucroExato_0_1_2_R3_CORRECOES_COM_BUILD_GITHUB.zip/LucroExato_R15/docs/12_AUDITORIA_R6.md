# 12. Auditoria completa antes da R6

Data: 23/09/2026.
Base auditada: `LucroExato_0_1_4_R5_BUILD_FIX_ANDROID_STUDIO`.

## Erros matemáticos confirmados

1. **Arredondamento prematuro do custo unitário**
   - A R5 fazia `total / rendimento` e já arredondava para centavos.
   - Em seguida usava esse valor arredondado para sugerir preço, margem e markup.
   - Caso real: R$ 66,59 / 24 = 277,4583 centavos. A tela pode mostrar R$ 2,77, mas o cálculo seguinte precisa continuar usando 277,4583.
   - A 50% de margem, o preço correto arredondado é R$ 5,55 e o preço exato da receita é R$ 133,18.

2. **Simulação misturava preço real com margem desejada**
   - A comparação podia mostrar preço real de R$ 9,00 e lucro compatível com esse preço, mas rotular a margem atual como 50% apenas porque 50% era a meta salva.
   - Com custo R$ 66,59 / 24 e preço R$ 9,00, a margem real é aproximadamente 69,2% e o markup aproximadamente 224,4%.

3. **Lucro atual da simulação ignorava taxas**
   - A R5 calculava `preço - custo` na comparação atual e não descontava taxa percentual e taxa fixa.

4. **Tela de detalhe tinha uma segunda implementação de cálculo**
   - Lucro, taxa, margem, markup, mão de obra e custos por unidade eram recalculados na UI com fórmulas separadas do motor.
   - Havia truncamentos com `toLong()` e risco de divergência de R$ 0,01 ou mais.

5. **Composição do custo usava rendimento errado quando havia perda**
   - Embalagem avulsa e outros custos por unidade eram mostrados usando o rendimento original, enquanto o motor usa rendimento vendável.
   - A soma visual podia não fechar com o custo total.

6. **Sub-receitas perdiam precisão**
   - O custo era calculado com `costPerUnitCents` já arredondado e, em alguns pontos, truncado.
   - Agora usa `custo total / rendimento vendável` e arredonda apenas o custo final consumido.

7. **Markup com taxa fixa era inconsistente**
   - O preço sugerido de markup incluía taxa fixa dentro da base, mas o markup exibido era medido somente contra o custo de produção.
   - A R6 define markup como acréscimo sobre o custo de produção; taxas afetam lucro/margem.

## Erros de entrada e formatação

8. **Ponto decimal era removido**
   - `1.5` podia virar `15` porque o parser tratava todo ponto como separador de milhar.

9. **Conversão para centavos truncava**
   - `valor * 100` seguido de `toLong()` podia perder um centavo por representação binária.
   - A R6 usa arredondamento decimal HALF_UP.

10. **Teclado numérico permite teclas de operação em alguns aparelhos**
    - Campos aceitavam o texto recebido sem filtrar `+ - / *`.
    - A R6 aceita só dígitos e um separador decimal e não concatena números depois de operador inválido.

11. **Inteiros apareciam com vírgula zero**
    - Exemplos: `24,0`, `400,0`, `50,0%`.
    - A R6 exibe `24`, `400`, `50%`, preservando casas quando realmente existem.

## Erros de UX e fluxo

12. **Não era possível testar preço/margem diretamente no resultado salvo**
    - Era necessário entrar em Editar receita.
    - A R6 adiciona teste rápido não destrutivo no Resultado.

13. **Teclado escondia os resultados**
    - O campo de preço ficava acima do teclado e os cards calculados abaixo dele.
    - R6 usa ajuste de IME e reorganiza os resultados para permanecerem visíveis durante a digitação.

14. **Quantidade de embalagem era ambígua**
    - “Qtd. usada” levava a informar 1 adesivo quando a receita inteira usava 24.
    - A R6 passa a dizer “Qtd. total usada” e alerta quando um item com aparência de embalagem está em 1 numa receita com rendimento maior.

15. **Possível dupla contagem de embalagem**
    - Existe campo legado `packagingPerUnitCents` e também embalagem como insumo.
    - A R6 avisa quando o campo legado está ativo e oferece removê-lo.

16. **Navegação inferior com só duas opções**
    - Ocupava altura, parecia vazia e o selecionado tinha aparência cortada.
    - Direção aprovada: Receitas e Insumos viram tabs no topo.

17. **Engrenagem do cabeçalho**
    - Ajustada para alinhar com a linha do título “Lucro Exato”, não com o centro do bloco título+subtítulo.

18. **Stepper não diferenciava concluído de atual**
    - Agora concluído, atual e futuro têm estados distintos.

19. **Dropdowns muito altos**
    - Limitados em altura com rolagem.

20. **Cards de insumos altos**
    - Reduzido espaço vertical sem remover as cores aprovadas.

21. **Ciclo de sub-receitas**
    - Era possível criar A → B e depois B → A.
    - A R6 filtra sub-receitas que criariam dependência circular.

## Validações adicionadas ao motor

- rendimento > 0;
- perda entre 0 e 99,99%;
- custos e taxas fixas não negativos;
- taxa percentual entre 0 e 99,99%;
- margem desejada < 100%;
- margem + taxa percentual < 100%;
- markup não negativo;
- preço escolhido > 0 quando informado;
- unidades de compra e uso compatíveis;
- quantidades finitas e válidas.

## Achados adicionais na auditoria de código

22. **Preço sugerido podia ficar alguns milésimos abaixo da meta após arredondar**
    - Quando o preço matemático terminava em fração de centavo e era arredondado para baixo, a margem real podia ficar ligeiramente menor que a margem desejada.
    - A R6 arredonda preço sugerido para cima ao centavo necessário, garantindo que a meta não seja subestimada por arredondamento.

23. **Histórico de preço do insumo podia ser apagado ao editar o cadastro**
    - O DAO usava `INSERT OR REPLACE` em `IngredientEntity`.
    - Como o histórico tem chave estrangeira com `ON DELETE CASCADE`, o `REPLACE` podia apagar os registros antigos antes de reinserir o insumo.
    - A R6 usa `@Upsert`, que atualiza sem apagar a linha pai, e só registra novo histórico quando preço/quantidade/unidade da compra realmente mudam.

24. **Cards da Home podiam ficar com custo antigo depois de alterar um insumo**
    - O recálculo acontecia ao abrir/editar a receita, não imediatamente após atualizar o catálogo.
    - A R6 recalcula as receitas em ordem de dependência, incluindo sub-receitas, depois da alteração de preço e depois de salvar uma receita-base.

25. **Excluir uma receita usada como sub-receita deixava referência órfã**
    - `sourceRecipeId` não possui chave estrangeira e a exclusão era permitida sem verificação.
    - A R6 bloqueia a exclusão enquanto outra receita depender dela e informa onde o vínculo deve ser removido.

26. **Voltar de um insumo podia devolver a Home para a aba Receitas**
    - O estado da aba estava dentro de `MainShell`, que é removido ao abrir outra tela.
    - A R6 mantém a aba selecionada no nível do aplicativo; voltar de um insumo retorna a Insumos.

27. **Erro de simulação podia parecer botão sem funcionar**
    - Exceções do cálculo eram convertidas silenciosamente em `null`.
    - A R6 mostra o motivo quando rendimento, margem, taxas ou outro valor tornam a simulação inválida.

28. **Texto de quantidade de receitas usava “receita(s)”**
    - Corrigido para singular/plural real: `1 receita`, `2 receitas`.

29. **Algumas quantidades fracionárias podiam ser escondidas no card**
    - A Home forçava rendimento com zero casas decimais.
    - A R6 remove zeros desnecessários, mas preserva até três casas significativas quando existirem.

30. **Feedback do cálculo podia continuar fora da área visível com o teclado**
    - Além de `adjustResize`/`imePadding`, os campos de margem e preço agora mostram no próprio campo o preço sugerido ou lucro/margem real enquanto o usuário digita.

31. **Atualizações automáticas podiam alterar a ordem da Home**
    - Recalcular uma receita reutilizava o mesmo salvamento de uma edição manual e atualizava `updatedAt`.
    - A R6 recalcula custos sem fingir que a receita foi editada pelo usuário; a ordem recente é preservada.

32. **Valores extremos podiam estourar `Long` silenciosamente**
    - Somatórios monetários agora usam adição verificada e preços calculados são validados antes da conversão para centavos inteiros.

# Lucro Exato — R3 (0.1.2-r3)

Rodada iniciada a partir do teste real do R2.

## Correções aplicadas
- Novo ícone baseado na opção 6 (saco de confeitar + etiqueta de preço) com fundo menta.
- Unidade de rendimento deixou de ser campo de texto e virou seletor.
- Seletor de unidade padronizado em nova receita, cadastro/edição de insumo e uso na receita.
- Campos numéricos selecionam todo o valor ao receber foco.
- Barra inferior reduzida para duas áreas: Receitas e Insumos. Simulação saiu da navegação principal.
- Simulação agora é aberta de dentro de uma receita e mostra Atual x Simulação.
- Rascunho aparece na Home e pode ser retomado. Nova receita não recupera rascunho silenciosamente.
- Busca do catálogo fica antes da lista de insumos adicionados; a lista de adicionados pode ser recolhida.
- Ingredientes, embalagens e consumíveis passam a ser tratados na interface como Insumos.
- Embalagens são orientadas a entrar pelo catálogo de insumos, reaproveitando preço de compra e quantidade usada.
- Modais grandes coloridos foram substituídos por superfícies neutras; editor de custo e ajuda viraram telas sobrepostas de fundo neutro.
- Tela de ajuda foi reescrita e corrigida: usa “preço de compra do insumo”, não “preço da embalagem”.
- Configurações sem efeito (moeda/sistema de medidas) foram removidas do R3.
- Preferência de margem/markup continua funcional apenas como padrão para novas receitas.
- Resultado parcial passou a ser descrito como estimativa quando faltam custos relevantes.
- Cards métricos deixaram de usar fundos coloridos; passam a usar fundo neutro e borda.
- Campos lado a lado receberam rótulos curtos e alturas coerentes para evitar quebra/corte de texto.
- Botões principais usam cantos moderados, evitando cápsulas exageradas fora dos chips.
- Resultado parcial de receitas salvas reconhece embalagem cadastrada como insumo, não apenas o campo legado de embalagem avulsa.
- Textos de cards comparativos e métricos foram limitados a uma linha com comportamento de overflow para evitar quebra em duas linhas e desalinhamento.

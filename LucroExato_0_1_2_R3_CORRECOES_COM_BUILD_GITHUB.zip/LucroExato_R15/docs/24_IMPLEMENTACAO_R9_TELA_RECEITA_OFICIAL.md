# R9 — implementação da tela oficial de receita

Referência visual: `21_REFERENCIA_TELA_RECEITA_OFICIAL.png`.
Referência do ícone: `22_REFERENCIA_ICONE_OFICIAL.jpg`.
Especificação: `23_ESPECIFICACAO_TECNICA_TELA_RECEITA_R9.docx`.

## Implementado
- Tela de receita refeita com fundo branco/quase branco, cartões brancos e cor apenas em detalhes.
- Removidos os três cards soltos do topo da R8 e removida a sanfona `Resumo`.
- `Preço e lucro` virou o primeiro bloco, fixo, sempre aberto e sem chevron.
- `Por unidade` e `Na receita` ficam na mesma caixa com divisor vertical fino.
- Margem real e Markup real em mini-cards compactos.
- Campo `Preço de venda (por unidade)` sempre visível e editável; preço salvo como manual.
- Teste rápido sempre visível com apenas `Margem` e `Markup`; o pill `Preço` foi removido.
- Atalhos percentuais ocupam a largura disponível e ficam alinhados ao campo do modo ativo.
- Preço sugerido não substitui o preço real automaticamente; ação `Usar` aplica o valor.
- Card rosa redundante da R8 removido.
- `Composição do preço` permanece dentro do bloco `Preço e lucro` e virou sanfona interna.
- Gráfico donut reduzido e legenda compactada.
- Sanfonas secundárias na ordem oficial: Insumos, Rendimento e escala, Custos adicionais, Modo de preparo.
- Sanfonas usam fundo branco, ícones neutros e chevron para baixo/para cima.
- `Custos adicionais` usa texto contextual `Mão de obra e taxas` e mantém embalagem avulsa somente quando realmente existir no campo legado.
- Banner de revisão ficou curto e também alerta embalagens unitárias suspeitas em receitas com rendimento maior.
- Cabeçalho oficial com voltar, nome/categoria/rendimento, imprimir e informação.
- Impressão implementada via Android PrintManager.
- Ícone do launcher recriado a partir da referência aprovada, preservando o fouet roxo, cabo rosa, seta rosa e três barras rosa/laranja/verde.
- Tokens principais de cor do tema atualizados para a especificação oficial.
- Versionamento: 0.1.8-r9 / versionCode 9.
- Workflow GitHub atualizado para gerar `LucroExato_0_1_8_R9_DEBUG.apk`.

## Regra crítica mantida
Os cálculos continuam usando o motor de precisão da R8. A R9 altera apresentação, fluxo de edição do preço e alertas; não troca as fórmulas aprovadas.

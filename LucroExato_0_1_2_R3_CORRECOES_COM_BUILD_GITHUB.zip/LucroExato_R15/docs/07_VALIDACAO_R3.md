# Validação R3 — 0.1.2-r3

## Validado nesta rodada

- XML de recursos: parse completo sem erros.
- Motor de cálculo puro Kotlin: compilado e executado com sucesso.
- Conversão e custo: 2 kg / R$ 70,00 usando 700 g = R$ 24,50.
- Conversão e custo: 1 l / R$ 5,50 usando 533 ml = R$ 2,93.
- Embalagem: 100 un / R$ 18,00 usando 24 un = R$ 4,32.
- Receita de R$ 5,55 / 24 un: custo unitário R$ 0,23 e sugestão por margem de 50% = R$ 0,46.
- Verificação estrutural dos arquivos Kotlin sem desequilíbrio bruto de parênteses/chaves/colchetes.
- Removida a aba principal Simular; simulação agora pertence à receita.
- Removida a configuração sem efeito “Unidades e moeda”.
- Unidades do rendimento e dos insumos usam seletor, não digitação livre.
- Rascunho explícito na Home e início de nova receita sem reaproveitar rascunho silenciosamente.
- Embalagens reconhecidas como insumos para o estado de resultado parcial.
- Ícone de launcher substituído pela opção 6 com fundo menta.

## Limitação do ambiente desta sessão

A compilação Android completa (`testDebugUnitTest` / `assembleDebug`) não foi concluída porque o wrapper precisa obter o Gradle 8.13 e este ambiente não conseguiu resolver/acessar `services.gradle.org`.

Por isso, o ZIP R3 é o projeto Android Studio corrigido e validado estruturalmente, mas não deve ser tratado como APK compilado nesta sessão. Ao abrir em um ambiente com Gradle disponível, execute a sincronização e o build normal do módulo `app`.

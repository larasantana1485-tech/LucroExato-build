# R10 — mudanças pós-R9

Implementação baseada exclusivamente em `25_ESPECIFICACAO_TECNICA_MUDANCAS_POS_R9_R10.docx`.
Partes não citadas na especificação foram preservadas.

## Tela principal da receita
- Lápis no cabeçalho abre a edição completa no passo Dados.
- Preço e lucro continua primeiro, aberto e sem chevron.
- Preço vazio mantém os custos e mostra `—` nos resultados dependentes do preço.
- `Teste rápido` virou `Ajustar preço`.
- Margem: 30/40/50/60/70%; Markup: 50/100/150/200%.
- Margem/Markup alteram imediatamente o mesmo estado do preço de venda e recalculam os resultados do topo.
- Removidos o bloco `Preço sugerido … Usar` e a faixa duplicada da simulação.
- Composição do preço permanece dentro do card principal.

## Sanfonas e alertas
- Abertura/fechamento animados em 200ms com expansão e fade.
- Chevron animado e auto-scroll ao abrir.
- Banner de conferência é clicável e leva para Insumos ou Custos adicionais.
- Alerta de embalagem mostra quais itens estão suspeitos.
- Rendimento e escala ganhou ajuda para Multiplicador, atalhos 0,5×/1×/1,5×/2× e lista escalada recolhível.

## Wizard
- Dados: Modo de preparo removido; Categoria sem `*`; nota única `* obrigatório`; Rendimento/Unidade com 56dp.
- Insumos: seleção em tela cheia; cards brancos; sem bottom sheet.
- Custos: ajuda `Como preencher custos`, ajuda contextual, categoria genérica `Taxa` removida e radio rows compactas em Adicionar custo.
- Resultado: Por unidade/Por receita no topo da precificação; Margem/Markup; alvo; preço sugerido; preço escolhido; resultado real — nessa ordem.

## Simular mudanças
- Seleção de insumo em tela cheia e pesquisável, sem dropdown gigante.
- Removido card azul de preço mantido.
- Comparação `Atual × simulado` compacta em colunas, usando `—` quando não há diferença.

## Insumos
- `+ Novo insumo` substitui o `+` isolado.
- Ícone repetido removido das linhas; chevron passa a indicar abertura/edição.
- Adicionar e editar continuam em tela cheia.

## Modo de preparo
- Sai da criação inicial e do Resultado.
- Continua como sanfona opcional da receita salva e ganhou editor direto em tela cheia.

## Design system
- Pink oficial para seleção; verde para valores positivos; amarelo para alerta.
- Body principal 15sp; secundário 13sp.
- Cards 16dp, inputs 14dp, chips/seletores com raio aproximado de 13dp.

## Invariantes
- `CostCalculator.kt` não foi alterado.
- Ícone do aplicativo não foi alterado.
- Fórmulas e precisão matemática permanecem as da R9 auditada.

# Validação R7

## Matemática
Foi executado um harness Kotlin diretamente sobre `CostCalculator.kt` e `Formatters.kt` com:
- casos fixos de custo por insumo e embalagem;
- caso R$ 66,59 / 24 com precisão interna;
- margem real e markup para preço de R$ 9,00;
- arredondamento monetário e parser decimal;
- 20.000 cenários aleatórios de margem com taxa percentual/fixa.

Resultado: `MATH_OK 20000 randomized + fixed cases`.

Propriedade verificada nos cenários válidos: o preço sugerido arredondado para centavos nunca fica abaixo da margem alvo.

## Migração e persistência
- Campo opcional `preparation` possui valor padrão vazio.
- Migração 1 -> 2 é aditiva e não apaga receitas existentes.
- JSON de backup e rascunho aceita dados antigos sem o novo campo.

## Validação estática
- XMLs analisados por parser.
- Não há mais definição privada de `SummaryCard`; há apenas a versão compartilhada.
- Varredura sintática do compilador Kotlin sem dependências Android não encontrou erros do tipo `expecting`, `unexpected tokens`, `redeclaration` ou `conflicting overloads`.

## Limitação deste ambiente
O `./gradlew testDebugUnitTest` / `assembleDebug` não pôde ser concluído aqui porque o wrapper precisa baixar Gradle 8.13 e o ambiente não resolve `services.gradle.org`. A validação final de Android/Compose deve ser feita no Android Studio, que também confirmará KAPT/Room e a renderização dos composables.

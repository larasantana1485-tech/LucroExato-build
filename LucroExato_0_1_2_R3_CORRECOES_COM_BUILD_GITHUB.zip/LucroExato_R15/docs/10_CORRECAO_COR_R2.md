# Correção de cor – R5

A paleta semântica do R2 foi restaurada também no card **Custo na receita**:

- antes de preencher os valores: `PinkSoft` (`#FFE4EC`);
- após existir prévia válida do custo: `Mint` (`#E1F6E8`).

As exceções solicitadas permanecem neutras: menus/dropdowns, modais e seletores de unidade/métrica não recebem fundo colorido decorativo.

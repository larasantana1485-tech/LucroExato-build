# 3. Catálogo e categorias — V1.0

## Categorias de receitas

- Bolos
- Doces
- Tortas
- Cookies
- Pães
- Salgados
- Sobremesas
- Bebidas
- Outros

## Categorias de ingredientes

- Chocolates e coberturas
- Farinhas e amidos
- Açúcares e adoçantes
- Leites e derivados
- Gorduras e óleos
- Ovos e derivados
- Frutas e derivados
- Castanhas e sementes
- Coco
- Recheios e pastas
- Aromas, extratos e bebidas
- Corantes e aditivos
- Embalagens
- Outros

## Regras do catálogo

- ingredientes iniciais são editáveis;
- usuário pode criar ingrediente próprio;
- embalagem registra preço, quantidade e unidade;
- cada atualização de preço entra no histórico;
- preço real pago tem prioridade;
- faixa de referência deve ser identificada como apoio, nunca como preço garantido;
- sub-receita usa o custo unitário calculado de uma receita salva;
- uma receita não pode ser adicionada como sub-receita dela mesma.

Consulta automática de preços online não pertence à R1.

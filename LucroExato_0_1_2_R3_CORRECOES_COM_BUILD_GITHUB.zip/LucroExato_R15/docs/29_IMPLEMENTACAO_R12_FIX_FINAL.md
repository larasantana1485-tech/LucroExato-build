# R12 — correção final após revisão em aparelho

Implementado sobre a R11, sem alterar o motor matemático nem o ícone aprovado.

## Corrigido nesta versão
- **Simular mudanças:** o seletor de insumo não usa mais a troca inline que podia falhar/bugar. Agora abre uma tela cheia modal, pesquisável, com retorno explícito para a simulação.
- **Sanfonas:** abertura ficou deliberadamente mais perceptível: ~550 ms ao expandir, ~480 ms ao fechar, fade suave e chevron sincronizado em ~500 ms. O auto-posicionamento permanece.
- **Tela final da receita:** removida a sanfona **Modo de preparo**, conforme a decisão mais recente.
- **Etapa 4 — Resultado:** reorganizada seguindo a ordem visual aprovada/inspirada na referência enviada:
  1. Preço e lucro / alerta
  2. Resumo da receita
  3. Defina seu preço de venda
  4. Por unidade | Por receita
  5. Campo de preço
  6. Calcular por Margem | Markup
  7. Atalhos e percentual personalizado
  8. Faturamento & Lucro em duas colunas
  9. Margem real e Markup
  10. Composição do preço
- O antigo card separado **“Preço sugerido para sua meta”** foi eliminado da etapa 4. Quando a receita está no modo sugerido, o próprio campo de preço mostra o valor calculado pela margem/markup; editar o campo passa para preço manual.
- **Composição do preço** adicionada ao final da etapa 4, com visual compacto e alternância Por unidade / Por receita.
- Aviso de preço abaixo do custo foi mantido em linguagem direta quando aplicável.

## Preservado
- CostCalculator: sem alterações.
- Precisão/rounding aprovados: sem alterações.
- Ícone do aplicativo: todos os recursos do launcher são idênticos à R11.
- Demais telas fora do escopo acima: preservadas.

## Validações locais
- Parser Kotlin: sem erros de sintaxe detectados.
- XML/Manifest: parseados.
- Matemática: casos fixos + 200.000 cenários aleatórios aprovados.
- Gradle local: não executa neste ambiente por ausência de acesso a services.gradle.org; confirmar assembleDebug no GitHub/Android Studio.

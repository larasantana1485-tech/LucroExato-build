# 1. Mapa de telas e fluxos — V1.0

## Navegação principal

Três abas inferiores:

1. **Receitas** — lista, busca, categorias e botão Nova receita.
2. **Ingredientes** — catálogo, preço de compra, unidade e histórico.
3. **Simular** — altera hipóteses sem modificar a receita salva.

Configurações fica no cabeçalho de Receitas.

## Primeiro uso

Tutorial de no máximo três telas, sempre com **Pular**:

1. “Escolha no catálogo e informe quanto você pagou. Você também pode usar preços de referência.”
2. “Informe as quantidades e quanto a receita rende.”
3. “Veja o custo real, preço de venda, margem e lucro.”

Ao final: **Começar** ou **Começar com receita de exemplo**. A receita de exemplo é marcada como demonstrativa.

## Nova receita

Fluxo em quatro etapas:

1. **Dados** — nome, categoria, rendimento e unidade.
2. **Ingredientes** — catálogo, quantidade usada e sub-receitas.
3. **Custos** — perdas, embalagem, mão de obra, energia/gás, extras e taxas.
4. **Resultado** — composição, custo total, custo unitário, preço sugerido, preço escolhido, lucro, margem e markup.

Ações finais: **Salvar receita** e, depois, **Simular variações**. Ao editar, usar **Salvar alterações**.

## Estados obrigatórios

- lista vazia;
- busca sem resultado;
- campo obrigatório ausente;
- unidade incompatível;
- margem + taxa inválidas;
- carregamento;
- salvamento concluído;
- backup inválido ou incompatível.

## Persistência

- rascunho automático;
- aviso ao sair: continuar depois ou descartar rascunho;
- receitas salvas localmente;
- backup e restauração manuais;
- funcionamento offline.

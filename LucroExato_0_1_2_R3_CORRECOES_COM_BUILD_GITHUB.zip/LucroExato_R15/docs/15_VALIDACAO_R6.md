# 15. Validação da R6

Data: 23/09/2026.

## Validações executadas neste ambiente

- XML de recursos e `AndroidManifest.xml`: parse válido.
- Núcleo puro Kotlin (`CostCalculator.kt` + `Formatters.kt`): compilado com `kotlinc` sem erros.
- Caso R$ 66,59 / 24 / margem 50%: custo interno 277,458333... centavos, preço sugerido R$ 5,55, receita R$ 133,18.
- Caso preço real R$ 9,00: margem ≈ 69,1713% e markup ≈ 224,3730%.
- Caso com taxa 5% + taxa fixa R$ 0,50 + margem alvo 50%: preço sugerido mínimo R$ 23,34 e margem real >= 50%.
- Formatação: 24,0 -> 24; 0,125 -> 0,125; ponto e vírgula decimais aceitos.
- Sanitização de teclado: operadores não são concatenados ao número.
- Auditoria randômica: 10.000 cenários verificando invariantes de margem/markup e composição de custo passaram.
- Verificação sintática adicional de todos os `.kt`: nenhum erro de parser Kotlin encontrado.

## Build Android completo

Este ambiente não possui Android SDK e não consegue resolver downloads externos por DNS. Por isso não foi possível executar aqui `assembleDebug`/`lint` com o classpath Android completo.

O projeto inclui `.github/workflows/build-debug.yml` e continua pronto para abrir no Android Studio. A validação final recomendada no computador é:

```text
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

Não considerar esta limitação como confirmação de build: a compilação Android final deve ser certificada pelo Android Studio ou pelo workflow incluído.

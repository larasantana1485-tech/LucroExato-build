# R13 — correções de estado, fluxo e inicialização

Implementado em 25/09/2026 sobre a R12.

## Correções
- Home bloqueada durante `ensureSeeded + recalculateAllRecipes`, eliminando a piscada com valores antigos.
- Ajustar preço: quando o preço salvo é manual e não corresponde ao target antigo, Margem/Markup exibem o valor real derivado do preço atual.
- Trocar Margem/Markup passa a refletir a métrica equivalente do preço atual, sem alterar o preço só por trocar de modo.
- Aviso amarelo da receita salva é clicável e pode ser dispensado com swipe horizontal; a pendência permanece no resumo da sanfona.
- Sanfonas: expansão 330 ms; o auto-scroll só acontece depois da expansão e somente se o cabeçalho não estiver visível.
- Editar receita existente: etapas Dados/Insumos/Custos/Resultado são clicáveis; botão primário vira `Salvar alterações` em qualquer etapa.
- Etapa 4: aviso compacto com `Revisar`, Base de custo compacta e remoção da composição de preço duplicada.
- Simular mudanças: seletor de insumo virou tela full-screen real, sem `Dialog` aninhado.
- Configurações: `Redefinir aplicativo` apaga dados do usuário, restaura catálogo padrão e reabre o onboarding.

## Preservado
- `CostCalculator.kt` byte a byte igual ao da R12.
- Ícone e recursos de launcher da R12.
- Criação de receita continua sequencial 1 → 2 → 3 → 4.

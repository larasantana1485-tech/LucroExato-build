# R7 — correções e melhorias aprovadas

## Correção de compilação
- `SummaryCard` deixou de ser um composable privado de `RecipeWizardScreen.kt` e passou a ser componente compartilhado em `Components.kt`.
- Isso corrige as três chamadas de `SummaryCard` em `MainScreens.kt` que apareciam como `Cannot access` no Android Studio.

## Fluxo preservado
A criação de receita continua exatamente em quatro etapas:
1. Dados
2. Insumos
3. Custos
4. Resultado

A edição de uma receita já salva ganhou atalhos por seção. Cada sanfona leva diretamente à etapa correspondente do wizard sem obrigar o usuário a recomeçar da etapa 1.

## Tela de receita salva
- Resumo em sanfonas: Resumo, Insumos, Modo de preparo, Custos adicionais e Preço e lucro.
- Cada sanfona mostra um resumo compacto mesmo fechada.
- Insumos abre por padrão e mostra os primeiros quatro itens com opção de expandir todos.
- `Modo de preparo` é opcional e é salvo junto da receita.

## Preço e lucro
- Quadro `Por unidade` x `Na receita` com custo, venda/faturamento e lucro.
- Teste rápido de margem e preço continua sem alterar a receita salva.
- Gráfico de composição do preço: lucro, ingredientes, embalagem, mão de obra, outros e taxas.
- Margem real e markup continuam conceitos separados.

## Persistência
- Banco Room atualizado da versão 1 para 2 com migração não destrutiva:
  `ALTER TABLE recipes ADD COLUMN preparation TEXT NOT NULL DEFAULT ''`.
- Backups antigos continuam aceitos; `preparation` ausente é restaurado como texto vazio.
- Rascunhos antigos continuam aceitos da mesma forma.

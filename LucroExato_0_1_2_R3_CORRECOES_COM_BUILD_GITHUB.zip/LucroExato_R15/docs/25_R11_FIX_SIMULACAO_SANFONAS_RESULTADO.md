# R11 — correções após teste em aparelho

Implementado somente o que foi reportado após a R10:

- Simular mudanças: quando nada foi alterado, mostra mensagem clara em vez de parecer que o botão falhou. Quando há resultado ou aviso, a tela rola automaticamente até ele.
- Sanfonas: expansão/fechamento e rotação do chevron ficaram mais lentos e perceptíveis; o auto-posicionamento aguarda o início da expansão.
- Etapa 4 Resultado: Por unidade/Por receita foi levado para o topo; Margem/Markup e percentual vêm antes de “Defina seu preço de venda”; preço sugerido, preço escolhido e resultado permanecem depois.

Nenhuma fórmula do CostCalculator foi alterada. Nenhuma outra tela foi redesenhada nesta correção.

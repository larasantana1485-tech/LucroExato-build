# Validação R8

## Casos determinísticos
- R$ 66,59 / 24 = 277,458333... centavos internamente.
- Custo exibido: R$ 2,77.
- Margem desejada 50%: preço unitário praticável R$ 5,55.
- Total canônico para 24 unidades: R$ 133,20.
- Preço real R$ 9,00: margem ~69,17% e markup ~224,37%.
- 10 custos individuais de 0,1 centavo somam 1 centavo no total da receita.

## Testes aleatórios
Foram executados 200.000 cenários aleatórios: 100.000 de margem e 100.000 de markup, incluindo taxas percentuais/fixas, perdas e custos fracionários. Em todos os casos válidos, o preço sugerido respeitou o alvo e o total da receita fechou com preço unitário × rendimento vendável.

## Compilação local disponível
`CostCalculator.kt` e `RecipeDraft.kt` foram compilados com `kotlinc` no ambiente de auditoria.

## Build Android
O build Android completo deve ser confirmado no Android Studio ou pelo workflow GitHub Actions incluído no projeto, pois o ambiente de geração não possui a cadeia Android/Gradle completa disponível localmente.

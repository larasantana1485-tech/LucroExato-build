# Validação da R2

## Correções funcionais

- compra e uso do ingrediente são editáveis dentro do fluxo da receita;
- tocar em ingrediente já adicionado permite corrigir preço, embalagem, unidade e uso;
- custo usado é recalculado antes de adicionar ou salvar;
- catálogo ampliado para 77 itens e 13 categorias;
- novos itens entram em bancos do R1 sem apagar preços informados pelo usuário;
- o preço padrão antigo do chocolate é migrado para R$ 70,00 por 2 kg somente quando ainda não foi editado;
- simulação altera um ingrediente específico, rendimento e margem sem modificar a receita salva;
- preço pode ser conferido por unidade ou pela receita inteira;
- resultado incompleto é identificado como parcial quando embalagem ou mão de obra não foram informadas.

## Correções visuais

- cartões e cantos mais compactos;
- rosa restrito às ações e aos destaques;
- ícones de lista padronizados, sem emojis;
- fluxo longo de ingrediente em tela inteira;
- launcher redesenhado com fouet, barras e seta de crescimento.

## Build verificado

- testes unitários: aprovados;
- APK debug: gerado;
- assinatura APK v2: válida;
- pacote: `br.com.lucroexato`;
- versão: `0.1.1-r2` (`versionCode 2`);
- `minSdk 26`, `targetSdk 36`.

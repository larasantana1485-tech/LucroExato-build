# 14. Casos matemáticos de conferência — R6

Casos usados para validar o motor antes de empacotar a R6.

| Caso | Resultado esperado |
|---|---:|
| R$ 70,00 / 2 kg × 700 g | R$ 24,50 |
| R$ 50,00 / 400 un × 24 adesivos | R$ 3,00 |
| R$ 5,00 / 100 un × 24 fechos | R$ 1,20 |
| R$ 5,50 / 1 L × 500 ml | R$ 2,75 |
| Custo total R$ 66,59 / 24 | 277,458333… centavos/un. internamente |
| Preço sugerido para margem 50% no caso acima | R$ 5,55/un. |
| Preço sugerido da receita inteira no caso acima | R$ 133,20 |
| Preço real R$ 9,00 com custo exato acima | lucro ≈ R$ 6,23; margem ≈ 69,17%; markup ≈ 224,37% |
| Custo R$ 10,00, taxa 5%, taxa fixa R$ 0,50 e margem alvo 50% | preço mínimo R$ 23,34; margem real ≥ 50% |
| R$ 90,00 de custo, rendimento 100, perda 10% | rendimento vendável 90; custo R$ 1,00/un. |

## Regra de arredondamento

- Custos monetários persistidos fecham em centavos.
- A divisão do custo total pelo rendimento mantém precisão completa para precificação.
- Preço sugerido sobe ao centavo necessário quando o valor exato tem fração de centavo, para não ficar abaixo da margem/markup desejado.
- Valores de interface arredondados nunca voltam a ser usados como entrada do cálculo seguinte.

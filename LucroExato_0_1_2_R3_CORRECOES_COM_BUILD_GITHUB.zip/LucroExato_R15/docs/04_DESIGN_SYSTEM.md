# 4. Design system — V1.0

## Direção visual

Leve, clara, compacta e acolhedora, sem aparência infantil. Referência aprovada: tons pastéis com rosa como cor de ação.

## Paleta

- fundo: `#FFF9F6`;
- superfície: `#FFFFFF`;
- texto principal: `#2B2930`;
- texto secundário: `#6F6A73`;
- ação principal: `#E84E7A`;
- rosa suave: `#FFE4EC`;
- lavanda: `#ECE4FF`;
- menta: `#E1F6E8`;
- pêssego: `#FFECD8`;
- azul suave: `#E1EDFF`;
- amarelo suave: `#FFF3C9`.

## Medidas

- topo compacto, aproximadamente 56 dp;
- botão principal: 48–52 dp;
- campos: cerca de 56 dp;
- cantos: 10–18 dp;
- espaçamento base: 8 dp;
- margens laterais: 16 dp;
- área mínima de toque: 48 dp.

## Componentes

- chips horizontais para categorias e filtros;
- cards baixos, com conteúdo alinhado;
- botão principal rosa e ação secundária contornada;
- diálogos compactos para uma decisão curta;
- tela inteira para fluxos longos;
- navegação inferior fixa nas três áreas principais.

## Restrições

- não usar bottom sheet de meia altura para fluxo complexo;
- não criar caixas altas ou grandes áreas vazias;
- não esconder ação principal abaixo de conteúdo variável;
- não misturar padrões diferentes de botão, campo ou espaçamento;
- textos devem falar de receita, ingrediente, custo, preço, margem e lucro — nunca de vendas, clientes ou estoque.

## Acessibilidade

- contraste legível mesmo em fundos pastéis;
- rótulo visível em campos obrigatórios;
- ícone acompanhado de texto nas ações importantes;
- erros explicados em linguagem direta;
- não depender apenas de cor para indicar estado.

# Lucro Exato — R5

## Ajustes desta revisão

- Etapa 2 foi simplificada: a tela principal mostra somente os insumos já adicionados e o botão pill `Adicionar insumos`.
- O catálogo saiu da tela principal da receita e passou para uma meia aba inferior.
- Na meia aba, busca e categorias permanecem fixas; somente a lista de insumos rola.
- Quando a busca não encontra nenhum item, aparece `Criar insumo` já com o nome pesquisado preenchido.
- Sub-receitas continuam disponíveis dentro da mesma meia aba sem poluir a tela principal.
- Itens já adicionados continuam destacados em verde/mint.
- Em Custos, removida a ação duplicada `+` ao lado de `Outros custos`; permanece somente o botão `Adicionar outro custo`.
- Corrigido o alinhamento de `Rendimento` e `Unidade`: mesma linha, mesmo topo e mesma altura.
- O mesmo padrão de alinhamento foi aplicado aos pares `Qtd. comprada + Unidade` e `Qtd. usada + Unidade`.
- Dropdowns/unidades continuam neutros, sem fundo colorido.
- Versão: `0.1.4-r5` / build 5.

## Regra visual consolidada

Cores semânticas permanecem em estados, itens adicionados, avisos e resultados. Modais, dropdowns, menus flutuantes e seletores estruturais permanecem neutros.

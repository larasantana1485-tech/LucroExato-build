# R8 — correções da auditoria R7

## Matemática
- Somatório dos insumos usa precisão subcentavo e arredonda uma vez no total.
- Preço sugerido do lote deriva do preço unitário praticável, evitando R$ 5,55 x 24 divergir do total.
- Margem e markup continuam conceitos separados.

## Preço
- `priceMode` diferencia explicitamente SUGGESTED e MANUAL.
- Receitas migradas de versões antigas assumem MANUAL por segurança, evitando alteração automática de preço já conhecido.
- Ao mexer na margem/markup na edição, o modo volta para SUGGESTED.

## Simulação
- Manter alvo respeita MARGIN ou MARKUP da receita.
- Teste rápido da receita salva tem três modos: Margem, Markup e Preço.

## Dados
- Backup restaurado é recalculado no motor atual antes da transação terminar.
- Rascunho antigo é limpo após restauração bem-sucedida.
- Mudança de dimensão incompatível em insumo em uso é bloqueada.
- Nomes de insumos/sub-receitas sincronizam no recálculo.
- Sub-receitas permitem editar quantidade diretamente.

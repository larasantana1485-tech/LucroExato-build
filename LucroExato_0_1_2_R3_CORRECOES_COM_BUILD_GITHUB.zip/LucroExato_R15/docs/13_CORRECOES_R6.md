# 13. Correções R6

## Navegação e identidade

- removida a navegação inferior de duas opções;
- adicionadas tabs superiores `Receitas` e `Insumos`;
- engrenagem realinhada com o título;
- ícone redesenhado com fouet inclinado claramente reconhecível + gráfico de crescimento;
- stepper diferencia etapas concluídas, atual e futuras.

## Motor matemático

- custo unitário exato mantido como `Double` até a precificação;
- centavos são arredondados apenas na fronteira de exibição/persistência;
- preço sugerido da receita é calculado a partir do preço exato, não de preço unitário previamente arredondado;
- margem, markup e lucro usam o mesmo motor em Resultado, Detalhe e Simulação;
- taxas entram corretamente no lucro/margem;
- markup passa a significar acréscimo sobre custo de produção;
- sub-receitas usam custo unitário derivado de custo total / rendimento vendável.

## Entrada numérica

- `1,5` e `1.5` são aceitos corretamente;
- conversão monetária usa HALF_UP;
- operadores do teclado são rejeitados;
- números inteiros não exibem `,0`;
- dinheiro mantém duas casas.

## Resultado e simulação

- Resultado salvo ganhou “Teste rápido de preço” sem editar a receita;
- simulação de custos permite escolher `Manter preço` ou `Manter margem`;
- comparação atual × simulação usa conceitos equivalentes;
- diferença de custo/preço/lucro/margem aparece explicitamente;
- preço atual do insumo aparece junto da embalagem de compra;
- IME/teclado tratado para não encobrir a leitura dos resultados.

## Insumos e embalagens

- texto alterado para quantidade total usada na receita;
- aviso contextual para embalagem/adesivo/fecho informado como 1 em receitas com rendimento maior;
- atalho para usar o rendimento como quantidade total;
- aviso para custo legado de embalagem evitar dupla contagem;
- cards compactados mantendo cores.

## Integridade

- bloqueio de ciclos de sub-receitas;
- dropdowns com altura máxima;
- novos testes para precisão, taxas, margem, markup, perda, conversões, parser e formatação.

## Correções adicionais da auditoria final

- preço sugerido usa teto ao centavo quando necessário para não ficar abaixo da margem/markup alvo;
- histórico de preços preservado ao editar insumo (`@Upsert` em vez de `REPLACE` no pai);
- histórico só ganha nova linha quando a compra realmente muda;
- alteração de insumo recalcula automaticamente receitas e sub-receitas dependentes;
- exclusão de receita-base é bloqueada quando ela ainda é usada como sub-receita;
- aba principal selecionada é preservada ao abrir/voltar de detalhes;
- erros de simulação ficam visíveis em vez de falhar silenciosamente;
- pluralização e exibição de rendimento corrigidas;
- campos de preço/margem mostram feedback calculado junto ao campo para continuar legível com o teclado aberto.

# R14 — três mudanças de 25/09 + correção da piscada na Home

## 1. Rendimento e escala
- remove o custo total repetido da sanfona;
- quando rendimento informado e vendável são iguais, mostra apenas “Rendimento atual”;
- “Multiplicador (×)” deixa de ser o campo principal e vira cálculo derivado;
- novo campo “Quantidade desejada (unidade)”;
- atalhos 0,5× / 1× / 1,5× / 2× preenchem a quantidade desejada;
- mostra equivalência em × quando diferente de 1×;
- mostra novo rendimento e custo estimado da escala;
- mostra 3 quantidades recalculadas imediatamente;
- “Ver todas as quantidades” abre uma tela cheia simples, sem sanfona dentro de sanfona;
- “Simular custos e rendimento” passa a se chamar “Simular mudanças”.

## 2. Etapa 4 — Resultado simples
- remove edição de preço, Margem/Markup, atalhos percentuais e campos de percentual da Etapa 4;
- mantém somente custo total, rendimento, custo por unidade, preço inicial sugerido, faturamento estimado, lucro estimado e lucro por unidade;
- preço de referência usa margem de 50% através do CostCalculator, inclusive taxas do motor;
- a referência é apenas informativa: não altera silenciosamente o preço já salvo de uma receita em edição;
- mantém aviso compacto para custos importantes ausentes e atalho “Revisar”;
- informa que preço, margem e markup podem ser ajustados depois na Ficha Técnica.

## 3. Resumo fixo na Ficha Técnica
- as sanfonas permanecem;
- quando o card “Preço e lucro” sai completamente da área visível, aparece uma faixa compacta com Custo/unidade, Venda e Margem real;
- a faixa some ao voltar para o card principal;
- não há cards/abas deslizáveis nesta revisão.

## 4. Bug de inicialização / piscada da Home
- o recálculo inicial de todas as receitas passa a ocorrer em uma única transação Room para impedir emissões intermediárias;
- o StateFlow de receitas passa a coletar de forma eager durante a inicialização;
- a Home só é liberada quando o StateFlow usado pela UI contém os mesmos totais finais do snapshot pós-recálculo;
- isso corrige o frame em que o card salvo aparecia com dados antigos/estranhos antes de voltar aos valores corretos.

## Fora de escopo
- motor CostCalculator não alterado;
- ícone não alterado;
- sanfonas não substituídas por swipe/abas;
- Planejar produção continua ideia futura.

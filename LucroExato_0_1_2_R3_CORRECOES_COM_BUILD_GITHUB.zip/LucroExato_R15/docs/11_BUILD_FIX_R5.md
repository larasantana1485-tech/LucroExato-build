# R5 — correção de compilação

Corrigido erro `Unresolved reference: matchParentSize` em `Components.kt`.

O `SelectionField` agora usa `Modifier.fillMaxWidth().height(56.dp)` no `Surface`, preservando o alinhamento e a altura fixa dos seletores de unidade sem depender de `matchParentSize`.

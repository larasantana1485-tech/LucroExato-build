$ErrorActionPreference = "Stop"
$Version = "8.13"
$ExpectedSha256 = "20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78"
$Base = if ($env:GRADLE_USER_HOME) { Join-Path $env:GRADLE_USER_HOME "bootstrap" } else { Join-Path $env:USERPROFILE ".gradle\bootstrap" }
$HomeDir = Join-Path $Base "gradle-$Version"
$Zip = Join-Path $Base "gradle-$Version-bin.zip"
$Part = "$Zip.part"
$Url = "https://services.gradle.org/distributions/gradle-$Version-bin.zip"
$GradleBat = Join-Path $HomeDir "bin\gradle.bat"

if (-not (Test-Path $GradleBat)) {
    New-Item -ItemType Directory -Force -Path $Base | Out-Null
    Remove-Item -Force -ErrorAction SilentlyContinue $Part
    Write-Host "Baixando Gradle $Version..."
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Part
    $Actual = (Get-FileHash $Part -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $ExpectedSha256) {
        Remove-Item -Force -ErrorAction SilentlyContinue $Part
        throw "Checksum do Gradle invalido. Download descartado."
    }
    Move-Item -Force $Part $Zip
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $HomeDir
    Expand-Archive -Path $Zip -DestinationPath $Base -Force
    if (-not (Test-Path $GradleBat)) { throw "A distribuicao do Gradle nao foi extraida corretamente." }
}

Write-Output $GradleBat

# Lucro Exato 0.1.13 R14

R14 implementa as três mudanças fechadas em 25/09/2026 e reforça a correção da piscada na Home.

## Mudanças principais
- **Rendimento e escala:** quantidade desejada vira o controle principal; atalhos × continuam; custo estimado e 3 quantidades são atualizados imediatamente; lista completa abre em tela própria.
- **Etapa 4:** agora é uma tela simples de resultado com custo, rendimento, preço inicial sugerido por margem de referência de 50%, faturamento e lucro. Margem/Markup interativos ficam na Ficha Técnica.
- **Ficha Técnica:** ao rolar além de “Preço e lucro”, uma faixa compacta mantém Custo, Venda e Margem visíveis; as sanfonas continuam.
- **Inicialização:** Home aguarda o snapshot final recalculado e o recálculo ocorre numa transação única para eliminar a piscada com totais antigos.

O `CostCalculator` e o ícone oficial não foram alterados.

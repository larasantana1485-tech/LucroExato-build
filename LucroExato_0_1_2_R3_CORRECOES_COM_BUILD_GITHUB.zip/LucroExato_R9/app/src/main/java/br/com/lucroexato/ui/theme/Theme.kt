package br.com.lucroexato.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val AppBackground = Color(0xFFFAF8F5)
val Surface = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1F1F22)
val TextSecondary = Color(0xFF6E6A73)
val Pink = Color(0xFFE84B8A)
val PinkDark = Color(0xFFD93B7D)
val PinkSoft = Color(0xFFFBE8F1)
val Lavender = Color(0xFFECE4FF)
val Mint = Color(0xFFE1F6E8)
val Peach = Color(0xFFFFECD8)
val BlueSoft = Color(0xFFE1EDFF)
val YellowSoft = Color(0xFFFFF4CC)
val Green = Color(0xFF138A5B)
val Outline = Color(0xFFE7E1DA)

private val Colors = lightColorScheme(
    primary = Pink,
    onPrimary = Color.White,
    primaryContainer = PinkSoft,
    onPrimaryContainer = PinkDark,
    secondary = Color(0xFF7A5AB8),
    onSecondary = Color.White,
    secondaryContainer = Lavender,
    background = AppBackground,
    onBackground = TextPrimary,
    surface = Surface,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFFF8F3F2),
    onSurfaceVariant = TextSecondary,
    outline = Outline,
    error = Color(0xFFB3261E)
)

private val AppTypography = Typography(
    headlineSmall = TextStyle(fontSize = 23.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 19.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(12.dp),
    extraLarge = RoundedCornerShape(14.dp)
)

@Composable
fun LucroExatoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, typography = AppTypography, shapes = AppShapes, content = content)
}

package br.com.lucroexato.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Pink

val AppFieldShape = RoundedCornerShape(12.dp)
val AppButtonShape = RoundedCornerShape(14.dp)
val AppCardShape = RoundedCornerShape(14.dp)

val SupplyCategories = listOf(
    "Chocolates e coberturas",
    "Farinhas e amidos",
    "Açúcares e adoçantes",
    "Leites e derivados",
    "Gorduras e óleos",
    "Ovos e derivados",
    "Frutas e derivados",
    "Castanhas e sementes",
    "Coco",
    "Recheios e pastas",
    "Aromas, extratos e bebidas",
    "Corantes e aditivos",
    "Embalagens",
    "Outros"
)

@Composable
fun CompactTopBar(title: String, onBack: (() -> Unit)? = null, action: (@Composable () -> Unit)? = null) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Voltar") }
        }
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        action?.invoke()
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun InfoCard(modifier: Modifier = Modifier, tint: Color = MaterialTheme.colorScheme.surface, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = tint),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() } }
}

@Composable
fun StepIndicator(current: Int, labels: List<String>) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        labels.forEachIndexed { index, label ->
            val step = index + 1
            val completed = step < current
            val selected = step == current
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val background = when {
                    selected -> Pink
                    completed -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                val foreground = when {
                    selected -> Color.White
                    completed -> Pink
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Surface(shape = CircleShape, color = background, modifier = Modifier.size(28.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        if (completed) Icon(Icons.Outlined.Check, null, tint = foreground, modifier = Modifier.size(17.dp))
                        else Text("$step", color = foreground, fontWeight = FontWeight.Bold)
                    }
                }
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected || completed) Pink else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }
    }
}

/** Numeric/money field used throughout the app. Tapping the value selects it all. */
@Composable
fun SmartNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    prefix: String? = null,
    suffix: String? = null,
    supportingText: String? = null,
    integerOnly: Boolean = false
) {
    var field by remember { mutableStateOf(TextFieldValue(value)) }
    LaunchedEffect(value) {
        if (field.text != value) field = TextFieldValue(value, TextRange(value.length))
    }
    OutlinedTextField(
        value = field,
        onValueChange = { changed ->
            val filtered = sanitizeNumericInput(changed.text, integerOnly)
            val normalized = TextFieldValue(filtered, TextRange(filtered.length))
            field = normalized
            onValueChange(normalized.text)
        },
        modifier = modifier.onFocusChanged { focus ->
            if (focus.isFocused && field.text.isNotEmpty()) field = field.copy(selection = TextRange(0, field.text.length))
        },
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        prefix = prefix?.let { { Text(it) } },
        suffix = suffix?.let { { Text(it) } },
        supportingText = supportingText?.let { { Text(it) } },
        keyboardOptions = KeyboardOptions(keyboardType = if (integerOnly) KeyboardType.Number else KeyboardType.Decimal),
        singleLine = true,
        shape = AppFieldShape
    )
}

/** Neutral dropdown field. Units are always selected, never typed manually. */
@Composable
fun SelectionField(
    value: String,
    options: List<String>,
    label: String,
    modifier: Modifier = Modifier,
    onChange: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier.defaultMinSize(minHeight = 56.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth().height(56.dp).clickable { expanded = true },
            shape = AppFieldShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, Outline)
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    Text(value, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Outlined.ArrowDropDown, contentDescription = "Escolher $label")
            }
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.widthIn(min = 120.dp, max = 280.dp).heightIn(max = 300.dp),
            shape = AppFieldShape,
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            border = BorderStroke(1.dp, Outline)
        ) {
            options.distinct().forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    onClick = { onChange(option); expanded = false }
                )
            }
        }
    }
}

@Composable
fun HelpTip(text: String) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { expanded = true }, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Outlined.HelpOutline, contentDescription = "Ajuda", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.widthIn(min = 120.dp, max = 280.dp).heightIn(max = 300.dp),
            shape = AppFieldShape,
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            border = BorderStroke(1.dp, Outline)
        ) {
            Box(Modifier.padding(horizontal = 14.dp, vertical = 10.dp).widthIn(max = 280.dp)) {
                Text(text, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun SummaryCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        modifier,
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = color),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, fontWeight = FontWeight.Bold, color = if (label.contains("Preço")) Green else valueColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

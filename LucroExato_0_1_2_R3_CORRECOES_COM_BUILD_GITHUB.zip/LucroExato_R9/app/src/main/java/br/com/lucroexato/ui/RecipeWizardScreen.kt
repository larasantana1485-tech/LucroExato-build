package br.com.lucroexato.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.RecipeDraft
import br.com.lucroexato.ui.theme.BlueSoft
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Mint
import br.com.lucroexato.ui.theme.Peach
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import br.com.lucroexato.ui.theme.PinkSoft
import br.com.lucroexato.ui.theme.YellowSoft
import kotlin.math.roundToLong

@Composable
fun RecipeWizardScreen(modifier: Modifier, vm: AppViewModel, onClose: () -> Unit, onSaved: (Long) -> Unit) {
    val draft by vm.draft.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    var askDiscard by remember { mutableStateOf(false) }

    fun requestClose() {
        if (draft.dirty) askDiscard = true else onClose()
    }
    BackHandler { if (draft.step > 1) vm.previousStep() else requestClose() }

    Scaffold(
        modifier = modifier,
        topBar = {
            Column {
                CompactTopBar(if (draft.editingRecipeId == null) "Nova receita" else "Editar receita") {
                    IconButton(onClick = ::requestClose) { Icon(Icons.Outlined.Close, "Fechar") }
                }
                StepIndicator(draft.step, listOf("Dados", "Insumos", "Custos", "Resultado"))
                Spacer(Modifier.height(8.dp))
            }
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (draft.step > 1) OutlinedButton(
                    onClick = { vm.previousStep() },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = AppButtonShape
                ) { Text("Voltar", maxLines = 1) }
                Button(
                    onClick = { if (draft.step < 4) vm.nextStep() else vm.saveRecipe(onSaved) },
                    modifier = Modifier.weight(1f).height(50.dp),
                    shape = AppButtonShape
                ) { Text(if (draft.step < 4) "Próximo" else "Salvar receita", maxLines = 1) }
            }
        }
    ) { inner ->
        when (draft.step) {
            1 -> RecipeDataStep(Modifier.padding(inner).imePadding(), draft, vm)
            2 -> RecipeIngredientsStep(Modifier.padding(inner).imePadding(), draft, catalog, recipes, vm)
            3 -> RecipeCostsStep(Modifier.padding(inner).imePadding(), draft, vm)
            else -> RecipeResultStep(Modifier.padding(inner), draft, catalog, vm)
        }
    }

    if (askDiscard) AlertDialog(
        onDismissRequest = { askDiscard = false },
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text("Sair da receita?") },
        text = { Text("O rascunho já está salvo e aparecerá na tela inicial para você continuar depois.") },
        confirmButton = { TextButton(onClick = { askDiscard = false; onClose() }) { Text("Continuar depois") } },
        dismissButton = { TextButton(onClick = { vm.discardDraft(); askDiscard = false; onClose() }) { Text("Descartar") } }
    )
}

@Composable
private fun RecipeDataStep(modifier: Modifier, draft: RecipeDraft, vm: AppViewModel) {
    val categories = listOf("Bolos", "Doces", "Tortas", "Cookies", "Pães", "Salgados", "Sobremesas", "Bebidas", "Outros")
    var yieldText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.yieldQuantity == 0.0) "" else number(draft.yieldQuantity)) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SectionTitle("Dados da receita", "O nome e o rendimento são obrigatórios.") }
        item {
            OutlinedTextField(
                draft.name,
                { value -> vm.updateDraft { it.copy(name = value) } },
                Modifier.fillMaxWidth(),
                shape = AppFieldShape,
                label = { Text("Nome da receita *", maxLines = 1) },
                placeholder = { Text("Ex.: Pão de Mel Tradicional", maxLines = 1) },
                singleLine = true
            )
        }
        item { Text("Categoria *", fontWeight = FontWeight.SemiBold) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { item -> FilterChip(draft.category == item, { vm.updateDraft { it.copy(category = item) } }, label = { Text(item, maxLines = 1) }) } } }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Top
            ) {
                SmartNumberField(
                    value = yieldText,
                    onValueChange = { text -> yieldText = text; vm.updateDraft { it.copy(yieldQuantity = parseDecimal(text) ?: 0.0) } },
                    label = "Rendimento *",
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                SelectionField(
                    value = draft.yieldUnit,
                    options = listOf("un", "g", "kg", "ml", "l"),
                    label = "Unidade",
                    modifier = Modifier.weight(0.62f).fillMaxHeight()
                ) { value -> vm.updateDraft { it.copy(yieldUnit = value) } }
            }
        }
        item {
            OutlinedTextField(
                value = draft.preparation,
                onValueChange = { value -> vm.updateDraft { it.copy(preparation = value) } },
                modifier = Modifier.fillMaxWidth(),
                shape = AppFieldShape,
                label = { Text("Modo de preparo (opcional)") },
                placeholder = { Text("Ex.: Misture os secos, adicione os líquidos e asse...") },
                minLines = 3,
                maxLines = 6
            )
        }
        item {
            InfoCard(tint = PinkSoft) {
                Text("Rascunho automático", fontWeight = FontWeight.SemiBold, color = Pink)
                Text("Se você sair, esta receita aparece na tela inicial para continuar depois.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RecipeIngredientsStep(
    modifier: Modifier,
    draft: RecipeDraft,
    catalog: List<IngredientEntity>,
    recipes: List<RecipeWithDetails>,
    vm: AppViewModel
) {
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<IngredientEntity?>(null) }
    var selectedDraftIndex by remember { mutableStateOf<Int?>(null) }
    var category by remember { mutableStateOf("Todos") }
    var selectedSubRecipe by remember { mutableStateOf<RecipeWithDetails?>(null) }
    var selectedSubRecipeDraftIndex by remember { mutableStateOf<Int?>(null) }
    var showCatalogSheet by remember { mutableStateOf(false) }

    val categories = listOf("Todos", "Embalagens") +
        (SupplyCategories + catalog.map { it.category }).distinct().filterNot { it == "Embalagens" }
    val filtered = catalog.filter {
        (category == "Todos" || it.category == category) && it.name.contains(search, true)
    }
    val availableSubRecipes = recipes.filter {
        it.recipe.id != draft.editingRecipeId &&
            !wouldCreateSubRecipeCycle(draft.editingRecipeId, it.recipe.id, recipes) &&
            category == "Todos" &&
            (search.isBlank() || it.recipe.name.contains(search, ignoreCase = true))
    }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            SectionTitle(
                "Insumos da receita",
                "Adicione ingredientes, embalagens e consumíveis usados nesta produção."
            )
        }
        item {
            OutlinedButton(
                onClick = {
                    search = ""
                    category = "Todos"
                    showCatalogSheet = true
                },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = androidx.compose.foundation.shape.CircleShape
            ) {
                Icon(Icons.Outlined.Add, null)
                Spacer(Modifier.size(6.dp))
                Text("Adicionar insumos", maxLines = 1)
            }
        }

        if (draft.ingredients.isEmpty()) {
            item {
                Text(
                    "Nenhum insumo adicionado ainda.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            item {
                Text(
                    "Adicionados (${draft.ingredients.size})",
                    fontWeight = FontWeight.SemiBold
                )
            }
            items(draft.ingredients.indices.toList()) { index ->
                val item = draft.ingredients[index]
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        when {
                            item.ingredientId != null -> catalog.firstOrNull { it.id == item.ingredientId }?.let {
                                selected = it
                                selectedDraftIndex = index
                            }
                            item.sourceRecipeId != null -> recipes.firstOrNull { it.recipe.id == item.sourceRecipeId }?.let {
                                selectedSubRecipe = it
                                selectedSubRecipeDraftIndex = index
                            }
                        }
                    },
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = Mint),
                    border = BorderStroke(1.dp, Outline),
                    elevation = CardDefaults.cardElevation(0.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.name,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "${number(item.quantity)} ${item.unit} • ${money(item.costCents)}",
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (item.ingredientId != null || item.sourceRecipeId != null) {
                            Icon(
                                Icons.Outlined.Edit,
                                "Editar",
                                tint = Pink,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        IconButton(onClick = { vm.removeDraftIngredient(index) }, modifier = Modifier.size(44.dp)) {
                            Icon(Icons.Outlined.DeleteOutline, "Remover")
                        }
                    }
                }
            }
        }
    }

    if (showCatalogSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showCatalogSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            dragHandle = null
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.64f)
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Adicionar insumos",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showCatalogSheet = false }) {
                        Icon(Icons.Outlined.Close, "Fechar")
                    }
                }

                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    shape = AppFieldShape,
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    placeholder = { Text("Buscar insumos...", maxLines = 1) },
                    singleLine = true
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { value ->
                        FilterChip(
                            selected = category == value,
                            onClick = { category = value },
                            label = { Text(value, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 8.dp)
                ) {
                    if (filtered.isEmpty() && availableSubRecipes.isEmpty()) {
                        item {
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    if (search.isBlank()) "Nenhum insumo nesta categoria." else "Nenhum insumo encontrado para “${search.trim()}”.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (search.isNotBlank()) {
                                    OutlinedButton(
                                        onClick = {
                                            val initialCategory = if (category == "Todos") "Outros" else category
                                            selectedDraftIndex = null
                                            selected = IngredientEntity(
                                                name = search.trim(),
                                                category = initialCategory,
                                                packagePriceCents = 0,
                                                packageQuantity = 1.0,
                                                packageUnit = if (initialCategory == "Embalagens") "un" else "kg"
                                            )
                                            showCatalogSheet = false
                                        },
                                        modifier = Modifier.fillMaxWidth().height(44.dp),
                                        shape = androidx.compose.foundation.shape.CircleShape
                                    ) {
                                        Icon(Icons.Outlined.Add, null)
                                        Spacer(Modifier.size(6.dp))
                                        Text("Criar insumo", maxLines = 1)
                                    }
                                }
                            }
                        }
                    } else {
                        items(filtered, key = { it.id }) { item ->
                            Card(
                                Modifier.fillMaxWidth().clickable {
                                    selectedDraftIndex = null
                                    selected = item
                                    showCatalogSheet = false
                                },
                                shape = AppCardShape,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, Outline),
                                elevation = CardDefaults.cardElevation(0.dp)
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            item.name,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "${item.category} • ${money(item.packagePriceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}",
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Icon(Icons.Outlined.Add, "Adicionar", tint = Pink)
                                }
                            }
                        }

                        if (availableSubRecipes.isNotEmpty()) {
                            item {
                                Text(
                                    "Sub-receitas",
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            items(availableSubRecipes, key = { "sub-${it.recipe.id}" }) { item ->
                                OutlinedButton(
                                    onClick = {
                                        selectedSubRecipeDraftIndex = null
                                        selectedSubRecipe = item
                                        showCatalogSheet = false
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = AppButtonShape
                                ) {
                                    Text(
                                        "${item.recipe.name} • ${money(item.recipe.costPerUnitCents)}/${item.recipe.yieldUnit}",
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    selected?.let { item ->
        val used = selectedDraftIndex?.let { draft.ingredients.getOrNull(it) }
        IngredientPurchaseScreen(
            item = item,
            initialUsedQuantity = used?.quantity,
            initialUsedUnit = used?.unit,
            editing = selectedDraftIndex != null,
            recipeYield = draft.yieldQuantity,
            onDismiss = { selected = null; selectedDraftIndex = null },
            onSave = { updated, price, packageQuantity, packageUnit, usedQuantity, usedUnit ->
                vm.saveAndUseIngredient(
                    ingredient = updated,
                    packagePriceCents = price,
                    packageQuantity = packageQuantity,
                    packageUnit = packageUnit,
                    usedQuantity = usedQuantity,
                    usedUnit = usedUnit,
                    draftIndex = selectedDraftIndex
                ) {
                    selected = null
                    selectedDraftIndex = null
                }
            }
        )
    }

    selectedSubRecipe?.let { item ->
        val editingIndex = selectedSubRecipeDraftIndex
        val existingQuantity = editingIndex?.let { draft.ingredients.getOrNull(it)?.quantity }
        SubRecipeQuantityDialog(
            item = item,
            initialQuantity = existingQuantity,
            editing = editingIndex != null,
            onDismiss = { selectedSubRecipe = null; selectedSubRecipeDraftIndex = null }
        ) { quantity ->
            val saved = if (editingIndex != null) vm.updateSubRecipe(editingIndex, item, quantity) else vm.addSubRecipe(item, quantity)
            if (saved) { selectedSubRecipe = null; selectedSubRecipeDraftIndex = null }
        }
    }
}

@Composable
private fun IngredientPurchaseScreen(
    item: IngredientEntity,
    initialUsedQuantity: Double?,
    initialUsedUnit: String?,
    editing: Boolean,
    recipeYield: Double,
    onDismiss: () -> Unit,
    onSave: (IngredientEntity, Long, Double, String, Double, String) -> Unit
) {
    var name by remember(item.id) { mutableStateOf(item.name) }
    var category by remember(item.id) { mutableStateOf(item.category) }
    var price by remember(item.id) { mutableStateOf(if (item.packagePriceCents > 0) moneyInput(item.packagePriceCents) else "") }
    var packageQuantity by remember(item.id) { mutableStateOf(if (item.packageQuantity > 0) number(item.packageQuantity) else "") }
    var packageUnit by remember(item.id) { mutableStateOf(item.packageUnit) }
    var usedQuantity by remember(item.id, initialUsedQuantity) { mutableStateOf(initialUsedQuantity?.let(::number) ?: "") }
    var usedUnit by remember(item.id, initialUsedUnit) { mutableStateOf(initialUsedUnit ?: defaultUsedUnit(item.packageUnit)) }
    var error by remember { mutableStateOf<String?>(null) }
    val priceCents = parseMoneyCents(price)
    val bought = parseDecimal(packageQuantity)
    val used = parseDecimal(usedQuantity)
    val preview = if (priceCents != null && bought != null && used != null && bought > 0 && used > 0) {
        runCatching { br.com.lucroexato.domain.CostCalculator.ingredientCostExactCents(priceCents, bought, packageUnit, used, usedUnit).roundToLong() }.getOrNull()
    } else null

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { CompactTopBar(if (editing) "Editar insumo" else "Adicionar insumo", onDismiss) },
                bottomBar = {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text("Cancelar") }
                        Button(onClick = {
                            error = when {
                                name.isBlank() -> "Informe o nome do insumo."
                                priceCents == null || priceCents <= 0 -> "Informe o preço pago."
                                bought == null || bought <= 0 -> "Informe a quantidade comprada."
                                used == null || used <= 0 -> "Informe a quantidade usada."
                                preview == null -> "As unidades da compra e do uso precisam ser compatíveis."
                                else -> null
                            }
                            if (error == null) onSave(item.copy(name = name.trim(), category = category.trim().ifBlank { "Outros" }), priceCents!!, bought!!, packageUnit, used!!, usedUnit)
                        }, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text(if (editing) "Salvar" else "Adicionar", maxLines = 1) }
                    }
                }
            ) { inner ->
                Column(
                    Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (item.id == 0L) {
                        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Nome do insumo *", maxLines = 1) }, singleLine = true)
                        SelectionField(category, SupplyCategories, "Categoria", Modifier.fillMaxWidth()) { selectedCategory ->
                            category = selectedCategory
                            if (selectedCategory == "Embalagens") {
                                packageUnit = "un"
                                usedUnit = "un"
                            }
                        }
                    } else {
                        Text(name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    SectionTitle("Compra", "Use o valor que você realmente pagou.")
                    SmartNumberField(price, { price = it }, "Preço pago *", Modifier.fillMaxWidth(), prefix = "R$ ")
                    Row(
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        SmartNumberField(packageQuantity, { packageQuantity = it }, "Qtd. comprada *", Modifier.weight(1f).fillMaxHeight())
                        SelectionField(packageUnit, listOf("kg", "g", "mg", "l", "ml", "un"), "Unidade", Modifier.weight(0.62f).fillMaxHeight()) { value ->
                            packageUnit = value
                            usedUnit = defaultUsedUnit(value)
                        }
                    }
                    val packagingLike = isPackagingLike(name, category)
                    SectionTitle(
                        "Uso nesta receita",
                        if (packagingLike)
                            "Informe o total usado para produzir todo o rendimento. Ex.: rende 24 e usa 1 por unidade → informe 24."
                        else
                            "Informe a quantidade total deste insumo usada na produção."
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        SmartNumberField(usedQuantity, { usedQuantity = it }, "Qtd. total usada *", Modifier.weight(1f).fillMaxHeight())
                        SelectionField(usedUnit, compatibleUnits(packageUnit), "Unidade", Modifier.weight(0.62f).fillMaxHeight()) { usedUnit = it }
                    }
                    if (packagingLike && recipeYield > 1.0 && used != null && kotlin.math.abs(used - 1.0) < 0.0001) {
                        InfoCard(tint = YellowSoft) {
                            Text("Confira a quantidade", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Esta receita rende ${number(recipeYield)} ${if (recipeYield == 1.0) "unidade" else "unidades"}. Se você usa 1 $name em cada unidade, o total usado é ${number(recipeYield)}.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            TextButton(onClick = { usedQuantity = number(recipeYield) }) {
                                Text("Usar ${number(recipeYield)} no total")
                            }
                        }
                    }
                    InfoCard(tint = if (preview == null) PinkSoft else Mint) {
                        ResultRow("Custo na receita", preview?.let(::money) ?: "Preencha os valores")
                        if (preview != null) Text("${money(priceCents!!)} ÷ ${number(bought!!)} $packageUnit × ${number(used!!)} $usedUnit", style = MaterialTheme.typography.bodySmall)
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}



private fun wouldCreateSubRecipeCycle(editingRecipeId: Long?, candidateId: Long, recipes: List<RecipeWithDetails>): Boolean {
    val target = editingRecipeId ?: return false
    val byId = recipes.associateBy { it.recipe.id }
    fun dependsOn(recipeId: Long, soughtId: Long, visited: MutableSet<Long>): Boolean {
        if (!visited.add(recipeId)) return false
        val recipe = byId[recipeId] ?: return false
        return recipe.ingredients.any { used ->
            val source = used.sourceRecipeId ?: return@any false
            source == soughtId || dependsOn(source, soughtId, visited)
        }
    }
    return candidateId == target || dependsOn(candidateId, target, mutableSetOf())
}

private fun isPackagingLike(name: String, category: String): Boolean {
    if (category.contains("embal", ignoreCase = true)) return true
    val normalized = name.lowercase()
    return listOf("embal", "saquinho", "saco", "caixa", "adesivo", "etiqueta", "fecho", "lacre", "fitilho", "fita").any { normalized.contains(it) }
}

private fun compatibleUnits(unit: String) = when (unit) {
    "kg", "g", "mg" -> listOf("kg", "g", "mg")
    "l", "ml" -> listOf("l", "ml")
    else -> listOf("un")
}

private fun defaultUsedUnit(unit: String) = when (unit) {
    "kg", "g", "mg" -> "g"
    "l", "ml" -> "ml"
    else -> "un"
}

@Composable
private fun SubRecipeQuantityDialog(
    item: RecipeWithDetails,
    initialQuantity: Double? = null,
    editing: Boolean = false,
    onDismiss: () -> Unit,
    onAdd: (Double) -> Unit
) {
    var quantity by remember(item.recipe.id, initialQuantity) { mutableStateOf(initialQuantity?.let(::number) ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text(if (editing) "Editar ${item.recipe.name}" else "Usar ${item.recipe.name}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = { SmartNumberField(quantity, { quantity = it }, "Quantidade em ${item.recipe.yieldUnit}", Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { parseDecimal(quantity)?.takeIf { it > 0 }?.let(onAdd) }) { Text(if (editing) "Salvar" else "Adicionar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun RecipeCostsStep(modifier: Modifier, draft: RecipeDraft, vm: AppViewModel) {
    var addExtra by remember { mutableStateOf(false) }
    var lossText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.lossPercent)) }
    var laborText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.laborMinutes == 0) "" else draft.laborMinutes.toString()) }
    var hourlyText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.hourlyRateCents == 0L) "" else moneyInput(draft.hourlyRateCents)) }
    var feeText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.variableFeePercent)) }
    var fixedFeeText by remember(draft.editingRecipeId) { mutableStateOf(if (draft.fixedFeePerUnitCents == 0L) "" else moneyInput(draft.fixedFeePerUnitCents)) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionTitle("Rendimento e custos", "Preencha somente o que fizer parte da sua produção.") }
        item { SmartNumberField(lossText, { text -> lossText = text; vm.updateDraft { it.copy(lossPercent = (parseDecimal(text) ?: 0.0).coerceIn(0.0, 99.99)) } }, "Perda estimada (%)", Modifier.fillMaxWidth(), supportingText = "Ex.: itens quebrados ou que não podem ser vendidos.") }
        item { SectionTitle("Mão de obra", "Informe quanto tempo você trabalha e quanto vale sua hora.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartNumberField(laborText, { text -> laborText = text.filter(Char::isDigit); vm.updateDraft { it.copy(laborMinutes = laborText.toIntOrNull() ?: 0) } }, "Tempo (min)", Modifier.weight(1f), integerOnly = true)
                SmartNumberField(hourlyText, { text -> hourlyText = text; vm.updateDraft { it.copy(hourlyRateCents = parseMoneyCents(text) ?: 0) } }, "Valor/hora", Modifier.weight(1f), prefix = "R$ ")
            }
        }
        item { SectionTitle("Taxas de venda", "Deixe zero se você vende sem taxa.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmartNumberField(feeText, { text -> feeText = text; vm.updateDraft { it.copy(variableFeePercent = parseDecimal(text) ?: 0.0) } }, "Taxa (%)", Modifier.weight(1f))
                SmartNumberField(fixedFeeText, { text -> fixedFeeText = text; vm.updateDraft { it.copy(fixedFeePerUnitCents = parseMoneyCents(text) ?: 0) } }, "Taxa fixa/un.", Modifier.weight(1f), prefix = "R$ ")
            }
        }
        item {
            InfoCard {
                Text("Embalagens entram como insumo", fontWeight = FontWeight.SemiBold, color = Pink)
                Text("Cadastre saquinhos, caixas, etiquetas, fechos e outros consumíveis na etapa Insumos. Informe o total usado na receita.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (draft.packagingPerUnitCents > 0L) {
            item {
                InfoCard(tint = YellowSoft) {
                    Text("Custo antigo de embalagem detectado", fontWeight = FontWeight.SemiBold)
                    Text("Há ${money(draft.packagingPerUnitCents)} por unidade além dos insumos. Se você já cadastrou a embalagem como insumo, remova este valor para não contar duas vezes.", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.updateDraft { it.copy(packagingPerUnitCents = 0L) } }) { Text("Remover custo antigo") }
                }
            }
        }
        item { SectionTitle("Outros custos", "Gás, energia, transporte e outros.") }
        items(draft.extras.indices.toList()) { index ->
            val item = draft.extras[index]
            Card(
                colors = CardDefaults.cardColors(containerColor = Peach),
                border = BorderStroke(1.dp, Outline),
                shape = AppCardShape,
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.description, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${money(item.valueCents)} • ${if (item.application == "PER_UNIT") "por unidade" else "na receita inteira"}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    IconButton(onClick = { vm.removeExtraCost(index) }) { Icon(Icons.Outlined.DeleteOutline, "Remover") }
                }
            }
        }
        item { OutlinedButton(onClick = { addExtra = true }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) { Icon(Icons.Outlined.Add, null); Spacer(Modifier.size(6.dp)); Text("Adicionar outro custo", maxLines = 1) } }
    }
    if (addExtra) ExtraCostEditor(onDismiss = { addExtra = false }) { type, description, cents, perUnit -> vm.addExtraCost(type, description, cents, perUnit); addExtra = false }
}

@Composable
private fun ExtraCostEditor(onDismiss: () -> Unit, onAdd: (String, String, Long, Boolean) -> Unit) {
    var type by remember { mutableStateOf("Energia/Gás") }
    var description by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var perUnit by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { CompactTopBar("Adicionar custo", onDismiss) },
                bottomBar = {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(50.dp), shape = AppButtonShape) { Text("Cancelar") }
                        Button(
                            onClick = {
                                val cents = parseMoneyCents(value)
                                if (description.isNotBlank() && cents != null && cents >= 0) onAdd(type, description.trim(), cents, perUnit)
                            },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = AppButtonShape
                        ) { Text("Adicionar") }
                    }
                }
            ) { inner ->
                Column(Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionTitle("Tipo de custo", "Escolha a categoria que melhor descreve o gasto.")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf("Energia/Gás", "Transporte", "Taxa", "Outros")) { item ->
                            FilterChip(type == item, { type = item }, label = { Text(item, maxLines = 1) })
                        }
                    }
                    OutlinedTextField(description, { description = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Descrição *", maxLines = 1) }, placeholder = { Text("Ex.: gás do forno", maxLines = 1) }, singleLine = true)
                    SmartNumberField(value, { value = it }, "Valor *", Modifier.fillMaxWidth(), prefix = "R$ ")
                    SectionTitle("Aplicar o custo")
                    Card(
                        Modifier.fillMaxWidth().clickable { perUnit = false },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Outline),
                        shape = AppCardShape
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(!perUnit, { perUnit = false })
                            Column { Text("Na receita inteira", maxLines = 1); Text("Ex.: gás e energia do preparo", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                    Card(
                        Modifier.fillMaxWidth().clickable { perUnit = true },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Outline),
                        shape = AppCardShape
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(perUnit, { perUnit = true })
                            Column { Text("Por unidade produzida", maxLines = 1); Text("Use só quando o gasto acontece a cada unidade", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecipeResultStep(modifier: Modifier, draft: RecipeDraft, catalog: List<IngredientEntity>, vm: AppViewModel) {
    val result = runCatching { draft.calculate() }.getOrNull()
    var targetText by remember(draft.editingRecipeId) { mutableStateOf(number(draft.targetPercent)) }
    var chosenText by remember(draft.editingRecipeId) { mutableStateOf(draft.chosenSalePriceCents?.let(::moneyInput) ?: "") }
    var pricePerRecipe by remember { mutableStateOf(false) }
    val hasPackaging = draft.packagingPerUnitCents > 0 || draft.ingredients.any { used ->
        val category = catalog.firstOrNull { it.id == used.ingredientId }?.category.orEmpty()
        isPackagingLike(used.name, category)
    }
    val missingCosts = buildList {
        if (!hasPackaging) add("embalagem")
        if (draft.laborMinutes == 0 || draft.hourlyRateCents == 0L) add("mão de obra")
    }

    LazyColumn(
        modifier.fillMaxSize().imePadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item { SectionTitle("Preço e lucro", "Resultado calculado com os valores informados.") }
        if (missingCosts.isNotEmpty()) {
            item {
                InfoCard(tint = YellowSoft) {
                    Text("Estimativa com os custos informados", fontWeight = FontWeight.Bold)
                    Text("Ainda não foi informado: ${missingCosts.joinToString(" e ")}. O cálculo abaixo é parcial até esses custos serem conferidos.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            InfoCard {
                Text("Resumo da receita", fontWeight = FontWeight.Bold)
                ResultRow("Insumos", money(result?.ingredientsCents ?: 0))
                if ((result?.packagingCents ?: 0) > 0) ResultRow("Embalagem avulsa", money(result?.packagingCents ?: 0))
                ResultRow("Mão de obra", money(result?.laborCents ?: 0))
                ResultRow("Outros custos", money(result?.extrasCents ?: 0))
                ResultRow("Custo total", money(result?.totalCostCents ?: 0), true)
                ResultRow("Rendimento vendável", "${number(result?.sellableYield ?: 0.0)} ${draft.yieldUnit}")
                ResultRow("Custo por unidade", money(result?.costPerUnitCents ?: 0), true)
            }
        }
        item { SectionTitle("Defina seu preço de venda") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!pricePerRecipe, { pricePerRecipe = false; chosenText = draft.chosenSalePriceCents?.let(::moneyInput) ?: "" }, label = { Text("Por unidade", maxLines = 1) })
                FilterChip(pricePerRecipe, {
                    pricePerRecipe = true
                    chosenText = draft.chosenSalePriceCents?.let { cents -> moneyInput((cents * (result?.sellableYield ?: draft.yieldQuantity)).roundToLong()) } ?: ""
                }, label = { Text("Por receita", maxLines = 1) })
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(draft.pricingMode == "MARGIN", {
                    val adjustedTarget = if (draft.targetPercent >= 100.0) 50.0 else draft.targetPercent
                    targetText = number(adjustedTarget, 0); chosenText = ""
                    vm.updateDraft { it.copy(pricingMode = "MARGIN", targetPercent = adjustedTarget, priceMode = "SUGGESTED", chosenSalePriceCents = null) }
                }, label = { Text("Margem", maxLines = 1) })
                HelpTip("Margem é quanto do preço de venda sobra depois dos custos e taxas.")
                FilterChip(draft.pricingMode == "MARKUP", {
                    targetText = number(draft.targetPercent, 0); chosenText = ""
                    vm.updateDraft { it.copy(pricingMode = "MARKUP", priceMode = "SUGGESTED", chosenSalePriceCents = null) }
                }, label = { Text("Markup", maxLines = 1) })
                HelpTip("Markup é o acréscimo percentual aplicado sobre o custo.")
            }
        }
        item {
            val suggestions = if (draft.pricingMode == "MARGIN") listOf(20.0, 30.0, 40.0, 50.0) else listOf(30.0, 50.0, 100.0, 150.0)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(suggestions) { value -> FilterChip(draft.targetPercent == value, { targetText = number(value, 0); chosenText = ""; vm.updateDraft { it.copy(targetPercent = value, priceMode = "SUGGESTED", chosenSalePriceCents = null) } }, label = { Text("${number(value, 0)}%", maxLines = 1) }) }
            }
        }
        item {
            SmartNumberField(
                targetText,
                { text -> targetText = text; chosenText = ""; vm.updateDraft { it.copy(targetPercent = parseDecimal(text) ?: 0.0, priceMode = "SUGGESTED", chosenSalePriceCents = null) } },
                if (draft.pricingMode == "MARGIN") "Margem desejada (%)" else "Markup desejado (%)",
                Modifier.fillMaxWidth(),
                supportingText = result?.let { value -> "Preço sugerido: ${money(value.suggestedPriceCents)} por unidade" }
            )
        }
        item {
            val suggested = result?.suggestedPriceCents ?: 0
            val displaySuggested = if (pricePerRecipe) (result?.suggestedRecipePriceCents ?: 0L) else suggested
            Card(
                Modifier.fillMaxWidth(),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = BlueSoft),
                border = BorderStroke(1.dp, Outline),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when {
                            missingCosts.isNotEmpty() && pricePerRecipe -> "Estimativa da receita"
                            missingCosts.isNotEmpty() -> "Estimativa por unidade"
                            pricePerRecipe -> "Preço sugerido da receita"
                            else -> "Preço sugerido por unidade"
                        },
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(money(displaySuggested), color = Green, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
        result?.let { value ->
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard("Custo un.", money(value.costPerUnitCents), BlueSoft, Modifier.weight(1f))
                    SummaryCard("Preço un.", money(value.salePriceCents), Mint, Modifier.weight(1f))
                    SummaryCard(if (draft.chosenSalePriceCents == null) "Lucro estimado" else "Lucro un.", money(value.profitPerUnitCents), PinkSoft, Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SummaryCard(if (draft.chosenSalePriceCents == null) "Margem estimada" else "Margem real", "${percent(value.marginPercent)}%", Peach, Modifier.weight(1f))
                    SummaryCard("Markup", "${percent(value.markupPercent)}%", YellowSoft, Modifier.weight(1f))
                }
            }
        }
        item {
            SmartNumberField(
                chosenText,
                { text ->
                    chosenText = text
                    val entered = parseMoneyCents(text)
                    val perUnit = if (pricePerRecipe && entered != null && result != null && result.sellableYield > 0) (entered.toDouble() / result.sellableYield).roundToLong() else entered
                    vm.updateDraft { it.copy(
                        priceMode = if (perUnit != null) "MANUAL" else "SUGGESTED",
                        chosenSalePriceCents = perUnit
                    ) }
                },
                if (pricePerRecipe) "Preço da receita (opcional)" else "Preço por unidade (opcional)",
                Modifier.fillMaxWidth(),
                prefix = "R$ ",
                supportingText = when {
                    draft.chosenSalePriceCents != null && result != null -> "Lucro: ${money(result.profitPerUnitCents)} • margem real: ${percent(result.marginPercent)}%"
                    pricePerRecipe && draft.chosenSalePriceCents != null && result != null -> {
                        val normalizedTotal = (draft.chosenSalePriceCents.toDouble() * result.sellableYield).roundToLong()
                        "Será salvo como ${money(draft.chosenSalePriceCents)}/un • total ${money(normalizedTotal)}."
                    }
                    pricePerRecipe -> "Vazio usa o sugerido. O total é ajustado para fechar com o preço por unidade."
                    else -> "Vazio usa o valor sugerido."
                }
            )
        }
        item { Text("Os cálculos dependem dos preços, quantidades e custos informados.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}


# Lucro Exato 0.1.8 R9

A R9 implementa a tela oficial de detalhe da receita definida na especificação técnica de 24/09/2026: Preço e lucro fixo no topo, comparação Por unidade × Na receita em uma única caixa, preço de venda editável, Teste rápido apenas com Margem/Markup, Composição do preço como sanfona interna e demais seções brancas e compactas. O launcher usa o ícone aprovado de fouet + crescimento.

Aplicativo Android offline para calcular custo, preço, lucro, margem e markup de receitas.

## Abrir no Android Studio

1. Abra esta pasta como projeto.
2. Aguarde a sincronização do Gradle.
3. Execute o módulo `app` em um aparelho com Android 8.0 (API 26) ou superior.

## Fluxo principal

1. Dados da receita e rendimento, com unidade escolhida por seletor.
2. Insumos: ingredientes, embalagens e consumíveis usando a mesma lógica de compra e uso.
3. Custos: perdas, mão de obra, taxas e outros gastos.
4. Resultado: custo total e unitário, estimativa/preço sugerido, lucro, margem e markup.

A Home mostra rascunhos não concluídos. `Nova receita` sempre inicia uma receita nova; um rascunho existente é tratado explicitamente antes de ser substituído.

A simulação saiu da barra inferior e agora é aberta de dentro de uma receita salva, comparando `Atual x Simulação` sem alterar os dados originais.

## Catálogo

O catálogo inicial inclui ingredientes e itens de embalagem. Novos insumos criados durante uma receita são salvos no catálogo para reutilização e atualização de preço.

## Validação

Comandos previstos:

- `./gradlew testDebugUnitTest`
- `./gradlew assembleDebug`

O R8 mantém a criação por etapas e as melhorias visuais da R7. A auditoria desta versão corrigiu o teste rápido de margem/markup/preço, persistência explícita de preço manual/sugerido, consistência entre preço unitário e preço da receita, precisão subcentavo dos insumos, restauração de backup, mudança incompatível de unidades e edição de quantidade de sub-receitas. Modais, dropdowns e seletores permanecem neutros. O build DEBUG usa uma chave fixa de teste em `app/keystore/lucroexato-debug.jks` para permitir atualização entre revisões futuras que reutilizem a mesma chave.
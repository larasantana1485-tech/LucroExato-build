package br.com.lucroexato.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.lucroexato.LucroExatoApplication
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.IngredientPriceEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.CostCalculator
import br.com.lucroexato.domain.DraftExtraCost
import br.com.lucroexato.domain.DraftIngredient
import br.com.lucroexato.domain.RecipeDraft
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.roundToLong
import org.json.JSONArray
import org.json.JSONObject

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LucroExatoApplication
    private val repository = app.repository
    private val prefs = application.getSharedPreferences("lucro_exato_prefs", 0)

    val ingredients = repository.observeIngredients().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val recipes = repository.observeRecipes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _savedDraft = MutableStateFlow(readDraft())
    val savedDraft = _savedDraft.asStateFlow()

    private fun blankDraft() = RecipeDraft(
        targetPercent = prefs.getFloat("default_target", 50f).toDouble(),
        pricingMode = prefs.getString("pricing_mode", "MARGIN") ?: "MARGIN",
        priceMode = "SUGGESTED"
    )

    private val _draft = MutableStateFlow(blankDraft())
    val draft = _draft.asStateFlow()

    private val _tutorialComplete = MutableStateFlow(prefs.getBoolean("tutorial_complete", false))
    val tutorialComplete = _tutorialComplete.asStateFlow()

    private val _defaultPricingMode = MutableStateFlow(prefs.getString("pricing_mode", "MARGIN") ?: "MARGIN")
    val defaultPricingMode = _defaultPricingMode.asStateFlow()
    private val _defaultTarget = MutableStateFlow(prefs.getFloat("default_target", 50f).toDouble())
    val defaultTarget = _defaultTarget.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val events = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
            runCatching { repository.recalculateAllRecipes() }
                .onFailure { _events.emit(it.message ?: "Algumas receitas precisam ser revisadas.") }
        }
    }

    fun completeTutorial(addExample: Boolean) {
        prefs.edit().putBoolean("tutorial_complete", true).apply()
        _tutorialComplete.value = true
        if (addExample) viewModelScope.launch {
            repository.ensureSeeded()
            repository.createExampleRecipe()
            _events.emit("Receita de exemplo adicionada. Os valores são apenas demonstrativos.")
        }
    }

    fun reopenTutorial() {
        _tutorialComplete.value = false
    }

    fun startNewRecipe() {
        clearDraft()
        _draft.value = blankDraft()
    }

    fun resumeDraft() {
        val saved = _savedDraft.value ?: readDraft()
        if (saved == null) {
            _draft.value = blankDraft()
            return
        }
        _draft.value = saved
        _events.tryEmit("Rascunho aberto.")
    }

    fun updateDraft(transform: (RecipeDraft) -> RecipeDraft) {
        _draft.value = transform(_draft.value).copy(dirty = true)
        persistDraft(_draft.value)
    }

    fun nextStep(): Boolean {
        val d = _draft.value
        val error = when (d.step) {
            1 -> when {
                d.name.isBlank() -> "Informe o nome da receita."
                d.yieldQuantity <= 0 -> "Informe quanto a receita rende."
                else -> null
            }
            2 -> if (d.ingredients.isEmpty()) "Adicione pelo menos um insumo." else null
            else -> null
        }
        if (error != null) {
            _events.tryEmit(error)
            return false
        }
        updateDraft { it.copy(step = (it.step + 1).coerceAtMost(4)) }
        return true
    }

    fun previousStep() = updateDraft { it.copy(step = (it.step - 1).coerceAtLeast(1)) }

    fun addCatalogIngredient(item: IngredientEntity, quantity: Double, unit: String): Boolean {
        val exact = runCatching {
            CostCalculator.ingredientCostExactCents(item.packagePriceCents, item.packageQuantity, item.packageUnit, quantity, unit)
        }.getOrElse {
            _events.tryEmit("Use uma unidade compatível com ${item.packageUnit}.")
            return false
        }
        updateDraft {
            it.copy(ingredients = it.ingredients + DraftIngredient(item.id, null, item.name, quantity, unit, exact.roundToLong(), exact))
        }
        return true
    }

    fun saveAndUseIngredient(
        ingredient: IngredientEntity,
        packagePriceCents: Long,
        packageQuantity: Double,
        packageUnit: String,
        usedQuantity: Double,
        usedUnit: String,
        draftIndex: Int? = null,
        onSaved: () -> Unit
    ) {
        val exactCost = runCatching {
            CostCalculator.ingredientCostExactCents(
                packagePriceCents,
                packageQuantity,
                packageUnit,
                usedQuantity,
                usedUnit
            )
        }.getOrElse {
            _events.tryEmit(it.message ?: "Confira as unidades da compra e do uso.")
            return
        }
        viewModelScope.launch {
            val updated = ingredient.copy(
                packagePriceCents = packagePriceCents,
                packageQuantity = packageQuantity,
                packageUnit = packageUnit
            )
            val id = runCatching { repository.saveIngredient(updated) }.getOrElse {
                _events.emit(it.message ?: "Não foi possível atualizar o insumo.")
                return@launch
            }
            repository.recalculateAllRecipes()
            updateDraft { current ->
                val used = DraftIngredient(id, null, updated.name, usedQuantity, usedUnit, exactCost.roundToLong(), exactCost)
                val list = if (draftIndex != null && draftIndex in current.ingredients.indices) {
                    current.ingredients.toMutableList().also { it[draftIndex] = used }
                } else {
                    current.ingredients + used
                }
                current.copy(ingredients = list)
            }
            _events.emit("${updated.name}: preço e quantidade atualizados.")
            onSaved()
        }
    }

    fun addSubRecipe(recipe: RecipeWithDetails, quantity: Double): Boolean = setSubRecipe(null, recipe, quantity)

    fun updateSubRecipe(index: Int, recipe: RecipeWithDetails, quantity: Double): Boolean = setSubRecipe(index, recipe, quantity)

    private fun setSubRecipe(index: Int?, recipe: RecipeWithDetails, quantity: Double): Boolean {
        if (quantity <= 0) return false
        val sellableYield = recipe.recipe.yieldQuantity * (1.0 - recipe.recipe.lossPercent / 100.0)
        if (sellableYield <= 0.0) return false
        val exactUnitCostCents = recipe.recipe.totalCostCents.toDouble() / sellableYield
        val exact = exactUnitCostCents * quantity
        updateDraft { current ->
            val used = DraftIngredient(
                ingredientId = null,
                sourceRecipeId = recipe.recipe.id,
                name = "Sub-receita: ${recipe.recipe.name}",
                quantity = quantity,
                unit = recipe.recipe.yieldUnit,
                costCents = exact.roundToLong(),
                costExactCents = exact
            )
            val list = if (index != null && index in current.ingredients.indices) {
                current.ingredients.toMutableList().also { it[index] = used }
            } else current.ingredients + used
            current.copy(ingredients = list)
        }
        return true
    }

    fun removeDraftIngredient(index: Int) = updateDraft {
        it.copy(ingredients = it.ingredients.filterIndexed { itemIndex, _ -> itemIndex != index })
    }

    fun addExtraCost(type: String, description: String, valueCents: Long, perUnit: Boolean) = updateDraft {
        it.copy(extras = it.extras + DraftExtraCost(type, description, valueCents, if (perUnit) "PER_UNIT" else "PER_RECIPE"))
    }

    fun removeExtraCost(index: Int) = updateDraft {
        it.copy(extras = it.extras.filterIndexed { itemIndex, _ -> itemIndex != index })
    }

    fun saveRecipe(onSaved: (Long) -> Unit) {
        val d = _draft.value
        val validation = when {
            d.name.isBlank() -> "Informe o nome da receita."
            d.yieldQuantity <= 0 -> "O rendimento precisa ser maior que zero."
            d.ingredients.isEmpty() -> "Adicione pelo menos um insumo."
            else -> runCatching { d.calculate() }.exceptionOrNull()?.message
        }
        if (validation != null) {
            _events.tryEmit(validation)
            return
        }
        viewModelScope.launch {
            val id = repository.saveRecipe(d.copy(dirty = false))
            repository.recalculateAllRecipes()
            clearDraft()
            _events.emit("Receita salva.")
            onSaved(id)
        }
    }

    fun editRecipe(id: Long, startStep: Int = 1, onReady: () -> Unit) {
        viewModelScope.launch {
            repository.recalculateRecipe(id)
            val loaded = repository.draftFromRecipe(id) ?: return@launch
            _draft.value = loaded.copy(step = startStep.coerceIn(1, 4), dirty = false)
            persistDraft(_draft.value)
            onReady()
        }
    }

    fun refreshRecipe(id: Long) = viewModelScope.launch { repository.recalculateRecipe(id) }

    fun discardDraft() {
        clearDraft()
        _draft.value = blankDraft()
    }

    fun deleteRecipe(id: Long, onDeleted: () -> Unit = {}) = viewModelScope.launch {
        val dependents = repository.dependentRecipeNames(id)
        if (dependents.isNotEmpty()) {
            _events.emit("Esta receita é usada como sub-receita em ${dependents.joinToString(limit = 2)}. Remova esse vínculo antes de excluir.")
            return@launch
        }
        repository.deleteRecipe(id)
        _events.emit("Receita excluída.")
        onDeleted()
    }

    fun saveIngredient(item: IngredientEntity, onSaved: (() -> Unit)? = null) = viewModelScope.launch {
        runCatching {
            repository.saveIngredient(item)
            repository.recalculateAllRecipes()
        }.onSuccess {
            _events.emit("Preço do insumo atualizado e receitas recalculadas.")
            onSaved?.invoke()
        }.onFailure {
            _events.emit(it.message ?: "Não foi possível salvar o insumo.")
        }
    }

    suspend fun priceHistory(id: Long): List<IngredientPriceEntity> = repository.ingredientPriceHistory(id)

    fun saveDefaultPricing(mode: String, target: Double) {
        val safeTarget = if (mode == "MARGIN") target.coerceIn(0.0, 95.0) else target.coerceAtLeast(0.0)
        prefs.edit().putString("pricing_mode", mode).putFloat("default_target", safeTarget.toFloat()).apply()
        _defaultPricingMode.value = mode
        _defaultTarget.value = safeTarget
        _events.tryEmit("Preferência salva.")
    }

    fun exportBackup(uri: Uri) = viewModelScope.launch {
        runCatching {
            val json = repository.exportJson()
            getApplication<Application>().contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json) }
                ?: error("Não foi possível abrir o arquivo.")
        }.onSuccess { _events.emit("Backup salvo com sucesso.") }
            .onFailure { _events.emit("Não foi possível salvar o backup: ${it.message}") }
    }

    fun importBackup(uri: Uri) = viewModelScope.launch {
        runCatching {
            val raw = getApplication<Application>().contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: error("Não foi possível ler o arquivo.")
            repository.importJson(raw)
        }.onSuccess {
            clearDraft()
            _draft.value = blankDraft()
            _events.emit("Backup restaurado e receitas recalculadas com sucesso.")
        }.onFailure { _events.emit("Backup não restaurado: ${it.message}") }
    }

    private fun clearDraft() {
        prefs.edit().remove("recipe_draft").apply()
        _savedDraft.value = null
    }

    private fun persistDraft(draft: RecipeDraft) {
        prefs.edit().putString("recipe_draft", draft.toJson().toString()).apply()
        _savedDraft.value = draft
    }

    private fun readDraft(): RecipeDraft? = runCatching {
        prefs.getString("recipe_draft", null)?.let { JSONObject(it).toDraft() }
    }.getOrNull()
}

private fun RecipeDraft.toJson() = JSONObject().apply {
    put("editingRecipeId", editingRecipeId); put("name", name); put("category", category); put("yieldQuantity", yieldQuantity); put("yieldUnit", yieldUnit); put("preparation", preparation)
    put("lossPercent", lossPercent); put("packagingPerUnitCents", packagingPerUnitCents); put("laborMinutes", laborMinutes); put("hourlyRateCents", hourlyRateCents)
    put("variableFeePercent", variableFeePercent); put("fixedFeePerUnitCents", fixedFeePerUnitCents); put("pricingMode", pricingMode); put("targetPercent", targetPercent); put("priceMode", priceMode)
    put("chosenSalePriceCents", chosenSalePriceCents); put("step", step); put("dirty", dirty)
    put("ingredients", JSONArray().apply { ingredients.forEach { item -> put(JSONObject().apply {
        put("ingredientId", item.ingredientId); put("sourceRecipeId", item.sourceRecipeId); put("name", item.name); put("quantity", item.quantity); put("unit", item.unit); put("costCents", item.costCents); put("costExactCents", item.costExactCents)
    }) } })
    put("extras", JSONArray().apply { extras.forEach { item -> put(JSONObject().apply {
        put("type", item.type); put("description", item.description); put("valueCents", item.valueCents); put("application", item.application)
    }) } })
}

private fun JSONObject.toDraft() = RecipeDraft(
    editingRecipeId = nullableLong("editingRecipeId"), name = getString("name"), category = getString("category"),
    yieldQuantity = getDouble("yieldQuantity"), yieldUnit = getString("yieldUnit"), preparation = optString("preparation", ""), lossPercent = getDouble("lossPercent"),
    ingredients = getJSONArray("ingredients").let { array -> (0 until array.length()).map { i -> array.getJSONObject(i).let { item ->
        DraftIngredient(item.nullableLong("ingredientId"), item.nullableLong("sourceRecipeId"), item.getString("name"), item.getDouble("quantity"), item.getString("unit"), item.getLong("costCents"), if (!item.has("costExactCents") || item.isNull("costExactCents")) null else item.getDouble("costExactCents"))
    } } },
    packagingPerUnitCents = getLong("packagingPerUnitCents"), laborMinutes = getInt("laborMinutes"), hourlyRateCents = getLong("hourlyRateCents"),
    extras = getJSONArray("extras").let { array -> (0 until array.length()).map { i -> array.getJSONObject(i).let { item ->
        DraftExtraCost(item.getString("type"), item.getString("description"), item.getLong("valueCents"), item.getString("application"))
    } } },
    variableFeePercent = getDouble("variableFeePercent"), fixedFeePerUnitCents = getLong("fixedFeePerUnitCents"), pricingMode = getString("pricingMode"),
    targetPercent = getDouble("targetPercent"), priceMode = optString("priceMode", if (nullableLong("chosenSalePriceCents") != null) "MANUAL" else "SUGGESTED"), chosenSalePriceCents = nullableLong("chosenSalePriceCents"), step = getInt("step"), dirty = getBoolean("dirty")
)

private fun JSONObject.nullableLong(key: String): Long? = if (!has(key) || isNull(key)) null else getLong(key)

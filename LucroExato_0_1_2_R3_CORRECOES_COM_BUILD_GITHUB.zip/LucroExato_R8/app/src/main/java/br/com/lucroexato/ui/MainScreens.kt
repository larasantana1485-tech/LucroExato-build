package br.com.lucroexato.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.data.IngredientEntity
import br.com.lucroexato.data.IngredientPriceEntity
import br.com.lucroexato.data.RecipeWithDetails
import br.com.lucroexato.domain.CostCalculator
import br.com.lucroexato.domain.CostInput
import br.com.lucroexato.domain.ExtraCostInput
import br.com.lucroexato.domain.IngredientCostInput
import br.com.lucroexato.ui.theme.BlueSoft
import br.com.lucroexato.ui.theme.Green
import br.com.lucroexato.ui.theme.Mint
import br.com.lucroexato.ui.theme.Peach
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import br.com.lucroexato.ui.theme.PinkSoft
import br.com.lucroexato.ui.theme.YellowSoft
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToLong

enum class MainTab { RECIPES, SUPPLIES }
private enum class SimulationMode { KEEP_PRICE, KEEP_TARGET }
private enum class QuickPricingMode { MARGIN, MARKUP, PRICE }

@Composable
fun MainShell(
    modifier: Modifier = Modifier,
    vm: AppViewModel,
    onSettings: () -> Unit,
    onNewRecipe: () -> Unit,
    onResumeDraft: () -> Unit,
    onRecipe: (Long) -> Unit,
    onIngredient: (Long) -> Unit,
    selectedTab: MainTab,
    onTabChange: (MainTab) -> Unit
) {
    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 10.dp, top = 14.dp, bottom = 6.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(Modifier.weight(1f)) {
                Text("Lucro Exato", style = MaterialTheme.typography.headlineSmall, color = Pink)
                Text(
                    "Custos e precificação de receitas",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // Alinhado à linha do título, e não ao centro do bloco título + subtítulo.
            IconButton(onClick = onSettings, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Outlined.Settings, "Configurações")
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            MainTopTab(
                selected = selectedTab == MainTab.RECIPES,
                icon = { Icon(Icons.Outlined.ReceiptLong, null, modifier = Modifier.size(20.dp)) },
                label = "Receitas",
                modifier = Modifier.weight(1f)
            ) { onTabChange(MainTab.RECIPES) }
            MainTopTab(
                selected = selectedTab == MainTab.SUPPLIES,
                icon = { Icon(Icons.Outlined.Inventory2, null, modifier = Modifier.size(20.dp)) },
                label = "Insumos",
                modifier = Modifier.weight(1f)
            ) { onTabChange(MainTab.SUPPLIES) }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Outline))
        when (selectedTab) {
            MainTab.RECIPES -> RecipesScreen(Modifier.weight(1f), vm, onNewRecipe, onResumeDraft, onRecipe)
            MainTab.SUPPLIES -> IngredientsScreen(Modifier.weight(1f), vm, onIngredient)
        }
    }
}

@Composable
private fun MainTopTab(
    selected: Boolean,
    icon: @Composable () -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier.clickable(onClick = onClick).padding(top = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(contentAlignment = Alignment.Center) { icon() }
            Text(
                label,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                color = if (selected) Pink else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Box(
            Modifier.fillMaxWidth(0.72f).height(3.dp)
                .background(if (selected) Pink else Color.Transparent)
        )
    }
}

@Composable
private fun RecipesScreen(
    modifier: Modifier,
    vm: AppViewModel,
    onNewRecipe: () -> Unit,
    onResumeDraft: () -> Unit,
    onRecipe: (Long) -> Unit
) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val savedDraft by vm.savedDraft.collectAsStateWithLifecycle()
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todas") }
    var confirmNew by remember { mutableStateOf(false) }
    val categories = listOf("Todas", "Bolos", "Doces", "Tortas", "Cookies", "Pães", "Salgados", "Sobremesas", "Bebidas", "Outros")
    val filtered = recipes.filter {
        (category == "Todas" || it.recipe.category == category) && it.recipe.name.contains(search, ignoreCase = true)
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        savedDraft?.takeIf { it.dirty }?.let { draft ->
            item {
                Card(
                    Modifier.fillMaxWidth().clickable(onClick = onResumeDraft),
                    shape = AppCardShape,
                    colors = CardDefaults.cardColors(containerColor = PinkSoft),
                    border = BorderStroke(1.dp, Outline),
                    elevation = CardDefaults.cardElevation(0.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Edit, null, tint = Pink)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(if (draft.editingRecipeId == null) "Rascunho" else "Edição não concluída", fontWeight = FontWeight.Bold)
                            Text(draft.name.ifBlank { "Receita sem nome" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Etapa ${draft.step} de 4 • toque para continuar", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("Continuar", color = Pink, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = AppFieldShape,
                placeholder = { Text("Buscar receitas...") },
                leadingIcon = { Icon(Icons.Outlined.Search, null) }
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { item -> FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item, maxLines = 1) }) }
            }
        }
        item {
            Button(
                onClick = { if (savedDraft?.dirty == true) confirmNew = true else onNewRecipe() },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = AppButtonShape
            ) {
                Icon(Icons.Outlined.Add, null); Spacer(Modifier.size(8.dp)); Text("Nova receita", maxLines = 1)
            }
        }
        item { SectionTitle("Minhas receitas", if (recipes.isEmpty()) "Crie sua primeira receita para começar." else recipeCountText(filtered.size)) }
        if (filtered.isEmpty()) {
            item {
                InfoCard(tint = PinkSoft) {
                    Text(if (recipes.isEmpty()) "Ainda não há receitas salvas." else "Nenhuma receita encontrada.", fontWeight = FontWeight.SemiBold)
                    Text("O Lucro Exato salva tudo no próprio celular e funciona offline.", style = MaterialTheme.typography.bodySmall)
                }
            }
        } else {
            items(filtered, key = { it.recipe.id }) { item -> RecipeCard(item, catalog) { onRecipe(item.recipe.id) } }
        }
    }

    if (confirmNew) {
        AlertDialog(
            onDismissRequest = { confirmNew = false },
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            shape = AppCardShape,
            title = { Text("Começar outra receita?") },
            text = { Text("Existe um rascunho salvo. Começar uma nova receita descarta esse rascunho.") },
            confirmButton = {
                TextButton(onClick = { confirmNew = false; onNewRecipe() }) { Text("Começar nova") }
            },
            dismissButton = {
                TextButton(onClick = { confirmNew = false; onResumeDraft() }) { Text("Continuar rascunho") }
            }
        )
    }
}

@Composable
private fun RecipeCard(item: RecipeWithDetails, catalog: List<IngredientEntity>, onClick: () -> Unit) {
    val missingChecks = buildList {
        if (!hasPackagingSupply(item, catalog)) add("embalagem")
        if (item.recipe.laborMinutes == 0 || item.recipe.hourlyRateCents == 0L) add("mão de obra")
    }
    val partial = missingChecks.isNotEmpty()
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(0.dp),
        border = BorderStroke(1.dp, Outline)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Card(
                Modifier.size(40.dp),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = PinkSoft),
                elevation = CardDefaults.cardElevation(0.dp)
            ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.ReceiptLong, null, tint = Pink, modifier = Modifier.size(22.dp)) } }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(item.recipe.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${item.recipe.category} • ${number(item.recipe.yieldQuantity)} ${item.recipe.yieldUnit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text("Custo un. ${money(item.recipe.costPerUnitCents)}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                if (partial) Text("Resultado parcial", style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A5A00), fontWeight = FontWeight.SemiBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Preço por unidade", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text(money(item.recipe.salePricePerUnitCents), color = Green, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

@Composable
private fun IngredientsScreen(modifier: Modifier, vm: AppViewModel, onIngredient: (Long) -> Unit) {
    val ingredients by vm.ingredients.collectAsStateWithLifecycle()
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    val categories = listOf("Todos", "Embalagens") + (SupplyCategories + ingredients.map { it.category }).distinct().filterNot { it == "Embalagens" }
    val filtered = ingredients.filter { (category == "Todos" || it.category == category) && it.name.contains(search, true) }
    LazyColumn(modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Seus insumos", style = MaterialTheme.typography.titleLarge)
                    Text("Ingredientes, embalagens e consumíveis", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { onIngredient(0) }) { Icon(Icons.Outlined.Add, "Novo insumo") }
            }
        }
        item { OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, placeholder = { Text("Buscar insumo...") }, leadingIcon = { Icon(Icons.Outlined.Search, null) }, singleLine = true) }
        item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(categories) { item -> FilterChip(category == item, { category = item }, label = { Text(item, maxLines = 1) }) } } }
        items(filtered, key = { it.id }) { item -> IngredientRow(item) { onIngredient(item.id) } }
    }
}

@Composable
private fun IngredientRow(item: IngredientEntity, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Inventory2, null, tint = Pink, modifier = Modifier.size(20.dp)) }
            Column(Modifier.weight(1f).padding(start = 8.dp)) {
                Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("${money(item.packagePriceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
        }
    }
}

@Composable
fun RecipeSimulationScreen(modifier: Modifier, vm: AppViewModel, recipeId: Long, onBack: () -> Unit) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val selected = recipes.firstOrNull { it.recipe.id == recipeId }
    var ingredientExpanded by remember { mutableStateOf(false) }
    var selectedIngredientId by remember(selected?.ingredients) {
        mutableStateOf(selected?.ingredients?.firstOrNull { it.ingredientId != null }?.ingredientId ?: 0L)
    }
    val recipeIngredient = selected?.ingredients?.firstOrNull { it.ingredientId == selectedIngredientId }
    val catalogIngredient = catalog.firstOrNull { it.id == selectedIngredientId }
    var yieldText by remember(recipeId, selected?.recipe?.yieldQuantity) {
        mutableStateOf(selected?.recipe?.yieldQuantity?.let { number(it) } ?: "")
    }
    var ingredientPriceText by remember(recipeId, selectedIngredientId, catalogIngredient) {
        mutableStateOf(catalogIngredient?.packagePriceCents?.let(::moneyInput) ?: "")
    }
    var marginText by remember(recipeId, selected?.recipe?.targetPercent) {
        mutableStateOf(selected?.recipe?.targetPercent?.let { number(it) } ?: "50")
    }
    var mode by remember { mutableStateOf(SimulationMode.KEEP_PRICE) }
    var comparison by remember { mutableStateOf<Pair<br.com.lucroexato.domain.CostResult, br.com.lucroexato.domain.CostResult>?>(null) }
    var simulationError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier.fillMaxSize().imePadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { CompactTopBar("Simular mudanças", onBack) }
        if (selected == null) {
            item { InfoCard(Modifier.padding(horizontal = 16.dp)) { Text("Receita não encontrada.") } }
        } else {
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text(selected.recipe.name, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("A simulação não altera a receita salva.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("O que deve ficar fixo?", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = mode == SimulationMode.KEEP_PRICE,
                            onClick = { mode = SimulationMode.KEEP_PRICE; comparison = null; simulationError = null },
                            label = { Text("Manter preço", maxLines = 1) }
                        )
                        FilterChip(
                            selected = mode == SimulationMode.KEEP_TARGET,
                            onClick = { mode = SimulationMode.KEEP_TARGET; comparison = null; simulationError = null },
                            label = { Text(if (selected.recipe.pricingMode == "MARKUP") "Manter markup" else "Manter margem", maxLines = 1) }
                        )
                    }
                    Text(
                        if (mode == SimulationMode.KEEP_PRICE)
                            "Mantém ${money(selected.recipe.salePricePerUnitCents)} por unidade e mostra como lucro e margem mudam."
                        else if (selected.recipe.pricingMode == "MARKUP")
                            "Mantém o markup desejado e recalcula o preço sugerido."
                        else
                            "Mantém a margem desejada e recalcula o preço sugerido.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (selected.ingredients.any { it.ingredientId != null }) {
                item {
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        OutlinedButton(
                            onClick = { ingredientExpanded = true },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = AppButtonShape
                        ) {
                            Text(recipeIngredient?.nameSnapshot ?: "Escolher insumo", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        DropdownMenu(
                            expanded = ingredientExpanded,
                            onDismissRequest = { ingredientExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.88f).heightIn(max = 300.dp),
                            shape = AppFieldShape,
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 0.dp,
                            border = BorderStroke(1.dp, Outline)
                        ) {
                            selected.ingredients.filter { it.ingredientId != null }.forEach { ingredient ->
                                DropdownMenuItem(
                                    text = { Text(ingredient.nameSnapshot, maxLines = 1) },
                                    onClick = {
                                        selectedIngredientId = ingredient.ingredientId ?: 0L
                                        ingredientExpanded = false
                                        comparison = null
                                        simulationError = null
                                    }
                                )
                            }
                        }
                    }
                }
                item {
                    SmartNumberField(
                        value = ingredientPriceText,
                        onValueChange = { ingredientPriceText = it; comparison = null; simulationError = null },
                        label = "Novo preço de compra",
                        prefix = "R$ ",
                        supportingText = catalogIngredient?.let {
                            "Atual: ${money(it.packagePriceCents)} / ${number(it.packageQuantity)} ${it.packageUnit}"
                        },
                        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                    )
                }
            }
            item {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmartNumberField(yieldText, { yieldText = it; comparison = null; simulationError = null }, "Rendimento", Modifier.weight(1f))
                    if (mode == SimulationMode.KEEP_TARGET) {
                        SmartNumberField(
                            marginText,
                            { marginText = it; comparison = null; simulationError = null },
                            if (selected.recipe.pricingMode == "MARKUP") "Markup (%)" else "Margem (%)",
                            Modifier.weight(1f)
                        )
                    } else {
                        InfoCard(Modifier.weight(1f), tint = BlueSoft) {
                            Text("Preço mantido", style = MaterialTheme.typography.bodySmall)
                            Text(money(selected.recipe.salePricePerUnitCents), fontWeight = FontWeight.Bold, color = Green)
                        }
                    }
                }
            }
            item {
                Button(
                    onClick = {
                        val simulatedPrice = parseMoneyCents(ingredientPriceText)
                        val simulatedYield = parseDecimal(yieldText) ?: selected.recipe.yieldQuantity
                        val target = parseDecimal(marginText) ?: selected.recipe.targetPercent
                        simulationError = null
                        val attempt = runCatching {
                            val currentInput = selected.toCostInput(
                                yieldQuantity = selected.recipe.yieldQuantity,
                                targetPercent = target,
                                chosenSalePriceCents = if (mode == SimulationMode.KEEP_PRICE) selected.recipe.salePricePerUnitCents else null,
                                pricingMode = selected.recipe.pricingMode
                            )
                            val simulatedIngredients = selected.ingredients.map { used ->
                                val newCost = if (
                                    used.ingredientId == selectedIngredientId &&
                                    simulatedPrice != null && catalogIngredient != null
                                ) {
                                    CostCalculator.ingredientCostExactCents(
                                        simulatedPrice,
                                        catalogIngredient.packageQuantity,
                                        catalogIngredient.packageUnit,
                                        used.quantityUsed,
                                        used.unit
                                    )
                                } else (used.costExactCents ?: used.costCents.toDouble())
                                IngredientCostInput(used.nameSnapshot, newCost)
                            }
                            val simulatedInput = selected.toCostInput(
                                yieldQuantity = simulatedYield,
                                targetPercent = target,
                                chosenSalePriceCents = if (mode == SimulationMode.KEEP_PRICE) selected.recipe.salePricePerUnitCents else null,
                                ingredients = simulatedIngredients,
                                pricingMode = selected.recipe.pricingMode
                            )
                            CostCalculator.calculate(currentInput) to CostCalculator.calculate(simulatedInput)
                        }
                        comparison = attempt.getOrNull()
                        simulationError = attempt.exceptionOrNull()?.message ?: if (comparison == null) "Confira os valores da simulação." else null
                    },
                    modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(50.dp),
                    shape = AppButtonShape
                ) { Text("Calcular simulação") }
            }
            simulationError?.let { message ->
                item {
                    InfoCard(Modifier.padding(horizontal = 16.dp), tint = YellowSoft) {
                        Text("Não foi possível calcular", fontWeight = FontWeight.Bold)
                        Text(message, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            comparison?.let { (current, simulated) ->
                item {
                    Card(
                        Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                        shape = AppCardShape,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Outline),
                        elevation = CardDefaults.cardElevation(0.dp)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Atual × simulação", fontWeight = FontWeight.Bold)
                            ComparisonRow("Custo da receita", money(current.totalCostCents), money(simulated.totalCostCents), moneyDifference(current.totalCostCents, simulated.totalCostCents))
                            ComparisonRow("Custo por unidade", money(current.costPerUnitCents), money(simulated.costPerUnitCents), moneyDifference(current.costPerUnitCents, simulated.costPerUnitCents))
                            val currentPrice = if (mode == SimulationMode.KEEP_PRICE) current.salePriceCents else current.suggestedPriceCents
                            val simulatedPriceValue = if (mode == SimulationMode.KEEP_PRICE) simulated.salePriceCents else simulated.suggestedPriceCents
                            ComparisonRow(
                                if (mode == SimulationMode.KEEP_PRICE) "Preço de venda" else "Preço sugerido",
                                money(currentPrice),
                                money(simulatedPriceValue),
                                moneyDifference(currentPrice, simulatedPriceValue)
                            )
                            ComparisonRow("Lucro por unidade", money(current.profitPerUnitCents), money(simulated.profitPerUnitCents), moneyDifference(current.profitPerUnitCents, simulated.profitPerUnitCents))
                            ComparisonRow("Margem", "${percent(current.marginPercent)}%", "${percent(simulated.marginPercent)}%", percentPointDifference(current.marginPercent, simulated.marginPercent))
                        }
                    }
                }
            }
        }
    }
}

private fun RecipeWithDetails.toCostInput(
    yieldQuantity: Double = recipe.yieldQuantity,
    targetPercent: Double = recipe.targetPercent,
    chosenSalePriceCents: Long? = recipe.salePricePerUnitCents,
    ingredients: List<IngredientCostInput> = this.ingredients.map { IngredientCostInput(it.nameSnapshot, it.costExactCents ?: it.costCents.toDouble()) },
    pricingMode: String = recipe.pricingMode
) = CostInput(
    yieldQuantity = yieldQuantity,
    lossPercent = recipe.lossPercent,
    ingredients = ingredients,
    packagingPerUnitCents = recipe.packagingPerUnitCents,
    laborMinutes = recipe.laborMinutes,
    hourlyRateCents = recipe.hourlyRateCents,
    extras = extraCosts.map { ExtraCostInput(it.valueCents, it.application == "PER_UNIT") },
    variableFeePercent = recipe.variableFeePercent,
    fixedFeePerUnitCents = recipe.fixedFeePerUnitCents,
    pricingMode = pricingMode,
    targetPercent = targetPercent,
    chosenSalePriceCents = chosenSalePriceCents
)

private fun moneyDifference(current: Long, simulated: Long): String {
    val delta = simulated - current
    return when {
        delta > 0 -> "+${money(delta)}"
        delta < 0 -> "-${money(-delta)}"
        else -> "Sem alteração"
    }
}

private fun percentPointDifference(current: Double, simulated: Double): String {
    val delta = simulated - current
    return when {
        kotlin.math.abs(delta) < 0.05 -> "Sem alteração"
        delta > 0 -> "+${percent(delta)} p.p."
        else -> "-${percent(-delta)} p.p."
    }
}

@Composable
private fun ComparisonRow(label: String, current: String, simulated: String, difference: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Atual: $current", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Simulado: $simulated", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (difference != null) Text("Diferença: $difference", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun RecipeDetailScreen(
    modifier: Modifier,
    vm: AppViewModel,
    recipeId: Long,
    onBack: () -> Unit,
    onEditSection: (Int) -> Unit,
    onSimulate: () -> Unit
) {
    val recipes by vm.recipes.collectAsStateWithLifecycle()
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val item = recipes.firstOrNull { it.recipe.id == recipeId }
    var expandedSection by remember(recipeId) { mutableStateOf("INSUMOS") }
    var showAllIngredients by remember(recipeId) { mutableStateOf(false) }
    var scaleText by remember(recipeId) { mutableStateOf("1") }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(recipeId) { vm.refreshRecipe(recipeId) }
    if (item == null) {
        Column(modifier.fillMaxSize()) {
            CompactTopBar("Receita", onBack)
            Text("Receita não encontrada.", Modifier.padding(16.dp))
        }
        return
    }

    val currentResult = runCatching {
        CostCalculator.calculate(item.toCostInput(chosenSalePriceCents = item.recipe.salePricePerUnitCents))
    }.getOrNull()
    val sale = currentResult?.salePriceCents ?: item.recipe.salePricePerUnitCents
    val profit = currentResult?.profitPerUnitCents ?: (sale - item.recipe.costPerUnitCents)
    val margin = currentResult?.marginPercent ?: 0.0
    val missingChecks = buildList {
        if (!hasPackagingSupply(item, catalog)) add("embalagem")
        if (item.recipe.laborMinutes == 0 || item.recipe.hourlyRateCents == 0L) add("mão de obra")
    }
    val partial = missingChecks.isNotEmpty()
    val scale = (parseDecimal(scaleText) ?: 1.0).coerceAtLeast(0.01)
    val sellableYield = currentResult?.sellableYield ?: item.recipe.yieldQuantity
    val feeTotal = currentResult?.let { (it.feeExactCents * it.sellableYield).roundToLong() } ?: 0L
    val additionalTotal = (currentResult?.packagingCents ?: 0L) +
        (currentResult?.laborCents ?: 0L) +
        (currentResult?.extrasCents ?: 0L) + feeTotal

    val initialQuickMode = if (item.recipe.pricingMode == "MARKUP") QuickPricingMode.MARKUP else QuickPricingMode.MARGIN
    var quickMode by remember(recipeId) { mutableStateOf(initialQuickMode) }
    var quickTargetText by remember(recipeId) { mutableStateOf(number(item.recipe.targetPercent)) }
    var quickPriceText by remember(recipeId) { mutableStateOf(moneyInput(item.recipe.salePricePerUnitCents)) }
    val quickTarget = parseDecimal(quickTargetText) ?: item.recipe.targetPercent
    val quickEnteredPrice = parseMoneyCents(quickPriceText)
    val quickResult = runCatching {
        when (quickMode) {
            QuickPricingMode.MARGIN -> CostCalculator.calculate(
                item.toCostInput(targetPercent = quickTarget, chosenSalePriceCents = null, pricingMode = "MARGIN")
            )
            QuickPricingMode.MARKUP -> CostCalculator.calculate(
                item.toCostInput(targetPercent = quickTarget.coerceAtLeast(0.0), chosenSalePriceCents = null, pricingMode = "MARKUP")
            )
            QuickPricingMode.PRICE -> CostCalculator.calculate(
                item.toCostInput(
                    targetPercent = item.recipe.targetPercent,
                    chosenSalePriceCents = quickEnteredPrice ?: sale,
                    pricingMode = item.recipe.pricingMode
                )
            )
        }
    }.getOrNull()

    LazyColumn(
        modifier.fillMaxSize().imePadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            CompactTopBar(item.recipe.name, onBack) {
                IconButton(onClick = { onEditSection(1) }) { Icon(Icons.Outlined.Edit, "Editar dados") }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(
                    "${item.recipe.category} • ${number(item.recipe.yieldQuantity)} ${item.recipe.yieldUnit}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Custo un.", money(currentResult?.costPerUnitCents ?: item.recipe.costPerUnitCents), BlueSoft, Modifier.weight(1f))
                MetricCard("Preço", money(sale), Mint, Modifier.weight(1f), valueColor = Green)
                MetricCard("Margem real", "${percent(margin)}%", YellowSoft, Modifier.weight(1f))
            }
        }
        if (partial) {
            item {
                InfoCard(Modifier.padding(horizontal = 16.dp), tint = YellowSoft) {
                    Text("Custos para conferir", fontWeight = FontWeight.Bold)
                    Text(
                        "Confira: ${missingChecks.joinToString(" e ")}. Se esse custo realmente não existe, você pode manter zero.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            AccordionSection(
                title = "Resumo",
                summary = "${number(sellableYield)} ${item.recipe.yieldUnit} • ${if (partial) "custos para conferir" else money(currentResult?.totalCostCents ?: item.recipe.totalCostCents)}",
                expanded = expandedSection == "RESUMO",
                onToggle = { expandedSection = if (expandedSection == "RESUMO") "" else "RESUMO" }
            ) {
                ResultRow("Custo total", money(currentResult?.totalCostCents ?: item.recipe.totalCostCents), true)
                ResultRow("Rendimento informado", "${number(item.recipe.yieldQuantity)} ${item.recipe.yieldUnit}")
                ResultRow("Rendimento vendável", "${number(sellableYield)} ${item.recipe.yieldUnit}")
                if (item.recipe.lossPercent > 0) ResultRow("Perda", "${percent(item.recipe.lossPercent)}%")
                OutlinedButton(onClick = onSimulate, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Icon(Icons.Outlined.Calculate, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Simular custos e rendimento")
                }
                Text("Escalar receita", fontWeight = FontWeight.SemiBold)
                SmartNumberField(scaleText, { scaleText = it }, "Multiplicador", Modifier.fillMaxWidth())
                item.ingredients.forEach { ingredient ->
                    ResultRow(ingredient.nameSnapshot, "${number(ingredient.quantityUsed * scale)} ${ingredient.unit}")
                }
                ResultRow("Novo rendimento", "${number(item.recipe.yieldQuantity * scale)} ${item.recipe.yieldUnit}", true)
            }
        }
        item {
            AccordionSection(
                title = "Insumos",
                summary = "${item.ingredients.size} itens • ${money(item.ingredients.sumOf { it.costExactCents ?: it.costCents.toDouble() }.roundToLong())}",
                expanded = expandedSection == "INSUMOS",
                tint = if (expandedSection == "INSUMOS") PinkSoft else MaterialTheme.colorScheme.surface,
                onToggle = { expandedSection = if (expandedSection == "INSUMOS") "" else "INSUMOS" }
            ) {
                val visible = if (showAllIngredients) item.ingredients else item.ingredients.take(4)
                visible.forEach { ingredient ->
                    CompactIngredientLine(ingredient.nameSnapshot, ingredient.quantityUsed, ingredient.unit, ingredient.costCents)
                }
                if (item.ingredients.size > 4) {
                    TextButton(onClick = { showAllIngredients = !showAllIngredients }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (showAllIngredients) "Mostrar menos" else "Ver todos os ${item.ingredients.size} insumos")
                    }
                }
                OutlinedButton(onClick = { onEditSection(2) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Icon(Icons.Outlined.Edit, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Editar insumos")
                }
            }
        }
        item {
            val prepSummary = item.recipe.preparation.lineSequence().firstOrNull { it.isNotBlank() }?.trim()
                ?.take(52)?.let { if (it.length >= 52) "$it…" else it }
                ?: "Opcional • não informado"
            AccordionSection(
                title = "Modo de preparo",
                summary = prepSummary,
                expanded = expandedSection == "PREPARO",
                onToggle = { expandedSection = if (expandedSection == "PREPARO") "" else "PREPARO" }
            ) {
                if (item.recipe.preparation.isBlank()) {
                    Text("Nenhum modo de preparo informado.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text(item.recipe.preparation)
                }
                OutlinedButton(onClick = { onEditSection(1) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Icon(Icons.Outlined.Edit, null)
                    Spacer(Modifier.size(8.dp))
                    Text(if (item.recipe.preparation.isBlank()) "Adicionar modo de preparo" else "Editar modo de preparo")
                }
            }
        }
        item {
            AccordionSection(
                title = "Custos adicionais",
                summary = "Embalagem, mão de obra e taxas • ${money(additionalTotal)}",
                expanded = expandedSection == "CUSTOS",
                onToggle = { expandedSection = if (expandedSection == "CUSTOS") "" else "CUSTOS" }
            ) {
                val result = currentResult
                ResultRow("Embalagem avulsa", money(result?.packagingCents ?: 0L))
                ResultRow("Mão de obra", money(result?.laborCents ?: 0L))
                ResultRow("Outros custos", money(result?.extrasCents ?: 0L))
                if (item.recipe.variableFeePercent > 0) ResultRow("Taxa percentual", "${percent(item.recipe.variableFeePercent)}%")
                if (item.recipe.fixedFeePerUnitCents > 0) ResultRow("Taxa fixa por unidade", money(item.recipe.fixedFeePerUnitCents))
                if (feeTotal > 0) ResultRow("Taxas no preço atual", money(feeTotal), true)
                OutlinedButton(onClick = { onEditSection(3) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Icon(Icons.Outlined.Edit, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Editar custos")
                }
            }
        }
        item {
            AccordionSection(
                title = "Preço e lucro",
                summary = "${money(sale)} • lucro ${money(profit)}/un",
                expanded = expandedSection == "PRECO",
                tint = if (expandedSection == "PRECO") BlueSoft else MaterialTheme.colorScheme.surface,
                onToggle = { expandedSection = if (expandedSection == "PRECO") "" else "PRECO" }
            ) {
                Text("Teste rápido", fontWeight = FontWeight.SemiBold)
                Text("Experimente margem, markup ou preço sem alterar a receita salva.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(quickMode == QuickPricingMode.MARGIN, {
                        quickMode = QuickPricingMode.MARGIN
                        if (quickTarget >= 100.0) quickTargetText = "50"
                    }, label = { Text("Margem") })
                    FilterChip(quickMode == QuickPricingMode.MARKUP, { quickMode = QuickPricingMode.MARKUP }, label = { Text("Markup") })
                    FilterChip(quickMode == QuickPricingMode.PRICE, { quickMode = QuickPricingMode.PRICE }, label = { Text("Preço") })
                }
                if (quickMode != QuickPricingMode.PRICE) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val values = if (quickMode == QuickPricingMode.MARGIN) listOf(30.0, 40.0, 50.0) else listOf(50.0, 100.0, 150.0)
                        values.forEach { target ->
                            FilterChip(
                                selected = kotlin.math.abs(quickTarget - target) < 0.001,
                                onClick = { quickTargetText = number(target) },
                                label = { Text("${number(target)}%") }
                            )
                        }
                    }
                    SmartNumberField(
                        quickTargetText,
                        { quickTargetText = it },
                        if (quickMode == QuickPricingMode.MARGIN) "Margem desejada (%)" else "Markup desejado (%)",
                        Modifier.fillMaxWidth(),
                        supportingText = quickResult?.let { "Preço sugerido: ${money(it.suggestedPriceCents)} por unidade" }
                    )
                } else {
                    SmartNumberField(
                        quickPriceText,
                        { quickPriceText = it },
                        "Testar preço de venda",
                        Modifier.fillMaxWidth(),
                        prefix = "R$ ",
                        supportingText = quickResult?.let { "Lucro: ${money(it.profitPerUnitCents)} • margem real: ${percent(it.marginPercent)}%" }
                            ?: "Este valor é apenas uma simulação."
                    )
                }
                quickResult?.let { result ->
                    PriceAndProfitComparison(result, item.recipe.yieldUnit)
                    PriceCompositionCard(item, catalog, result)
                    InfoCard(tint = MaterialTheme.colorScheme.primaryContainer) {
                        when (quickMode) {
                            QuickPricingMode.MARGIN -> ResultRow("Margem desejada", "${percent(quickTarget)}%")
                            QuickPricingMode.MARKUP -> ResultRow("Markup desejado", "${percent(quickTarget)}%")
                            QuickPricingMode.PRICE -> ResultRow("Preço testado", money(result.salePriceCents))
                        }
                        if (quickMode != QuickPricingMode.PRICE) ResultRow("Preço sugerido", money(result.suggestedPriceCents), true)
                        ResultRow("Margem real", "${percent(result.marginPercent)}%")
                        ResultRow("Markup real", "${percent(result.markupPercent)}%")
                    }
                } ?: Text("Confira os valores informados.", color = MaterialTheme.colorScheme.error)
                OutlinedButton(onClick = { onEditSection(4) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) {
                    Icon(Icons.Outlined.Edit, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Editar preço e margem")
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { confirmDelete = true },
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                shape = AppButtonShape
            ) {
                Icon(Icons.Outlined.DeleteOutline, null)
                Spacer(Modifier.size(8.dp))
                Text("Excluir receita")
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shape = AppCardShape,
        title = { Text("Excluir receita?") },
        text = { Text("Essa ação não pode ser desfeita.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteRecipe(recipeId, onBack) }) { Text("Excluir") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun AccordionSection(
    title: String,
    summary: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    tint: Color = MaterialTheme.colorScheme.surface,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = tint),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(
                    if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                    contentDescription = if (expanded) "Fechar" else "Abrir"
                )
            }
            if (expanded) {
                Column(
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) { content() }
            }
        }
    }
}

@Composable
private fun CompactIngredientLine(name: String, quantity: Double, unit: String, costCents: Long) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${number(quantity)} $unit", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(money(costCents), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PriceAndProfitComparison(result: br.com.lucroexato.domain.CostResult, yieldUnit: String) {
    val revenueTotal = (result.salePriceCents.toDouble() * result.sellableYield).roundToLong()
    val profitTotal = (result.profitPerUnitExactCents * result.sellableYield).roundToLong()
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        if (maxWidth < 360.dp) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoCard(Modifier.fillMaxWidth(), tint = MaterialTheme.colorScheme.surface) {
                    Text("Por unidade", fontWeight = FontWeight.Bold)
                    ResultRow("Custo", money(result.costPerUnitCents))
                    ResultRow("Venda", money(result.salePriceCents))
                    ResultRow("Lucro", money(result.profitPerUnitCents), true)
                }
                InfoCard(Modifier.fillMaxWidth(), tint = MaterialTheme.colorScheme.surface) {
                    Text("Na receita (${number(result.sellableYield)} $yieldUnit)", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    ResultRow("Custo", money(result.totalCostCents))
                    ResultRow("Faturamento", money(revenueTotal))
                    ResultRow("Lucro", money(profitTotal), true)
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoCard(Modifier.weight(1f), tint = MaterialTheme.colorScheme.surface) {
                    Text("Por unidade", fontWeight = FontWeight.Bold)
                    ResultRow("Custo", money(result.costPerUnitCents))
                    ResultRow("Venda", money(result.salePriceCents))
                    ResultRow("Lucro", money(result.profitPerUnitCents), true)
                }
                InfoCard(Modifier.weight(1f), tint = MaterialTheme.colorScheme.surface) {
                    Text("Na receita (${number(result.sellableYield)} $yieldUnit)", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    ResultRow("Custo", money(result.totalCostCents))
                    ResultRow("Faturamento", money(revenueTotal))
                    ResultRow("Lucro", money(profitTotal), true)
                }
            }
        }
    }
}

private data class PriceCompositionSegment(val label: String, val cents: Double, val color: Color)

@Composable
private fun PriceCompositionCard(
    item: RecipeWithDetails,
    catalog: List<IngredientEntity>,
    result: br.com.lucroexato.domain.CostResult
) {
    if (result.salePriceCents <= 0 || result.profitPerUnitExactCents < 0) {
        InfoCard(tint = YellowSoft) {
            Text("Composição do preço", fontWeight = FontWeight.Bold)
            Text("O preço testado não cobre todos os custos. Aumente o preço para visualizar a composição.", style = MaterialTheme.typography.bodySmall)
        }
        return
    }

    val byId = catalog.associateBy { it.id }
    val packagingSupplyCents = item.ingredients.filter { used ->
        val category = used.ingredientId?.let { byId[it]?.category }.orEmpty()
        val name = used.nameSnapshot.lowercase()
        category.contains("embal", ignoreCase = true) ||
            listOf("embal", "saquinho", "saco", "caixa", "adesivo", "etiqueta", "fecho", "lacre", "fitilho", "fita").any { name.contains(it) }
    }.sumOf { it.costExactCents ?: it.costCents.toDouble() }
    val regularIngredientCents = (result.ingredientsCents.toDouble() - packagingSupplyCents).coerceAtLeast(0.0)
    val y = result.sellableYield.coerceAtLeast(0.000001)
    val segments = listOf(
        PriceCompositionSegment("Lucro", result.profitPerUnitExactCents.coerceAtLeast(0.0), Green),
        PriceCompositionSegment("Ingredientes", regularIngredientCents / y, Pink),
        PriceCompositionSegment("Embalagem", (packagingSupplyCents + result.packagingCents.toDouble()) / y, Color(0xFF8E7CC3)),
        PriceCompositionSegment("Mão de obra", result.laborCents.toDouble() / y, Color(0xFFF4A261)),
        PriceCompositionSegment("Outros", result.extrasCents.toDouble() / y, Color(0xFF7AA6E8)),
        PriceCompositionSegment("Taxas", result.feeExactCents.coerceAtLeast(0.0), Color(0xFF5A7DDE))
    ).filter { it.cents > 0.004 }

    InfoCard(tint = MaterialTheme.colorScheme.surface) {
        Text("Composição do preço", fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    val total = result.salePriceCents.toDouble().coerceAtLeast(1.0)
                    var start = -90f
                    val stroke = size.minDimension * 0.18f
                    segments.forEach { segment ->
                        val sweep = (segment.cents / total * 360.0).toFloat().coerceAtLeast(0f)
                        if (sweep > 0f) {
                            drawArc(
                                color = segment.color,
                                startAngle = start,
                                sweepAngle = sweep,
                                useCenter = false,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke)
                            )
                            start += sweep
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(money(result.salePriceCents), fontWeight = FontWeight.Bold)
                    Text("por unidade", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                segments.forEach { segment ->
                    val pct = segment.cents * 100.0 / result.salePriceCents.toDouble()
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(segment.color, androidx.compose.foundation.shape.CircleShape))
                        Text(segment.label, Modifier.weight(1f).padding(start = 6.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${percent(pct)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun IngredientDetailScreen(modifier: Modifier, vm: AppViewModel, ingredientId: Long, onBack: () -> Unit) {
    val catalog by vm.ingredients.collectAsStateWithLifecycle()
    val existing = catalog.firstOrNull { it.id == ingredientId }
    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var category by remember(existing) { mutableStateOf(existing?.category ?: "Outros") }
    var price by remember(existing) { mutableStateOf(existing?.packagePriceCents?.let(::moneyInput) ?: "") }
    var quantity by remember(existing) { mutableStateOf(existing?.packageQuantity?.let { number(it) } ?: "") }
    var unit by remember(existing) { mutableStateOf(existing?.packageUnit ?: "kg") }
    var history by remember { mutableStateOf<List<IngredientPriceEntity>>(emptyList()) }
    LaunchedEffect(existing?.id) { if (existing != null) history = vm.priceHistory(existing.id) }

    LazyColumn(modifier.fillMaxSize().imePadding(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { CompactTopBar(if (existing == null) "Novo insumo" else existing.name, onBack) }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), shape = AppFieldShape, label = { Text("Nome do insumo *", maxLines = 1) }, singleLine = true)
                SelectionField(category, SupplyCategories, "Categoria *", Modifier.fillMaxWidth()) { selectedCategory ->
                    category = selectedCategory
                    if (selectedCategory == "Embalagens" && existing == null) unit = "un"
                }
                SmartNumberField(price, { price = it }, "Preço pago *", Modifier.fillMaxWidth(), prefix = "R$ ")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmartNumberField(quantity, { quantity = it }, "Qtd. comprada *", Modifier.weight(1f))
                    SelectionField(unit, listOf("kg", "g", "mg", "l", "ml", "un"), "Unidade", Modifier.weight(0.62f)) { unit = it }
                }
                existing?.let { current ->
                    if (current.referenceMinCentsPerBase != null && current.referenceMaxCentsPerBase != null) {
                        InfoCard(tint = BlueSoft) { Text("Preço de referência", fontWeight = FontWeight.SemiBold); Text("${money(current.referenceMinCentsPerBase)} – ${money(current.referenceMaxCentsPerBase)} por kg"); Text("Use seu preço real sempre que souber.", style = MaterialTheme.typography.bodySmall) }
                    }
                }
                Button(onClick = {
                    val cents = parseMoneyCents(price); val qty = parseDecimal(quantity)
                    if (name.isNotBlank() && category.isNotBlank() && cents != null && cents > 0 && qty != null && qty > 0) {
                        vm.saveIngredient(
                            IngredientEntity(id = existing?.id ?: 0, name = name.trim(), category = category.trim(), packagePriceCents = cents, packageQuantity = qty, packageUnit = unit, referenceMinCentsPerBase = existing?.referenceMinCentsPerBase, referenceMaxCentsPerBase = existing?.referenceMaxCentsPerBase, isBuiltIn = existing?.isBuiltIn ?: false),
                            onSaved = onBack
                        )
                    }
                }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = AppButtonShape) { Text(if (existing == null) "Adicionar insumo" else "Salvar alterações", maxLines = 1) }
            }
        }
        if (history.isNotEmpty()) {
            item { Box(Modifier.padding(horizontal = 16.dp)) { SectionTitle("Histórico de preços", "Seus últimos valores") } }
            items(history.take(10)) { item ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.recordedAt)), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${money(item.priceCents)} / ${number(item.packageQuantity)} ${item.packageUnit}", fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

private fun recipeCountText(count: Int): String = if (count == 1) "1 receita" else "$count receitas"

private fun hasPackagingSupply(item: RecipeWithDetails, catalog: List<IngredientEntity>): Boolean {
    if (item.recipe.packagingPerUnitCents > 0L) return true
    val byId = catalog.associateBy { it.id }
    return item.ingredients.any { used ->
        val category = used.ingredientId?.let { byId[it]?.category }.orEmpty()
        val name = used.nameSnapshot.lowercase()
        category.contains("embal", ignoreCase = true) ||
            listOf("embal", "saquinho", "saco", "caixa", "adesivo", "etiqueta", "fecho", "lacre", "fitilho", "fita").any { name.contains(it) }
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    background: Color,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Card(
        modifier.heightIn(min = 72.dp),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = background),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun ResultRow(label: String, value: String, strong: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontWeight = if (strong) FontWeight.Bold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.size(8.dp))
        Text(value, fontWeight = if (strong) FontWeight.Bold else FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

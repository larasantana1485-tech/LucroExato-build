# Lucro Exato 0.1.15 R16

R16 mantém as três mudanças fechadas em 25/09/2026 e corrige o comportamento do resumo fixo da Ficha Técnica para reproduzir a sensação do mockup interativo 2, sem empurrar ou travar a rolagem.

## Mudanças principais
- **Rendimento e escala:** quantidade desejada vira o controle principal; atalhos × continuam; custo estimado e 3 quantidades são atualizados imediatamente; lista completa abre em tela própria.
- **Etapa 4:** agora é uma tela simples de resultado com custo, rendimento, preço inicial sugerido por margem de referência de 50%, faturamento e lucro. Margem/Markup interativos ficam na Ficha Técnica.
- **Ficha Técnica:** ao rolar além de “Preço e lucro”, uma faixa compacta mantém Custo, Venda e Margem visíveis; as sanfonas continuam.
- **Inicialização:** Home aguarda o snapshot final recalculado e o recálculo ocorre numa transação única para eliminar a piscada com totais antigos.

O `CostCalculator` e o ícone oficial não foram alterados.


## Correção R16
- Corrige erro de compilação Kotlin no `padding` do resumo sticky (`horizontal` + `top` não pertencem à mesma sobrecarga).
- Nenhuma alteração de cálculo ou comportamento planejado da R15.

package br.com.lucroexato.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Percent
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.com.lucroexato.BuildConfig
import br.com.lucroexato.ui.theme.Outline
import br.com.lucroexato.ui.theme.Pink
import androidx.compose.ui.graphics.Color

@Composable
fun SettingsScreen(modifier: Modifier, vm: AppViewModel, onBack: () -> Unit) {
    val savedMode by vm.defaultPricingMode.collectAsStateWithLifecycle()
    val savedTarget by vm.defaultTarget.collectAsStateWithLifecycle()
    var pricingMode by remember(savedMode) { mutableStateOf(savedMode) }
    var target by remember(savedTarget) { mutableStateOf(number(savedTarget)) }
    var helpDialog by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if (uri != null) vm.exportBackup(uri) }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) pendingRestore = uri }

    LazyColumn(modifier.fillMaxSize().imePadding(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { CompactTopBar("Configurações", onBack) }
        item {
            BoxedSection("Backup e restauração", "Suas receitas e insumos ficam no aparelho.") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { export.launch("LucroExato_backup.json") }, modifier = Modifier.weight(1f).height(46.dp), shape = AppButtonShape) {
                        Icon(Icons.Outlined.Backup, null); Text("Salvar", maxLines = 1)
                    }
                    OutlinedButton(onClick = { restore.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.weight(1f).height(46.dp), shape = AppButtonShape) {
                        Icon(Icons.Outlined.Restore, null); Text("Restaurar", maxLines = 1)
                    }
                }
            }
        }
        item {
            BoxedSection("Preferências de precificação", "Usadas como padrão somente em novas receitas.") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(pricingMode == "MARGIN", { pricingMode = "MARGIN" }, label = { Text("Margem", maxLines = 1) }, shape = AppPillShape)
                    FilterChip(pricingMode == "MARKUP", { pricingMode = "MARKUP" }, label = { Text("Markup", maxLines = 1) }, shape = AppPillShape)
                }
                SmartNumberField(target, { target = it }, "Percentual padrão", Modifier.fillMaxWidth(), suffix = "%")
                OutlinedButton(onClick = { vm.saveDefaultPricing(pricingMode, parseDecimal(target) ?: 50.0) }, modifier = Modifier.fillMaxWidth(), shape = AppButtonShape) { Text("Salvar preferência", maxLines = 1) }
            }
        }
        item {
            BoxedSection("Preços de referência", null) {
                Text("Quando houver uma faixa de mercado cadastrada, ela aparece apenas como apoio. O preço que você realmente pagou sempre tem prioridade.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Card(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Outline),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                ListItem(
                    headlineContent = { Text("Ver mini tutorial", maxLines = 1) },
                    supportingContent = { Text("Três telas rápidas sobre o uso do app", maxLines = 1) },
                    leadingContent = { Icon(Icons.Outlined.School, null) },
                    modifier = Modifier.fillMaxWidth().appClickable(AppPillShape) { vm.reopenTutorial() }
                )
                ListItem(
                    headlineContent = { Text("Ajuda sobre os cálculos", maxLines = 1) },
                    supportingContent = { Text("Margem, markup, perdas e custos", maxLines = 1) },
                    leadingContent = { Icon(Icons.Outlined.HelpOutline, null) },
                    modifier = Modifier.fillMaxWidth().appClickable(AppPillShape) { helpDialog = true }
                )
                ListItem(
                    headlineContent = { Text("Sobre o aplicativo", maxLines = 1) },
                    supportingContent = { Text("Versão ${BuildConfig.VERSION_NAME} • build ${BuildConfig.VERSION_CODE}", maxLines = 1) },
                    leadingContent = { Icon(Icons.Outlined.Info, null) }
                )
            }
        }
        item {
            Card(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                shape = AppCardShape,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color(0xFFF0B8C8)),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                ListItem(
                    headlineContent = { Text("Redefinir aplicativo", color = Pink, fontWeight = FontWeight.SemiBold) },
                    supportingContent = { Text("Apaga receitas e alterações e volta ao estado inicial.", maxLines = 2) },
                    leadingContent = { Icon(Icons.Outlined.DeleteOutline, null, tint = Pink) },
                    modifier = Modifier.fillMaxWidth().appClickable(AppPillShape) { confirmReset = true }
                )
            }
        }
    }

    pendingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            shape = AppCardShape,
            title = { Text("Restaurar este backup?") },
            text = { Text("As receitas e os insumos atuais serão substituídos pelos dados do arquivo escolhido.") },
            confirmButton = { TextButton(onClick = { vm.importBackup(uri); pendingRestore = null }) { Text("Restaurar") } },
            dismissButton = { TextButton(onClick = { pendingRestore = null }) { Text("Cancelar") } }
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 0.dp,
            shape = AppCardShape,
            title = { Text("Redefinir o Lucro Exato?") },
            text = {
                Text("Receitas, alterações no catálogo, históricos de preço, rascunhos e preferências serão apagados. O catálogo padrão será restaurado e o tutorial inicial voltará a aparecer. Faça um backup antes se quiser guardar seus dados.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    vm.resetApplication()
                }) { Text("Redefinir", color = Pink, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancelar") } }
        )
    }

    if (helpDialog) CalculationHelpDialog { helpDialog = false }
}

@Composable
private fun CalculationHelpDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = MaterialTheme.colorScheme.background) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = { CompactTopBar("Como o Lucro Exato calcula", onDismiss) }
            ) { inner ->
                Column(
                    Modifier.padding(inner).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HelpFormulaCard(Icons.Outlined.Calculate, "Custo usado", "Preço pago × quantidade usada ÷ quantidade total.")
                    HelpFormulaCard(Icons.Outlined.Calculate, "Custo por unidade", "Custo total da produção ÷ rendimento vendável.")
                    HelpFormulaCard(Icons.Outlined.Percent, "Margem", "Mostra quanto do preço de venda sobra depois de custos e taxas.")
                    HelpFormulaCard(Icons.Outlined.TrendingUp, "Markup", "Mostra quanto o preço de venda foi acrescido sobre o custo.")
                    HelpFormulaCard(Icons.Outlined.Info, "Perdas", "Reduzem o rendimento vendável e aumentam o custo de cada unidade.")
                    Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth().height(48.dp), shape = AppButtonShape) { Text("Entendi") }
                }
            }
        }
    }
}

@Composable
private fun HelpFormulaCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, text: String) {
    Card(
        Modifier.fillMaxWidth(),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, tint = Pink)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(text, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun BoxedSection(title: String, subtitle: String?, content: @Composable () -> Unit) {
    Card(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
        shape = AppCardShape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Outline),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall)
            content()
        }
    }
}

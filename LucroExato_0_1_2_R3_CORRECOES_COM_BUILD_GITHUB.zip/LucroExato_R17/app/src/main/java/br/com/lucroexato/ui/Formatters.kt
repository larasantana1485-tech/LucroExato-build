package br.com.lucroexato.ui

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.NumberFormat
import java.util.Locale

private val br = Locale.forLanguageTag("pt-BR")
private val currency = NumberFormat.getCurrencyInstance(br)
private val symbols = DecimalFormatSymbols(br)

fun money(cents: Long): String = currency.format(cents / 100.0)
fun moneyInput(cents: Long): String = String.format(br, "%.2f", cents / 100.0)

/**
 * Exibe até [maxDecimals] casas, mas nunca acrescenta ",0" a um inteiro.
 * Ex.: 24.0 -> "24"; 1.5 -> "1,5"; 0.125 -> "0,125".
 */
fun number(value: Double, maxDecimals: Int = 3): String {
    if (!value.isFinite()) return "0"
    val pattern = buildString {
        append("0")
        if (maxDecimals > 0) {
            append(".")
            repeat(maxDecimals) { append("#") }
        }
    }
    return DecimalFormat(pattern, symbols).apply {
        roundingMode = RoundingMode.HALF_UP
        isGroupingUsed = false
    }.format(value)
}

fun percent(value: Double): String = number(value, 1)

/**
 * Aceita vírgula ou ponto como separador decimal sem tratar ponto simples como milhar.
 * Também entende texto colado com R$ e separadores de milhar brasileiros/americanos.
 */
fun parseDecimal(text: String): Double? {
    val raw = text.trim()
        .replace("R$", "", ignoreCase = true)
        .replace(" ", "")
        .replace("\u00A0", "")
    if (raw.isBlank()) return null

    val comma = raw.lastIndexOf(',')
    val dot = raw.lastIndexOf('.')
    val normalized = when {
        comma >= 0 && dot >= 0 -> {
            // O separador que aparece por último é o decimal; o outro é de milhar.
            if (comma > dot) raw.replace(".", "").replace(',', '.')
            else raw.replace(",", "")
        }
        comma >= 0 -> raw.replace(',', '.')
        else -> raw // ponto único é decimal: 1.5 continua 1.5
    }
    return normalized.toDoubleOrNull()?.takeIf { it.isFinite() }
}

fun parseMoneyCents(text: String): Long? = parseDecimal(text)?.let { value ->
    if (value < 0) return null
    runCatching {
        BigDecimal.valueOf(value)
            .movePointRight(2)
            .setScale(0, RoundingMode.HALF_UP)
            .longValueExact()
    }.getOrNull()
}

/** Mantém só dígitos e um separador decimal; ponto digitado vira vírgula. */
fun sanitizeNumericInput(text: String, integerOnly: Boolean): String {
    val out = StringBuilder()
    var decimalSeen = false
    for (ch in text) {
        when {
            ch.isDigit() -> out.append(ch)
            !integerOnly && (ch == ',' || ch == '.') && !decimalSeen -> {
                if (out.isEmpty()) out.append('0')
                out.append(',')
                decimalSeen = true
            }
            ch.isWhitespace() -> Unit
            else -> break // não transforma "1+2" em "12"
        }
    }
    return out.toString()
}

fun purchaseRelationText(priceInput: String, quantityInput: String, unit: String): String? {
    val cents = parseMoneyCents(priceInput) ?: return null
    val quantity = parseDecimal(quantityInput) ?: return null
    if (cents <= 0L || quantity <= 0.0) return null
    return "${money(cents)} por ${number(quantity)} $unit"
}

# R17 — nomenclatura de insumos, ações da Home e estados de interação

Implementado sobre a R16 (0.1.15-r16), sem alteração do motor matemático.

## 1. Compra de insumos
- `Qtd. comprada` foi substituído por `Quantidade total`.
- `Qtd. total usada` foi substituído por `Quantidade usada`.
- A tela passa a mostrar a relação de compra em linguagem natural, por exemplo: `R$ 6,49 por 395 g`.
- Mensagens de validação, tutorial e ajuda foram alinhadas à nova nomenclatura.
- Fórmula preservada: preço pago ÷ quantidade total × quantidade usada.

## 2. Home — gerenciamento de receita
- Card continua abrindo a ficha técnica no toque normal.
- Menu discreto `⋮` no card com `Editar receita` e `Excluir receita`.
- Exclusão exige confirmação e usa tratamento já existente para receitas usadas como sub-receita.
- Não foi adicionada função de duplicar receita.

## 3. Ficha técnica
- Removido completamente o resumo sticky `Custo / Venda / Margem` que surgia durante a rolagem.
- Valores continuam disponíveis apenas na seção `Preço e lucro`.

## 4. Estados visuais de interação
- Criado `appClickable(shape, ...)` para recortar o feedback de toque à forma real do componente.
- Cards, pills, tabs, seletores, linhas clicáveis e acordes customizados foram migrados para feedback limitado ao próprio shape.
- Pills/chips usam shape explícito e consistente.
- Área clicável pode continuar acessível sem revelar um retângulo de seleção fora do design.

## Versão
- versionCode: 17
- versionName: 0.1.16-r17

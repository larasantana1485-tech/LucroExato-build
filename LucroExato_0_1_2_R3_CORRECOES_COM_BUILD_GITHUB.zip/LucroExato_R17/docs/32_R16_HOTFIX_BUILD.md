# R16 — hotfix de compilação

O GitHub Actions da R15 falhou em `RecipeDetailOfficial.kt:558` porque Compose não possui uma sobrecarga de `Modifier.padding` que aceite simultaneamente `horizontal` e `top`.

Correção aplicada:

- antes: `padding(horizontal = 16.dp, top = 6.dp)`
- agora: `padding(start = 16.dp, top = 6.dp, end = 16.dp)`

Não há mudança de lógica, cálculo ou design pretendido; apenas correção sintática para compilação.
